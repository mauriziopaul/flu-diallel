/* ========================================================================== */
/*                                                                            */
/*   AcppConfigureMe.h                                                        */
/*   (c) 2014 Alan Lenarcic                                                   */
/*                                                                            */
/*   If "PCKGNAME" is set, Acpp should be able to anonymously place lists     */
/*       in target                                                            */
/*                                                                            */
/* ========================================================================== */

#ifndef PCKGNAME
  //#define PCKGNAME "AcppTest"
  #define PCKGNAME "BayesSpike"
#endif
