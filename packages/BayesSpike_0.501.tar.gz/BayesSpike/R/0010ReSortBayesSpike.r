

####################################################################################
##  ZeroOutFunction()
##
##   When p is large, this chooses a sparse subset of coordinates to start 
##  the sampler chains based upon one draw of MBX$SampleNewTaus() and MBS$SampleBFixed()
##  which fill the ProbTau and ProbFixed Vectors respectively
##
ZeroOutFunction <- function(MBS) {

print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
print("$$ ZeroOutFunction"); flush.console();
print("$$ Hey: MBS$ is large before a sample we are going to blank up and sample small");
flush.console();
MBS$DoAddCoordsOnSetBeta <- 0;
RfFlag <- MBS$RefreshBeta(rep(0,MBS$p));
MyTryProbs <- NULL;
MyTryProbTau <- NULL;  MyTryProbFixed <- NULL;
if (MBS$TBSR5$OnChainIter >= 2) {
  try(MyTryProbs <- MBS$ProbVector);
  if (!is.null(MyTryProbs)) {
    if (is.null(MBS$tauEndList)) {
      MyTryProbFixed <- log(MyTryProbs/(1.0-MyTryProbs));  
      MyTryProbFixed[(MyTryProbFixed > 0 & !is.finite(MyTryProbFixed)) | MyTryProbs == 1.0] <- 4;
      MyTryProbFixed[(MyTryProbFixed < 0 & !is.finite(MyTryProbFixed)) | MyTryProbs == 0.0] <- -4;
    } else if (MBS$FirstRandom > 1 && MBS$FirstRandom <= MBS$p) {
      MyTryProbFixed <- log(MyTryProbs[1:MBS$iFirstRandom]/(1.0-MyTryProbs[1:MBS$iFirstRandom]))
      MyTryProbFixed[(MyTryProbFixed > 0 & !is.finite(MyTryProbFixed)) | MyTryProbs[1:MBS$iFirstRandom] == 1.0] <- 4;
      MyTryProbFixed[(MyTryProbFixed < 0 & !is.finite(MyTryProbFixed)) | MyTryProbs[1:MBS$iFirstRandom] == 0.0] <- -4;
    }
    if (!is.null(MBS$tauEndList)) {
      MyTryProbTau <- log(MyTryProbs[MBS$FirstRandom:length(MyTryProbs)] /
        (1.0 - MyTryProbs[MBS$FirstRandom:length(MyTryProbs)]));
      MyTryProbTau[(MyTryProbTau > 0 & !is.finite(MyTryProbTau)) | 
        MyTryProbs[MBS$FirstRandom:length(MyTryProbs)] >= 1.0] <- 4;
      MyTryProbTau[(MyTryProbTau < 0 & !is.finite(MyTryProbTau)) |
        MyTryProbs[MBS$FirstRandom:length(MyTryProbs)]  <= 0.0] <- -4;
    }
  }  
} else {
  if (length(MBS$SigmaPrior) >= 2 && MBS$SigmaPrior[2] > 0) {
    try(MBS$OnSigma <- 1.5*MBS$SigmaPrior[2])
  }
}
try(MBS$BlankAllNewCoords());
  if (length(MBS$tauEndList) >= 1) {
    if (!is.null(MyTryProbTau)) {
      MyProb <- MyTryProbTau;
    } else {
      MBS$SampleTausOnly <- 1;
      MBS$SampleNewTaus();
      MyProb <- MBS$ProbTau;
    }
    if (MBS$FirstRandom >= MBS$p) {
      print(paste("$$ ZeroOutFunction: ERROR ERROR ERROR, FirstRandom = ", MBS$FirstRandom, sep=""));
      flush.console();
      print("ERRORERRORERRORERRORERRORERRORERROR"); flush.console();
      MyT = "1 = 2";
      eval(parse(text=MyT));
      return(-1);
    }
    GoTau  <- MBS$OnTau;
    print(paste("$$ ZeroOutFunction: We sample Taus and the number of nonzero are ", length(GoTau[GoTau>0]),
     "/", length(GoTau), sep="")); flush.console();
    Fac = 1;
    if (length(MBS$tauEndList) >= 2)   {
      TauLens <- MBS$tauEndList[2:length(MBS$tauEndList)] -
        MBS$tauEndList[1:(length(MBS$tauEndList)-1)];
      TauLens <- c(TauLens, MBS$tauEndList- MBS$FirstRandom+1);
      Fac <- floor(mean(TauLens));
    } else if (length(MBS$tauEndList) == 1) {
      Fac <- MBS$tauEndList[1] - MBS$FirstRandom+1;
    }
    OnPiAT = MBS$OnPiA[1];
    if (length(MBS$OnPiA) == 2) { OnPiAT <- MBS$OnPiA[2]; }
    KeepCount <- round(5*length(GoTau)  * OnPiAT);
    if (KeepCount >= .5 * length(GoTau)) { KeepCount = round(.5* length(GoTau)); }
    if (KeepCount >= length(GoTau[GoTau>0])) { KeepCount <- length(GoTau[GoTau>0]); }
    if (KeepCount <= 5) { KeepCount = 5; } 
    if (KeepCount > length(MBS$tauEndList)) {
      KeepCount <- length(MBS$tauEndList);
    }    
    if (KeepCount < length(GoTau[GoTau>0])) {
      Expt <- GiveMeNewBalance(lX=MyProb/2.0, WantTot = KeepCount, StartMove=1.0, MaxTTs = 300);
      if (length(Expt[Expt > 0]) < KeepCount) {
        KeepCount <- length(Expt[Expt > 0]);
      }
      print(paste("$$ after calculating Expt we have its sum is ", round(sum(Expt),4),
        "/", length(Expt), sep="")); flush.console();
      Keepers <- sample(1:length(GoTau), prob=Expt, replace=FALSE, size=KeepCount);
      print(paste("$$ Now we reduce active set to length(Keepers) = ", length(Keepers), sep=""));
      flush.console();
      DoTau <- rep(0, length(GoTau));
      DoTau[Keepers] <- GoTau[Keepers];
      try(MBS$DoAddCoordsOnSetBeta <- 0);
      try(MBS$BlankAllNewCoords());
      print(paste("AssignTau: about to Assign ")); flush.console();
      try(MBS$AssignTau(DoTau));
      print(paste("$$ Reduced DoTau length(Keepers) = ", length(Keepers), " is added", sep=""));
      print(paste("$$ After AssignTau, AllNewCoords = ", MBS$AllNewCoords, sep="")); flush.console();
      flush.console();
    } else {
      print(paste("$$ KeepCount = ", KeepCount, " but length(GoTau) = ",
        length(GoTau[GoTau>0]), "/", length(GoTau), " so no change.", sep=""));
      flush.console(); 
      if (length(GoTau[GoTau > 0]) <= KeepCount) {
        MyG <- sort(MyProb, decreasing=TRUE, index=TRUE)$ix[1:KeepCount];
        DG <- GoTau[MyG];
        DG[DG == 0.0] <- MBS$tauPriorMean
        GoTau[MyG] <- DG;
      } else {
        Keepers <- 1:length(GoTau);
      }
      try(MBS$BlankAllNewCoords());
      print(paste("$$ Now Assigning Tau to GoTau")); flush.console();
      MBS$AssignTau(GoTau);
      print(paste("$$ After AssigningTau to GoTau length ", length(GoTau), " we ",
        " have AllNewCoords = ", MBS$AllNewCoords, sep=""));
      flush.console();
    }
  }
  print("$$ Well Looking into the length of MBS$tauEndList"); flush.console();
  if (length(MBS$tauEndList) >= 1) {
    AllRandomCoords <- MBS$AllNewCoords;
  } else {
    AllRandomCoords <- NULL;
  }
  if((MBS$FirstRandom > 1 && MBS$FirstRandom <= MBS$p) || length(MBS$tauEndList) <= 0) {
      if (length(MBS$tauEndList) == 0) {   pF = MBS$p;  
      } else { pF <- MBS$FirstRandom-1;}
      if (!is.null(MyTryProbFixed)) {
        BProbs <- MyTryProbFixed;
        if (Verbose >= 1) {
          print(paste("$$ ZeroOutFunction(): Probability of Historical fixed variables ",
            "has Historical MIPS summing to ", round(sum(dLogit(BProbs)),4), "/", pF, sep=""));
         flush.console();
        }
      } else {
        MBS$SampleTausOnly <- 1;
        print(paste("$$  ZeroOutFunction() : We're refreshing fixed effects. ")); flush.console();
        MBS$SampleFixedB();
        print(paste("$$ Now to SampleTausOnly")); flush.console();
        MBS$SampleTausOnly <- 0;
        BProbs <- MBS$ProbFixed;
        if (Verbose >= 1) {
          print(paste("$$ ZeroOutFunction() : MIPs taken from MBS SampleFixedB()", 
            round(sum(dLogit(BProbs)),4), "/", pF, sep=""));
          flush.console();
        }
      }     
      
      OnPiAF <- MBS$OnPiA[1];
      KeepCount <- round(25*pF * OnPiAF);
      if (KeepCount <= 0) { KeepCount = 1; }
      if (KeepCount > pF) { KeepCount <- pF; }
      
      eBProbs <- GiveMeNewBalance(lX=BProbs/2.0, WantTot = KeepCount, StartMove=1.0, MaxTTs = 300);
      if (length(eBProbs[eBProbs > 0])  < KeepCount) {
        KeepCount <- length(eBProbs[eBProbs > 0]); 
      }                                                   
      if (Verbose >= 1) {
        print("$$ ZeroOutFunction() Sampling Keepers.");
      }
      Keepers <- sample(1:pF, prob=eBProbs, replace=FALSE, size=KeepCount);
      DKeepers <- (1:pF)[!(( 1:pF)  %in% Keepers )]; 
      print(paste("$$  We have chosen to eliminate a count of Keepers ", length(DKeepers)));
      flush.console();
      if (MBS$FirstRandom <= 0 || is.null(MBS$tauEndList) || length(MBS$tauEndList) <= 0) {
        ABeta <- MBS$Beta;
        ABeta[MBS$Beta == 0.0 && MBS$BFixed >= 1] <- 1;
      } else if (MBS$FirstRandom > 1 && MBS$FirstRandom <= MBS$p) {
        ABeta <- c(rep(1, MBS$FirstRandom-1), rep(0, MBS$p- MBS$FirstRandom+1)) * MBS$Beta;
        ABeta[(1:length(MBS$BFixed))[MBS$Beta == 0.0 && MBS$BFixed >= 1]] <- 1;
      }
      
      if (length(DKeepers) > 0) {
        ABeta[DKeepers] <- 0.0;
      }
      try(MBS$DoAddCoordsOnSetBeta <- 0);
     
      try(MBS$RefreshBeta(ABeta));
      ##try(MBS$SetAllNewCoords(length(AllRandomCoords)+length(Keepers), length(Keepers)));
    }
    print("About to Count All New Coords() "); flush.console();
    try(MBS$CountAllNewCoords());
    print(paste("$$  Adding initially ", MBS$AllNewCoords, "/", MBS$p, " new coords, maximum allotment is ",
      MBS$MaximumAllocation, ", OnKappaMem = ",  MBS$OnKappaMem, sep=""));  flush.console();
    print(paste("$$ length(MBS$Beta[MBS$Beta != 0.0]) == ", 
      length(MBS$Beta[MBS$Beta != 0.0]), sep="")); flush.console();
    print(paste("$$  Resizing now to run one regression and hopefully eliminate noise variables. ", sep=""));
    flush.console();
    try(MBS$AddAllNewCoords());
    print(paste("$$ We have AllNewCoords added, OnKappaS = ", MBS$OnKappaS, 
      ", OnKappaMem = ", MBS$OnKappaMem, ", NumActive = ", MBS$NumActive, sep=""));   flush.console();
    print(paste("$$ Now we Refresh OrderedActive")); flush.console();
    try(AGo <- NULL);
    try(AGo <- MBS$RefreshOrderedActive(1));
    print(paste("$$  Refreshing XtResid. ")); flush.console();
    if (MBS$dfRobit > 0) {
      MBS$RobitReplace();
    } else if (MBS$dfTNoise > 0) {
      MBS$UpdateTNoise();
    } else {
      MBS$UpdateFreshXtResid();
    }
    try(print(paste("$$  UpdateFreshXtResid conducted, p length is ", MBS$OnKappaS, " Our Test is: ", sep=""))); flush.console();
    ATestCount <- NULL;
    BackVerbose <- MBS$Verbose;
    ##MBS$Verbose = 4;
    try(ATestCount <- MBS$TestXtResid());
    MBS$Verbose <- BackVerbose;
    try(print(paste("$$ Test For XtResid is ", ATestCount, sep=""))); flush.console();
    if (!is.null(ATestCount) && ATestCount > 0)  {
      print("$$ 0010ReSortBayesSpike.r:::WE Quit"); flush.console();
      print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
      eval(parse(text=SetGText("MBS", "globalenv()", S=1)));
      return(-1);
    }

    if (is.null(AGo) || (is.numeric(AGo) && AGo < 0)) {
      print("$$ Resample AGo, we failed to RefreshOrderedActive, this is a bad result, no regressions"); flush.console();
      return(-1);
    }
    try(MBS$PrepareForRegression()); 
    print(paste("$$  Now sampling PropBeta which will have length ", MBS$NumActive, sep=""));
    try(MBS$SamplePropBeta());
    CNBeta <- MBS$PropBeta[abs(MBS$PropBeta) > 999999]
    if (any(is.nan(MBS$PropBeta)) || length(CNBeta) >= 1) {
      print(paste("$$ CNBeta has errors in PropBeta, please new work.  Triggering an error", sep="")); flush.console();
      -1 <- 2;
    }
    try(print("$$ About to FillsBetaFromPropBetaAndCompute() ")); flush.console();
    try(MBS$FillsBetaFromPropBetaAndCompute()); 
    try(print("$$ About to UpdateSigma() ")); flush.console();
    try(MBS$UpdateSigma()); 
    try(print(paste("$$ ZeroOut Sampler, predictability after this is var(Y) = ",
      round(var(MBS$Y),6), " and YResid Squared is ", round(MBS$YResidSq,6), 
      " so Sigma = ", MBS$OnSigma, sep=""))); flush.console();
    print(paste("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$", sep=""));
    flush.console();
    return(1);
}

dLogit <- function(lX) {
  NI <- exp(lX) / (1.0+exp(lX));
  NI[lX < -10] = exp(-abs(lX[lX < -10]));
  NI[lX > 10] = 1.0 - exp(-abs(lX[lX > 10]));
  return(NI);
}
##  GiveMeNewBalance: Helper function
##
##  Let lX be a real vector
##    We are looking for a vector LB = exp(lX + alpha) / (1.0 + exp(lX+alpha))
##     for some alpha such that  sum(LB) = WantTot
##
GiveMeNewBalance <- function(lX, WantTot = 1, StartMove = 1, MaxTTs = 300, epsilon = .00001) {
  if (WantTot <= 0) {
    print(paste("Error:GiveMeNewBalance, does not work if WantTot=", WantTot, sep=""));
    return(-1);
  }
  if (length(lX) < WantTot) {
    print(paste("Error:GiveMeNeBalance, there are only ", length(lX),
      "members of lX not good enough to make ", WantTot, sep=""));
  }
  alphaOld = 0;
  AG <- dLogit(lX);
  if (length(AG[AG >= 1.0]) >= WantTot) {
    print(paste("GiveMeNewBalance, cannot be corrected, there are already ",
      " length(AG[AG >= 1.0]) = ",
      length(AG[AG >= 1.0]), " non zero, sample a subset then already!",
      sep="")); 
      flush.console();
    return(dLogit(lX));
  }
  if (length(AG[AG <= 0.0]) >= length(lX) - WantTot) {
    print(paste("GiveMeNewBalance, cannot be corrected, there are already ",
      "length(AG[AG <= 0.0]) = ",
      length(AG[AG <= 0.0]), " are zero, be happy its small!",
      sep="")); 
      flush.console();
    return(dLogit(lX));
  }
  LBOld <- sum(dLogit(lX));
  if (LBOld > WantTot) { StartMove = -1.0 *abs(StartMove) }
  alphaNew = alphaOld + StartMove;
  LBNew <- sum(dLogit(lX+alphaNew));
  tt = 0;
  if (LBNew > WantTot && LBOld > WantTot) {
    while(LBNew > WantTot && tt < MaxTTs) {
      alphaNew = alphaNew - abs(StartMove);
      LBNew <- sum(dLogit(lX+alphaNew)); tt <- tt+1;
      if (tt >= MaxTTs) {
        print(paste("GiveMeNewBalance, cannot succeed, tt = ", tt, 
          " and WantTot = ", WantTot, sep=""));  flush.console();
        return(-1);
      }
    }
    if (LBNew > WantTot) {
      print(paste("Error: GiveMeNewBalance in 300 moves we could not make WantTot = ",
        WantTot, " for LBNew = ", LBNew, " for alphaNew = ", alphaNew, sep=""));
      flush.console();  return(-1);
    }
  } else if (LBNew < WantTot && LBOld < WantTot) {
    while(LBNew < WantTot && tt < MaxTTs) {
      alphaNew = alphaNew + abs(StartMove);
      LBNew <- sum(dLogit(lX+alphaNew)); tt <- tt+1;
      if (tt >= MaxTTs) {
        print(paste("GiveMeNewBalance, cannot succeed, tt = ", tt, 
          " and WantTot = ", WantTot, sep=""));  flush.console();
        return(-1);
      }
    }
    if (LBNew < WantTot) {
      print(paste("Error: GiveMeNewBalance in 300 moves we could not make large WantTot = ",
        WantTot, " for LBNew = ", LBNew, " for alphaNew = ", alphaNew, sep=""));
      print(paste(" We will return a smaller form. ")); flush.console();
      return(dLogit(lX+1.0));
      flush.console();  return(-1);
    }
  }
  tt = 0;
  if (alphaNew < alphaOld) {
    LBMid <- LBNew;  alphaMid <- alphaNew;
    alphaNew <- alphaOld;  LBNew <- LBOld;
    alphaOld <- alphaMid;  LBOld <- LBMid;
  }
  while(abs(LBNew- WantTot) > epsilon && tt < MaxTTs) {
    alphaMid <- (alphaNew+alphaOld)  / 2.0;
    LBMid <- sum(dLogit(lX+alphaMid));  tt <- tt+1;
    if (abs(LBMid-WantTot) <= epsilon) {
      return(dLogit(alphaMid+lX));
    } else if (LBMid > WantTot) {
      alphaNew <- alphaMid;  LBNew <- LBMid;
    } else {
      alphaOld <- alphaMid;  LBOld <- LBMid;
    } 
  }
  return(dLogit(alphaMid+lX));  
}