##
## SourceS3LinearModelsHelperFunctions.R
##
##
## Created by Alan Lenarcic on 9/3/10.
## Copyright 2010 UNC Genetics. All rights reserved.
##
##

MatrixFlagUnique <- function(MatS) {
  ##Strings =   ## Someday I should code this
}

DefaultInbredSwitch = 1;
##########################################################
## Given a Diallel vector reporting sample s in 1:n has
##    mother of strain i and father of strain j, this constructs
##    the design matrix;
##
##   I know this is a lot of code
##    numj, ajModel, CrossModel, SexModel, MotherModel, 
##    BetaInbredLevel, BetaInbredTimesSex all satisfy the levels we've described

MakeAM <- function(n) {
 ## A <- (n-2)^2+(n-2);
 ## B <- 2*(n-2)/ sqrt(n-1);
 ## C <- 1 - 1/(n-1);
 ## k <- (-B+ sqrt(B^2+ 4 * A * C)) / ( 2 * A) 
 k <- (-1 + sqrt(n)) / (n-1)^(3/2) 
 AMM <- matrix(-k, n-1,n-1);
 diag(AMM) <- k * (n-2) + 1 / sqrt(n-1);
 AM <- rbind(AMM, rep(-1/sqrt(n-1), n-1));
 return(AM);
}
ConstructXJK <- function(numj, ajModel, CrossModel, SexModel, MotherModel, 
     BetaInbredLevel, BetaInbredTimesSex, SexVector = 0, Listjk, CO, FixedEffects = NULL, 
     RandomEffectsGroups = NULL, RandomEffects = NULL,
     Verbose = FALSE, CrossModelsList = NULL,
     ALLINCLUSIVE = FALSE, InbredSwitch = DefaultInbredSwitch, verbose = NULL, 
     DoFirstCenter = FALSE, ...) {
  if (!exists("DoFirstCenter") || is.null(DoFirstCenter) || 
    (!is.logical(DoFirstCenter) && is.numeric(DoFirstCenter)&& DoFirstCenter < 1)) {
    DoFirstCenter = FALSE;
  }
  if (!is.null(verbose) && is.numeric(verbose)) {
    Verbose <- as.logical(verbose);  verbose = as.logical(verbose);
  }
  if (!is.null(verbose) && is.logical(verbose)) {
    Verbose <- as.logical(verbose);
  }
  if (!is.logical(Verbose)) {
    Verbose <- FALSE;
  }
  verbose <- as.logical(Verbose);
  if (Verbose == TRUE) {
    print("Start ConstructXJK");
  }
  X <- rep(1, length(Listjk[,1]));
  clx = "Mu";	
	if (length(Listjk[1,]) == 3) {
		SexVector = Listjk[,1];  Listjk = Listjk[,2:3];
		if (max(SexVector) == 1 && min(SexVector) == 0) {
			SexVector = SexVector - .5;	
		} else if (max(SexVector) == min(SexVector)) {
		    print("Error: There is uniform Gender in this study");
			return;
		}
	} else if ( length(SexVector)  <= 1 || length(SexVector) != length(Listjk[,1])) {
      SexModel = 0;
      SexVector = 0;
  }
  if (max(SexVector) == 1 && min(SexVector) == 0) {
    SexVector = SexVector - .5;	
  }
  
  if (verbose == TRUE) {
    print("SexModel > 0 question?")
    print(paste("SexModel = ", SexModel));
    flush.console();
  }
  if (SexModel > 0) {
    if (length(SexVector) == length(Listjk[,1])) { 
			X <- cbind(X, SexVector);
			colnames(X) = c("Mu", "Gender:Av");
			clx = c("Mu", "Gender:Av");
		} else {
			print("Sorry Gender Vector Not Supplied Correctly,");
			print(paste(" length(Gender) = ", length(SexVector), 
						" but Gender Model = ", SexModel, sep=""));
			return(-1);
		}
	} 
	if (BetaInbredLevel == 1 || BetaInbredLevel == 3) {
	  if (InbredSwitch == 1) {
	    BetaHyVec = rep(0, length(Listjk[,1]));
	    BetaHyVec[Listjk[,1] == Listjk[,2]] = 1;	  
	  } else {
	    BetaHyVec = rep(1, length(Listjk[,1]));
	    BetaHyVec[Listjk[,1] == Listjk[,2]] = 0;
	  }
		X <- cbind(X, BetaHyVec);
		clx = c(clx, "BetaInbred:Av");
	}
	if ((BetaInbredLevel == 1 || BetaInbredLevel == 3) &&
		 SexModel > 0 && BetaInbredTimesSex >= 1) {
	  if (InbredSwitch == 1) {
	    BetaHyVec = rep(0, length(Listjk[,1]));
	    BetaHyVec[Listjk[,1] == Listjk[,2]] = 1;	  
	  } else {
	    BetaHyVec = rep(1, length(Listjk[,1]));
	    BetaHyVec[Listjk[,1] == Listjk[,2]] = 0;
	  }
	  X <- cbind(X, SexVector * BetaHyVec);
	  clx = c(clx, "BetaInbred:Gender:Av");
	}	
	if (verbose == TRUE) {
	  print("Onto FixedEffects"); flush.console();
        }
  if (!is.null(FixedEffects)) {
    if (length(dim(FixedEffects)) == 2) {
      X <- cbind(X, FixedEffects);
      colnames(X) <- c(clx, colnames(FixedEffects));
       clx = colnames(X);
    } else {
      X <- cbind(X, FixedEffects);
      if (length(names(FixedEffects)) >= 1) {
        colnames(X) <- c(clx, names(FixedEffects)[1]);
         clx = colnames(X);
      } else {
        colnames(X) <- c(clx, "FixedEffect");
         clx = colnames(X);
      }
    }
  }
  if (verbose == TRUE) {
    print("Onto Random Effects"); flush.console();
  }
  if (!is.null(RandomEffects)) {
    if (length(dim(RandomEffects)) == 2) {
      if (verbose == TRUE) {
        print("The Dim is Two");
        flush.console();
      }
      X <- cbind(X, RandomEffects);
      colnames(X) <- c(clx, colnames(RandomEffects));
       clx = colnames(X);
    } else {
      X <- cbind(X, RandomEffects);
      if (length(colnames(RandomEffects)) >= 1) {
        colnames(X) <- c(clx, names(colRandomEffects)[1]);
         clx = colnames(X);
      } else {
        colnames(X) <- c(clx, "RandomEffect");
         clx = colnames(X);
      }
    }
  } 
  if (verbose == TRUE) {
    print("OntoNewStuff"); flush.console();
  }

  D1aj = matrix(0, length(Listjk[,1]), numj);
  D1aj[cbind(1:length(Listjk[,1]), Listjk[,1])] = 
  D1aj[cbind(1:length(Listjk[,1]), Listjk[,1])] + 1;
  D1aj[cbind(1:length(Listjk[,1]), Listjk[,2])] = 
  D1aj[cbind(1:length(Listjk[,1]), Listjk[,2])] + 1;
  colnames(D1aj) = paste("aj:", 1:numj, sep="");
  if (DoFirstCenter == TRUE) {
    AM <- MakeAM(NCOL(D1aj)); 
    D1aj2 <- D1aj %*% AM;
    colnames(D1aj2) <- colnames(D1aj)[1:(NCOL(D1aj)-1)];
    D1aj = D1aj2;
  }

  if (verbose == TRUE) {
    print("Adding aj"); flush.console();
  }
  if (ajModel  >= 1) {	
    X <- cbind(X, D1aj);
	clx = c(clx, colnames(D1aj));
	colnames(X) = clx;
  }
	
  if (verbose == TRUE) {
    print("Adding Gender:aj"); flush.console();
  }
  if (SexModel > 1) {
    clX = colnames(X);
    X <- cbind(X, SexVector * D1aj);
    try(colnames(X) <- c(clX, paste("Gender:", colnames(D1aj), sep="")));
    if (length(clX) + length(colnames(D1aj)) != NCOL(X)) {
      print(paste("Error in adding columes Gender:aj, clx length ", length(clX),
        ",  Length colnames D1aj is ", length(colnames(D1aj)), 
        " but NCOL(X) is ", NCOL(X), sep="")); flush.console();
    }
  }
  if (verbose == TRUE) {
    print("Considering Adding Mother"); flush.console();
  }	
	if (MotherModel > 0) {
		try(DMMaj <- matrix(0, length(Listjk[,1]), numj));
		DMMaj[cbind(1:length(Listjk[,1]), Listjk[,1])] = 
		DMMaj[cbind(1:length(Listjk[,1]), Listjk[,1])] + 1;
		DMMaj[cbind(1:length(Listjk[,1]), Listjk[,2])] = 
		DMMaj[cbind(1:length(Listjk[,1]), Listjk[,2])] - 1;	
    try(colnames(DMMaj) <- paste("motherj:", 1:numj, sep=""));
    if (DoFirstCenter == TRUE) {
     AM <- MakeAM(NCOL(DMMaj)); 
     DMMaj2 <- DMMaj %*% AM;
     colnames(DMMaj2) <- colnames(DMMaj)[1:(NCOL(DMMaj)-1)];
     DMMaj = DMMaj2;
    }	
		clX = colnames(X);
		try(X <- cbind(X, DMMaj));
		try(colnames(X) <- c(clX, colnames(DMMaj)));
    if (length(clX) + length(colnames(DMMaj)) != NCOL(X)) {
      print(paste("Error in X assembly: X has ", NCOL(X), " columns ", sep=""));
      print(paste(" You had clX length ", length(clX), " and length colnames DMMaj ",
        length(colnames(DMMaj)), sep="")); flush.console();
    }
		if (SexModel > 2) {
			clX = colnames(X);
			X <- cbind(X, SexVector * DMMaj);
      try(colnames(X) <- c(clX, paste("Gender:", colnames(DMMaj), sep="")));
		}
	}

  if (verbose == TRUE) {
    print("Considering Adding BetaInbredLevels"); flush.console();
  }	
  if (verbose == TRUE) {
    print("Adding BetaInbred Levels"); flush.console();
  }
  if (BetaInbredLevel > 1) {
    D1aj = matrix(0, length(Listjk[,1]), numj);
    D1aj[cbind(1:length(Listjk[,1]), Listjk[,1])] = 
    D1aj[cbind(1:length(Listjk[,1]), Listjk[,1])] + 1;
    D1aj[cbind(1:length(Listjk[,1]), Listjk[,2])] = 
    D1aj[cbind(1:length(Listjk[,1]), Listjk[,2])] + 1;
    colnames(D1aj) = paste("aj:", 1:numj, sep="");
    if (InbredSwitch == 1) {
      DHaj = D1aj;
      DHaj[DHaj == 1] = 0;
      DHaj[DHaj == 2] = 1;       
    } else {
      DHaj = D1aj;
      DHaj[DHaj == 2] = 0;
    }
    try(colnames(DHaj) <- paste("dominancej:", 1:NCOL(D1aj), sep=""));
    if (DoFirstCenter == TRUE) {
     AM <- MakeAM(NCOL(DHaj)); 
     DHaj2 <- DHaj %*% AM;
     colnames(DHaj2) <- colnames(DHaj)[1:(NCOL(DHaj)-1)];
     try(DHaj <- DHaj2);
    }	
    try(clx <- colnames(X));
    try(X <- cbind(X, DHaj)); 
    try(colnames(X) <- c(clx, colnames(DHaj))); 
    if (SexModel >= 4) {
      try(clx <- colnames(X));
      try(X <- cbind(X, SexVector * DHaj));
      try(colnames(X) <- c(clx, paste("Gender:", colnames(DHaj), sep=""))); 
      try(clx <- colnames(X));			
    }
  }
	
	
  if (verbose == TRUE) {
    print("CrossModel"); flush.console();
  }	
  if (!is.null(CrossModelsList)) {
    if (any(2:7 %in% CrossModelsList)) {
      CrossModel = max((2:7)[2:7 %in% CrossModelsList]);
    }
  }
  if (CrossModel > 1 && CrossModel < 8) {	    
    Djk = matrix(0, length(X[,1]), numj * (numj+1)/2);
    match1 = match( Listjk[,1] * numj + Listjk[,2], CO$jCross * numj + CO$kCross );
    IM = (1:length(match1))[!is.na(match1)]
    match1 = match1[is.na(match1) == FALSE];
    Djk[cbind(IM, CO$idCross[match1])] = 
      Djk[cbind(IM, CO$idCross[match1])]  + 1
    match2 = match( Listjk[,1] * numj + Listjk[,2], CO$kCross * numj + CO$jCross );
    IM = (1:length(match2))[!is.na(match2)]
    match2 = match2[is.na(match2) == FALSE];	
    Djk[cbind(IM,  CO$idCross[match2])] = 
      Djk[cbind(IM, CO$idCross[match2]) ]+ 1;
    ##print("Making DjkColnames"); flush.console();
    colnames(Djk) =  paste("SymCrossjk:j:", CO$jCross, ";k:", CO$kCross, sep=""); 
    if ( InbredSwitch == 1 || (( BetaInbredLevel > 1 || BetaInbredTimesSex > 1 ) &&
         (ALLINCLUSIVE == FALSE)) ) {
      Djk = Djk[, (numj+1):length(Djk[1,])]
    }
    if (DoFirstCenter == TRUE) {
     AM <- MakeAM(NCOL(Djk)); 
     Djk2 <- Djk %*% AM;
     colnames(Djk2) <- colnames(Djk)[1:(NCOL(Djk)-1)];
     Djk = Djk2;
    }	
    clx = colnames(X);
    X <- cbind(X, Djk);
    if (verbose == TRUE) {
      ##print(paste("CrossModel, Adding SymCrossjk terms ", CrossModel, sep="")); flush.console();
      ##print(paste("length(clx) = ", length(clx), sep=""));
      ##addr = paste("SymCrossjk:j:", CO$jCross, ";k:", CO$kCross, sep="")
      ##print(paste("length(addr) = ", length(addr), sep=""));
    }
    ##print("Binding Sym Colnames")
    colnames(X) = c(clx, colnames(Djk));
    if (verbose == TRUE) {
      print(paste("CrossModel, Success with SymCrossjk ", CrossModel, sep="")); flush.console();
    }	    
    if (SexModel > 4) {
      clx = colnames(X);
      X <- cbind(X, SexVector * Djk);
      ##print("Binding Gender Colnames");
      colnames(X) = c(clx, paste("Gender:", colnames(Djk), sep=""));		
    }
    if (verbose == TRUE) {
      print(paste("CrossModel, afterInbredLevel2 ConstructXJK: ", CrossModel, sep="")); flush.console();
    }			
    ##print("AfterInbredLevel2 ConstructXJK");			
    } else if (CrossModel == 1) {
		##clx = colnames(X);
		##DNaj = D1aj;  DNaj[DNaj != 1] = 0;
		##clx = colnames(X);
		##X = cbind(X, DNaj);
		##colnames(X) = c(clx, paste("dominancej:", 1:numj, sep=""));
		##if (SexModel > 3) {
		##	clx = colnames(X);
		##	X <- cbind(X, SexVector * DNaj);
		##	colnames(X) = c(clx, paste("Gender:dominancej:", 1:numj, sep=""));
		##}
		
     }
  if (!is.null(CrossModelsList)) {
    if (any(5:7 %in% CrossModelsList)) {
      CrossModel = max((5:7)[5:7 %in% CrossModelsList]);
    }
  }
  if (CrossModel >= 5 && CrossModel < 8) {
    Djk2 = matrix(0, length(X[,1]), numj * (numj-1)/2);
    match1 = match( Listjk[,1] * numj + Listjk[,2], CO$jCrossO * numj + CO$kCrossO );
    IM = (1:length(match1))[!is.na(match1)]
    match1 = match1[is.na(match1) == FALSE];
    Djk2[cbind(IM, CO$idCrossO[match1])] = 
    Djk2[cbind(IM, CO$idCrossO[match1])]  + 1;
    match2 = match( Listjk[,1] * numj + Listjk[,2], CO$kCrossO * numj + CO$jCrossO );
		IM = (1:length(match2))[!is.na(match2)]
		match2 = match2[is.na(match2) == FALSE];	
		Djk2[cbind(IM,  CO$idCrossO[match2])] = 
		Djk2[cbind(IM, CO$idCrossO[match2]) ] - 1;
		Djk2 = Djk2;
    colnames(Djk2) <- paste("ASymCrossjkDkj:j:", CO$jCrossO, ";k:", CO$kCrossO, sep="");
    if (DoFirstCenter == TRUE) {
     AM <- MakeAM(NCOL(Djk2)); 
     Djk3 <- Djk2 %*% AM;
     colnames(Djk3) <- colnames(Djk2)[1:(NCOL(Djk2)-1)];
     Djk2 = Djk3;
    }			
		clx = colnames(X);
		X <- cbind(X, Djk2);
    colnames(X) = c(clx, colnames(Djk2));
    if (SexModel >= 5) {
      clx = colnames(X);
      X <- cbind(X,  (SexVector * Djk2));
      colnames(X) = c(clx, paste("Gender:", colnames(Djk2), sep=""));		
	  }		
		
	}
  if (verbose == TRUE) {
    print(paste("CrossModel, is it more than 8?: ", CrossModel, sep="")); flush.console();
  }
  if (!is.null(CrossModelsList)) {
    if (any(8:10 %in% CrossModelsList)) {
      CrossModel = max((8:10)[8:10 %in% CrossModelsList]);
    }
  }
  if (CrossModel >= 8) {
		DjkAll = matrix(0, length(X[,1]), numj * numj);
		Rep1s = rep(1, length(X[,1]));  Rep1s[ Listjk[,1] != Listjk[,2]] = 0;
		DjkAll[, Listjk[,1]] = Rep1s;
		match1 = match( Listjk[,1] * numj + Listjk[,2], CO$jCrossO * numj + CO$kCrossO );
		IM = (1:length(match1))[!is.na(match1)]
		match1 = match1[is.na(match1) == FALSE];
		DjkAll[cbind(IM, numj + CO$idCrossO[match1])] = 
		DjkAll[cbind(IM, numj + CO$idCrossO[match1])]  + 1;
		match2 = match( Listjk[,1] * numj + Listjk[,2], CO$kCrossO * numj + CO$jCrossO );
		IM = (1:length(match2))[!is.na(match2)]
		match2 = match2[is.na(match2) == FALSE];	
		DjkAll[cbind(IM, numj * (numj+1)/2 +  CO$idCrossO[match2])] = 
		DjkAll[cbind(IM, numj * (numj+1)/2 + CO$idCrossO[match2]) ] - 1;
    cnamesDjkAll = c(paste("AllCrossjk:j:", 1:numj, ";k:", 1:numj, sep=""),
			paste("AllCrossjk:j:", CO$jCrossO, ";k:", CO$kCrossO, sep = ""),
			paste("AllCrossjk:j:", CO$kCrossO, ";k:", CO$jCrossO, sep=""))
    if (InbredSwitch == 1 || (( BetaInbredLevel > 1 || BetaInbredTimesSex > 1) &&
        (ALLINCLUSIVE == FALSE)) ) {
      PDjkAll = DjkAll[,(numj+1):length(DjkAll[1,])];
      PcnamesDjkAll = cnamesDjkAll[(numj+1):length(DjkAll[1,])]
    } else { PDjkAll = DjkAll;  PcnamesDjkAll = cnamesDjkAll; }
		clx = colnames(X);
    if (DoFirstCenter == TRUE) {
     AM <- MakeAM(NCOL(PDjkAll)); 
     PDjkAll2 <- PDjkAll %*% AM;
     colnames(PDjkAll2) <- colnames(PDjkAll)[1:(NCOL(PDjkAll)-1)];
     PDjkAll = PDjkAll2;
     PcnamesDjkAll <- PcnamesDjkAll[1:(length(PcnamesDjkAll)-1)];
    }	
		X <- cbind(X, PDjkAll);
		colnames(X) = c(clx, PcnamesDjkAll);
		if (SexModel >= 5) {
			clx = colnames(X);
			GcnamesDjkAll = c(paste("Gender:AllCrossjk:j:",  PcnamesDjkAll, sep=""))
			if ( ( BetaInbredLevel > 1 || BetaInbredTimesSex > 1 ) &&
          (ALLINCLUSIVE == FALSE) ) {
        PGcnamesDjkAll = GcnamesDjkAll[(numj+1):length(GcnamesDjkAll)];
      } else {PGcnamesDjkAll = GcnamesDjkAll;}
			X <- cbind(X,  (SexVector * PDjkAll));
			colnames(X) = c(clx, PGcnamesDjkAll);
		}			
	}
	return(X);
}


.DefaultAllFixedVariables =c("Mu", "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av");
.DefaultAllRandomVariables = c("aj", "Gender:aj",
"motherj", "Gender:motherj", "dominancej",
"Gender:dominancej", "SymCrossjk", "Gender:SymCrossjk",
"ASymCrossjkDkj", "Gender:ASymCrossjkDkj", "AllCrossjk", "Gender:AllCrossjk");
.DefaultAllnumjVariables = c("aj", "Gender:aj",
"motherj", "Gender:motherj", "dominancej");
.DefaultHalfnumjSqVariables = c("SymCrossjk", "Gender:SymCrossjk");
.DefaultnumjSqVariables = c( "AllCrossjk", "Gender:AllCrossjk");

.DefaultOffHalfnumjSqVariables = c(
"ASymCrossjkDkj", "GendASymCrossjkDkj");


OrderAllList = c("Mu", "Gender:Av", "BetaInbred:Av", 
"BetaInbred:Gender:Av", "FixedEffect", "RandomEffect", "aj", "Gender:aj",
"motherj", "Gender:motherj", "dominancej",
"Gender:dominancej", "SymCrossjk", "Gender:SymCrossjk",
"ASymCrossjkDkj", "Gender:ASymCrossjkDkj", "AllCrossjk", "Gender:AllCrossjk");
idAllList = 1:length(OrderAllList);
IsFixed = c(1,1,1,1,  1, rep(0,length(OrderAllList)-4));

NetRelations = list();
NetRelations[[1]] = c("Mu", "aj", "BetaInbred:Av", "dominancej");
NetRelations[[2]] = c("Gender:Av", "Gender:aj", "BetaInbred:Gender:Av", "Gender:dominancej");
NetRelations[[3]] = c("motherj", "Gender:motherj");
NetRelations[[4]] = c("SymCrossjk", "AllCrossjk");
NetRelations[[5]] = c("Gender:SymCrossjk", "Gender:AllCrossjk");
NetRelations[[6]] = c("ASymCrossjkDkj");
NetRelations[[7]] = c("Gender:ASymCrossjkDkj");
NetRelations[[8]] = c("FixedEffect", "RandomEffect");

fLenBetaAllListInbredTrue <- function(numj) {
 c(1,1,1,1,numj, numj, numj, numj, numj,
    numj, numj * (numj-1)/2,
    numj * (numj-1)/2,numj * (numj-1)/2,
    numj * (numj-1)/2, numj^2 - numj, numj^2 - numj, -999, -999);
}
fLenBetaAllListInbredFalse <- function(numj) {
 c(1,1,1,1, numj, numj, numj, numj, 0,
  0, numj * (numj+1)/2,
  numj * (numj+1)/2,numj * (numj-1)/2,
  numj * (numj-1)/2, numj^2, numj^2, -999, -999);
}

fLenBetaAllListHybridTrue <- function(numj) {
 c(1,1,1,1,numj, numj, numj, numj, numj,
    numj, numj * (numj-1)/2,
    numj * (numj-1)/2,numj * (numj-1)/2,
    numj * (numj-1)/2, numj^2 - numj, numj^2 - numj, -999, -999);
}
fLenBetaAllListHybridFalse <- function(numj) {
 c(1,1,1,1, numj, numj, numj, numj, 0,
  0, numj * (numj+1)/2,
  numj * (numj+1)/2,numj * (numj-1)/2,
  numj * (numj-1)/2, numj^2, numj^2, -999, -999);
}

FindMaximizerTable <- function(ExampleLists, Verbose = 0) {
  if (Verbose > 0) {
    print("FindMaximizerTable, Start "); flush.console();
  }
  if (!is.null(dim(ExampleLists)) && length(dim(ExampleLists)) == 1) {
    return(as.vector(ExampleLists));
  }
  if (is.null(dim(ExampleLists))) {
    return(as.vector(ExampleLists));
  }
  if (is.null(dim(ExampleLists)) || length(ExampleLists) == 6 ||
     length(ExampleLists) == 7) {
    return(as.vector(ExampleLists));  
  }
  RR = rep(0, length(ExampleLists[1,]));    
  for (ii in 1:length(RR)) {
    if (Verbose > 1) {
      print(paste("FindMaximizerTable, on ii = ", ii, sep="")); flush.console();
    }
    RR[ii] = max(ExampleLists[,ii]);
  }
  if (Verbose > 0) {
    print("FindMaximizerTable, Returning "); flush.console();
  }
  return(RR);
}
IsInBunch <- function(Maxer, ExampleList) {
  StrMax = paste(Maxer, collapse=",");
  if (is.null(dim(ExampleList)) || length(dim(ExampleList)) == 1) {
    if (StrMax == paste(ExampleList, collapse=",")) {
             return(TRUE);
    }
  }
  for (ii in 1:length(ExampleList[,1])) {
    if (StrMax == paste(ExampleList[ii,], collapse=",")) {
             return(TRUE);
    }
  }
  return(FALSE);
}

GiveBetaNums<- function(XNames, GotList, PrintForFun = FALSE,
  CBetaInbredLevel, CBetaInbredTimesSex) {
    ids = 1:length(XNames);
    Begger = ids[ substr(XNames, 1,nchar(GotList[1])) == GotList[1]];
    if (length(GotList) == 1) {
       try(names(Begger) <- GotList[1]);
       return(Begger);
    }
    for (jj in 2:length(GotList)) {
       Begger = c(Begger, 
          ids[ substr(XNames, 1,nchar(GotList[jj])) == GotList[jj]]);
    }
    try(names(Begger) <- XNames[Begger]);
    BadList = c("SymCrossjk", "Gender:SymCrossjk", 
                      "AllCrossjk", "Gender:AllCrossjk");
    if (any(substr(XNames,1,nchar("dominancej")) == "dominancej") &&
      any(substr(GotList,1,nchar("dominancej")) == "dominancej") &&
      any(GotList %in% BadList) &&
      (CBetaInbredLevel > 1 || CBetaInbredTimesSex > 1) ) {
      for (jj in 1:length(BadList)) {
        try(Begger <- IdentifyUndesiredCombos(BadList[jj], Begger, PrintForFun));
      }
    }
    if (PrintForFun == TRUE) {
       print("Did we Print?");
    }  
    return(Begger);
}
CollapseGotList <- function(BetaList,GotList) {
   RetMarks = rep(0, length(GotList));
   for(ii in 1:length(GotList)) {
     RetMarks[ii] = length(BetaList[ 
       substr(names(BetaList),1,nchar(GotList[ii])) == GotList[ii]] );
   }
   names(RetMarks) = GotList;
   RetMarks[1:length(RetMarks)] = cumsum(RetMarks)
   return(RetMarks);
}

IdentifyUndesiredCombos <- function(StartSeq, WholeList, PrintForFun = FALSE) {
  IDD = (1:length(WholeList))[ substr(names(WholeList), 1, nchar(StartSeq)) ==
    StartSeq];
  NG = substr(names(WholeList)[IDD],nchar(StartSeq)+1, 
    nchar(names(WholeList)[IDD]));
    
  BadCombos = grep("^\\:j\\:(\\d+),k\\:\\1$", NG);
  if (length(BadCombos) == 0) {
    BadCombos = NULL;
  }

  NG2 = unlist(strsplit(NG, ":j:"));
  NG2 = NG2[NG2 != ""];
  
  NG2 = strsplit(as.character(NG2), ";k:");
  if (length(NG2) > 0) {
    NG3 = t(matrix(unlist(NG2), 2,length(NG2)));
    if (PrintForFun == TRUE) {
      print(NG3);
    }
    BadCombos = c(BadCombos, (1:length(NG))[
      as.numeric(NG3[,1]) == as.numeric(NG3[,2])]);
  }
  DeadBadCombos = IDD[BadCombos];
  if (PrintForFun == TRUE) {
    print(paste("UndesiredCombos:  StartSeq = ", StartSeq, 
      ", num BadCombos: ", length(BadCombos), sep=""));
    print(NG);
  }
  NotBadCombos = (1:length(WholeList))[! 1:length(WholeList) 
    %in% DeadBadCombos];
  return(WholeList[NotBadCombos]);
}
## MotherModel CrossModel SexModel BetaInbredLevel BetaInbredTimesSex
MatUMeld <- function(NewVector, OldMat) {
  MinO = cbind( rep(NewVector[1], length(OldMat[,1])),  OldMat );
  if (length(NewVector) > 1) {
    for (jj in 2:length(NewVector)) {
      MinO = rbind( MinO, cbind( rep(NewVector[jj], length(OldMat[,1])),
        OldMat ));
    }
  }
  return(MinO);
}

GenerateModelsList <- function(ajLevels=c(0,1), 
             MotherLevels=c(0,1), CrossLevels=c(0,1,2), 
             SexLevels = c(0,1,2,3,4,5), BetaInbredLevels=c(0,1,2,3), 
             BetaInbredTimesSexLevels =c(0,1)) {
    ajLevels = sort(ajLevels, decreasing=TRUE);
    MotherLevels = sort(MotherLevels, decreasing=TRUE);
    CrossLevels = sort(CrossLevels, decreasing=TRUE);
    SexLevels = sort(SexLevels, decreasing=TRUE);
    BetaInbredLevels = sort(BetaInbredLevels, decreasing=TRUE);
    BetaInbredTimesSexLevels=sort(BetaInbredTimesSexLevels, decreasing=TRUE);
    C0 = BetaInbredTimesSexLevels;
    C0 = cbind(rep(BetaInbredLevels, each=length(C0)), 
               rep(C0, length(BetaInbredLevels)));
    C0 = MatUMeld(SexLevels, C0);
    C0 = MatUMeld(CrossLevels, C0);
    C0 = MatUMeld(MotherLevels, C0);
    C0 = MatUMeld(ajLevels, C0);
    
    C0 = C0[C0[,5] >= C0[,6],];
    C0 = C0[!(C0[,4] >= 4 & C0[,5] < 2 & C0[,3] < 1), ];
    C0 = C0[!(C0[,4] >= 3 & C0[,2] < 1 & C0[,3] < 1), ];
    C0 = C0[!(C0[,4] >= 2 & C0[,1] < 1),];
    C0 = C0[!(C0[,3] >= 1 & C0[,1] < 1 &  C0[,5] < 1),];
     return(C0);
 }
 
 

GriffingsGCAAnalysis <- function(Y, Listjk) {
  numj = length(unique(as.numeric(Listjk)));
  lListjk = length(Listjk[,1]);
  MyX = matrix(0, length(Listjk[,1]), length(unique(as.numeric(Listjk))));
  MyX[cbind(1:lListjk, Listjk[,1])] = MyX[cbind(1:lListjk, Listjk[,1])] + 1;
  MyX[cbind(1:lListjk, Listjk[,2])] = MyX[cbind(1:lListjk, Listjk[,2])]  + 1;
  MyLM = lm(Y~MyX-1)
  
  MyNames = c("Mu", paste("aj:", 1:numj, sep=""),"Sigma:1");
  MyStatCoef=coef(MyLM);
  MyMu = mean(MyStatCoef);  MyAj = MyStatCoef - MyMu;
  MyMu = 2 * MyMu;
  sdMu = 2*sqrt(sum( coefficients(summary(MyLM))[,2]^2 ));
  sdAj = coefficients(summary(MyLM))[,2];
  SigmaEst = (summary(MyLM)$sigma)^2;  names(SigmaEst) = "Sigma:1";
  dfs = summary(MyLM)$df[2]
  SdSigmaEst = SigmaEst * dfs * (1/qchisq( .025, df = dfs) -
   1/qchisq( .5, df = dfs)) / 2;
  names(SdSigmaEst) = "Sigma:1"; 
  
  meanVector = c(MyMu, MyAj, SigmaEst); names(meanVector) = MyNames;
  sdVector = c(sdMu, sdAj,SdSigmaEst);  names(sdVector) = MyNames; 
  return(list(lmOb = MyLM, meanVector = meanVector, sdVector = sdVector) );
} 

GriffingsSATME <- function(Y, Listjk, X) {
  library(lme4);
  colMaxX = rep(0, length(X[1,]));
  for (ii in 1:length(X[1,])) {
    colMaxX = max(X[Listjk[,1] != Listjk[,2],1])
  }
  IsNameACopy <- function(XColNames) { 
    IX = (1:length(XColNames))[substr(XColNames,1,8) == "SymCross"];
    if (length(IX) == 0) {
      print("GriffingsSATME: There is no SymCross, give up on GriffingsSAT"); 
      print("The XColNames is :");
      print(XColNames);
      flush.console();
      return(NULL);
    }
    BNamesX = XColNames[substr(XColNames,1,8) == "SymCross"];
    SplNames1 = strsplit(BNamesX, "SymCrossjk:j:");
    SplNames1 = unlist(SplNames1)[unlist(SplNames1) != ""]
    SplNames2 = strsplit(SplNames1, ";k:")
    SplNames2 = t(matrix(unlist(SplNames2), 2,length(SplNames2)))
    MyRet = rep(FALSE, length(XColNames));
    MyRet[IX[SplNames2[,1] != SplNames2[,2]]] = TRUE;
    return(MyRet);
  }
  XNamesWant = colnames(X)[substr(colnames(X), 1,2) == "aj" |
    (substr(colnames(X),1,8) == "SymCross" &
     IsNameACopy(colnames(X)) )]
  XNeeds = X[,colnames(X)%in% XNamesWant];
  colnames(XNeeds) = XNamesWant;
  MyLM = lm(Y~XNeeds-1)
  numj = length(unique(as.numeric(Listjk)));

  MyNames = c("Mu", XNamesWant,"Sigma:1");
  MyStatCoef=coef(MyLM); names(MyStatCoef) = MyNames[2:(length(MyNames)-1)];
  MyMu = mean( XNeeds%*% MyStatCoef);  MyOtCoefs = MyStatCoef - MyMu;
  sdMu = 2*sqrt(sum( coefficients(summary(MyLM))[,2]^2 ));
  sdOt = coefficients(summary(MyLM))[,2];
  names(sdOt) = names(MyOtCoefs);
  SigmaEst = (summary(MyLM)$sigma)^2;  names(SigmaEst) = "Sigma:1";
  dfs = summary(MyLM)$df[2]
  SdSigmaEst = SigmaEst * dfs * (1/qchisq( .025, df = dfs) -
   1/qchisq( .5, df = dfs)) / 2;
  names(SdSigmaEst) = "Sigma:1"; 
  
  meanVector = c(MyMu, MyOtCoefs, SigmaEst); names(meanVector) = MyNames;
  sdVector = c(sdMu, sdOt,SdSigmaEst);  names(sdVector) = MyNames; 
  return(list(lmOb = MyLM, meanVector = meanVector, sdVector = sdVector) );
} 

KillFromMeOneThis <- function(ParamVec, AString) {
  IndexIn = (1:length(ParamVec))[ substr(names(ParamVec),1, nchar(AString)) == AString];
  IndexOut = (1:length(ParamVec))[!(substr(names(ParamVec),1, nchar(AString)) == AString)]; 
  OutLess <- IndexOut[IndexOut < min(IndexIn)];
  OutMore <- IndexOut[IndexOut > max(IndexIn)];
  NewParamVec <- c(ParamVec[OutLess], ParamVec[IndexIn[1:(length(IndexIn)-1)]],
    ParamVec[OutMore]);
  names(NewParamVec) <- names(ParamVec)[c(OutLess, IndexIn[1:(length(IndexIn)-1)],
    OutMore)];
  return(NewParamVec); 

}
