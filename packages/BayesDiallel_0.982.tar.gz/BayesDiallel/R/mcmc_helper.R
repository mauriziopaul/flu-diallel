##require(WVmisc)
require(coda)

mcmc.subset <- function(coda.object, burnin=0, thin=1, wanted=1:length(varnames(coda.object)))
{
	total <- nrow(coda.object[[1]])
	num.steps <- floor((total-burnin)/thin)
	steps <- burnin + (1:num.steps)*thin

  if (is.character(wanted))
  {
    mi=match(wanted, varnames(coda.object))
    if (any(is.na(mi)))
    {
      stop("Could not find wanted variable names: ", paste(collapse=",", wanted[is.na(mi)]))
    }
    wanted=mi
  }
	for (i in 1:length(coda.object))
	{
	  coda.object[[i]] <- as.mcmc(coda.object[[i]][steps,wanted])
	}
	as.mcmc.list(coda.object)
}

mcmc.stack <- function(coda.object)
{
	if (inherits(coda.object, "mcmc"))
	{
		return (coda.object)
	}
	if (!inherits(coda.object, "mcmc.list"))
	{
		stop("Non-mcmc object passed to function\n")
	}
	chain <- coda.object[[1]]
	for (i in 2:nchain(coda.object))
	{
		chain <- rbind(chain, coda.object[[i]])
	}
	as.mcmc(chain)
}	

plot.hpd <- function(coda.object,
		wanted=varnames(coda.object),
		prob.wide=0.95,
		prob.narrow=0.50,
		xlab="HPD interval",
		names=NULL,
		type="p",
		name.margin = 6.1,
		plt.left=NULL, plt.right=NULL, plt.bottom=NULL, plt.title=NULL,
		ylab="",  name.line = 3.9, main="", main.line=2,
		...)
{
	which.wanted=ifow(is.integer(wanted), wanted, match(wanted, varnames(coda.object)))
	num.wanted=length(which.wanted)
	if(!exists("name.margin") || is.null(name.margin)) { name.margin = 6.1; }
	chain <- mcmc.stack(coda.object)
	mu    <- colMeans(chain[,which.wanted])
	med   <- apply(coda::HPDinterval(chain, prob=0.01)[which.wanted,],
			1, mean)
	hpd.wide    <- coda::HPDinterval(chain, prob=prob.wide)[which.wanted,]
	hpd.narrow  <- coda::HPDinterval(chain, prob=prob.narrow)[which.wanted,]
	
    mid.vals <- med;
	if (is.null(names)) names <- varnames(chain)[which.wanted]
	else names <- rep(names, length.out=length(wanted))
	ypos <- plot.ci(med, hpd.narrow, hpd.wide, names=names, xlab=xlab, col.midvals="white", pch.midvals="|", type=type, 
    name.margin=name.margin,plt.left=plt.left, plt.right=plt.right, 
    plt.bottom=plt.bottom, plt.title=plt.title, ylab=ylab, 
    name.line = name.line, main=main, main.line=main.line, ...)
	if ("p"==type)
	{
		points(mu, ypos, pch="|")
	}
	invisible(ypos)
}

