## Attempt to simulate future crosses:
##
## k alleles
##
## k ~ 1+ expo
##Beta_j <- sum( b_j1 + b_j2+b_j3...)
##Beta_j <- rnorm(tauj^2)  = k taujd^2

#  b_ji ~ tauj^2/d

if (FALSE) {
## Art Ronis Hudson Placement 914-478-7111    

library(BayesDiallel);
data(PiximusData);
dir.create("c:/Stat/BayesDiallelBack", showWarnings=FALSE);
AFDPreCenteredBMCwithWeight = DiallelAnalyzer(data = Piximus.Data, father.strain="father.strain.name",
   mother.strain="mother.strain.name", phenotype="BoneMineralContent", is.female="is.female",
   sep="", FixedEffects = "MouseWeight",
   RandomEffects = NULL, 
   Models=Example.Piximus.Models[1], sigmasq.start = 1,  numChains = 3,  lengthChains=900,
   burnin = 1,
   DIC.Only=FALSE,  tauPriorFile = Example.Piximus.tau.Prior.Info,
   SaveAFDFile = "c:/Stat/BayesDiallelBack/SaveAFDBackUpPiximusDataWeightCentered.RData",
   DoBayesSpike=TRUE, BSSaveDir ="c:/Stat/BayesDiallelBack/BS",
   LogTransform=FALSE, DoFirstCenter =TRUE, PriorProbFixed = c(-1,-1,-1,-1,1.0), 
   Verbose = 1, BSLengthChains = 400, BSNumChains =2);
  library(BayesDiallel);
  load("c:/Stat/BayesDiallelBack/SaveAFDBackUpPiximusDataWeightCentered.RData");
 
dir.create("c:/Stat/BayesDiallelBack", showWarnings=FALSE); 
data(PiximusData)
AFD = DiallelAnalyzer(data = Piximus.Data, father.strain="father.strain.name",
   mother.strain="mother.strain.name", phenotype="MouseWeight", is.female="is.female",
   sep="", FixedEffects = NULL,
   RandomEffects = NULL,  LogTransform = TRUE,
   Models=Example.Piximus.Models, sigmasq.start = 1,  numChains = 5,  lengthChains=2500,
   burnin = 1,
   DIC.Only=FALSE,  tauPriorFile = Example.Piximus.tau.Prior.Info,
   SaveAFDFile = "c:/Stat/BayesDiallelBack/SaveAFDBackUpWeightPiximusData.RData");   
   library(BayesDiallel)
  load("c:/Stat/BayesDiallelBack/SaveAFDBackUpWeightPiximusData.RData");
  
  data = Piximus.Data;
  father.strain="father.strain.name";
  mother.strain="mother.strain.name";
  phenotype="MouseWeight";
  is.female="is.female"; Y = NULL;
  FixedEffects=NULL; nameFixedEffects = NULL;
  RandomEffects=NULL; nameRandomEffects=NULL;
  RandomEffectsGroups = NULL;
  Models=Example.Piximus.Models[1:2]; tauPriorFile = Example.Piximus.tau.Prior.Info; 
  sep=","; na.strings="NA"; 
  sigmasq.start = 1; numChains =3; lengthChains = 1500;
  Verbose = TRUE; LogTransform = FALSE; SqrtTransform = FALSE;
  burnin = 1; thin = 1; DIC.Only = FALSE;
  DoBayesSpike = FALSE; PriorProbTau = NULL;
  PriorProbFixed = NULL; 
  BSSaveDir = NULL; strain.map = NULL; SaveAFDFile = "";
  ProbUnknownGender = NULL; ListUnknownGender = NULL; NoChainsUnknownGender = FALSE; 
  phenotype.name = ""; DoGelman = TRUE; 
  MissingYIndices=NULL; LowCensorBound=NULL;
  UpCensorBound = NULL; NoChainsImputeY=FALSE; DataFile=NULL; DoFirstCenter = NULL;
  BSLengthChains=3000; BSNumChains=4;
  this <- AFD$AllDiallelObs[[1]];
  
  AFFS <- summary(AFD$AllDiallelObs[[1]]$cent.chains);
  AS <- AFD$AllDiallelObs[[1]]$cent.chains
  MS <- list();
  for (jj in 1:length(AS)) {
    MLS <- matrix(rep(AFFS[[1]][,1], each=NROW(AS[[1]])), NROW(AS[[1]]), NCOL(AS[[1]]));
    colnames(MLS) <- colnames(AS[[1]]);
    MS[[jj]] <- as.mcmc(MLS);
  }

  AFFD <- summary(AFD$AllDiallelObs[[1]]$raw.chains);
  M2 <- list();
  AS <- AFD$AllDiallelObs[[1]]$CodaChains;
  for (jj in 1:length(AS)) {
    MLS <- matrix(rep(AFFD[[1]][,1], each=NROW(AS[[1]])), NROW(AS[[1]]), NCOL(AS[[1]]));
    colnames(MLS) <- colnames(AS[[1]]);
    M2[[jj]] <- as.mcmc(MLS);
  }   
  try(AFD$AllDiallelObs[[1]]$CodaChains <- M2);
  try(AFD$AllDiallelObs[[1]]$.cent.chains <- MS);  
  library(BayesDiallel)
  ##load("c:/Stat/BayesDiallelBack/SaveAFDBackUpWeightPiximusData.RData"); 
  UseMyWeightFunction =  function(N, KDim, tauIn) {
      TUseWeightFunction(N, KDim, tauIn, TDF = 4000);
  } 
  ##SpeculativeWeightGenesSimulation;
  UseFixed = FALSE; KDim = 5; 
  pMix = .5; SigmakK=0; SigmakKSq=0; SexMix=.5;
  SigmakKSampleFunction <- function(KDim, rho = .2, Band = -1) {
  Aii <- matrix(rep(1:KDim, KDim), KDim, KDim);
  Ajj <- t(Aii);
  SigmakK <- matrix(rho^(abs(Aii-Ajj)), KDim, KDim);
  if (is.numeric(Band) && Band >= 1) {
    SigmakK[abs(Aii-Ajj) > Band] <- 0;
  }
  return(SigmakK);
  }
  SigmakKFunction <-  SigmakKSampleFunction
  ListSigmakK <- NULL;
  this <- AFD$AllDiallelObs[[1]];
}
##
if (FALSE) {

PoisLambda <- 2;
Randk <- 1+rpois(1,2);
rnorm( bj1)

k <- 5;
tauSq <-3;
A1 <- 2;
A2 <- -1;
b1 <- A1/k + rnorm(k, 0, 1)*sqrt(tauSq/k*(1-1/k));
b2 <- A2/k + rnorm(k,0,1) *sqrt(tauSq/k*(1-1/k));
}

# E[A*B]-E[A]E[B] = Cov(A*B)
# E[A*B] = Cov(A*B) + E[A] E[B]

##sqrt(tauSq/k*(1-1/k));
## bj1
## bj1+bj2+bj3+bj4 = A1;
##
if (FALSE) {
  Betajj = 2*1+.5 + 2*.4;
  BetajJ = 1 - 1 + (.5--.5) + .75 + .3;
  BetaJj = 1 - 1 + (-.5-.5) + .75 - .3;
  BetaJJ = 2*-1 + .5 + 2*-.3;
  p = .5;  barSigmakK <- .15;  barSigmakKSq = .1;
  tauA = 6; tauM=1; tauB=1; tauV=2; tauW=.5;
  sigma <- 1;  KDim=1:10; 
  
  Betajj <- matrix(rnorm(4*3),4,3);
  BetajJ <- matrix(rnorm(4*3),4,3);
  BetaJj <- matrix(rnorm(4*3),4,3);
  BetaJJ <- matrix(rnorm(4*3),4,3);  
  KDim <- 1:5;
}



setMethodS3("SpeculativeGenesSimulation", "DiallelOb", function (this,
  UseFixed = FALSE, KDim = 1:10, 
  pMix = .5, barSigmakK=0, barSigmakKSq=0, SexMix=.5,...) {
  if (!exists("TrueVector")) { TrueVector = NULL; }
  if (!exists("UseFixed")) { UseFixed=FALSE; }
  if (!exists("thin")) { thin = 1;}
  if (!exists("KDim")) { KDim = 1:10; }
  if (!exists("pMix")) { pMix = .5; }
  if (!exists("SexMix")) { SexMix = .5; }
  if (!exists("barSigmakK") || is.null(barSigmakK) || barSigmakK <= -1/KDim ||
    barSigmakK >= 1) {
    barSigmakK <- 0;    
  }
  if (!exists("barSigmakKSq") || is.null(barSigmakKSq) || barSigmakKSq < 0 ||
    barSigmakKSq >= 1) {
    barSigmakKSq <- 0;    
  }
  FakeChains = NULL;  FakeX = NULL;
  LSText <- "
  FakeChains = this$getPosteriorPredictionsMeanChains();
  FakeCoda = FakeChains;
  ##FakeX = this$PostKeeper$FakeX;
  ";
  try(eval(parse(text=LSText)));
  try(CodaChains <- this$getCent.chains());
  if (this$DoFirstCenter == FALSE) {
    NewCodaChains <- list();
    for (ii in 1:length(this$.cent.chains)) {
      NN <- matrix(as.numeric(this$.cent.chains[[ii]]), NROW(this$.cent.chains[[ii]]),
        NCOL(this$.cent.chains[[ii]]));
      colnames(NN) <- colnames(this$CodaChains[[1]])
      NewCodaChains[[ii]] <- as.mcmc(NN);
    }
    CodaChains <- as.mcmc.list(NewCodaChains);
  }
  if (is.null(CodaChains) || length(CodaChains) <= 0 || length(CodaChains[[1]]) <= 0) {
     print(paste("PosteriorDSq[", this$.iOb, 
       ": Hey, Cent.Chains Doesn't work why is that?", sep="")); flush.console();
  }
  DD <- matrix(rep(1:this$.numj, this$.numj), this$.numj, this$.numj);
  Sires <- t(DD)[lower.tri(DD)];
  Dams <- DD[lower.tri(DD)];
  BetajjLocs <- (Sires-1)*this$.numj+(Sires-1)+1;
  BetaJJLocs <- (Dams-1)*this$.numj+(Dams-1)+1;
  BetajJLocs <- (Sires-1)*this$.numj+(Dams-1)+1;
  BetaJjLocs <- (Dams-1)*this$.numj+(Sires-1)+1;  
  if (this$.SexModel <= 0) {
    BetajjChain <- StackAndGetMe(FakeChains, BetajjLocs, 1, enditer = NULL, OutLimit=3)
    BetajJChain <- StackAndGetMe(FakeChains, BetajJLocs, 1, enditer = NULL, OutLimit=3)
    BetaJjChain <- StackAndGetMe(FakeChains, BetaJjLocs, 1, enditer = NULL, OutLimit=3)
    BetaJJChain <- StackAndGetMe(FakeChains, BetaJJLocs, 1, enditer = NULL, OutLimit=3)
  }  else {
    NSq <- this$.numj*this$.numj;
    BetajjChain <- StackAndGetMe(FakeChains, c(BetajjLocs,NSq+BetajjLocs), 1, enditer = NULL, OutLimit=3)
    BetajJChain <- StackAndGetMe(FakeChains, c(BetajJLocs,NSq+BetajJLocs), 1, enditer = NULL, OutLimit=3)
    BetaJjChain <- StackAndGetMe(FakeChains, c(BetaJjLocs,NSq+BetajJLocs), 1, enditer = NULL, OutLimit=3)
    BetaJJChain <- StackAndGetMe(FakeChains, c(BetaJJLocs,NSq+BetajJLocs), 1, enditer = NULL, OutLimit=3)    
  }
  LLN <- colnames(CodaChains[[1]]);
  tauALoc <- (1:length(LLN))[LLN %in% c("tau:aj", "tauaj")];
  tauMLoc <- (1:length(LLN))[LLN %in% c("tau:motherj", "taumotherj")];
  tauBLoc <- (1:length(LLN))[LLN %in% c("tau:dominancej", "taudominancej")];
  tauVLoc <- (1:length(LLN))[LLN %in% c("tau:SymCrossjk", "tauSymCrossjk")];
  tauWLoc <- (1:length(LLN))[LLN %in% c("tau:ASymCrossjkDkj", "tauASymCrossjkDkj")];
  LLs <- c("A", "M", "B", "V", "W");
   for (ss in 1:length(LLs)) {
     MyT <- paste(" if (length(tau", LLs[ss], "Loc) <= 0) { ",
       " tau", LLs[ss], "Loc <- -1; } ", sep="");
     try(eval(parse(text=MyT)));
   }
  sigmaLoc <- (1:length(LLN))[LLN %in% c("Sigma:1", "sigma:1", "Sigma", "sigma")];
  taus <-  StackAndGetMe(CodaChains, c(tauALoc,tauMLoc,tauBLoc, tauVLoc, tauWLoc, sigmaLoc), this$.AFD$burnin, enditer = NULL)
  
  ReturnVarFunction <- CalcMyVarianceFunction(BetajjChain, BetajJChain, BetaJjChain, BetaJJChain, p=pMix, 
    barSigmakK, barSigmakKSq, KDim,
    taus[,1], taus[,2], taus[,3], taus[,4], taus[,5]);
  library(coda);
  if (this$.SexModel <= 0) {
    if (length(KDim) == 1) {
      colnames(ReturnVarFunction) <- paste("j:", Sires, ":J:", Dams, sep="");
      try(ReturnVarFunction <- as.mcmc(ReturnVarFunction));
      ReturnVarSummary <- summary(ReturnVarFunction);
    } else {
      ReturnVarSummary <- list();
      for (jj in 1:length(KDim)) {
        colnames(ReturnVarFunction[[jj]]) <- paste("j:", Sires, ":J:", Dams, sep="");
        try(ReturnVarFunction[[jj]] <- as.mcmc(ReturnVarFunction[[jj]]));
        ReturnVarSummary[[jj]] <- summary(ReturnVarFunction[[jj]]);
        names(ReturnVarSummary)[jj] <- paste("KDim:", KDim[jj], sep="");
      }
    }
  } else {
    LSS <- paste("j:", Sires, ":J:", Dams, sep="");
    LS2 <- c(paste("S:0:", LSS, sep=""), paste("S:1:", LSS, sep=""));
    if (length(KDim) == 1) {
      colnames(ReturnVarFunction) <- LS2;
      try(ReturnVarFunction <- as.mcmc(ReturnVarFunction));
      ReturnVarSummary <- summary(ReturnVarFunction);
    } else {
      ReturnVarSummary <- list();
      for (jj in 1:length(KDim)) {
        colnames(ReturnVarFunction[[jj]]) <- LS2;
        try(ReturnVarFunction[[jj]] <- as.mcmc(ReturnVarFunction[[jj]]));
        ReturnVarSummary[[jj]] <- summary(ReturnVarFunction[[jj]]);
        names(ReturnVarSummary)[jj] <- paste("KDim:", KDim[jj], sep="");
      }
    }    
  }
  NoiseChain <- as.mcmc(taus[,6]);
  NoiseSummary <- summary(NoiseChain)
  if (this$.SexModel <= 0) {
  return(list(VarSummary=ReturnVarSummary, NoiseSummary=NoiseSummary, 
     VarChain=ReturnVarFunction, NoiseChain=NoiseChain, 
     BetajjChain=BetajjChain, BetajJChain=BetajJChain, BetaJjChain=BetaJjChain,
     BetaJJChain=BetaJJChain));
  }
  MeanChains = pMix^2*BetajjChain + pMix*(1-pMix) * BetajJChain +
    pMix*(1-pMix) * BetaJjChain + (1-pMix)^2 * BetaJJChain;
  if (!is.list(ReturnVarFunction)) {
    IRD <- NCOL(ReturnVarFunction)/2;
    VarianceWithSexChain <- SexMix*ReturnVarFunction[,1:IRD] +
      (1-SexMix) * ReturnVarFunction[,IRD+(1:IRD)] +
      SexMix*(1-SexMix)*(MeanChains[,1:IRD]-MeanChains[,IRD+(1:IRD)])^2;
    try(colnames(VarianceWithSexChain) <- paste("S:B:j:", Sires,":J:", Dams, sep=""));
    try(VarianceWithSexChain <- as.mcmc(VarianceWithSexChain));
    try(VarianceWithSexSummary <- summary(VarianceWithSexChain));
  } else {
    VarianceWithSexChain <- list();
    VarianceWithSexSummary <- list();
    for (ii in 1:length(ReturnVarFunction)) {
        IRD <- NCOL(ReturnVarFunction[[ii]])/2; 
        VarianceWithSexChain[[ii]] <- SexMix*ReturnVarFunction[[ii]][,1:IRD] +
      (1-SexMix) * ReturnVarFunction[[ii]][,IRD+(1:IRD)] +
        SexMix*(1-SexMix)*(MeanChains[,1:IRD]-MeanChains[,IRD+(1:IRD)])^2;
        try(names(VarianceWithSexChain)[ii] <- paste("KDim:", KDim[ii], sep=""))
        try(colnames(VarianceWithSexChain[[ii]]) <- paste("S:B:j:", Sires,":J:", Dams, sep=""));
        try(VarianceWithSexChain[[ii]] <- as.mcmc(VarianceWithSexChain[[ii]]));
       try(VarianceWithSexSummary[[ii]] <- summary(VarianceWithSexChain[[ii]]));
    }
  }
  return(list(VarSummary=ReturnVarSummary, VarianceWithSexSummary=VarianceWithSexSummary,
     NoiseSummary=NoiseSummary, 
     VarChain=ReturnVarFunction, VarianceWithSexChain=VarianceWithSexChain, 
     NoiseChain=NoiseChain, MeanChains=MeanChains,
     BetajjChain=BetajjChain, BetajJChain=BetajJChain, BetaJjChain=BetaJjChain,
     BetaJJChain=BetaJJChain)); 
});
DefaultUseMyWeightFunction =  function(N, KDim, tauIn) {
      TUseWeightFunction(N, KDim, tauIn, TDF = 4);
}
setMethodS3("SpeculativeGenesBackCrossSimulation", "DiallelOb", function (this,
  UseFixed = FALSE, KDim = 1:10, 
  pMix = .5, barSigmakK=0, SexMix=.5, ...) {
  if (!exists("TrueVector")) { TrueVector = NULL; }
  if (!exists("UseFixed")) { UseFixed=FALSE; }
  if (!exists("thin")) { thin = 1;}
  if (!exists("KDim")) { KDim = 1:10; }
  if (!exists("pMix")) { pMix = .5; }
  if (!exists("SexMix")) { SexMix = .5; }
  if (!exists("barSigmakK") || is.null(barSigmakK) || barSigmakK <= -1/KDim ||
    barSigmakK >= 1) {
    barSigmakK <- 0;    
  }
  
  FakeChains = NULL;  FakeX = NULL;
  LSText <- "
  FakeChains = this$getPosteriorPredictionsMeanChains();
  FakeCoda = FakeChains;
  ##FakeX = this$PostKeeper$FakeX;
  ";
  try(eval(parse(text=LSText)));
  try(CodaChains <- this$getCent.chains());
  if (this$DoFirstCenter == FALSE) {
    NewCodaChains <- list();
    for (ii in 1:length(this$.cent.chains)) {
      NN <- matrix(as.numeric(this$.cent.chains[[ii]]), NROW(this$.cent.chains[[ii]]),
        NCOL(this$.cent.chains[[ii]]));
      colnames(NN) <- colnames(this$CodaChains[[1]])
      NewCodaChains[[ii]] <- as.mcmc(NN);
    }
    CodaChains <- as.mcmc.list(NewCodaChains);
  }
  if (is.null(CodaChains) || length(CodaChains) <= 0 || length(CodaChains[[1]]) <= 0) {
     print(paste("PosteriorDSq[", this$.iOb, 
       ": Hey, Cent.Chains Doesn't work why is that?", sep="")); flush.console();
  }
  DD <- matrix(rep(1:this$.numj, this$.numj), this$.numj, this$.numj);
  Sires <- t(DD)[lower.tri(DD)];
  Dams <- DD[lower.tri(DD)];
  BetajjLocs <- (Sires-1)*this$.numj+(Sires-1)+1;
  BetajJLocs <- (Sires-1)*this$.numj+(Dams-1)+1;
  if (this$.SexModel <= 0) {
    BetajjChain <- StackAndGetMe(FakeChains, BetajjLocs, 1, enditer = NULL, OutLimit=3)
    BetajJChain <- StackAndGetMe(FakeChains, BetajJLocs, 1, enditer = NULL, OutLimit=3)
  }  else {
    NSq <- this$.numj*this$.numj;
    BetajjChain <- StackAndGetMe(FakeChains, c(BetajjLocs,NSq+BetajjLocs), 1, enditer = NULL, OutLimit=3)
    BetajJChain <- StackAndGetMe(FakeChains, c(BetajJLocs,NSq+BetajJLocs), 1, enditer = NULL, OutLimit=3)
  }
  LLN <- colnames(CodaChains[[1]]);
  tauALoc <- (1:length(LLN))[LLN %in% c("tau:aj", "tauaj")];
  tauMLoc <- (1:length(LLN))[LLN %in% c("tau:motherj", "taumotherj")];
  tauBLoc <- (1:length(LLN))[LLN %in% c("tau:dominancej", "taudominancej")];
  tauVLoc <- (1:length(LLN))[LLN %in% c("tau:SymCrossjk", "tauSymCrossjk")];
  tauWLoc <- (1:length(LLN))[LLN %in% c("tau:ASymCrossjkDkj", "tauASymCrossjkDkj")];
  LLs <- c("A", "M", "B", "V", "W");
   for (ss in 1:length(LLs)) {
     MyT <- paste(" if (length(tau", LLs[ss], "Loc) <= 0) { ",
       " tau", LLs[ss], "Loc <- -1; } ", sep="");
     try(eval(parse(text=MyT)));
   }
  sigmaLoc <- (1:length(LLN))[LLN %in% c("Sigma:1", "sigma:1", "Sigma", "sigma")];
  taus <-  StackAndGetMe(CodaChains, c(tauALoc,tauMLoc,tauBLoc, tauVLoc, tauWLoc, sigmaLoc), this$.AFD$burnin, enditer = NULL)
  

  
  ReturnVarFunction <- CalcBackCrossVarianceFunction(BetajjChain, BetajJChain, p=pMix, 
    barSigmakK,  KDim,
    taus[,1], taus[,2], taus[,3], taus[,4], taus[,5]);
  library(coda);
  if (this$.SexModel <= 0) {
    if (length(KDim) == 1) {
      colnames(ReturnVarFunction) <- paste("j:", Sires, ":J:", Dams, sep="");
      try(ReturnVarFunction <- as.mcmc(ReturnVarFunction));
      ReturnVarSummary <- summary(ReturnVarFunction);
    } else {
      ReturnVarSummary <- list();
      for (jj in 1:length(KDim)) {
        colnames(ReturnVarFunction[[jj]]) <- paste("j:", Sires, ":J:", Dams, sep="");
        try(ReturnVarFunction[[jj]] <- as.mcmc(ReturnVarFunction[[jj]]));
        ReturnVarSummary[[jj]] <- summary(ReturnVarFunction[[jj]]);
        names(ReturnVarSummary)[jj] <- paste("KDim:", KDim[jj], sep="");
      }
    }
  } else {
    LSS <- paste("j:", Sires, ":J:", Dams, sep="");
    LS2 <- c(paste("S:0:", LSS, sep=""), paste("S:1:", LSS, sep=""));
    if (length(KDim) == 1) {
      colnames(ReturnVarFunction) <- LS2;
      try(ReturnVarFunction <- as.mcmc(ReturnVarFunction));
      ReturnVarSummary <- summary(ReturnVarFunction);
    } else {
      ReturnVarSummary <- list();
      for (jj in 1:length(KDim)) {
        colnames(ReturnVarFunction[[jj]]) <- LS2;
        try(ReturnVarFunction[[jj]] <- as.mcmc(ReturnVarFunction[[jj]]));
        ReturnVarSummary[[jj]] <- summary(ReturnVarFunction[[jj]]);
        names(ReturnVarSummary)[jj] <- paste("KDim:", KDim[jj], sep="");
      }
    }    
  }
  NoiseChain <- as.mcmc(taus[,6]);
  NoiseSummary <- summary(NoiseChain)
  if (this$.SexModel <= 0) {
  return(list(VarSummary=ReturnVarSummary, NoiseSummary=NoiseSummary, 
     VarChain=ReturnVarFunction, NoiseChain=NoiseChain, 
     BetajjChain=BetajjChain, BetajJChain=BetajJChain));
  }
  MeanChains = pMix*BetajjChain + (1-pMix) * BetajJChain;
  
  if (!is.list(ReturnVarFunction)) {
    IRD <- NCOL(ReturnVarFunction)/2;
    VarianceWithSexChain <- SexMix*ReturnVarFunction[,1:IRD] +
      (1-SexMix) * ReturnVarFunction[,IRD+(1:IRD)] +
      SexMix*(1-SexMix)*(MeanChains[,1:IRD]-MeanChains[,IRD+(1:IRD)])^2;
    try(colnames(VarianceWithSexChain) <- paste("S:B:j:", Sires,":J:", Dams, sep=""));
    try(VarianceWithSexChain <- as.mcmc(VarianceWithSexChain));
    try(VarianceWithSexSummary <- summary(VarianceWithSexChain));
  } else {
    VarianceWithSexChain <- list();
    VarianceWithSexSummary <- list();
    for (ii in 1:length(ReturnVarFunction)) {
        IRD <- NCOL(ReturnVarFunction[[ii]])/2; 
        VarianceWithSexChain[[ii]] <- SexMix*ReturnVarFunction[[ii]][,1:IRD] +
      (1-SexMix) * ReturnVarFunction[[ii]][,IRD+(1:IRD)] +
        SexMix*(1-SexMix)*(MeanChains[,1:IRD]-MeanChains[,IRD+(1:IRD)])^2;
        try(names(VarianceWithSexChain)[ii] <- paste("KDim:", KDim[ii], sep=""))
        try(colnames(VarianceWithSexChain[[ii]]) <- paste("S:B:j:", Sires,":J:", Dams, sep=""));
        try(VarianceWithSexChain[[ii]] <- as.mcmc(VarianceWithSexChain[[ii]]));
       try(VarianceWithSexSummary[[ii]] <- summary(VarianceWithSexChain[[ii]]));
    }
  }
 
  return(list(VarSummary=ReturnVarSummary, VarianceWithSexSummary=VarianceWithSexSummary,
     NoiseSummary=NoiseSummary, 
     VarChain=ReturnVarFunction, VarianceWithSexChain=VarianceWithSexChain, 
     NoiseChain=NoiseChain, MeanChains=MeanChains,
     BetajjChain=BetajjChain, BetajJChain=BetajJChain)); 
});

StackAndGetMe <- function(ACodaChains, Locs, startiter=1, enditer = NULL, OutLimit=3) {
  if (!exists("enditer") || is.null(enditer) || enditer <= 0) {
    enditer <- NROW(ACodaChains[[1]]);
  }   
  if (!exists("startiter") || is.null(startiter) || startiter <= 0 ||
    startiter >= NROW(ACodaChains[[1]])) {
    startier = 1;  
  }
  RetMatrix <- matrix(0, (enditer-startiter+1)*length(ACodaChains), length(Locs));
  AA <- 0;
  for (ii in 1:length(ACodaChains)) {
    IRD <- (1:length(Locs))[Locs>=1];
    RetMatrix[AA+1:(enditer-startiter+1),IRD] <- ACodaChains[[ii]][
      startiter:enditer,Locs[Locs>=1]];
    AA <- AA + (enditer-startiter+1)
  }
  colnames(RetMatrix) <- Locs;
  if (OutLimit > 0) {
    for (jj in 1:NCOL(RetMatrix)) {
      IQR <- quantile(RetMatrix[,jj],.75)-quantile(RetMatrix[,jj],.25)
      RetMatrix[RetMatrix[,jj] < quantile(RetMatrix[,jj],.25) - OutLimit*IQR,jj] <-
        quantile(RetMatrix[,jj],.5);
      RetMatrix[RetMatrix[,jj] > quantile(RetMatrix[,jj],.75) + OutLimit*IQR,jj] <-
        quantile(RetMatrix[,jj],.5);
    }
  }
  return(RetMatrix)
}

##
## Give Betajj, BetajJ, BetaJj
CalcMyVarianceFunction <- function(Betajj, BetajJ, BetaJj, BetaJJ, p, 
  barSigmakK, barSigmakKSq, KDim,
  tauA, tauM, tauB, tauV, tauW) {
  if (length(KDim) >= 2 && length(Betajj) >= 2) {
    MyReturn <- list();
    for (ii in 1:length(KDim)) {
      MyReturn[[ii]] <- CalcMyVarianceFunction(
        Betajj, BetajJ, BetaJj, BetaJJ, p, 
        barSigmakK, barSigmakKSq, KDim[ii],
        tauA, tauM, tauB, tauV, tauW);
      names(MyReturn)[ii] <- paste("KDim:",KDim[ii], sep="");
    }
    return(MyReturn);
  }
   ##KDim <- NROW(SigmakK);
   FirstFunction <- p^2*(1-p^2)  * (
     Betajj^2/KDim + 2 * (tauA+tauB) * (1-1/KDim) ) +
     p*(1-p) * (1-p*(1-p)) * (
       BetajJ^2/KDim + 2 * (tauA + tauM + tauV + .25*tauW)* (1-1/KDim)  +
       BetaJj^2/KDim + 2 * (tauA + tauM + tauV + .25*tauW)* (1-1/KDim) 
     ) +
     (1-p)^2*(1-(1-p)^2)*    
     (BetaJJ^2/KDim + 2 * (tauA+tauB) * (1-1/KDim));
   SecondFunction <- -KDim*2*(
      p^2*Betajj*(p*(1-p)*BetajJ+p*(1-p)*BetaJj+(1-p)^2*BetaJJ)/KDim^2 +
      2*tauA / KDim*(1-1/KDim)*p^2*(2*p*(1-p)+(1-p)^2) +
      p*(1-p)*BetajJ*(p*(1-p)*BetaJj+(1-p)^2*BetaJJ)/KDim^2+
      p^2*(1-p)^2*(2*tauA-2*tauM+tauV-.25*tauW)/KDim*(1-1/KDim)+
      p*(1-p)^2 * tauA / KDim*(1-1/KDim)+
      p*(1-p)^3*(BetaJj*BetaJJ/KDim^2+
      (tauA)/KDim*(1-1/KDim)) );
   
   ThirdFunction <- (KDim^2-KDim)*
     ((2*p^3*(1-p) * barSigmakK + p^2*(1-p)^2 * barSigmakKSq) *(
       Betajj^2/KDim^2 - 2*(tauA+tauB)/KDim^2) +
      (2*p*(1-p)^3 * barSigmakK + p^2*(1-p)^2 * barSigmakKSq) *(
       BetaJJ^2/KDim^2 - 2*(tauA+tauB)/KDim^2
      )
     );
   FourthFunction <- (KDim^2-KDim)* 
     (p^2*(1-p)^2 *barSigmakKSq+p^2*(1-p)*(1-2*p)* barSigmakK) *
     (Betajj*BetajJ/KDim^2 + Betajj*BetaJj/KDim^2  - 2 * tauA/KDim^2);
   FifthFunction <- (KDim^2-KDim)*p*(1-p)^2*(2*p-1-p*barSigmakK)*
     (BetajJ*BetaJJ/KDim^2 + BetaJj*BetaJJ/KDim^2 - 2 * tauA/KDim^2);
   SixthFunction <- (KDim^2-KDim) * (p^2 * (1-p)^2 *(barSigmakKSq-2*barSigmakK)+
     p * (1-p)* barSigmakK)*
     ( BetajJ*BetajJ/KDim^2-2*(2*tauA+2*tauM+tauV+.25*tauW)/KDim^2+
       BetaJj*BetaJj/KDim^2);
    LastFunction <- (KDim^2-KDim)* p^2*(1-p)^2*((barSigmakKSq)-2*barSigmakK) *
      (Betajj*BetaJJ/KDim^2 +
       BetajJ*BetaJj/KDim^2- (2*tauA-2*tauM+tauV-.25*tauW)/KDim^2);
    Total <- FirstFunction+SecondFunction+ThirdFunction+FourthFunction+
      FifthFunction+SixthFunction+LastFunction;
    ## Test KDim = 0;
    ##(.25*(Betajj^2+BetajJ^2+BetaJj^2+BetaJJ^2)-(.25*(Betajj+BetajJ+BetaJj+BetaJJ))^2);
    return(Total)
}



##
## Give Betajj, BetajJ, BetaJj
CalcBackCrossVarianceFunction <- function(Betajj, BetajJ, p, 
  barSigmakK, KDim,
  tauA, tauM, tauB, tauV, tauW) {
  if (length(KDim) >= 2 && length(Betajj) >= 2) {
    MyReturn <- list();
    for (ii in 1:length(KDim)) {
      MyReturn[[ii]] <- CalcBackCrossVarianceFunction(
        Betajj, BetajJ, p, 
        barSigmakK, KDim[ii],
        tauA, tauM, tauB, tauV, tauW);
      names(MyReturn)[ii] <- paste("KDim:",KDim[ii], sep="");
    }
    return(MyReturn);
  }
   ##KDim <- NROW(SigmakK);
   FirstFunction <- p*(1-p)  * (
     Betajj^2/KDim + 2 * (tauA+tauB) * (1-1/KDim)) +
     (1-p-(1-p)^2)*
       (BetajJ^2/KDim + 2 * (tauA + tauM + tauV + .25*tauW)* (1-1/KDim));
   SecondFunction <- -KDim*2*p*(1-p)*(
      Betajj*BetajJ/KDim^2 +  tauA / KDim^2*(1-1/KDim) );
   ThirdFunction <- (KDim^2-KDim)* barSigmakK *
      p*(1-p)*(Betajj^2/KDim^2 - 2*(tauA+tauB)/KDim^2);
   ## Cov( (1-B^d_k), (1-B^d_k') ) =
   ##    (1-p)^2+p(1-p)SigmakKSq - (1-p)^2
   FourthFunction <- (KDim^2-KDim)* barSigmakK *
      p*(1-p)*(BetajJ^2/KDim^2 - (2*tauA+2*tauM+tauV+.25*tauW)/KDim^2);
   FifthFunction <- (KDim^2-KDim)*p*(1-p)* barSigmakK *
     (BetajJ*Betajj/KDim^2 + tauA/KDim^2);
    Total <- FirstFunction+SecondFunction+ThirdFunction+FourthFunction+
      FifthFunction;
    ## Test KDim = 0;
    ##(.25*(Betajj^2+BetajJ^2+BetaJj^2+BetaJJ^2)-(.25*(Betajj+BetajJ+BetaJj+BetaJJ))^2);
    return(Total)
}

SigmakKSampleFunction <- function(KDim, rho = .2, Band = -1) {
  Aii <- matrix(rep(1:KDim, KDim), KDim, KDim);
  Ajj <- t(Aii);
  SigmakK <- matrix(rho^(abs(Aii-Ajj)), KDim, KDim);
  if (is.numeric(Band) && Band >= 1) {
    SigmakK[abs(Aii-Ajj) > Band] <- 0;
  }
  return(SigmakK);
}

setMethodS3("SpeculativeWeightGenesSimulation", "DiallelOb", function (this,
  UseFixed = FALSE, KDim = 1:10, 
  pMix = .5, SigmakK=0, SexMix=.5,UseMyWeightFunction =DefaultUseMyWeightFunction,
  SigmakKFunction = NULL, ListSigmakK=NULL, ...) {
  if (!exists("TrueVector")) { TrueVector = NULL; }
  if (!exists("UseFixed")) { UseFixed=FALSE; }
  if (!exists("thin")) { thin = 1;}
  if (!exists("KDim")) { KDim = 1:10; }
  if (!exists("pMix")) { pMix = .5; }
  if (!exists("SexMix")) { SexMix = .5; }
  if (!exists("SigmakK") || is.null(SigmakK) || 
    (length(SigmakK) == 1 && SigmakK[1] <= -1/KDim) ||
    any(SigmakK >= 1) ||
    (is.matrix(SigmakK) && mean(SigmakK[lower.tri(SigmakK)]) <= -1/KDim)) {
    SigmakK <- 0;    
  }
  if (!exists("barSigmakKSq") || is.null(barSigmakKSq) || barSigmakKSq < 0 ||
    barSigmakKSq >= 1) {
    barSigmakKSq <- 0;    
  }
  FakeChains = NULL;  FakeX = NULL;
  LSText <- "
  FakeChains = this$getPosteriorPredictionsMeanChains();
  FakeCoda = FakeChains;
  ##FakeX = this$PostKeeper$FakeX;
  ";
  try(eval(parse(text=LSText)));
  try(CodaChains <- this$getCent.chains());
  if (this$DoFirstCenter == FALSE) {
    NewCodaChains <- list();
    for (ii in 1:length(this$.cent.chains)) {
      NN <- matrix(as.numeric(this$.cent.chains[[ii]]), NROW(this$.cent.chains[[ii]]),
        NCOL(this$.cent.chains[[ii]]));
      colnames(NN) <- colnames(this$CodaChains[[1]])
      NewCodaChains[[ii]] <- as.mcmc(NN);
    }
    CodaChains <- as.mcmc.list(NewCodaChains);
  }
  if (is.null(CodaChains) || length(CodaChains) <= 0 || length(CodaChains[[1]]) <= 0) {
     print(paste("PosteriorDSq[", this$.iOb, 
       ": Hey, Cent.Chains Doesn't work why is that?", sep="")); flush.console();
  }
  DD <- matrix(rep(1:this$.numj, this$.numj), this$.numj, this$.numj);
  Sires <- t(DD)[lower.tri(DD)];
  Dams <- DD[lower.tri(DD)];
  ## this <-AFD$AllDiallelObs[[1]]
  ASN <- colnames(this$CodaChains[[1]]);
  Gets <-c("aj:", "Gender:aj", "motherj", "Gender:motherj", 
    "dominancej", "Gender:dominancej", "SymCrossjk", "Gender:SymCrossjk", "ASymCrossjkDkj",
    "Gender:ASymCrossjkDkj");
  if (this$.SexModel <= 0) {
    Gets <- Gets[substr(Gets, 1, nchar("Gender"))!="Gender"]
  }
  sNGets <- strsplit(Gets, ":");
  for (ii in 1:length(Gets)) {sNGets[[ii]] <-paste(paste(sNGets[[ii]],  collapse=""), "V", sep="");}
  sNGets <-unlist(sNGets)
  for (ii in 1:length(Gets)) {
    print(paste("Assemble chain dam/sire ", Gets[ii], sep="")); flush.console();
    ATT <- paste(sNGets[ii],  " = ",
     "(1:length(ASN))[substr(ASN,1,nchar(\"", Gets[ii], "\"))== \"", 
       Gets[ii],"\"];", sep="");
    eval(parse(text=ATT))
    if (ii <=6 ){
      ATT <- paste( "ASSMe = strsplit(ASN[", sNGets[ii], "], \":\");
        if (length(ASSMe) <= 0) {
          ASSMe <- rep(-1, this$.numj);
          ", sNGets[ii], "Dam <- rep(-1, length(Dams));
          ", sNGets[ii], "Sire <- rep(-1, length(Sires));
        } else {
        KTT <- rep(0, length(", sNGets[ii], "));
        for (tt in 1:length(KTT)) {
          KTT[tt] = as.numeric(ASSMe[[tt]][length(ASSMe[[tt]])]);
        }
        ", sNGets[ii] ,"Dam = rep(0, length(Dams));
        ", sNGets[ii] ,"Sire = rep(0, length(Sires)); 
        for (tt in 1:length(Dams)) {
          ", sNGets[ii] ,"Dam[tt] = ", sNGets[ii], "[KTT==Dams[tt]];
          ", sNGets[ii] ,"Sire[tt] = ", sNGets[ii], "[KTT==Sires[tt]];
        }}       
        Beta", sNGets[ii], "DamChain <- StackAndGetMe(this$cent.chains, ", 
          sNGets[ii], "Dam, this$.AFD$burnin, enditer = NULL, OutLimit=-1)
        Beta", sNGets[ii], "SireChain <- StackAndGetMe(this$cent.chains, ", 
          sNGets[ii], "Sire, this$.AFD$burnin, enditer = NULL, OutLimit=-1)
        ", sep="");
        eval(parse(text=ATT));
        if (Gets[ii] == "dominancej"){
          AKK = (1:length(ASN))[ASN=="BetaInbred:Av"];
          BetaInbred = StackAndGetMe(this$cent.chains, rep(AKK, NCOL(BetadominancejVDamChain)),
            this$.AFD$burnin, enditer = NULL, OutLimit=-1);
          BetadominancejVDamChain = BetadominancejVDamChain +  .5*BetaInbred;
          BetadominancejVSireChain = BetadominancejVSireChain +  .5*BetaInbred;          
        }
        if (Gets[ii] == "Genderdominancej"){
          AKK = (1:length(ASN))[ASN=="BetaInbred:Gender:Av"];
          BetaGenderInbred = StackAndGetMe(this$cent.chains, rep(AKK, NCOL(BetaGenderdominancejVDamChain)),
            this$.AFD$burnin, enditer = NULL, OutLimit=-1);
          BetaGenderdominancejVDamChain = BetaGenderdominancejVDamChain +  BetaGenderInbred;
          BetaGenderdominancejVSireChain = BetaGenderdominancejVSireChain +  BetaGenderInbred;          
        }
    } else {
        ATT <- paste( "ASSMe = strsplit(ASN[", sNGets[ii], "], \":\");
        if (length(ASSMe) > 0) {
        KTT1 <- rep(0, length(", sNGets[ii], "));
        KTT2 <- rep(0, length(", sNGets[ii], "));
        for (tt in 1:length(KTT2)) {
          KTT2[tt] = as.numeric(ASSMe[[tt]][length(ASSMe[[tt]])]);
          PS <- unlist(strsplit(ASSMe[[tt]][length(ASSMe[[tt]])-1], \";\"));
          KTT1[tt] = as.numeric(PS[1]);
        }
        ", sNGets[ii] , "Me = rep(0, length(Dams));
        for (tt in 1:length(Dams)) {
          ", sNGets[ii] ,"Me[tt] = ", sNGets[ii], "[KTT1==Dams[tt]&KTT2==Sires[tt]];
        }
        } else {
          ", sNGets[ii], "Me <- rep(-1, length(Dams));   
        }
        Beta", sNGets[ii], "MeChain <- StackAndGetMe(this$cent.chains, ", 
          sNGets[ii], "Me, this$.AFD$burnin, enditer = NULL, OutLimit=-1)      
        ", sep="");
        eval(parse(text=ATT))           
    }
  }
  if (this$.SexModel >= 1) {
  NGS<- sNGets[substr(sNGets, 1, nchar("Gender"))!="Gender"];
   for(ii in 1:length(NGS)){
    if (ii <=3) {
     ATT <- paste("
       Beta", NGS[ii], "DamChain <- cbind(Beta", NGS[ii], "DamChain + ",
         ".5*BetaGender", NGS[ii], "DamChain, Beta", NGS[ii], "DamChain - ",
         ".5*BetaGender", NGS[ii], "DamChain);
       Beta", NGS[ii], "SireChain <- cbind(Beta", NGS[ii], "SireChain + ",
         ".5*BetaGender", NGS[ii], "SireChain, Beta", NGS[ii], "SireChain - ",
         ".5*BetaGender", NGS[ii], "SireChain);
     ",sep="");
     eval(parse(text=ATT))           
   } else {
     ATT <- paste("
       Beta", NGS[ii], "MeChain <- cbind(Beta", NGS[ii], "MeChain + ",
         ".5*BetaGender", NGS[ii], "MeChain, Beta", NGS[ii], "MeChain - ",
         ".5*BetaGender", NGS[ii], "MeChain);
     ",sep="");
     eval(parse(text=ATT))      
   }
  }} else {
    NGS <- sNGets;
  }
  
 
  LLN <- colnames(CodaChains[[1]]);
  tauALoc <- (1:length(LLN))[LLN %in% c("tau:aj", "tauaj")];
  tauMLoc <- (1:length(LLN))[LLN %in% c("tau:motherj", "taumotherj")];
  tauBLoc <- (1:length(LLN))[LLN %in% c("tau:dominancej", "taudominancej")];
  tauVLoc <- (1:length(LLN))[LLN %in% c("tau:SymCrossjk", "tauSymCrossjk")];
  tauWLoc <- (1:length(LLN))[LLN %in% c("tau:ASymCrossjkDkj", "tauASymCrossjkDkj")];
  LLs <- c("A", "M", "B", "V", "W");
   for (ss in 1:length(LLs)) {
     MyT <- paste(" if (length(tau", LLs[ss], "Loc) <= 0) { ",
       " tau", LLs[ss], "Loc <- -1; } ", sep="");
     try(eval(parse(text=MyT)));
   }
  sigmaLoc <- (1:length(LLN))[LLN %in% c("Sigma:1", "sigma:1", "Sigma", "sigma")];
  taus <-  StackAndGetMe(CodaChains, c(tauALoc,tauMLoc,tauBLoc, tauVLoc, tauWLoc, sigmaLoc), this$.AFD$burnin, enditer = NULL)
  
  ListVarNoCov <- list();
  ListVarWithCov <- list();
  ListSumNoCov <- list();
  ListSumWithCov <- list();
  for (kk in 1:length(KDim)) {
    AKDim <- KDim[[kk]]
    if (exists("SigmakKFunction") && !is.null(SigmakKFunction) &&
      is.function(SigmakKFunction)) {
      try(SigmakK <- SigmakKFunction(AKDim));
    } else if (exists("ListSigmakK") && !is.null(ListSigmakK) &&
     is.function(ListSigmakK)) {
      try(SigmakK <- ListSigmakK(AKDim));
    } else if (exists("ListSigmakK") && !is.null(ListSigmakK) &&
      is.list(ListSigmakK)) {
      try(SigmakK <- ListSigmakK[[kk]]);
    }
   
    N <- NROW(BetaajVDamChain);
    Wtsj <- list();  WtsJ <- list();
    for (ii in 1:5) {
      Wtsj[[ii]] <- UseMyWeightFunction(N, AKDim, taus[,ii])
      WtsJ[[ii]] <- UseMyWeightFunction(N, AKDim, taus[,ii])
    }
    if (length(SigmakK) == 1) {
     SigmakK <-  matrix(SigmakK, NCOL(Wtsj[[1]]), NCOL(Wtsj[[1]]));
     diag(SigmakK) <- 0;
    } else if (NCOL(SigmakK) ==  NCOL(Wtsj[[1]]) && 
      NCOL(Wtsj[[1]]) == NROW(SigmakK)) {
      diag(SigmakK) <- 0;
    } else {
      print("Error SigmakK supplied is in Error!")
    } 
  EBjjkBjjk <- matrix(0,NROW(BetaajVSireChain), NCOL(BetaajVSireChain));
  EBJJkBJJk <- matrix(0,NROW(BetaajVSireChain), NCOL(BetaajVSireChain));
  SumVarjj <- 2*rowSums(taus[,1] * (Wtsj[[1]]-Wtsj[[1]]^2) + taus[,2] *
    (Wtsj[[3]]-Wtsj[[3]]^2));
  SumVarJJ <- 2*rowSums(taus[,1] * (WtsJ[[1]]-WtsJ[[1]]^2) + taus[,2] *
    (WtsJ[[3]]-WtsJ[[3]]^2));
  for (jj in 1:NCOL(BetaajVSireChain)) {
    EBjjkBjjk[,jj] <- rowSums( (2*BetaajVSireChain[,jj] *Wtsj[[1]] +
      2*BetadominancejVSireChain[,jj] *Wtsj[[3]])^2 ) + SumVarjj;
    EBJJkBJJk[,jj] <- rowSums( (2*BetaajVDamChain[,jj] *WtsJ[[1]] +
      2*BetadominancejVDamChain[,jj] *WtsJ[[3]])^2 ) + SumVarJJ;
  }
  SumVarjJK <- rowSums(taus[,1] * (Wtsj[[1]]^2+WtsJ[[1]]^2)+
    taus[,2] * (Wtsj[[2]]^2 + WtsJ[[2]]^2) +
    taus[,4] * (Wtsj[[4]]^2) + .25*taus[,5]*(Wtsj[[5]]^2));
  SumCovjjjJ <- rowSums(taus[,1] * (Wtsj[[1]]^2));
  SumCovjJJJ <- rowSums(taus[,1] * (WtsJ[[1]]^2));
  EBjJkBjJk <- matrix(0,NROW(BetaajVSireChain), NCOL(BetaajVSireChain));
  EBJjkBJjk <- matrix(0,NROW(BetaajVSireChain), NCOL(BetaajVSireChain));
  EBjJkBJjk <- matrix(0,NROW(BetaajVSireChain), NCOL(BetaajVSireChain));
  EBjjkBjJk <- matrix(0,NROW(BetaajVSireChain), NCOL(BetaajVSireChain));
  EBjjkBJjk <- matrix(0,NROW(BetaajVSireChain), NCOL(BetaajVSireChain));
  EBjjkBJJk <- matrix(0,NROW(BetaajVSireChain), NCOL(BetaajVSireChain));
  EBjJkBJJk <- matrix(0,NROW(BetaajVSireChain), NCOL(BetaajVSireChain));
  EBJjkBJJk <- matrix(0,NROW(BetaajVSireChain), NCOL(BetaajVSireChain));
  for (jj in 1:NCOL(BetaajVSireChain)) {
    EBjJkBjJk[,jj] <- rowSums( (BetaajVSireChain[,jj] *Wtsj[[1]] +
      BetaajVDamChain[,jj] *WtsJ[[1]] - BetamotherjVSireChain[,jj] *Wtsj[[2]]+
      BetamotherjVDamChain[,jj] *WtsJ[[2]] +
      BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + .5*
      BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]])^2) + SumVarjJK;
    EBJjkBJjk[,jj] <- rowSums( (BetaajVSireChain[,jj] *Wtsj[[1]] +
      BetaajVDamChain[,jj] *WtsJ[[1]] + BetamotherjVSireChain[,jj] *Wtsj[[2]]-
      BetamotherjVDamChain[,jj] *WtsJ[[2]] +
      BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] -.5*
      BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]])^2) + SumVarjJK;
    EBjJkBJjk[,jj] <-rowSums( (BetaajVSireChain[,jj] *Wtsj[[1]] +
      BetaajVDamChain[,jj] *WtsJ[[1]] - BetamotherjVSireChain[,jj] *Wtsj[[2]]+
      BetamotherjVDamChain[,jj] *WtsJ[[2]] +
      BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] -.5*
      BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]])*
      (BetaajVSireChain[,jj] *Wtsj[[1]] +
      BetaajVDamChain[,jj] *WtsJ[[1]] + BetamotherjVSireChain[,jj] *Wtsj[[2]]-
      BetamotherjVDamChain[,jj] *WtsJ[[2]] +
      BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] +.5*
      BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]])) + SumVarjJK;
     EBjjkBJjk[,jj] <-rowSums( (2*BetaajVSireChain[,jj] *Wtsj[[1]] + 
       2*BetadominancejVSireChain[,jj] *Wtsj[[2]])*
      (BetaajVSireChain[,jj] *Wtsj[[1]] +
      BetaajVDamChain[,jj] *WtsJ[[1]] + BetamotherjVSireChain[,jj] *Wtsj[[2]]-
      BetamotherjVDamChain[,jj] *WtsJ[[2]] +
      BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] +.5*
      BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]])) + SumCovjjjJ;
    EBjjkBjJk[,jj] <-rowSums( (2*BetaajVSireChain[,jj] *Wtsj[[1]] + 
       2*BetadominancejVSireChain[,jj] *Wtsj[[2]])*
      (BetaajVSireChain[,jj] *Wtsj[[1]] +
      BetaajVDamChain[,jj] *WtsJ[[1]] + BetamotherjVSireChain[,jj] *Wtsj[[2]]-
      BetamotherjVDamChain[,jj] *WtsJ[[2]] +
      BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] -.5*
      BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]])) + SumCovjjjJ;
    EBjjkBJJk[,jj] <-rowSums( (2*BetaajVSireChain[,jj] *Wtsj[[1]] + 
       2*BetadominancejVSireChain[,jj] *Wtsj[[2]])*
      (2*BetaajVDamChain[,jj] *WtsJ[[1]] + 
        2*BetadominancejVDamChain[,jj] *WtsJ[[2]]));
    EBjJkBJJk[,jj] <-rowSums( (BetaajVSireChain[,jj] *Wtsj[[1]] +
       BetaajVDamChain[,jj] *WtsJ[[1]] - BetamotherjVSireChain[,jj] *Wtsj[[2]]+
       BetamotherjVDamChain[,jj] *WtsJ[[2]] +
       BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] -.5*
       BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]])*
        (2*BetaajVDamChain[,jj] *WtsJ[[1]] +
         2*BetadominancejVDamChain[,jj] *WtsJ[[3]])) + SumCovjJJJ;
    EBJjkBJJk[,jj] <-rowSums( (BetaajVSireChain[,jj] *Wtsj[[1]] +
       BetaajVDamChain[,jj] *WtsJ[[1]] - BetamotherjVSireChain[,jj] *Wtsj[[2]]+
       BetamotherjVDamChain[,jj] *WtsJ[[2]] +
       BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] +.5*
       BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]])*
        (2*BetaajVDamChain[,jj] *WtsJ[[1]] +
         2*BetadominancejVDamChain[,jj] *WtsJ[[3]])) + SumCovjJJJ;
  } 
  VarNoCov <- pMix^2*(1-pMix^2) * EBjjkBjjk  +
    ((1-pMix)^2-(1-pMix)^4) * EBJJkBJJk+
    (pMix*(1-pMix)-pMix^2*(1-pMix)^2)*(EBjJkBjJk+EBJjkBJjk) +
    pMix^2*(pMix*(1-pMix)*(EBjjkBjJk +EBjjkBJjk) +
       (1-pMix)^2 * EBjjkBJJk)+
    pMix*(1-pMix)*( pMix*(1-pMix)*EBjJkBJjk + (1-pMix)^2*(EBjJkBJJk +EBJjkBJJk));
  ListVarNoCov[[kk]] <- VarNoCov;
  ListSumNoCov[[kk]] <- summary(as.mcmc(VarNoCov));
 if (FALSE) {    
   SecondFunction <- -KDim*2*(
      p^2*Betajj*(p*(1-p)*BetajJ+p*(1-p)*BetaJj+(1-p)^2*BetaJJ)/KDim^2 +
      2*tauA / KDim*(1-1/KDim)*p^2*(2*p*(1-p)+(1-p)^2) +
      p*(1-p)*BetajJ*(p*(1-p)*BetaJj+(1-p)^2*BetaJJ)/KDim^2+
      p^2*(1-p)^2*(2*tauA-2*tauM+tauV-.25*tauW)/KDim*(1-1/KDim)+
      p*(1-p)^3 * tauA / KDim*(1-1/KDim)+
      p*(1-p)^3*(BetaJj*BetaJJ/KDim^2+
      (tauA)/KDim*(1-1/KDim)) );
  }
   


  EBjjkBjjK <- EBjjkBjjk*0;
  pModSigmakK <- 2 * pMix^3*(1-pMix) * SigmakK  + pMix^2*(1-pMix)^2 * SigmakK^2;
  for (jj in 1:NCOL(BetaajVSireChain)) {
    EBjjkBjjK[,jj] <- rowSums( (2*BetaajVSireChain[,jj] *Wtsj[[1]] +
      2*BetadominancejVSireChain[,jj] *Wtsj[[3]]) *
      ((2*BetaajVSireChain[,jj] *Wtsj[[1]] +
      2*BetadominancejVSireChain[,jj] *Wtsj[[3]]) %*% pModSigmakK  ))  - 4*taus[,1]*
      rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)) - 4*taus[,3] *
      rowSums(Wtsj[[3]] * (Wtsj[[3]] %*% pModSigmakK));
  }
  EBJJkBJJK <- EBjjkBjjk*0;
  pModSigmakK <- 2 * pMix*(1-pMix)^3 * SigmakK  + pMix^2*(1-pMix)^2 * SigmakK^2;
  for (jj in 1:NCOL(BetaajVSireChain)) {
    EBJJkBJJK[,jj] <- rowSums( (2*BetaajVDamChain[,jj] *WtsJ[[1]] +
      2*BetadominancejVDamChain[,jj] *WtsJ[[3]]) *
      ((2*BetaajVDamChain[,jj] *WtsJ[[1]] +
      2*BetadominancejVDamChain[,jj] *WtsJ[[3]]) %*% pModSigmakK  ))  - 4*taus[,1]*
      rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK)) - 4*taus[,3] *
      rowSums(WtsJ[[3]] * (WtsJ[[3]] %*% pModSigmakK));
  }
  EBjjkBjJK <- EBjjkBjjk*0;
  EBjjkBJjK <- EBjjkBjjk*0;
  pModSigmakK <- pMix^2*(1-pMix)*(1-2*pMix) * SigmakK  + pMix^2*(1-pMix)^2 * SigmakK^2;
  for (jj in 1:NCOL(BetaajVSireChain)) {
    EBjjkBjJK[,jj] <- rowSums( (2*BetaajVSireChain[,jj] *Wtsj[[1]] +
      2*BetadominancejVSireChain[,jj] *Wtsj[[3]]) *
      ((BetaajVSireChain[,jj] *Wtsj[[1]]+BetaajVDamChain[,jj] *WtsJ[[1]] +
        BetamotherjVSireChain[,jj] *Wtsj[[1]]-BetamotherjVDamChain[,jj] *WtsJ[[1]]+
        BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] +
        .5*BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]]) %*% pModSigmakK  ))  - taus[,1]*
      rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK));
    EBjjkBJjK[,jj] <- rowSums( (2*BetaajVSireChain[,jj] *WtsJ[[1]] +
      2*BetadominancejVSireChain[,jj] *Wtsj[[3]]) *
      ((BetaajVSireChain[,jj] *Wtsj[[1]]+BetaajVDamChain[,jj] *WtsJ[[1]] -
        BetamotherjVSireChain[,jj] *Wtsj[[1]]+BetamotherjVDamChain[,jj] *WtsJ[[1]]+
        BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] -
        .5*BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]]) %*% pModSigmakK  ))  - taus[,1]*
      rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK));
  } 
  EBjJkBJJK <- EBjjkBjjk*0;
  EBJjkBJJK <- EBjjkBjjk*0;
  pModSigmakK <- pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK);
  for (jj in 1:NCOL(BetaajVSireChain)) {
    EBjJkBJJK[,jj] <- rowSums( (2*BetaajVDamChain[,jj] *WtsJ[[1]] +
      2*BetadominancejVDamChain[,jj] *WtsJ[[3]]) *
      ((BetaajVSireChain[,jj] *Wtsj[[1]]+BetaajVDamChain[,jj] *WtsJ[[1]] +
        BetamotherjVSireChain[,jj] *Wtsj[[1]]-BetamotherjVDamChain[,jj] *WtsJ[[1]]+
        BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] +
        .5*BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]]) %*% pModSigmakK  ))  - taus[,1]*
      rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK));
    EBJjkBJJK[,jj] <- rowSums( (2*BetaajVDamChain[,jj] *WtsJ[[1]] +
      2*BetadominancejVDamChain[,jj] *WtsJ[[3]]) *
      ((BetaajVSireChain[,jj] *Wtsj[[1]]+BetaajVDamChain[,jj] *WtsJ[[1]] -
        BetamotherjVSireChain[,jj] *Wtsj[[1]]+BetamotherjVDamChain[,jj] *WtsJ[[1]]+
        BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] -
        .5*BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]]) %*% pModSigmakK  ))  - taus[,1]*
      rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK));
  } 
  EBjJkBjJK <- EBjjkBjjk*0;
  EBJjkBJjK <- EBjjkBjjk*0;
  pModSigmakK <- pMix*(1-pMix)^2*( SigmakK^2-2*SigmakK)+ pMix * (1-pMix) * SigmakK;
  for (jj in 1:NCOL(BetaajVSireChain)) {
    EBjJkBjJK[,jj] <- rowSums( (BetaajVSireChain[,jj] *Wtsj[[1]]+BetaajVDamChain[,jj] *WtsJ[[1]] +
        BetamotherjVSireChain[,jj] *Wtsj[[1]]-BetamotherjVDamChain[,jj] *WtsJ[[1]]+
        BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] +
        .5*BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]]) *
      ((BetaajVSireChain[,jj] *Wtsj[[1]]+BetaajVDamChain[,jj] *WtsJ[[1]] +
        BetamotherjVSireChain[,jj] *Wtsj[[1]]-BetamotherjVDamChain[,jj] *WtsJ[[1]]+
        BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] +
        .5*BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]]) %*% pModSigmakK  ))  - 2*taus[,1]*
      (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
       rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK))) -  2*taus[,2]*
      (rowSums(WtsJ[[2]] * (WtsJ[[2]]%*% pModSigmakK))+
       rowSums(Wtsj[[2]] * (Wtsj[[2]]%*% pModSigmakK)))-  taus[,4]*
      (rowSums(WtsJ[[4]] * (WtsJ[[4]]%*% pModSigmakK)))- taus[,5]*
      (rowSums(WtsJ[[5]] * (WtsJ[[5]]%*% pModSigmakK)))
    EBJjkBJjK[,jj] <- rowSums( (BetaajVSireChain[,jj] *Wtsj[[1]]+BetaajVDamChain[,jj] *WtsJ[[1]] -
        BetamotherjVSireChain[,jj] *Wtsj[[1]]+BetamotherjVDamChain[,jj] *WtsJ[[1]]+
        BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] -
        .5*BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]]) *
      ((BetaajVSireChain[,jj] *Wtsj[[1]]+BetaajVDamChain[,jj] *WtsJ[[1]] -
        BetamotherjVSireChain[,jj] *Wtsj[[1]]+BetamotherjVDamChain[,jj] *WtsJ[[1]]+
        BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] -
        .5*BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]]) %*% pModSigmakK  ))  - 2*taus[,1]*
      (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
       rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK))) - 2*taus[,2]*
      (rowSums(WtsJ[[2]] * (WtsJ[[2]]%*% pModSigmakK))+
       rowSums(Wtsj[[2]] * (Wtsj[[2]]%*% pModSigmakK)))-  taus[,4]*
      (rowSums(WtsJ[[4]] * (WtsJ[[4]]%*% pModSigmakK)))- taus[,5]*
      (rowSums(WtsJ[[5]] * (WtsJ[[5]]%*% pModSigmakK)))
  } 
  EBjJkBJjK <- EBjjkBjjk*0;
  EBjjkBJJK <- EBjjkBjjk*0;
  pModSigmakK <- pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK);
  for (jj in 1:NCOL(BetaajVSireChain)) {
    EBjJkBjJK[,jj] <- rowSums( (BetaajVSireChain[,jj] *Wtsj[[1]]+BetaajVDamChain[,jj] *WtsJ[[1]] +
        BetamotherjVSireChain[,jj] *Wtsj[[1]]-BetamotherjVDamChain[,jj] *WtsJ[[1]]+
        BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] +
        .5*BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]]) *
      ((BetaajVSireChain[,jj] *Wtsj[[1]]+BetaajVDamChain[,jj] *WtsJ[[1]] -
        BetamotherjVSireChain[,jj] *Wtsj[[1]]+BetamotherjVDamChain[,jj] *WtsJ[[1]]+
        BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] -
        .5*BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]]) %*% pModSigmakK))-taus[,1]*
      (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
       rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))-taus[,2]*
      (rowSums(WtsJ[[2]] * (WtsJ[[2]]%*% pModSigmakK))+
       rowSums(Wtsj[[2]] * (Wtsj[[2]]%*% pModSigmakK)))-taus[,4]*
      (rowSums(WtsJ[[4]] * (WtsJ[[4]]%*% pModSigmakK)))-taus[,5]*
      (rowSums(WtsJ[[5]] * (WtsJ[[5]]%*% pModSigmakK)))
    EBjjkBJJK[,jj] <- rowSums( (2*BetaajVSireChain[,jj]*Wtsj[[1]]+
        2*BetadominancejVSireChain[,jj] *Wtsj[[1]]) *
      ((2*BetaajVDamChain[,jj] *WtsJ[[1]] +
        2*BetadominancejVDamChain[,jj] *WtsJ[[1]]) %*% pModSigmakK  ));
  }   
  VarWithCov <- VarNoCov  + EBjjkBjjK + EBJJkBJJK + EBjJkBjJK + 
    EBJjkBJjK +
    EBjjkBjJK + EBjjkBJjK + EBjjkBJJK +
    EBjJkBJjK + EBjJkBJJK +
    EBJjkBJJK;
  ListVarWithCov[[kk]] <- VarWithCov;
  ListSumWithCov[[kk]] <- summary(as.mcmc(VarWithCov));
 }
 NoiseSummary <- summary(as.mcmc(taus[,6]));
 if (this$.SexModel <= 0) {
  return(list(ListSumWithCov=ListSumWithCov, ListSumNoCov=ListSumNoCov, 
    ListVarWithCov=ListVarWithCov,
    ListVarNoCov=ListVarNoCov, 
     NoiseSummary=NoiseSummary, NoiseChains=taus[,6], KDim=KDim));
  }
  BetajjChain <- 2*BetaajVSireChain + 2*BetadominancejVSireChain;
  BetajJChain <- BetaajVSireChain + BetaajVDamChain + 
     BetamotherjVSireChain - BetamotherjVDamChain +
     BetaSymCrossjkVMeChain + .5 * BetaASymCrossjkDkjVMeChain;
  BetaJjChain <- BetaajVSireChain + BetaajVDamChain - 
     BetamotherjVSireChain + BetamotherjVDamChain +
     BetaSymCrossjkVMeChain - .5 * BetaASymCrossjkDkjVMeChain;
  BetaJJChain <- 2*BetaajVDamChain + 2*BetadominancejVDamChain;
  
  MeanChains = pMix^2*BetajjChain + pMix*(1-pMix) * BetajJChain +
    pMix*(1-pMix) * BetaJjChain + (1-pMix)^2 * BetaJJChain;

    ListVarWithSexWithCovChain <- list();
    ListVarWithSexWithCovSummary <- list();
    ListVarWithSexNoCovChain <- list();
    ListVarWithSexNoCovSummary <- list();
    for (ii in 1:length(ListVarWithCov)) {
        IRD <- NCOL(ListVarWithCov[[ii]])/2; 
        ListVarWithSexWithCovChain[[ii]] <- SexMix*ListVarWithCov[[ii]][,1:IRD] +
      (1-SexMix) * ListVarWithCov[[ii]][,IRD+(1:IRD)] +
        SexMix*(1-SexMix)*(MeanChains[,1:IRD]-MeanChains[,IRD+(1:IRD)])^2;
        try(names(ListVarWithSexWithCovChain)[ii] <- paste("KDim:", KDim[ii], sep=""))
        try(colnames(ListVarWithSexWithCovChain[[ii]]) <- paste("S:B:j:", Sires,":J:", Dams, sep=""));
        try(ListVarWithSexWithCovChain[[ii]] <- as.mcmc(ListVarWithSexWithCovChain[[ii]]));
       try(ListVarWithSexWithCovSummary[[ii]] <- summary(ListVarWithSexWithCovChain[[ii]]));

       IRD <- NCOL(ListVarNoCov[[ii]])/2; 
        ListVarWithSexNoCovChain[[ii]] <- SexMix*ListVarNoCov[[ii]][,1:IRD] +
      (1-SexMix) * ListVarNoCov[[ii]][,IRD+(1:IRD)] +
        SexMix*(1-SexMix)*(MeanChains[,1:IRD]-MeanChains[,IRD+(1:IRD)])^2;
        try(names(ListVarWithSexNoCovChain)[ii] <- paste("KDim:", KDim[ii], sep=""))
        try(colnames(ListVarWithSexNoCovChain[[ii]]) <- paste("S:B:j:", Sires,":J:", Dams, sep=""));
        try(ListVarWithSexNoCovChain[[ii]] <- as.mcmc(ListVarWithSexNoCovChain[[ii]]));
       try(ListVarWithSexNoCovSummary[[ii]] <- summary(ListVarWithSexNoCovChain[[ii]]));
    }

  return(list(ListSumWithCov=ListSumWithCov, ListSumNoCov=ListSumNoCov, 
    ListVarWithCov=ListVarWithCov,
    ListVarNoCov=ListVarNoCov, 
     NoiseSummary=NoiseSummary, 
     ListVarWithSexWithCovChain=ListVarWithSexWithCovChain, 
     ListVarWithSexWithCovSummary=ListVarWithSexWithCovSummary, 
     ListVarWithSexNoCovSummary = ListVarWithSexNoCovSummary,
     ListVarWithSexNoCovChain = ListVarWithSexNoCovChain,
     NoiseChain=taus[,6], MeanChains=MeanChains, KDim=KDim)); 
 }
);

setMethodS3("SpeculativeWeightHeritabilitySimulation", "DiallelOb", function (this,
  UseFixed = FALSE, KDim = 1:10, 
  pMix = .5, SigmakK=0, SexMix=.5,UseMyWeightFunction =DefaultUseMyWeightFunction,
  SigmakKFunction = NULL, ListSigmakK=NULL, ...) {
  if (!exists("TrueVector")) { TrueVector = NULL; }
  if (!exists("UseFixed")) { UseFixed=FALSE; }
  if (!exists("thin")) { thin = 1;}
  if (!exists("KDim")) { KDim = 1:10; }
  if (!exists("pMix")) { pMix = .5; }
  if (!exists("SexMix")) { SexMix = .5; }
  if (!exists("SigmakK") || is.null(SigmakK) || 
    (length(SigmakK) == 1 && SigmakK[1] <= -1/KDim) ||
    any(SigmakK >= 1) ||
    (is.matrix(SigmakK) && mean(SigmakK[lower.tri(SigmakK)]) <= -1/KDim)) {
    SigmakK <- 0;    
  }
  if (!exists("barSigmakKSq") || is.null(barSigmakKSq) || barSigmakKSq < 0 ||
    barSigmakKSq >= 1) {
    barSigmakKSq <- 0;    
  }
  FakeChains = NULL;  FakeX = NULL;
  LSText <- "
  FakeChains = this$getPosteriorPredictionsMeanChains();
  FakeCoda = FakeChains;
  ##FakeX = this$PostKeeper$FakeX;
  ";
  try(eval(parse(text=LSText)));
  try(CodaChains <- this$getCent.chains());
  if (this$DoFirstCenter == FALSE) {
    NewCodaChains <- list();
    for (ii in 1:length(this$.cent.chains)) {
      NN <- matrix(as.numeric(this$.cent.chains[[ii]]), NROW(this$.cent.chains[[ii]]),
        NCOL(this$.cent.chains[[ii]]));
      colnames(NN) <- colnames(this$CodaChains[[1]])
      NewCodaChains[[ii]] <- as.mcmc(NN);
    }
    CodaChains <- as.mcmc.list(NewCodaChains);
  }
  if (is.null(CodaChains) || length(CodaChains) <= 0 || length(CodaChains[[1]]) <= 0) {
     print(paste("PosteriorDSq[", this$.iOb, 
       ": Hey, Cent.Chains Doesn't work why is that?", sep="")); flush.console();
  }
  DD <- matrix(rep(1:this$.numj, this$.numj), this$.numj, this$.numj);
  Sires <- t(DD)[lower.tri(DD)];
  Dams <- DD[lower.tri(DD)];
  ## this <-AFD$AllDiallelObs[[1]]
  ASN <- colnames(this$CodaChains[[1]]);
  Gets <-c("aj:", "Gender:aj", "motherj", "Gender:motherj", 
    "dominancej", "Gender:dominancej", "SymCrossjk", "Gender:SymCrossjk", "ASymCrossjkDkj",
    "Gender:ASymCrossjkDkj");
  if (this$.SexModel <= 0) {
    Gets <- Gets[substr(Gets, 1, nchar("Gender"))!="Gender"];
  }
  sNGets <- strsplit(Gets, ":");
  for (ii in 1:length(Gets)) { sNGets[[ii]] <-paste(paste(sNGets[[ii]],  collapse=""), "V", sep="");}
  sNGets <-unlist(sNGets)
  for (ii in 1:length(Gets)) {
    print(paste("Assemble chain dam/sire ", Gets[ii], sep="")); flush.console();
    ATT <- paste(sNGets[ii],  " = ",
     "(1:length(ASN))[substr(ASN,1,nchar(\"", Gets[ii], "\"))== \"", 
       Gets[ii],"\"];", sep="");
    eval(parse(text=ATT))
    if (ii <=6 ){
      ATT <- paste( "ASSMe = strsplit(ASN[", sNGets[ii], "], \":\");
        if (length(ASSMe) <= 0) {
          ASSMe <- rep(-1, this$.numj);
          ", sNGets[ii], "Dam <- rep(-1, length(Dams));
          ", sNGets[ii], "Sire <- rep(-1, length(Sires));
        } else {
        KTT <- rep(0, length(", sNGets[ii], "));
        for (tt in 1:length(KTT)) {
          KTT[tt] = as.numeric(ASSMe[[tt]][length(ASSMe[[tt]])]);
        }
        ", sNGets[ii] ,"Dam = rep(0, length(Dams));
        ", sNGets[ii] ,"Sire = rep(0, length(Sires)); 
        for (tt in 1:length(Dams)) {
          ", sNGets[ii] ,"Dam[tt] = ", sNGets[ii], "[KTT==Dams[tt]];
          ", sNGets[ii] ,"Sire[tt] = ", sNGets[ii], "[KTT==Sires[tt]];
        }}       
        Beta", sNGets[ii], "DamChain <- StackAndGetMe(this$cent.chains, ", 
          sNGets[ii], "Dam, this$.AFD$burnin, enditer = NULL, OutLimit=-1)
        Beta", sNGets[ii], "SireChain <- StackAndGetMe(this$cent.chains, ", 
          sNGets[ii], "Sire, this$.AFD$burnin, enditer = NULL, OutLimit=-1)
        ", sep="");
        eval(parse(text=ATT));
        if (Gets[ii] == "dominancej"){
          AKK = (1:length(ASN))[ASN=="BetaInbred:Av"];
          BetaInbred = StackAndGetMe(this$cent.chains, rep(AKK, NCOL(BetadominancejVDamChain)),
            this$.AFD$burnin, enditer = NULL, OutLimit=-1);
          BetadominancejVDamChain = BetadominancejVDamChain +  .5*BetaInbred;
          BetadominancejVSireChain = BetadominancejVSireChain +  .5*BetaInbred;          
        }
        if (Gets[ii] == "Genderdominancej"){
          AKK = (1:length(ASN))[ASN=="BetaInbred:Gender:Av"];
          BetaGenderInbred = StackAndGetMe(this$cent.chains, rep(AKK, NCOL(BetaGenderdominancejVDamChain)),
            this$.AFD$burnin, enditer = NULL, OutLimit=-1);
          BetaGenderdominancejVDamChain = BetaGenderdominancejVDamChain +  BetaGenderInbred;
          BetaGenderdominancejVSireChain = BetaGenderdominancejVSireChain +  BetaGenderInbred;          
        }
    } else {
        ATT <- paste( "ASSMe = strsplit(ASN[", sNGets[ii], "], \":\");
        if (length(ASSMe) > 0) {
        KTT1 <- rep(0, length(", sNGets[ii], "));
        KTT2 <- rep(0, length(", sNGets[ii], "));
        for (tt in 1:length(KTT2)) {
          KTT2[tt] = as.numeric(ASSMe[[tt]][length(ASSMe[[tt]])]);
          PS <- unlist(strsplit(ASSMe[[tt]][length(ASSMe[[tt]])-1], \";\"));
          KTT1[tt] = as.numeric(PS[1]);
        }
        ", sNGets[ii] , "Me = rep(0, length(Dams));
        for (tt in 1:length(Dams)) {
          ", sNGets[ii] ,"Me[tt] = ", sNGets[ii], "[KTT1==Dams[tt]&KTT2==Sires[tt]];
        }
        } else {
          ", sNGets[ii], "Me <- rep(-1, length(Dams));   
        }
        Beta", sNGets[ii], "MeChain <- StackAndGetMe(this$cent.chains, ", 
          sNGets[ii], "Me, this$.AFD$burnin, enditer = NULL, OutLimit=-1)      
        ", sep="");
        eval(parse(text=ATT))           
    }
  }
  if (this$.SexModel >= 1) {
  NGS<- sNGets[substr(sNGets, 1, nchar("Gender"))!="Gender"];
   for(ii in 1:length(NGS)){
    if (ii <=3) {
     ATT <- paste("
       Beta", NGS[ii], "DamChain <- cbind(Beta", NGS[ii], "DamChain + ",
         ".5*BetaGender", NGS[ii], "DamChain, Beta", NGS[ii], "DamChain - ",
         ".5*BetaGender", NGS[ii], "DamChain);
       Beta", NGS[ii], "SireChain <- cbind(Beta", NGS[ii], "SireChain + ",
         ".5*BetaGender", NGS[ii], "SireChain, Beta", NGS[ii], "SireChain - ",
         ".5*BetaGender", NGS[ii], "SireChain);
     ",sep="");
     eval(parse(text=ATT))           
   } else {
     ATT <- paste("
       Beta", NGS[ii], "MeChain <- cbind(Beta", NGS[ii], "MeChain + ",
         ".5*BetaGender", NGS[ii], "MeChain, Beta", NGS[ii], "MeChain - ",
         ".5*BetaGender", NGS[ii], "MeChain);
     ",sep="");
     eval(parse(text=ATT))      
   }
  }} else {
    NGS <- sNGets;
  }
  
 
  LLN <- colnames(CodaChains[[1]]);
  tauALoc <- (1:length(LLN))[LLN %in% c("tau:aj", "tauaj")];
  tauMLoc <- (1:length(LLN))[LLN %in% c("tau:motherj", "taumotherj")];
  tauBLoc <- (1:length(LLN))[LLN %in% c("tau:dominancej", "taudominancej")];
  tauVLoc <- (1:length(LLN))[LLN %in% c("tau:SymCrossjk", "tauSymCrossjk")];
  tauWLoc <- (1:length(LLN))[LLN %in% c("tau:ASymCrossjkDkj", "tauASymCrossjkDkj")];
  LLs <- c("A", "M", "B", "V", "W");
   for (ss in 1:length(LLs)) {
     MyT <- paste(" if (length(tau", LLs[ss], "Loc) <= 0) { ",
       " tau", LLs[ss], "Loc <- -1; } ", sep="");
     try(eval(parse(text=MyT)));
   }
  sigmaLoc <- (1:length(LLN))[LLN %in% c("Sigma:1", "sigma:1", "Sigma", "sigma")];
  taus <-  StackAndGetMe(CodaChains, c(tauALoc,tauMLoc,tauBLoc, tauVLoc, tauWLoc, sigmaLoc), this$.AFD$burnin, enditer = NULL)
  
  if (FALSE) {
       BetaASymCrossjkDkjVMeChain <-  BetaASymCrossjkDkjVMeChain*0;
       BetadominancejVDamChain <- BetadominancejVDamChain*0;         
       BetadominancejVSireChain <- BetadominancejVSireChain * 0;     
       BetaGenderajVDamChain <- BetaGenderajVDamChain*0;           
       BetaGenderajVSireChain <- BetaGenderajVSireChain*0;
       BetaGenderASymCrossjkDkjVMeChain <- BetaGenderASymCrossjkDkjVMeChain * 0;
       BetaGenderdominancejVDamChain <- BetaGenderdominancejVDamChain*0;
       BetaGenderdominancejVSireChain <- BetaGenderdominancejVSireChain*0;  
       BetaGendermotherjVDamChain <- BetaGendermotherjVDamChain*0; 
       BetaGendermotherjVSireChain<-  BetaGendermotherjVSireChain*0;   
       BetaGenderSymCrossjkVMeChain <- BetaGenderSymCrossjkVMeChain*0;
       BetamotherjVDamChain <-  BetamotherjVDamChain*0; 
       BetamotherjVSireChain <-  BetamotherjVSireChain*0;          
       BetaSymCrossjkVMeChain <- BetaSymCrossjkVMeChain*0;
       jj <- 21;
  }
  ListVarWithCov <- list();
  ListSumWithCov <- list();
  for (kk in 1:length(KDim)) {
    AKDim <- KDim[[kk]]
    if (exists("SigmakKFunction") && !is.null(SigmakKFunction) &&
      is.function(SigmakKFunction)) {
      try(SigmakK <- SigmakKFunction(AKDim));
    } else if (exists("ListSigmakK") && !is.null(ListSigmakK) &&
     is.function(ListSigmakK)) {
      try(SigmakK <- ListSigmakK(AKDim));
    } else if (exists("ListSigmakK") && !is.null(ListSigmakK) &&
      is.list(ListSigmakK)) {
      try(SigmakK <- ListSigmakK[[kk]]);
    }
   
    N <- NROW(BetaajVDamChain);
    Wtsj <- list();  WtsJ <- list();
    for (ii in 1:5) {
      Wtsj[[ii]] <- UseMyWeightFunction(N, AKDim, taus[,ii])
      WtsJ[[ii]] <- UseMyWeightFunction(N, AKDim, taus[,ii])
    }
    if (length(SigmakK) == 1) {
     SigmakK <-  matrix(SigmakK, NCOL(Wtsj[[1]]), NCOL(Wtsj[[1]]));
     diag(SigmakK) <- 0;
    } else if (NCOL(SigmakK) ==  NCOL(Wtsj[[1]]) && 
      NCOL(Wtsj[[1]]) == NROW(SigmakK)) {
      diag(SigmakK) <- 0;
    } else {
      print("Error SigmakK supplied is in Error!")
    } 
    
    ## This text was automatically generated
    try(eval(parse(text=PutInVaritabilityText())));
    for (jj in 1:NCOL(BetaajVSireChain)) {
      Varitability[,jj,] <- Varitability[,jj,]  /
        rowSums(Varitability[,jj,]   +  taus[,6] );
    }
    ListVarWithCov[[kk]] <- Varitability;
    ListSumWithCov[[kk]] <- list();
    for (jj in 1:5) {
      try(ListSumWithCov[[kk]][[jj]] <- summary(as.mcmc(Varitability[,,jj])));
    }

 }
 NoiseSummary <- summary(as.mcmc(taus[,6]));
 if (this$.SexModel <= 0) {
  return(list(ListSumWithCov=ListSumWithCov, 
    ListVarWithCov=ListVarWithCov,
     NoiseSummary=NoiseSummary, NoiseChains=taus[,6], KDim=KDim));
  }
  BetajjChain <- 2*BetaajVSireChain + 2*BetadominancejVSireChain;
  BetajJChain <- BetaajVSireChain + BetaajVDamChain + 
     BetamotherjVSireChain - BetamotherjVDamChain +
     BetaSymCrossjkVMeChain + .5 * BetaASymCrossjkDkjVMeChain;
  BetaJjChain <- BetaajVSireChain + BetaajVDamChain - 
     BetamotherjVSireChain + BetamotherjVDamChain +
     BetaSymCrossjkVMeChain - .5 * BetaASymCrossjkDkjVMeChain;
  BetaJJChain <- 2*BetaajVDamChain + 2*BetadominancejVDamChain;
  
  MeanChains = pMix^2*BetajjChain + pMix*(1-pMix) * BetajJChain +
    pMix*(1-pMix) * BetaJjChain + (1-pMix)^2 * BetaJJChain;

    ListVarWithSexWithCovChain <- list();
    ListVarWithSexWithCovSummary <- list();

    for (ii in 1:length(ListVarWithCov)) {
        IRD <- NCOL(ListVarWithCov[[ii]])/2; 
        ListVarWithSexWithCovChain[[ii]] <- SexMix*ListVarWithCov[[ii]][,1:IRD] +
      (1-SexMix) * ListVarWithCov[[ii]][,IRD+(1:IRD)] +
        SexMix*(1-SexMix)*(MeanChains[,1:IRD]-MeanChains[,IRD+(1:IRD)])^2;
        try(names(ListVarWithSexWithCovChain)[ii] <- paste("KDim:", KDim[ii], sep=""))
        try(colnames(ListVarWithSexWithCovChain[[ii]]) <- paste("S:B:j:", Sires,":J:", Dams, sep=""));
        try(ListVarWithSexWithCovChain[[ii]] <- as.mcmc(ListVarWithSexWithCovChain[[ii]]));
       try(ListVarWithSexWithCovSummary[[ii]] <- summary(ListVarWithSexWithCovChain[[ii]]));
    }

  return(list(ListSumWithCov=ListSumWithCov,
    ListVarWithCov=ListVarWithCov,
     NoiseSummary=NoiseSummary, 
     ListVarWithSexWithCovChain=ListVarWithSexWithCovChain, 
     ListVarWithSexWithCovSummary=ListVarWithSexWithCovSummary, 
     ListVarWithSexNoCovSummary = ListVarWithSexNoCovSummary,
     ListVarWithSexNoCovChain = ListVarWithSexNoCovChain,
     NoiseChain=taus[,6], MeanChains=MeanChains, KDim=KDim)); 
 }
);
 
 TUseWeightFunction <-function(N, KDim, tauIn, TDF = 4) {
   if (length(tauIn) == N) {
     MyMat <- matrix(TDF/ rchisq(N*KDim, TDF), N, KDim);
     MyMat <- MyMat / rowSums(MyMat);
     return(MyMat);
   }
   MyMat <- matrix(TDF/ rchisq(N*KDim, TDF), N, KDim);
   MyMat <- MyMat / rowSums(MyMat);
   return(MyMat);
 }
 SpikeUseWeightFunction <-function(N, KDim, tauIn, pi0=.5) {
   if (length(tauIn) == N) {
     MyMat <- matrix(rbinom(N*Kdim,0,1-pi0), N, KDim);
     MyMat[rowSums(MyMat)==0,1] <- 1;
     MyMat <- MyMat / rowSums(MyMat);
     return(MyMat);
   }
   MyMat <- matrix(rbinom(N*Kdim,0,1-pi0), N, KDim);
   MyMat[rowSums(MyMat)==0,1] <- 1;
   MyMat <- MyMat / rowSums(MyMat);
   return(MyMat);
 }
##
## Give Betajj, BetajJ, BetaJj
CalcMyWeightFunction <- function(Betaja, BetaJa, Betajb, BetaJb, 
  Betajm, BetaJm, Betajv, BetaJv, Betajw, BetaJw,
  SigmakK, SigmakKSq, KDim,
  tauA, tauM, tauB, tauV, tauW,
  UseMyWeightFunction) {
  if (length(KDim) >= 2 && length(Betajj) >= 2) {
    MyReturn <- list();
    for (ii in 1:length(KDim)) {
      MyReturn[[ii]] <- CalcMyWeightFunction(
      Betaja, BetaJa, Betajb, BetaJb, 
      Betajm, BetaJm, Betajv, BetaJv, Betajw, BetaJw,
      SigmakK, SigmakKSqq, KDim[ii],
        tauA, tauM, tauB, tauV, tauW);
      names(MyReturn)[ii] <- paste("KDim:",KDim[ii], sep="");
    }
    return(MyReturn);
  }
  if (dim(Betaja) == 2 && NROW(Betaja)  >= 1) {
    
  }
   ##KDim <- NROW(SigmakK);
   FirstFunction <- p^2*(1-p^2)  * (
     Betajj^2/KDim + 2 * (tauA+tauB) * (1-1/KDim) ) +
     p*(1-p) * (1-p*(1-p)) * (
       BetajJ^2/KDim + 2 * (tauA + tauM + tauV + .25*tauW)* (1-1/KDim)  +
       BetaJj^2/KDim + 2 * (tauA + tauM + tauV + .25*tauW)* (1-1/KDim) 
     ) +
     (1-p)^2*(1-(1-p)^2)*    
     (BetaJJ^2/KDim + 2 * (tauA+tauB) * (1-1/KDim));
   SecondFunction <- -KDim*2*(
      p^2*Betajj*(p*(1-p)*BetajJ+p*(1-p)*BetaJj+(1-p)^2*BetaJJ)/KDim^2 +
      2*tauA / KDim*(1-1/KDim)*p^2*(2*p*(1-p)+(1-p)^2) +
      p^2*BetajJ*((1-p)^2*BetaJj+p*(1-p)*BetaJJ)/KDim^2+
      p^2*(1-p)^2*(2*tauA-2*tauM+tauV-.25*tauW)/KDim*(1-1/KDim)+
      p^3*(1-p) * tauA / KDim*(1-1/KDim)+
      p^3*(1-p)*(BetaJj*BetaJJ/KDim^2+
      (tauA)/KDim*(1-1/KDim)) );
   
   ThirdFunction <- (KDim^2-KDim)*
     ((2*p^3*(1-p) * barSigmakK + p^2*(1-p)^2 * barSigmakKSq) *(
       Betajj^2/KDim^2 - 2*(tauA+tauB)/KDim^2) +
      (2*p*(1-p)^3 * barSigmakK + p^2*(1-p)^2 * barSigmakKSq) *(
       BetaJJ^2/KDim^2 - 2*(tauA+tauB)/KDim^2
      )
     );
   FourthFunction <- (KDim^2-KDim)* 
     (p^2*(1-p)^2 *barSigmakKSq+p^2*(1-p)*(1-2*p)* barSigmakK) *
     (Betajj*BetajJ/KDim^2 + Betajj*BetaJj/KDim^2  - 2 * tauA/KDim^2);
   FifthFunction <- (KDim^2-KDim)*p*(1-p)^2*(2*p-1-p*barSigmakK)*
     (BetajJ*BetaJJ/KDim^2 + BetaJj*BetaJJ/KDim^2 - 2 * tauA/KDim^2);
   SixthFunction <- (KDim^2-KDim) * (p^2 * (1-p)^2 *(barSigmakKSq-2*barSigmakK)+
     p * (1-p)* barSigmakK)*
     ( BetajJ*BetajJ/KDim^2-2*(2*tauA+2*tauM+tauV+.25*tauW)/KDim^2+
       BetaJj*BetaJj/KDim^2);
    LastFunction <- (KDim^2-KDim)* p^2*(1-p)^2*((barSigmakKSq)-2*barSigmakK) *
      (Betajj*BetaJJ/KDim^2 +
       BetajJ*BetaJj/KDim^2- (2*tauA-2*tauM+tauV-.25*tauW)/KDim^2);
    Total <- FirstFunction+SecondFunction+ThirdFunction+FourthFunction+
      FifthFunction+SixthFunction+LastFunction;
    ## Test KDim = 0;
    ##(.25*(Betajj^2+BetajJ^2+BetaJj^2+BetaJJ^2)-(.25*(Betajj+BetajJ+BetaJj+BetaJJ))^2);
    return(Total)
}
