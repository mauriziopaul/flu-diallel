

setMethodS3("AutoMFFunction", "DiallelOb", function(this, burnin = 1, thin = 1,
  AFD = NULL,...) {
  if (is.null(AFD)) { 
    AFD <- this$.AFD;
  }
  if (!is.null(this$DoFirstCenter) && 
    ((is.logical(this$DoFirstCenter) &&
       this$DoFirstCenter == TRUE) ||
      (is.numeric(this$DoFirstCenter) && this$DoFirstCenter >= 1)
     )) {  
    this$.cent.chains <- NULL;
    ALLV <- (1:NCOL(this$CodaChains[[1]]));
    IDL <- list();
    NewNames <- list();
    if (is.null(AFD$AllCenteredRandomVariables) ||
      length(AFD$AllCenteredRandomVariables) <= 0) { 
      AllCenteredRandomVariables <- BayesDiallel:::.DefaultAllRandomVariables;
    } else {
       AllCenteredRandomVariables <- AFD$AllCenteredRandomVariables;   
    }
    Anyjj <- 0;
    for (jj in 1:length(AllCenteredRandomVariables)) {
      ARV <- AllCenteredRandomVariables[jj];
      if (any(substr(colnames(this$CodaChains[[1]]), 1, nchar(ARV)) == ARV)) {
      Anyjj <- Anyjj+1;
      IDL[[Anyjj]] <- (1:NCOL(this$CodaChains[[1]]))[
       substr(colnames(this$CodaChains[[1]]), 1, nchar(ARV)) == ARV];
      ALLV <- ALLV[!(ALLV %in% IDL[[Anyjj]])];
      NewNames[[Anyjj]] <- colnames(this$CodaChains[[1]])[IDL[[Anyjj]]];
      if (AllCenteredRandomVariables[jj] %in% 
        c("SymCrossjk", "Gender:SymCrossjk", "ASymCrossjkDkj", "Gender:ASymCrossjkDkj")) {
        NewNames[[Anyjj]] <- c(NewNames[[Anyjj]], paste(ARV, ":j", this$.numj, ";k:", 
          this$.numj-1, sep=""));
      } else if  (AllCenteredRandomVariables[jj] %in% 
        c("AllCrossjk", "Gender:AllCrossjk")) {
        NewNames[[Anyjj]] <- c(NewNames[[Anyjj]], paste(ARV, ":j", this$.numj, ";k:", 
          this$.numj-1, sep=""));        
      } else {
        NewNames[[Anyjj]] <- c(NewNames[[Anyjj]], paste(ARV, ":", this$.numj, sep="")); 
      }
      }
    }
    NewList <- list(); 
    ALLVLess <- ALLV[ALLV < min(unlist(IDL))];
    ALLVMore <- ALLV[ALLV > min(unlist(IDL))];   
    for (tt in 1:length(this$CodaChains)) {
      NewM <- matrix(0, NROW(this$CodaChains[[1]]), 
        length(ALLVLess) + length(unlist(NewNames)) + length(ALLVMore));
      ABT <- 0;
      NewM[, 1:length(ALLVLess)] <- this$CodaChains[[tt]][, ALLVLess];
      ABT <- ABT + length(ALLVLess);
      AllNames <- colnames(this$CodaChains[[tt]])[ALLVLess];
      for (jj in 1:length(NewNames)) {
        PL <- length(NewNames[[jj]]);
        AM <- MakeAM(PL)
        NewM[, ABT + 1:length(NewNames[[jj]])] <- this$CodaChains[[tt]][, IDL[[jj]]] %*% t(AM);
        ABT <- ABT + length(NewNames[[jj]]);
        AllNames <- c(AllNames, NewNames[[jj]]);
      }
      NewM[,ABT+1:length(ALLVMore)] <- this$CodaChains[[tt]][, ALLVMore];
      AllNames <- c(AllNames, colnames(this$CodaChains[[tt]])[ALLVMore]);
      colnames(NewM) <- AllNames;
      try(NewM <- as.mcmc(NewM));
      NewList[[tt]] <- NewM;
    } 
    try(NewList <- as.mcmc.list(NewList));
    try(this$.cent.chains <- NewList);
    
    
    return(this$.cent.chains);  
  }
  if (is.null(AFD)) {  AFD = this$.AFD; }
  
  AllR = AFD$.AllRandomVariables;
  if (is.null(AllR)) {
    SPT <- colnames(this$CodaChains[[1]]);
    SPT <- SPT[substr(SPT,1,nchar("tau")) == "tau"];
    if (length(SPT) > 0) {
      AllR <- substr(SPT, nchar("tau:")+1, nchar(SPT));
    }
  }
  AL = list(); AC = 0;
  for (ii in 1:length(this$CodaChains)) {
    NN = colnames(this$CodaChains[[ii]]);
    if (is.null(NN)) {
    
    } else {
      MyL = list();
      for (jj in 1:length(AllR)) {
         MyL[[jj]] = (1:length(NN))[ substr(NN, 1, nchar(AllR[jj])) == AllR[jj] ];
      }
      NK =  sort(unique(unlist(MyL)));
      ABD = as.mcmc(as.matrix(this$CodaChains[[ii]]));
      if (burnin > 1) {
        if (burnin > NROW(ABD)) {
          print(paste("AutoMFFunction: What is this?",
            "  ABD is not large enough! for burnin = ", burnin, sep="")); flush.console();
        }
        try(ABD <- ABD[burnin:NROW(ABD),]);
      }
      if (thin > 1 && round(thin) == thin) {
        st = thin * (1:(NROW(ABD) %/% thin));
        ABD = as.mcmc(ABD[st,]);
      }
      colnames(ABD) = NN;
      for (jj in 1:length(AllR)) {
        if (length(MyL[[jj]]) > 1) {
          try(ABD[,MyL[[jj]]] <- ABD[,MyL[[jj]]] - rowMeans(ABD[,MyL[[jj]] ] ) );
          try(NN[ MyL[[jj]] ] <- as.vector(
            paste( NN[MyL[[jj]] ], " - mean(", AllR[jj], ")", sep="")));
          colnames(ABD) = NN;
        }
      }
      AC = AC +1;
      try(AL[[AC]] <- as.mcmc(ABD));
    }
  }
  
  
  ## Unfortunately deprecation of MCMC list is a big problem for this function
  ##  I do not know whether AL can be made into MCMC or MCMC list!
  if (!is.null(AL)) {  try(AL <- as.mcmc.list(AL), silent=TRUE); }
  return(AL);

});

setMethodS3("getChains", "DiallelOb", function(this,...) {
  if (!is.null(this$.cent.chains)) {
    return(this$.cent.chains);
  }
  try(this$.cent.chains <- AutoMFFunction(this, AFD=this$.AFD));
  return(this$.cent.chains);
});
setMethodS3("getBSCent.chains", "DiallelOb", function(this, ...) {
  if(is.null(this$.AFD$.BS)) {
    tryCatch("getBSCent.chains: Error: BS is NULL!")
  } 
  AFD <- this$.AFD;
  BSAFD <- this$.AFD$.BS
  if (is.null(BSAFD$CenteredColumns) || length(BSAFD$CenteredColumns) <= 0) {
    return(this$getBSUnCent.chains());
  }
  NewCodaList <- list();
     RenameDeCenteredBSAFDCoda(BSAFD=this$.AFD$.BS);
     DCList <- this$.AFD$.BS$DeCenteredCodaList;
     eval(parse(text=SetGText("DCList", "globalenv()", S=1)));
     nTau <- sum(substr(colnames(DCList[[1]]), 1,nchar("tau")) == "tau");
     nBeta <- min((1:NCOL(DCList[[1]]))[substr(colnames(DCList[[1]]), 1,nchar("tau")) %in% c("Tau", "tau")])-1; 
     NeedNames <- 1:(nTau+nBeta+1);         
     OCNames <- this$.AFD$.BS$OtherDeCenterCodaNames;
  if (is.null(OCNames) || length(OCNames) <= 0) {
    print("getBSCent.chains: oh no OCNames is NULL!"); flush.console();
  }
     for (ii in 1:length(DCList)) {
       NewCodaList[[ii]] <- matrix(DCList[[ii]][,NeedNames],
       NROW(DCList[[1]]), length(NeedNames));     
       colnames(NewCodaList[[ii]]) = OCNames[NeedNames];
       NewCodaList[[ii]] <- as.mcmc(NewCodaList[[ii]]);
     }
     DoRawAnyWay = FALSE;
     ACodaList = NewCodaList;
     return(ACodaList);
});
    
setMethodS3("getBSUnCent.chains", "DiallelOb", function(this, ...) {
  if(is.null(this$.AFD$.BS)) {
    tryCatch("getBSUnCent.chains: Error: BS is NULL!")
  }
  AFD <- this$.AFD;  BSAFD <- this$.AFD$.BS;
  NewCodaList <- list();
  nTau <- sum(substr(colnames(AFD$.BS$CodaList[[1]]), 1,nchar("tau")) == "tau");
  nBeta <- NCOL(this$.AFD$.BS$X);  
  NeedNames <- 1:(nTau+nBeta+1);
  OtherNameCodaList <- BSAFD$OtherNameCodaList;
  for (ii in 1:length(AFD$.BS$CodaList)) {
          NewCodaList[[ii]] <- matrix(AFD$.BS$CodaList[[ii]][,NeedNames],
            NROW(AFD$.BS$CodaList[[1]]), length(NeedNames));
          colnames(NewCodaList[[ii]]) = OtherNameCodaList[NeedNames];
          NewCodaList[[ii]] <- as.mcmc(NewCodaList[[ii]]);
        }
        ACodaList = NewCodaList; ARawList = NewCodaList;
  DoRawAnyWay = TRUE;
  return(NewCodaList);
});
setMethodS3("getCent.chains", "DiallelOb", function(this,DoBS =FALSE, ...) {
  if (!is.null(this$.cent.chains) && length(this$.cent.chains) > 0 && length(this$.cent.chains[[1]]) > 0) {
    return(this$.cent.chains);
  }
  try(this$.cent.chains <- AutoMFFunction(this, AFD=this$.AFD));
  if (DoBS == TRUE && !is.null(this$.AFD$.BS)) {
     AFD <- this$.AFD;  BSAFD <- this$.AFD$.BS;
     if (is.null(BSAFD$CenteredColumns)  || 
       length(BSAFD$CenteredColumns) <= 0) {       
       return(this$getBSUnCent.chains());
     }
     return(this$.AFD$.BS$DeCenteredCodaList);
  }
  return(this$.cent.chains);
});

setMethodS3("getRaw.chains", "DiallelOb", function(this,...) {
  return(this$CodaChains);
});

setMethodS3("getResiduals", "FullDiallelAnalyze", function(this,...) {
  return(this$AllDiallelObs[[this$OnObs]]$getResiduals()); 
});
setMethodS3("getResiduals", "DiallelOb", function(this,...) {
  if (is.null(this$.Residuals) || length(this$.Residuals) <= 0) {
  X <- this$getX();  
  Residuals <- list();
  if (is.null(this$.AFD$burnin) || !is.numeric(this$.AFD$burnin)) {
    burnin <- 1; 
  }
  Ourend = NROW(this$CodaChains[[1]]);
  for (ii in 1:length(this$CodaChains)) {
    Residuals[[ii]] <- this$.AFD$Y -  this$CodaChains[[ii]][burnin:Ourend,1:length(this$Beta)] %*% t(X);
    colnames(Residuals[[ii]]) <- paste("Subject:", 1:NROW(X));
    Residuals[[ii]] <- as.mcmc(Residuals[[ii]]);
  }  
  try(Residuals <- as.mcmc.list(Residuals));
  try(this$.Residuals <- Residuals);
  }
  return(this$.Residuals); 
});

setMethodS3("summary.table", "DiallelOb", function(this, burnin=-1,thin=1,
  Verbose=0, Override = FALSE,...) {
  
 if (is.null(this$CodaChains)) {
   throw("Error, no extant CodaChains");
 }
 if (!is.null(this$summarytable)) {
   if (Override == FALSE) {
     print("Summarytable Already Exists!, Turn Override == True to recalculate");
     flush.console();
     return(this$summarytable);S
   }
 }
 
 if (burnin < 0) {
   burnin = round(.2 * dim(this$CodaChains[[1]])[1]);
 }
 
 SubSetChains = mcmc.subset(this$CodaChains, burnin=burnin, thin=thin);
 MySummary =  summary(SubSetChains);
 
 NeedFixedBeta = (1:length(this$Beta))[names(this$Beta) %in% 
   names(this$.tauFixed)];
 if (any(substr(names(this$Beta), 1, nchar("FixedEffect")) == "FixedEffect")){
   NeedFixedBeta = c(NeedFixedBeta, (1:length(names(this$Beta)))[
      substr(names(this$Beta), 1, nchar("FixedEffect")) == "FixedEffect"])
 } 
 NeedFixedBeta = sort(unique(NeedFixedBeta));
 TableStart = cbind( 
   MySummary$statistics[NeedFixedBeta,1],
   MySummary$quantiles[NeedFixedBeta,c(3,1,5)] );
 rownames(TableStart) = names(this$Beta)[NeedFixedBeta];
 TableWork = TableStart;
 for (jj in 1:length(this$tau)) {
   NewChain = list();  NewChain[[1]] = NULL;
   for (chi in 1:length(SubSetChains)) {
     IT = SubSetChains[[chi]][,
       substr(colnames(SubSetChains[[chi]]), 1,
         nchar(names(this$tau)[jj]) )== names(this$tau)[jj]]
     IT = IT - rowMeans(IT);
     colnames(IT) =
       paste((names(this$Beta))[substr(colnames(SubSetChains[[chi]]), 1,
         nchar(names(this$tau)[jj]) )== names(this$tau)[jj]], " - mean[",
         names(this$tau)[jj], "]", sep="");
     if (chi == 1) {
       NewChain[[1]] = as.mcmc(IT);
     } else {
       NewChain[[1]] = as.mcmc(rbind(NewChain[[1]],IT));
     }
   }
   NewChain = as.mcmc(NewChain);
   MySummary = summary(NewChain);
   ##MMean = colMeans(NewChain[[1]]);
   ##QQuarts = NULL;
   ##for (chi in 1:length(NewChain[[1]][1,])) {
   ##  QQuarts = rbind(QQuarts, 
   ##    quantile(NewChain[[1]][,chi], c(.5,.025,.975)))
   ##}
   ## QQuarts = quantile(NewChain[[1]])
   ##nTableWork = rownames(TableWork);
    TableWork = rbind(TableWork,
      cbind( MySummary$statistics[,1],
       MySummary$quantiles[,c(3,1,5)] ) );
   ## TableWork = rbind(TableWork,
   ## cbind(MMean, QQuarts));
   ## rownames(TableWork) = c(nTableWork, colnames(NewChain[[1]]) );
   
 }
 colnames(TableWork) = c("E[Beta|Y]", "Med", "q-.025", "q-.975");
 this$summarytable = TableWork;
 return(TableWork);
});
setMethodS3("summary", "FullDiallelAnalyze", function(this, Override = FALSE, ...){
  if (length(this$AllDiallelObs > 2)) {
    print("FullDialllelAnalyze:   Conducting Summaries ");
  }
  for (ii in 1:length(this$AllDiallelObs)) {
   if (length(this$AllDiallelObs) <= 0 || ii > length(this$AllDiallelObs)) {
     print("FullDiallelAnalyze:Summary Table Error, ii is bad!"); flush.console();
     tryCatch("Summary Table Error");
   }
   if (!is.null(this$AllDiallelObs[[ii]]$summarytable)) {
    if (Override == FALSE) {
      print(paste("Summarytable ", ii, "Already Exists!, Turn Override == True to recalculate", sep=""));
      flush.console();
    } else {
      MyS = summary.table(this$AllDiallelObs[[ii]]);
    }
    print(paste(" -----Model: ", ii, sep=""));
    MyString = StringForCrossList(c(this$AllDiallelObs[[ii]]$.ajModel,
      this$AllDiallelObs[[ii]]$.MotherModel,
      this$AllDiallelObs[[ii]]$.CrossModel,
      this$AllDiallelObs[[ii]]$.SexModel,
      this$AllDiallelObs[[ii]]$.BetaInbredLevel,
      this$AllDiallelObs[[ii]]$.BetaInbredTimesSex,
      this$AllDiallelObs[[ii]]$dfTNoise
      ));
    print(paste("  Model Type: ", paste(MyString, collapse= ", "), sep=""));
    print(this$AllDiallelObs[[ii]]$summarytable);
   }   
  
  }
});

BayesFactor <- function(PCodaList, PriorProb,NamesColumns) {
  NamesColumns = NamesColumns[NamesColumns != "SimID"];
  AllNames = colnames(PCodaList[[1]]);
  FixedNames = AllNames[substr(AllNames, 1, nchar("ProbFixed")) == "ProbFixed"];
  idFixedNames = (1:length(AllNames))[substr(AllNames, 1, nchar("ProbFixed")) == "ProbFixed"]
  FixedNames = substr(FixedNames, nchar("ProbFixed:")+1, nchar(FixedNames));
  FixedNames=strsplit(FixedNames, "\\d+:Beta:\\d+:", perl=TRUE)
  iF = rep("", length(FixedNames));
  for (ii in 1:length(iF)) {
    iF[ii] = FixedNames[[ii]][2];
  }
  FixedNames = iF
  idRandomNames = (1:length(AllNames))[substr(AllNames, 1, nchar("Prob:tau")) == "Prob:tau"];
  RandomNames = AllNames[substr(AllNames,1,nchar("Prob:tau")) == "Prob:tau"];
  RandomNames = substr(RandomNames,nchar("Prob:tau:")+1, nchar(RandomNames));
  
  AllPNC =  NamesColumns[substr(NamesColumns,1,nchar("PosteriorProb:")) == "PosteriorProb:"];
  AllPNC = substr(AllPNC, nchar("PosteriorProb:")+1, nchar(AllPNC));
  
  MySummaryA = summary(DeLogit(PCodaList, 1.0));
  MySummaryB = summary(DeLogit(PCodaList,-1.0));
  MyMeansA = MySummaryA[[1]][,1];
  MyMeansB = MySummaryB[[1]][,1];
  MyMeans = MyMeansA;
  
  PosteriorProb = c(MyMeans[idFixedNames], MyMeans[idRandomNames]);
  AntiPosteriorProb = c(MyMeansB[idFixedNames], MyMeansB[idRandomNames]);
  names(PosteriorProb) = c(FixedNames, RandomNames);
  
  if (length(PriorProb) == 2) {
    BayesFactor = c((MyMeans[idFixedNames] / PriorProb[1])/
      ((1-MyMeans[idFixedNames]) / (1-PriorProb[1])),
      (MyMeans[idRandomNames] / PriorProb[2])/
      ((1-MyMeans[idRandomNames]) / (1-PriorProb[2])));
      KTTF = idFixedNames[PosteriorProb[idFixedNames] == 1.0];
      KTTFi = match(KTTF, idFixedNames)
      KTTR = idRandomNames[PosteriorProb[idRandomNames] == 1.0];
      KTTRi = match(KTTR, idRandomNames);
     BayesFactor[KTTFi] = 1.0/AntiPosteriorProb[KTTF] * (1-PriorProb[1]) / PriorProb[1];
     BayesFactor[KTTRi + length(idFixedNames)] =  1.0/AntiPosteriorProb[KTTR] * (1-PriorProb[2]) / PriorProb[2];
  } else {
    BayesFactor = (PosteriorProb / PriorProb[1]) /
      ((1-PosteriorProb) / (1-PriorProb[1]))
    BayesFactor[PosteriorProb == 0] = exp(-40);
    BayesFactor[PosteriorProb == 1] = 1.0 /AntiPosteriorProb[PosteriorProb == 1] * (1-PriorProb[1]) / (PriorProb[1]);     
  }

  names(BayesFactor) = names(PosteriorProb);
  
  PPosteriorProb = rep(0, length(AllPNC));
    MyM = match(names(PosteriorProb), AllPNC);
  PPosteriorProb[MyM] = PosteriorProb;
  names(PPosteriorProb) = paste("PosteriorProb:", AllPNC, sep="");
 
  BBayesFactor = rep(0, length(AllPNC));
    MyM = match(names(BayesFactor), AllPNC);
  BBayesFactor[MyM] = BayesFactor;
  names(BBayesFactor) = paste("BayesFactor:", AllPNC, sep="");
  returner=c(PPosteriorProb, BBayesFactor);
  names(returner) = c(names(PPosteriorProb), names(BBayesFactor));
  return(returner);
}



MXChain <- function(MXM, Chains) {
  NewChains = list();
  for (ii in 1:length(Chains)) {
    IDI = (1:length(Chains[[ii]][1,]))[colnames(Chains[[ii]]) %in% colnames(MXM)];
    NIDI = (1:length(Chains[[ii]][1,]))[!(colnames(Chains[[ii]]) %in% colnames(MXM))];
    MTT = match(colnames(MXM), colnames(Chains[[ii]])[
      colnames(Chains[[ii]]) %in% colnames(MXM)]);
    NewChains[[ii]] = cbind(
      Chains[[ii]][,IDI] %*% MXM[MTT,MTT], Chains[[ii]][,NIDI]);
    colnames(NewChains[[ii]]) = c(colnames(Chains[[ii]])[IDI],
      colnames(Chains[[ii]])[NIDI]);
    NewChains[[ii]] = as.mcmc(NewChains[[ii]])
  }
  return(as.mcmc(NewChains));
}

setMethodS3("CreateMatrixMX", "DiallelOb", function(this, ...) {
  MX <- matrix(0, length(this$Beta), length(this$Beta));
  diag(MX) = 1;
  MyF = this$DpBeta%*%t(this$DpBeta);
  
  MX = MX - MyF / colSums(MyF);
  MX[cbind(1:length(this$.idFixedVariables),
           1:length(this$.idFixedVariables)
     )] = 1; 
  colnames(MX) = names(this$Beta);
  rownames(MX) = names(this$Beta); 
  return(MX)
});
setMethodS3("CreateMatrixXD", "DiallelOb", function(this, AFD = NULL,...) {
  if (is.null(AFD)) {
    AFD = this$.AFD;
  }
  FListjk = cbind(rep(1:this$.numj, each=this$.numj),
    rep(1:this$.numj, this$.numj));
  if (this$.SexModel > 0) {
     FSexVector = c(rep(0, length(FListjk[,1])),
                   rep(1, length(FListjk[,1])) );
     FListjk <- rbind(FListjk, FListjk);
  }
 if (any(substr(names(this$Beta), 1, nchar("FixedEffect")) == 
   "FixedEffect") || length(this$.AFD$FixedEffects) >= 0) {
   if (is.null(dim(this$.AFD$FixedEffects))) {
     NFixedEffects = matrix(0, length(FListjk[,1]),
      1);
     colnames(NFixedEffects) = "FixedEffect:1"
   } else {
     NFixedEffects = matrix(0, length(FListjk[,1]),
       dim(this$.AFD$FixedEffects)[2]);   
     colnames(NFixedEffects) = colnames(AFD$FixedEffects);
   }  
 } else {
   NFixedEffects = NULL;
 }
 if (any(substr(names(this$ADiallelOb$Beta), 1, nchar("RandomEffect")) == 
   "RandomEffect")) {
   if (is.null(dim(this$RandomEffects))) {
     NRandomEffects = matrix(0, length(FakeListjk[,1]),
      1);
     colnames(NRandomEffects) = "RandomEffect:1";
   } else {
     NRandomEffects = matrix(0, length(FakeListjk[,1]),
       dim(this$RandomEffects)[2]);   
     colnames(NRandomEffects) = colnames(this$RandomEffects);
   }  
 } else {
   NRandomEffects = NULL;
 }
  XD = ConstructXJK(this$.numj, this$.ajModel,
     this$.CrossModel, this$.SexModel, this$.MotherModel, 
     this$.BetaInbredLevel, this$.BetaInbredTimesSex, FSexVector, FListjk, AFD$ACrossLocations,
     FixedEffects = NFixedEffects, 
     RandomEffectsGroups = AFD$RandomEffectsGroups, RandomEffects = NRandomEffects,
     Verbose = FALSE, DoFirstCenter = this$DoFirstCenter);
  return(XD);
})

GetFixedNames <- function(SampleBeta) {
   if (is.numeric(SampleBeta[1])) {
     FN = names(SampleBeta);
   } else { FN = SampleBeta; }
   FN = FN[substr(FN, 1, nchar("Sigma")) != "Sigma"];  
   FN = FN[substr(FN, 1, nchar("Prob")) != "Prob"];  
   tauNames = GetRandomNames(FN);
   FN = FN[substr(FN,1,nchar("tau")) != "tau"]
   for (ii in 1:length(tauNames)) {
     FN = FN[substr(FN,1,nchar(tauNames)[ii]) != tauNames[ii]];
   }
   FN = FN[FN != "SimID"]
   return(FN);
}
GetRandomNames <- function(SampleBeta) {
  if (is.numeric(SampleBeta[2])) {
    RN = names(SampleBeta);
  } else { RN = SampleBeta; }
  RN = RN[substr(RN, 1, nchar("tau")) == "tau"];
  RN = substr(RN, nchar("tau:")+1, nchar(RN));
  return(RN);
} 

NamesHSqTable <- function(SampleBeta) {
 FN = GetFixedNames(SampleBeta);
 RN = GetRandomNames(SampleBeta);
  Sets <- c(FN, RN);
 CN = c(paste("HSqMean:", Sets,sep=""),
      paste("HSqMedian:", Sets,sep=""),
      paste("HSqSd:", Sets,sep=""),
      paste("HSqPointMean:", Sets,sep=""),
      paste("HSqPropMean:", Sets,sep=""),
      paste("HSqPropMedian:", Sets,sep=""),
      paste("HSqPropSd:", Sets,sep=""),
      paste("HSqPropPointMean:", Sets,sep=""),
      paste("RSqMean:", Sets,sep=""),
      paste("RSqMedian:", Sets,sep=""),
      paste("RSqSd:", Sets,sep=""),
      paste("RSqPointMean:",Sets,sep=""),
      paste("HSqtPointMean:", Sets, sep=""),
      paste("HSqtPropPointMean:", Sets, sep=""),
      paste("RSqtPointMean:", Sets, sep=""));
 return(CN);    
}
NamesBayesFactorTable <- function(SampleBeta) {
  FN = GetFixedNames(SampleBeta);
  RN = GetRandomNames(SampleBeta);
  Sets = c(FN, RN);
  CN = c(paste("PosteriorProb:", Sets, sep=""),
    paste("BayesFactor:", Sets, sep=""))
  return(CN);
}

MakeHSqTable <- function(CodaChains = NULL, AllX, AY, CurrentHSqTableNames,
  startiter=1, thin=1, enditer=NULL, TrueVector = NULL) {
  
  if (is.null(CodaChains) && is.null(TrueVector)) {
    print("MakeHSq Table Error: Supply CodaChains or TrueVector"); flush.console();
    tryCatch("MakeHSqTable given no codaChain input");
  }
  CurrentHSqTableNames = CurrentHSqTableNames[CurrentHSqTableNames != "SimID"];
  FN = GetFixedNames(colnames(CodaChains[[1]]));
  RN = GetRandomNames(colnames(CodaChains[[1]]));  
  
  HSqHead = c("HSqMean", "HSqMedian", "HSqSd", "HSqPointMean",
    "HSqPropMean", "HSqPropMedian", "HSqPropSd", "HSqPropPointMean",
    "RSqMean", "RSqMedian", "RSqSd", "RSqPointMean", "HSqtPointMean",
    "HSqtPropPointMean", "RSqtPointMean");
  if (is.null(HSqHead)) {
    HSqHead = c("HSqMean", "HSqMedian", "HSqSd", "HSqPointMean",
    "HSqPropMean", "HSqPropMedian", "HSqPropSd", "HSqPropPointMean",
    "RSqMean", "RSqMedian", "RSqSd", "RSqPointMean");
  }
  HSqLocList = list();
  for (ii in 1:length(HSqHead)) {
    HSqLocList[[ii]] = HSqLocate(FN, RN, CurrentHSqTableNames, paste(HSqHead[ii], ":", sep=""));
  }
  Answer = rep(0, length(CurrentHSqTableNames));
  names(Answer) = CurrentHSqTableNames;
  HSqUnweight = PosteriorHSq(CodaChains=CodaChains, AllX=AllX, UseFixed=TRUE,
    ProperRatio=FALSE, AFD = NULL, startiter=startiter,thin=thin,enditer=enditer,
    TrueVector = TrueVector)
  MySummary = summary(HSqUnweight$LPHSq);
    HSqMean = MySummary[[1]][,1];
    HSqMedian = MySummary[[1]][,2];
    HSqSd = MySummary[[2]][,3];
    HSqPointMean = HSqUnweight$PointHSq;
    HSqtPointMean = HSqUnweight$tPointHSq;
  HSqWeight = PosteriorHSq(CodaChains=CodaChains, AllX=AllX, UseFixed=TRUE,
    ProperRatio=TRUE, AFD = NULL, startiter=startiter,thin=thin,enditer=enditer,
    TrueVector = TrueVector)
      MySummary = summary(HSqWeight$LPHSq);
    HSqPropMean = MySummary[[1]][,1];
    HSqPropMedian = MySummary[[1]][,2];
    HSqPropSd = MySummary[[2]][,3];
    HSqPropPointMean = HSqWeight$PointHSq;
    HSqtPropPointMean = HSqWeight$tPointHSq;
  RSqAnswer = PosteriorRSq(CodaChains=CodaChains, AllX=AllX, UseFixed=TRUE,
    ProperRatio=FALSE, AY = AY, startiter=startiter,thin=thin,enditer=enditer,
    TrueVector=TrueVector);
     MySummary=summary(RSqAnswer$LPRSq)
    RSqMean = MySummary[[1]][,1];
    RSqMedian = MySummary[[1]][,2];
    RSqSd = MySummary[[2]][,3];
    RSqPointMean = RSqAnswer$PointRSq;
    RSqtPointMean = RSqAnswer$tPointRSq;  
    
  RTResult = rep(0,length(CurrentHSqTableNames));
  for (ii in 1:length(HSqHead)) {
    FTSIndex = c(HSqLocList[[ii]]$iMatchFTSFNFTS,
      HSqLocList[[ii]]$iMatchFTSRNFTS);
    RIndex = c(HSqLocList[[ii]]$iMatchFNFNFTS,
      HSqLocList[[ii]]$iMatchRNRNFTS);
    MyText = paste("  RTResult[FTSIndex] = ", HSqHead[ii], "[RIndex];", sep="")
    eval(parse(text=MyText));    

  }  
  names(RTResult) = CurrentHSqTableNames;
  return(RTResult)
     
}
HSqLocate <- function(FN, RN, CurrentHN, HSqHeader, ...) {
 ITT = (1:length(CurrentHN))[substr(CurrentHN, 1, nchar(HSqHeader)) == HSqHeader];
  FTS = CurrentHN[ITT];
  FTS = substr(FTS, nchar(HSqHeader)+1, nchar(FTS));
  if (length(FN) > 0) {
  MatchFNFTS = match(FN, FTS)
  if (sum(!is.na(MatchFNFTS)) >= 1) {
  iMatchFNFNFTS = (1:length(FN))[!is.na(MatchFNFTS)];
  iMatchFTSFNFTS = ITT[MatchFNFTS[!is.na(MatchFNFTS)]];
  } else {
    iMatchFNFNFTS = NULL; iMatchFTSFNFTS = NULL;
  }
  } else {
    iMatchFNFNFTS = NULL; iMatchFTSFNFTS = NULL;
    MatchFNFTS = NULL;
  }
  if (length(RN) > 0) {
    MatchRNFTS = match(RN, FTS)
    if (sum(!is.na(MatchRNFTS)) > 0) {
    iMatchRNRNFTS = length(FN) + (1:length(RN))[!is.na(MatchRNFTS)];
    iMatchFTSRNFTS = ITT[MatchRNFTS[!is.na(MatchRNFTS)]];
    } else {
      iMatchRNRNFTS = NULL; iMatchFTSRNFTS = NULL;
    }
  } else {
    MatchRNFTS = NULL; iMatchRNRNFTS = NULL; iMatchFTSRNFTS = NULL;
  }
  return(list(iMatchFNFNFTS = iMatchFNFNFTS, iMatchFTSFNFTS=iMatchFTSFNFTS,
    iMatchRNRNFTS = iMatchRNRNFTS, iMatchFTSRNFTS = iMatchFTSRNFTS));
}
PosteriorRSq <- function(CodaChains = NULL, AllX, UseFixed=FALSE,
  ProperRatio=FALSE, AY = NULL, startiter=1,thin=1,enditer=NULL,
  TrueVector = NULL,...) {
  if (is.null(CodaChains) && is.null(TrueVector)) {
    print("PosteriorRSq: is NULL "); flush.console();
    return(NULL);
  }
  if (is.null(AY)) {
    tryCatch("PosteriroRSq: Error, AY is NULL!"); flush.console();
  }
  SumYSq = sum((AY-mean(AY))^2);
  if (!is.null(CodaChains)) {
    tauParameters = GetRandomNames(colnames(CodaChains[[1]]));
    fixedParameters = GetFixedNames(colnames(CodaChains[[1]]));
    indexSigma = (1:length(colnames(CodaChains[[1]])))[
      substr(colnames(CodaChains[[1]]),1, nchar("Sigma")) == "Sigma"];
   weights = rep(1, length(fixedParameters) + length(tauParameters));
   if (ProperRatio == TRUE) {
     weights[1:length(fixedParameters)] = length(AllX[,1]);
     for (jj in 1:length(tauParameters)) {
       NT = length(colnames(CodaChains[[1]])[
         substr(colnames(CodaChains[[1]]),1,nchar(tauParameters[jj])) ==
         tauParameters[jj]
       ]);
       weights[length(fixedParameters) + jj] =  2 * NT;
     }
   }
   idFixed = (1:length(colnames(CodaChains[[1]])))[
     colnames(CodaChains[[1]]) %in% fixedParameters
   ]
   idTau = (1:length(colnames(CodaChains[[1]])))[
     colnames(CodaChains[[1]]) %in%
     paste("tau:", tauParameters, sep="")
   ]
  } else if (!is.null(TrueVector)) {
    tauParameters = GetRandomNames(names(TrueVector));
    fixedParameters = GetFixedNames(names(TrueVector));
    indexSigma = (1:length(names(TrueVector)))[
      substr(names(TrueVector),1, nchar("Sigma")) == "Sigma"];
   weights = rep(1, length(fixedParameters) + length(tauParameters));
   if (ProperRatio == TRUE) {
     weights[1:length(fixedParameters)] = length(AllX[,1]);
     for (jj in 1:length(tauParameters)) {
       NT = length(names(TrueVector)[
         substr(names(TrueVector),1,nchar(tauParameters[jj])) ==
         tauParameters[jj]
       ]);
       weights[length(fixedParameters) + jj] =  2 * NT;
     }
   }
   idFixed = (1:length(names(TrueVector)))[
     names(TrueVector) %in% fixedParameters
   ]
   idTau = (1:length(names(TrueVector)))[
     names(TrueVector) %in%
     paste("tau:", tauParameters, sep="")
   ]     
  }
  if (length(tauParameters) + length(fixedParameters) == 0) {
    return(NULL);
  }


  if (!exists("startiter")) { startiter = 1; }
  if (!exists("enditer")) { enditer = NULL;}
  if (!exists("thin")) { thin = 1; } 
  if (is.null(enditer)) { enditer = length(CodaChains[[1]][,1]) }
  if (enditer <= 0) { enditer = length(CodaChains[[1]][,1]) }
  if (enditer < startiter) {
    print("error, coda thin, startiter must be less than end iter");
    tryCatch(" end iter error!");
  }
  iters = startiter:enditer;
  if (is.null(thin)) {
    AT = (startiter+1):(enditer-1);
    AT = AT[(AT-startiter) %% thin == 0]
    iters = c(startiter, AT, enditer);
  }
  iters = iters[ iters %in% (1:length(CodaChains[[1]][,1])) ];
  PointFixed = rep(0, length(fixedParameters));
  if (!exists("TrueVector")) {TrueVector = NULL;}
  if (!is.null(TrueVector)) {
    tPointFixed = TrueVector[names(TrueVector) %in% fixedParameters];
  }

  if (length(PointFixed) > 0) {
    if (!is.null(CodaChains)) {
    for (ii in 1:length(CodaChains)) {
      if (sum(colnames(CodaChains[[ii]]) %in% fixedParameters) > 1) {
        PointFixed = PointFixed + colSums(  CodaChains[[ii]][iters,
        colnames(CodaChains[[ii]]) %in% fixedParameters]);
      } else if (sum(colnames(CodaChains[[ii]]) %in% fixedParameters)  == 1) {
        PointFixed = PointFixed + sum(  CodaChains[[ii]][iters,
        colnames(CodaChains[[ii]]) %in% fixedParameters]);        
      }
    }
    PointFixed = PointFixed / (length(CodaChains) * length(iters));
    }
  }
  PointRandom = rep(0, length(tauParameters));
  if (!is.null(CodaChains)) {
  if (length(PointRandom) >= 1) {
  for (ii in 1:length(CodaChains)) {
    if (sum(colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep=""))  > 1) {
      PointRandom = PointRandom + colSums(  CodaChains[[ii]][iters,
        colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep="")]);
    } else if (sum(colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep=""))  == 1) {
      PointRandom = PointRandom + sum(  CodaChains[[ii]][iters,
        colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep="")]);        
    }
  }
  PointRandom = PointRandom / (length(CodaChains) * length(iters)); 
  }}
  if (!is.null(TrueVector)) {
    tPointRandom = TrueVector[names(TrueVector) %in% paste("tau:", tauParameters, sep="")];
  }
  ListPointRandom = list();
  if (!is.null(CodaChains)) {
  for (jj in 1:length(tauParameters)) {
    RTP = (1:length(CodaChains[[1]][1,]))[
      substr(colnames(CodaChains[[1]]), 1, nchar(tauParameters[jj])) ==
       tauParameters[jj]];
    PR = rep(0, length(RTP));
    for (ii in 1:length(CodaChains)) {
      PR = PR + colSums( CodaChains[[ii]][iters, RTP] );  
    }
    PR = PR / ( length(CodaChains) * length(iters));
    names(PR) = colnames(CodaChains[[1]])[RTP];
    ListPointRandom[[jj]] = PR;
  }}
  if (!is.null(TrueVector)) {
    tListPointRandom = list();
    for (jj in 1:length(tauParameters)) {
      RTP = (1:length(TrueVector))[
        substr(names(TrueVector), 1, nchar(tauParameters[jj])) == tauParameters[jj] ];
      PR = rep(0, length(RTP));
      PR = TrueVector[RTP];
      names(PR) = names(TrueVector)[RTP];
      tListPointRandom[[jj]] = PR;
    }
  } else { tListPointRandom = NULL; }
  if (!is.null(CodaChains)) {
  PointSigma = 0; 
  for (ii in 1:length(CodaChains)) {
    PointSigma = PointSigma + sum(  CodaChains[[ii]][iters, indexSigma]
     );
  }
  PointSigma = PointSigma / (length(CodaChains) * length(iters));
  if (!is.null(TrueVector)) {
    tPointSigma = TrueVector[indexSigma];
  }
  }
  if (!is.null(TrueVector)) {
    tPointSigma = TrueVector[substr(TrueVector,1, nchar("Sigma")) == "Sigma"];
  }
  LPRSq = list();
  PFD = NULL;
  if (length(fixedParameters) > 1) {
  MiX = match(fixedParameters, colnames(AllX));
  idXfP = (1:length(fixedParameters))[!is.na(MiX)];
  idMiX = MiX[!is.na(MiX)];
  idMiX = idMiX[sort(idXfP, index=TRUE)$ix];
  idXfP = sort(idXfP);
  MyXF = t(AllX[,idMiX]) * PointFixed[idXfP];
  PFD = rowSums( (MyXF - rowMeans(MyXF))^2 );
  } else if (length(fixedParameters) == 1) {
  MiX = match(fixedParameters, colnames(AllX));
  idXfP = (1:length(fixedParameters))[!is.na(MiX)];
  idMiX = MiX[!is.na(MiX)];
  idMiX = idMiX[sort(idXfP, index=TRUE)$ix];
  idXfP = sort(idXfP);
    MyXF = AllX[,idMiX] * PointFixed[idXfP];
  PFD = sum( (MyXF - mean(MyXF))^2 );       
  }
  if (!is.null(TrueVector)) {
  tPFD = NULL;
  if (length(fixedParameters) > 1) {
  MiX = match(fixedParameters, colnames(AllX));
  idXfP = (1:length(fixedParameters))[!is.na(MiX)];
  idMiX = MiX[!is.na(MiX)];
  idMiX = idMiX[sort(idXfP, index=TRUE)$ix];
  idXfP = sort(idXfP);
  MyXF = t(AllX[,idMiX]) * tPointFixed[idXfP];
  tPFD = rowSums( (MyXF - rowMeans(MyXF))^2 );
  } else if (length(fixedParameters) == 1) {
  MiX = match(fixedParameters, colnames(AllX));
  idXfP = (1:length(fixedParameters))[!is.na(MiX)];
  idMiX = MiX[!is.na(MiX)];
  idMiX = idMiX[sort(idXfP, index=TRUE)$ix];
  idXfP = sort(idXfP);
    MyXF = AllX[,idMiX] * tPointFixed[idXfP];
  tPFD = sum( (MyXF - mean(MyXF))^2 );       
  }}
  if (length(tauParameters) > 0) {
    if (!is.null(ListPointRandom)) {
    for (jj in 1:length(tauParameters)) {
      PRT = (1:length(colnames(AllX)))[
          substr(colnames(AllX),1,nchar(tauParameters[jj])) ==
          tauParameters[jj]
        ];
      nPRT = colnames(AllX)[PRT];
      NPT = names(ListPointRandom[[jj]]);
      iMatchAB = match(NPT, nPRT);
        iMA = (1:length(iMatchAB))[!is.na(iMatchAB)];
        iMB = (iMatchAB)[!is.na(iMatchAB)];
     PT = AllX[,iMB] %*% (ListPointRandom[[jj]][iMA]);
     PT = colSums( (PT - colMeans(PT))^2 );
     PFD = c(PFD, PT);
    }
    PointRSq = PFD  / SumYSq;
    names(PointRSq) = c(fixedParameters, tauParameters);
    }
    if (!is.null(tListPointRandom)) {
      for (jj in 1:length(tauParameters)) {
        PRT = (1:length(colnames(AllX)))[
          substr(colnames(AllX),1,nchar(tauParameters[jj])) == tauParameters[jj]];
        nPRT = colnames(AllX)[PRT];
        NPT = names(tListPointRandom[[jj]]);
        iMatchAB = match(NPT, nPRT);
        iMA = (1:length(iMatchAB))[!is.na(iMatchAB)];
        iMB = (iMatchAB)[!is.na(iMatchAB)];
        tPT = AllX[,iMB] %*% (tListPointRandom[[jj]][iMA]);
        tPT = colSums( (tPT - colMeans(tPT))^2 );
        tPFD = c(tPFD, tPT);
      }
    }
  }
  if (!is.null(TrueVector)) {
    tPointRSq = tPFD / SumYSq;
    names(tPointRSq) = c(fixedParameters, tauParameters);
  } else {
    tPointRSq = NULL;
  }

  LPRSq = list();
  for (ii in 1:length(CodaChains)) {
    MyCoda = CodaChains[[ii]][iters,];
    LD = matrix(0, length(MyCoda[,1]),
      length(fixedParameters) + length(tauParameters));
      IDNX = colnames(AllX);  
    mIDNX = match(IDNX, fixedParameters);
    NT = (1:length(IDNX))[!is.na(mIDNX)];  NmIDNX = mIDNX[!is.na(mIDNX)];
    FixedCodaChains = MyCoda[, idFixed];
    PLT = NULL;
    if (length(fixedParameters) > 0) {
    for (jj in 1:length(fixedParameters)) {
      if (length(fixedParameters) > 1) {
        STT = FixedCodaChains[,jj] %*% t(AllX[, colnames(AllX) == fixedParameters[jj]])
      } else {
        STT = FixedCodaChains %*% t(AllX[, colnames(AllX) == fixedParameters])        
      }
      STT = rowMeans((STT - rowMeans(STT))^2);
      PLT = cbind(PLT, STT);
    }
    LD[,NmIDNX] = PLT;
    }

    if (length(tauParameters) > 0) {
    for (jj in 1:length(tauParameters)) {
      PRD = (1:length(colnames(CodaChains[[ii]])))[
        substr(colnames(CodaChains[[ii]]), 1, nchar(tauParameters[jj])) ==
          tauParameters[jj]
      ];
      PRT = (1:length(colnames(AllX)))[
          substr(colnames(AllX),1,nchar(tauParameters[jj])) ==
          tauParameters[jj]
        ];
        
      nPRT = colnames(AllX)[PRT];
      NPT = names(ListPointRandom[[jj]]);
      iMatchAB = match(NPT, nPRT);
        iMA = (1:length(iMatchAB))[!is.na(iMatchAB)];
        iMB = (iMatchAB)[!is.na(iMatchAB)];
        
      STT = MyCoda[,iMA] %*% t(AllX[,iMB]);
      LD[, length(fixedParameters) + jj] = 
        rowSums((STT - rowMeans(STT))^2);    
    }
    }
    colnames(LD) = c(fixedParameters, tauParameters);
    LD = LD / SumYSq;
    LD = as.mcmc(LD);
    LPRSq[[ii]] = LD;
  }
  LPRSq = as.mcmc(LPRSq);

  names(PointRSq) = c(fixedParameters, tauParameters);
  return(list(LPRSq = LPRSq, PointRSq = PointRSq, tPointRSq = tPointRSq));
}



setMethodS3("PosteriorDSq", "DiallelOb", function (this,
  startiter=1,thin=1,enditer=NULL,
  TrueVector = NULL,UseFixed = FALSE, DoBS = FALSE, ...) {
  if (!exists("startiter")) { startiter = 1;} 
  if (!exists("TrueVector")) { TrueVector = NULL; }
  if (!exists("UseFixed")) { UseFixed=FALSE; }
  if (!exists("enditer")) { enditer = NULL; }
  if (!exists("thin")) { thin = 1;}
  FakeChains = NULL;  FakeX = NULL;
  LSText <- "
  FakeChains = this$getPosteriorPredictionsMeanChains();
  FakeCoda = FakeChains;
  ##FakeX = this$PostKeeper$FakeX;
  ";
  try(eval(parse(text=LSText)));
  if (is.null(FakeX)) {
    try(FakeX <- this$MakeFakeX(DoFirstCenter = this$.AFD$DoFirstCenter));
  }
  if (is.null(FakeX)) {
    print("Doh, Fake X is null can't do DSq"); flush.console();
  }
  try(CodaChains <- this$getCent.chains(DoBS == DoBS));
  if (this$DoFirstCenter == FALSE) {
    NewCodaChains <- list();
    for (ii in 1:length(this$.cent.chains)) {
      NN <- matrix(as.numeric(this$.cent.chains[[ii]]), NROW(this$.cent.chains[[ii]]),
        NCOL(this$.cent.chains[[ii]]));
      colnames(NN) <- colnames(this$CodaChains[[1]])
      NewCodaChains[[ii]] <- as.mcmc(NN);
    }
    CodaChains <- as.mcmc.list(NewCodaChains);
  }
  if (is.null(CodaChains) || length(CodaChains) <= 0 || length(CodaChains[[1]]) <= 0) {
     print(paste("PosteriorDSq[", this$.iOb, 
       ": Hey, Cent.Chains Doesn't work why is that?", sep="")); flush.console();
  }
  ProperRatio = TRUE;
  if (is.null(CodaChains) && is.null(TrueVector)) {
    print("PosteriorDSq: the Coda Chains is NULL, also the True Vector is NULL!"); flush.console();
    print("This Case is in error. "); flush.console();
    return(NULL);         
  }
  ##if (is.null(AY)) {
  ##  tryCatch("PosteriorDSq: Error, AY is NULL!"); flush.console();
  ##}
  if (!exists("TrueVector")) {
    TrueVector = NULL;
  }

  AllX = FakeX;
  CentAllX <- AllX;
  for (iti in 1:NCOL(AllX)) {
    CentAllX[,iti] <- AllX[,iti] - mean(AllX[,iti]);
  }
  if (!is.null(CodaChains)) {
    tauParameters = GetRandomNames(colnames(CodaChains[[1]]));
    fixedParameters = GetFixedNames(colnames(CodaChains[[1]]));
    indexSigma = (1:length(colnames(CodaChains[[1]])))[
      substr(colnames(CodaChains[[1]]),1, nchar("Sigma")) == "Sigma"];
    weights = rep(1, length(fixedParameters) + length(tauParameters));
    if (ProperRatio == TRUE) {
      weights[1:length(fixedParameters)] = length(AllX[,1]);
      for (jj in 1:length(tauParameters)) {
        NT = length(colnames(CodaChains[[1]])[
          substr(colnames(CodaChains[[1]]),1,nchar(tauParameters[jj])) ==
          tauParameters[jj]
        ]);
        weights[length(fixedParameters) + jj] =  2 * NT;
      }
    }
    idFixed = (1:length(colnames(CodaChains[[1]])))[
      colnames(CodaChains[[1]]) %in% fixedParameters
      ]
    idTau = (1:length(colnames(CodaChains[[1]])))[
      colnames(CodaChains[[1]]) %in%
      paste("tau:", tauParameters, sep="")
    ];
  } else if (!is.null(TrueVector)) {
    tauParameters = GetRandomNames(names(TrueVector));
    fixedParameters = GetFixedNames(names(TrueVector));
    indexSigma = (1:length(names(TrueVector)))[
      substr(names(TrueVector),1, nchar("Sigma")) == "Sigma"];
    weights = rep(1, length(fixedParameters) + length(tauParameters));
    if (ProperRatio == TRUE) {
      weights[1:length(fixedParameters)] = length(AllX[,1]);
      for (jj in 1:length(tauParameters)) {
        NT = length(names(TrueVector)[
          substr(names(TrueVector),1,nchar(tauParameters[jj])) ==
          tauParameters[jj]
        ]);
        weights[length(fixedParameters) + jj] =  2 * NT;
      }
    }
    idFixed = (1:length(names(TrueVector)))[
      names(TrueVector) %in% fixedParameters
    ]
    idTau = (1:length(names(TrueVector)))[
      names(TrueVector) %in%
      paste("tau:", tauParameters, sep="")
    ]     
  }
  if (length(tauParameters) + length(fixedParameters) == 0) {
    return(NULL);
  }

 

  if (!exists("startiter")) { startiter = 1; }
  if (!exists("enditer")) { enditer = NULL;}
  if (!exists("thin")) { thin = 1; } 
  if (is.null(enditer)) { enditer = length(CodaChains[[1]][,1]) }
  if (enditer <= 0) { enditer = length(CodaChains[[1]][,1]) }
  if (enditer < startiter) {
    print("error, coda thin, startiter must be less than end iter");
    tryCatch(" end iter error!");
  }
  iters = startiter:enditer;
  if (is.null(thin)) {
    AT = (startiter+1):(enditer-1);
    AT = AT[(AT-startiter) %% thin == 0]
    iters = c(startiter, AT, enditer);
  }
  iters = iters[ iters %in% (1:length(CodaChains[[1]][,1])) ];
  if (dim(FakeCoda[[1]])[1] < max(iters)) {
     iters = (NROW(CodaChains[[1]])-dim(FakeCoda[[1]])[1]+1):NROW(CodaChains[[1]])
  }
  PointFixed = rep(0, length(fixedParameters));
  if (!exists("TrueVector")) {TrueVector = NULL;}
  if (!is.null(TrueVector)) {
    tPointFixed = TrueVector[names(TrueVector) %in% fixedParameters];
  }

  if (length(PointFixed) > 0) {
    if (!is.null(CodaChains)) {
    for (ii in 1:length(CodaChains)) {
      for (jj in 1:length(fixedParameters)) {
        PointFixed[jj] = PointFixed[jj] + sum(
          CodaChains[[ii]][iters,
            colnames(CodaChains[[ii]]) == fixedParameters[jj]]);
      }
    }
    PointFixed = PointFixed / (length(CodaChains) * length(iters));
    }
  }
  PointRandom = rep(0, length(tauParameters));
  if (!is.null(CodaChains)) {
  if (length(PointRandom) >= 1) {
  for (ii in 1:length(CodaChains)) {
    if (sum(colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep=""))  > 1) {
      PointRandom = PointRandom + colSums(  CodaChains[[ii]][iters,
        colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep="")]);
    } else if (sum(colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep=""))  == 1) {
      PointRandom = PointRandom + sum(  CodaChains[[ii]][iters,
        colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep="")]);        
    }
  }
  PointRandom = PointRandom / (length(CodaChains) * length(iters)); 
  }}
  if (!is.null(TrueVector)) {
    tPointRandom = TrueVector[names(TrueVector) %in% paste("tau:", tauParameters, sep="")];
  }
  ListPointRandom = list();
  if (!is.null(CodaChains)) {
  for (jj in 1:length(tauParameters)) {
    RTP = (1:length(CodaChains[[1]][1,]))[
      substr(colnames(CodaChains[[1]]), 1, nchar(tauParameters[jj])) ==
       tauParameters[jj]];
    PR = rep(0, length(RTP));
    for (ii in 1:length(CodaChains)) {
      PR = PR + colSums( CodaChains[[ii]][iters, RTP] );  
    }
    PR = PR / ( length(CodaChains) * length(iters));
    names(PR) = colnames(CodaChains[[1]])[RTP];
    ListPointRandom[[jj]] = PR;
  }}
  if (!is.null(TrueVector)) {
    tListPointRandom = list();
    for (jj in 1:length(tauParameters)) {
      RTP = (1:length(TrueVector))[
        substr(names(TrueVector), 1, nchar(tauParameters[jj])) == tauParameters[jj] ];
      PR = rep(0, length(RTP));
      PR = TrueVector[RTP];
      names(PR) = names(TrueVector)[RTP];
      tListPointRandom[[jj]] = PR;
    }
  } else { tListPointRandom = NULL; }
  if (!is.null(CodaChains)) {
  PointSigma = 0; 
  for (ii in 1:length(CodaChains)) {
    PointSigma = PointSigma + sum(  CodaChains[[ii]][iters, indexSigma]
     );
  }
  PointSigma = PointSigma / (length(CodaChains) * length(iters));
  if (!is.null(TrueVector)) {
    tPointSigma = TrueVector[indexSigma];
  }
  }
  if ((!exists("tPointSigma") || is.null(tPointSigma)) && !is.null(TrueVector)) {
    tPointSigma = TrueVector[substr(names(TrueVector),1, nchar("Sigma")) == "Sigma"];
  }
  LPDSq = list();
  PFD = NULL;
  if (length(fixedParameters) > 1) {
  MiX = match(fixedParameters, colnames(AllX));
  idXfP = (1:length(fixedParameters))[!is.na(MiX)];
  idMiX = MiX[!is.na(MiX)];
  idMiX = idMiX[sort(idXfP, index=TRUE)$ix];
  idXfP = sort(idXfP);
  MyXF = t(CentAllX[,idMiX]) * PointFixed[idXfP];
  PFD = rowSums( (MyXF - rowMeans(MyXF))^2 );
  } else if (length(fixedParameters) == 1) {
  MiX = match(fixedParameters, colnames(AllX));
  idXfP = (1:length(fixedParameters))[!is.na(MiX)];
  idMiX = MiX[!is.na(MiX)];
  idMiX = idMiX[sort(idXfP, index=TRUE)$ix];
  idXfP = sort(idXfP);
    MyXF = CentAllX[,idMiX] * PointFixed[idXfP];
  PFD = sum( (MyXF - mean(MyXF))^2 );       
  }
  if (!is.null(TrueVector)) {
  tPFD = NULL;
  if (length(fixedParameters) > 1) {
  MiX = match(fixedParameters, colnames(AllX));
  idXfP = (1:length(fixedParameters))[!is.na(MiX)];
  idMiX = MiX[!is.na(MiX)];
  idMiX = idMiX[sort(idXfP, index=TRUE)$ix];
  idXfP = sort(idXfP);
  MyXF = t(CentAllX[,idMiX]) * tPointFixed[idXfP];
  tPFD = rowSums( (MyXF - rowMeans(MyXF))^2 );
  } else if (length(fixedParameters) == 1) {
  MiX = match(fixedParameters, colnames(AllX));
  idXfP = (1:length(fixedParameters))[!is.na(MiX)];
  idMiX = MiX[!is.na(MiX)];
  idMiX = idMiX[sort(idXfP, index=TRUE)$ix];
  idXfP = sort(idXfP);
    MyXF = CentAllX[,idMiX] * tPointFixed[idXfP];
  tPFD = sum( (MyXF - mean(MyXF))^2 );       
  }}
  if (length(tauParameters) > 0) {
    if (!is.null(ListPointRandom)) {
    for (jj in 1:length(tauParameters)) {
      PRT = (1:length(colnames(AllX)))[
          substr(colnames(AllX),1,nchar(tauParameters[jj])) ==
          tauParameters[jj]
        ];
      nPRT = colnames(CentAllX)[PRT];
      NPT = names(ListPointRandom[[jj]]);
      iMatchAB = match(NPT, nPRT);
        iMA = (1:length(iMatchAB))[!is.na(iMatchAB)];
        iMB = (iMatchAB)[!is.na(iMatchAB)];
     PT = CentAllX[,PRT[iMB]] %*% (ListPointRandom[[jj]][iMA]);
     PT = colSums( (PT - colMeans(PT))^2 );
     PFD = c(PFD, PT);
    }
    
    PointDSq = PFD  ;
    names(PointDSq) = c(fixedParameters, tauParameters);
    }
    if (!is.null(tListPointRandom)) {
      for (jj in 1:length(tauParameters)) {
        PRT = (1:length(colnames(AllX)))[
          substr(colnames(AllX),1,nchar(tauParameters[jj])) == tauParameters[jj]];
        nPRT = colnames(AllX)[PRT];
        NPT = names(tListPointRandom[[jj]]);
        iMatchAB = match(NPT, nPRT);
        iMA = (1:length(iMatchAB))[!is.na(iMatchAB)];
        iMB = (iMatchAB)[!is.na(iMatchAB)];
        tPT = CentAllX[,PRT[iMB]] %*% (tListPointRandom[[jj]][iMA]);
        tPT = colSums( (tPT - colMeans(tPT))^2 );
        tPFD = c(tPFD, tPT);
      }
    }
  }
  FakeYmMeanSq = list();
  for (ii in 1:length(FakeCoda)) {
    FakeYmMeanSq[[ii]] = rowSums((FakeCoda[[ii]] - rowMeans(FakeCoda[[ii]]))^2);
  }
  PointYmMeanSq = 0;
  for (ii in 1:length(FakeCoda)) {
    PointYmMeanSq = PointYmMeanSq + sum(FakeYmMeanSq[[ii]]);
  }
  PointYmMeanSq = PointYmMeanSq / ( length(iters) * length(FakeYmMeanSq));
  PointDSq = c(PointDSq, NROW(AllX) * PointSigma);
  names(PointDSq) <- c(fixedParameters, tauParameters, "Sigma");
  PointDSq <- PointDSq[!(names(PointDSq) %in% c("Mu", "mu", "Mean"))];
  PointDSq <- PointDSq / sum(PointDSq);
  NewPointDSq <- c(PointDSq[1:(length(PointDSq)-1)], 
    sum(PointDSq[1:(length(PointDSq)-1)]), PointDSq[length(PointDSq)]);
  names(NewPointDSq) <- c(names(PointDSq)[1:(length(PointDSq)-1)],
    "total.explained", "Noise");
  PointDSq <- NewPointDSq;

  if (!is.null(TrueVector)) {
    tPointDSq = c(tPFD, NROW(AllX) * TrueVector[names(TrueVector) %in% c("Sigma", "Sigma:1", "sigma:1", "sigma")]);
    tPointDSq <- tPointDSq / sum(tPointDSq);
    names(tPointDSq) = c(fixedParameters, tauParameters, "Noise");
    tPointDSq <- tPointDSq[names(tPointDSq) != "Mu"];
    NewtPointDSq <- c(tPointDSq[1:(length(tPointDSq)-1)],
      sum(tPointDSq[1:(length(tPointDSq)-1)]),
      tPointDSq[length(tPointDSq)]);
    names(NewtPointDSq) <- c(names(tPointDSq)[1:(length(tPointDSq)-1)],
    "total.explained", "Noise");
    tPointDSq <- NewtPointDSq;
  } else {
    tPointDSq = NULL;
  }

  LPDSq = list();
  for (ii in 1:length(CodaChains)) {
    MyCoda = CodaChains[[ii]][iters,];
    LD = matrix(0, length(MyCoda[,1]),
      length(fixedParameters) + length(tauParameters)+2);
      IDNX = colnames(AllX);  
    mIDNX = match(IDNX, fixedParameters);
    NT = (1:length(IDNX))[!is.na(mIDNX)];  NmIDNX = mIDNX[!is.na(mIDNX)];
    FixedCodaChains = MyCoda[, idFixed];
    PLT = NULL;
    if (length(fixedParameters) > 0) {
    for (jj in 1:length(fixedParameters)) {
      if (length(fixedParameters) > 1) {
        STT = FixedCodaChains[,jj] %*% t(CentAllX[, colnames(AllX) == fixedParameters[jj]])
      } else {
        STT = FixedCodaChains %*% t(CentAllX[, colnames(AllX) == fixedParameters])        
      }
      STT = rowSums((STT - rowMeans(STT))^2);
      PLT = cbind(PLT, STT);
    }
    LD[,NmIDNX] = PLT;
    }

    if (length(tauParameters) > 0) {
    for (jj in 1:length(tauParameters)) {
      PRD = (1:length(colnames(CodaChains[[ii]])))[
        substr(colnames(CodaChains[[ii]]), 1, nchar(tauParameters[jj])) ==
          tauParameters[jj]
      ];
      PRT = (1:length(colnames(AllX)))[
          substr(colnames(AllX),1,nchar(tauParameters[jj])) ==
          tauParameters[jj]
        ];
        
      nPRT = colnames(AllX)[PRT];
      NPT = names(ListPointRandom[[jj]]);
      iMatchAB = match(NPT, nPRT);
        iMA = (1:length(iMatchAB))[!is.na(iMatchAB)];
        iMB = (iMatchAB)[!is.na(iMatchAB)];
      ATO <- (1:length(colnames(MyCoda)))[colnames(MyCoda) %in% NPT];
      iMA = ATO[iMA];
      iMB = PRT[iMB]
        
      STT = MyCoda[,iMA] %*% t(CentAllX[,iMB]);
      LD[, length(fixedParameters) + jj] = 
        rowSums((STT - rowMeans(STT))^2);    
    }
    }
    LD[, NCOL(LD)] <- NROW(AllX) * 
      MyCoda[,colnames(MyCoda)%in%c("Sigma", "Sigma:1", "sigma:1", "sigma")];
    LD[, NCOL(LD)-1] <- 0.0;
    APT <- rowSums(LD);
    LD = LD / APT;
    LD[, NCOL(LD)-1] <- 1.0 - LD[, NCOL(LD)];
    colnames(LD) = c(fixedParameters, tauParameters, "total.explained", "Noise");

    LD = LD[,colnames(LD) != "Mu"]
    LD = as.mcmc(LD);
    LPDSq[[ii]] = LD;
  }
  LPDSq = as.mcmc(LPDSq);
  

  this$.PosteriorDSqAll =  list(LPDSq = LPDSq, PointDSq = PointDSq, tPointDSq = tPointDSq);
  return(this$.PosteriorDSqAll);
});



setMethodS3("PosteriorPSq", "DiallelOb", function (this,
  startiter=1,thin=1,enditer=NULL,
  TrueVector = NULL,UseFixed = FALSE, DoBS=FALSE, ...) {
  
  AFD <- this$.AFD;
  if (AFD$Verbose >= 1) {
    print(paste("PosteriorPSq: Starting, DoBS=",DoBS, sep="")); flush.console();
  }
  FakeChains = NULL;  FakeX = NULL;
  LSText <- "
    this$PostKeeper <- NULL;
    if (DoBS == FALSE) {
    AT = this$PosteriorPredSummary(AFD = this$.AFD,
      burnin = this$.AFD$burnin, thin = this$.AFD$thin, keep=TRUE, plotdensity=FALSE,
      WithNoise = FALSE, DoBS=DoBS);
    this$.PosteriorPredictionsMeanChains = this$PostKeeper$FakeCoda;
    FakeChains = this$getPosteriorPredictionsMeanChains();
    FakeCoda = FakeChains;
    FakeX = this$PostKeeper$FakeX;
    FakeY = this$PostKeeper$FakeCoda
    } else {
      BSOut = this$PosteriorPredSummary(AFD = this$.AFD,
      burnin = this$.AFD$burnin, thin = this$.AFD$thin, keep=TRUE, plotdensity=FALSE,
      WithNoise = FALSE, DoBS=DoBS);
      if (!is.list(this$.AFD$.BSOther)) {
        this$.AFD$.BSOther <- list();
      }
      this$.AFD$.BSOther$.PosteriorPredictionsMeanChains = BSOut$FakeCoda;
      FakeChains = this$.AFD$.BSOther$PostKeeper$FakeCoda;
      FakeCoda = FakeChains;
      FakeX = this$.AFD$.BSOther$PostKeeper$FakeX;
      FakeY = this$.AFD$.BSOther$PostKeeper$FakeCoda        
    }
    FakeCY <- list();
    for (iti in 1:length(FakeY)) {
      FakeCY[[iti]] <- FakeY[[iti]] - rowMeans(FakeY[[iti]]);
      colnames(FakeCY[[iti]]) <- rownames(FakeY[[iti]]);
    }
  ";
  try(eval(parse(text=LSText)));
  if (is.null(FakeX) || DoBS == TRUE) {
    try(FakeX <- this$MakeFakeX(DoBS = DoBS));
  }
  if (is.null(FakeX)) {
    print("Doh, Fake X is null can't do DSq"); flush.console();
  }
  CodaChains = this$CodaChains; ProperRatio = TRUE;
  if (DoBS==TRUE && !is.null(this$.AFD$.BS)) {
    CodaChains <- this$getBSUnCent.chains();
  }
  if (is.null(CodaChains) && is.null(TrueVector)) {
    print("PosteriorPSq: is NULL "); flush.console();
    return(NULL);         
  }
  ##if (is.null(AY)) {
  ##  tryCatch("PosteriorDSq: Error, AY is NULL!"); flush.console();
  ##}
  if (!exists("TrueVector")) {
    TrueVector = NULL;
  }

  AllX = FakeX;
  CentAllX <- AllX;
  for (iti in 1:NCOL(AllX)) {
    CentAllX[,iti] <- AllX[,iti] - mean(AllX[,iti]);
  }                                 
  colnames(CentAllX) <- colnames(AllX);
  if (!is.null(CodaChains)) {
    tauParameters = GetRandomNames(colnames(CodaChains[[1]]));
    fixedParameters = GetFixedNames(colnames(CodaChains[[1]]));
    indexSigma = (1:length(colnames(CodaChains[[1]])))[
      substr(colnames(CodaChains[[1]]),1, nchar("Sigma")) == "Sigma"];
    weights = rep(1, length(fixedParameters) + length(tauParameters));
    if (ProperRatio == TRUE) {
      weights[1:length(fixedParameters)] = length(AllX[,1]);
      for (jj in 1:length(tauParameters)) {
        NT = length(colnames(CodaChains[[1]])[
          substr(colnames(CodaChains[[1]]),1,nchar(tauParameters[jj])) ==
          tauParameters[jj]
        ]);
        weights[length(fixedParameters) + jj] =  2 * NT;
      }
    }
    idFixed = (1:length(colnames(CodaChains[[1]])))[
      colnames(CodaChains[[1]]) %in% fixedParameters
      ]
    idTau = (1:length(colnames(CodaChains[[1]])))[
      colnames(CodaChains[[1]]) %in%
      paste("tau:", tauParameters, sep="")
    ];
  } else if (!is.null(TrueVector)) {
    tauParameters = GetRandomNames(names(TrueVector));
    fixedParameters = GetFixedNames(names(TrueVector));
    indexSigma = (1:length(names(TrueVector)))[
      substr(names(TrueVector),1, nchar("Sigma")) == "Sigma"];
    weights = rep(1, length(fixedParameters) + length(tauParameters));
    if (ProperRatio == TRUE) {
      weights[1:length(fixedParameters)] = length(AllX[,1]);
      for (jj in 1:length(tauParameters)) {
        NT = length(names(TrueVector)[
          substr(names(TrueVector),1,nchar(tauParameters[jj])) ==
          tauParameters[jj]
        ]);
        weights[length(fixedParameters) + jj] =  2 * NT;
      }
    }
    idFixed = (1:length(names(TrueVector)))[
      names(TrueVector) %in% fixedParameters
    ]
    idTau = (1:length(names(TrueVector)))[
      names(TrueVector) %in%
      paste("tau:", tauParameters, sep="")
    ]     
  }
  if (length(tauParameters) + length(fixedParameters) == 0) {
    return(NULL);
  }

  CastTildeTrue <- function(TrueVector, fixedParameters, tauParameters, AllX) {
    ATrueFixed <- TrueVector[names(TrueVector) %in% fixedParameters];
    LNewTrueFixed <- list();
    for (iti in 1:length(tauParameters)) {
       NameX <- colnames(AllX)[
         substr(colnames(AllX),1, nchar(tauParameters[[iti]]) ) ==
         tauParameters[[iti]] ];
       nL <- length(NameX);
       aST <- strsplit(NameX, ":");
       RR <- aST[[length(aST)]];
       AF <- paste(paste(RR[1:(length(RR)-1)], collapse=":"),
         ":", as.numeric(RR[length(RR)])+1, sep="");
       
       MM <- MakeAM(nL+1);
       MyV <- rep(0, nL+1);  names(MyV) <- c(NameX, AF);   
       AMM <- match(names(TrueVector), names(MyV));
       if (length(AMM[!is.na(AMM)]) >= 1) {
         MyV[AMM[!is.na(AMM)]] <- TrueVector[!is.na(AMM)]   
         LNewTrueFixed[[iti]]  <-  nL / (1+nL) *as.vector( t(MM) %*% MyV  )
         names(LNewTrueFixed[[iti]]) <-names(MyV)[1:(length(MyV)-1)]
       } else {
         LNewTrueFixed[[iti]] <- NULL;
       }
    }
    ANewTrue <- c(ATrueFixed, unlist(LNewTrueFixed),
      TrueVector[names(TrueVector) %in% c("Sigma", "sigma", "Sigma:1", "sigma:1")]);
    return(ANewTrue);
  }
  if (exists("TrueVector")  && !is.null(TrueVector) && length(TrueVector) >= 1 &&
    !is.null(this$.AFD$DoFirstCenter) && ( (is.logical(this$.AFD$DoFirstCenter) &&
    this$.AFD$DoFirstCenter==TRUE ) ||
    (is.numeric(this$.AFD$DoFirstCenter) && this$.AFD$DoFirstCenter >= .5))) {
    TrueVector <- CastTildeTrue(TrueVector, fixedParameters, tauParameters, AllX)  
  }
 

  if (!exists("startiter")) { startiter = 1; }
  if (!exists("enditer")) { enditer = NULL;}
  if (!exists("thin")) { thin = 1; } 
  if (is.null(enditer)) { enditer = length(CodaChains[[1]][,1]) }
  if (enditer <= 0) { enditer = length(CodaChains[[1]][,1]) }
  if (enditer < startiter) {
    print("error, coda thin, startiter must be less than end iter");
    tryCatch(" end iter error!");
  }
  iters = startiter:enditer;
  if (is.null(thin)) {
    AT = (startiter+1):(enditer-1);
    AT = AT[(AT-startiter) %% thin == 0]
    iters = c(startiter, AT, enditer);
  }
  iters = iters[ iters %in% (1:length(CodaChains[[1]][,1])) ];
  if (dim(FakeCoda[[1]])[1] < max(iters)) {
     iters = (NROW(CodaChains[[1]])-dim(FakeCoda[[1]])[1]+1):NROW(CodaChains[[1]])
  }
  PointFixed = rep(0, length(fixedParameters));
  names(PointFixed) <- fixedParameters;
  if (!exists("TrueVector")) {TrueVector = NULL;}
  if (!is.null(TrueVector)) {
    tPointFixed = TrueVector[names(TrueVector) %in% fixedParameters];
    names(tPointFixed) <- names(TrueVector)[names(TrueVector) %in% fixedParameters]
  }

  if (length(PointFixed) > 0) {
    if (!is.null(CodaChains)) {
    for (ii in 1:length(CodaChains)) {
      for (jj in 1:length(fixedParameters)) {
        PointFixed[jj] = PointFixed[jj] + sum(
          CodaChains[[ii]][iters,
            colnames(CodaChains[[ii]]) == fixedParameters[jj]]);
      }
    }
    PointFixed = PointFixed / (length(CodaChains) * length(iters));
    }
  }
  names(PointFixed) <- fixedParameters; 
  PointRandom = rep(0, length(tauParameters));
  if (!is.null(CodaChains)) {
  if (length(PointRandom) >= 1) {
  for (ii in 1:length(CodaChains)) {
    if (sum(colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep=""))  > 1) {
      PointRandom = PointRandom + colSums(  CodaChains[[ii]][iters,
        colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep="")]);
    } else if (sum(colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep=""))  == 1) {
      PointRandom = PointRandom + sum(  CodaChains[[ii]][iters,
        colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep="")]);        
    }
  }
  PointRandom = PointRandom / (length(CodaChains) * length(iters)); 
  }}
  if (!is.null(TrueVector)) {
    tPointRandom = TrueVector[names(TrueVector) %in% paste("tau:", tauParameters, sep="")];
  }
  ListPointRandom = list();
  if (!is.null(CodaChains)) {
  for (jj in 1:length(tauParameters)) {
    RTP = (1:length(CodaChains[[1]][1,]))[
      substr(colnames(CodaChains[[1]]), 1, nchar(tauParameters[jj])) ==
       tauParameters[jj]];
    PR = rep(0, length(RTP));
    for (ii in 1:length(CodaChains)) {
      PR = PR + colSums( CodaChains[[ii]][iters, RTP] );  
    }
    PR = PR / ( length(CodaChains) * length(iters));
    names(PR) = colnames(CodaChains[[1]])[RTP];
    ListPointRandom[[jj]] = PR;
  }}
  if (!is.null(TrueVector)) {
    tListPointRandom = list();
    for (jj in 1:length(tauParameters)) {
      RTP = (1:length(TrueVector))[
        substr(names(TrueVector), 1, nchar(tauParameters[jj])) == tauParameters[jj] ];
      PR = rep(0, length(RTP));
      PR = TrueVector[RTP];
      names(PR) = names(TrueVector)[RTP];
      tListPointRandom[[jj]] = PR;
    }
  } else { tListPointRandom = NULL; }
  if (!is.null(CodaChains)) {
  PointSigma = 0; 
  for (ii in 1:length(CodaChains)) {
    PointSigma = PointSigma + sum(  CodaChains[[ii]][iters, indexSigma]
     );
  }
  PointSigma = PointSigma / (length(CodaChains) * length(iters));
  if (!is.null(TrueVector)) {
    tindexSigma <- (1:length(TrueVector))[names(TrueVector) %in% c("Sigma", "sigma", "Sigma:1", "sigma:1")]
    tPointSigma = TrueVector[tindexSigma];
  }
  }
  if ((!exists("tPointSigma") || is.null(tPointSigma)) && !is.null(TrueVector)) {
    tPointSigma = TrueVector[substr(names(TrueVector),1, nchar("Sigma")) == "Sigma"];
  }

  ##PMatrix <- AllX %*% pseudoinverse( t(AllX) %*% AllX) %*% t(AllX);
  ##ImP <- diag(rep(1,NROW(PMatrix))) - PMatrix;
  pVec <- rep(0, NCOL(AllX));
  tpVec <- rep(0, NCOL(AllX));
 
  if (length(fixedParameters) > 1) {
    MiX = match(fixedParameters, colnames(AllX));
    idXfP = (1:length(fixedParameters))[!is.na(MiX)];
    idMiX = MiX[!is.na(MiX)];
    idMiX = idMiX[sort(idXfP, index=TRUE)$ix];
    idXfP = sort(idXfP);
    if (length(idMiX) <= 0) { idMiX <- NULL;  idXfP <- NULL; }
  } else if (length(fixedParameters) == 1) {
    MiX = match(fixedParameters, colnames(AllX));
    idXfP = (1:length(fixedParameters))[!is.na(MiX)];
    idMiX = MiX[!is.na(MiX)];
    idMiX = idMiX[sort(idXfP, index=TRUE)$ix];
    idXfP = sort(idXfP);
    if (length(idMiX) <= 0) { idMiX <- NULL;  idXfP <- NULL; }
  } else {
    idMiX <- NULL;  idXfP <- NULL;
  }
  listTaufP <- list();  listTauMiX <- list();
  if (length(tauParameters) >= 2) {
    for (iti in 1:length(tauParameters)) {
      MM <- colnames(AllX)[substr(colnames(AllX),1, nchar(tauParameters[iti])) ==
        tauParameters[iti]];
      MCC <- match(MM, colnames(CodaChains[[1]]));
      listTauMiX[[iti]] <- match(MM[!is.na(MCC)], colnames(AllX))
      listTaufP[[iti]] <- MCC[!is.na(MCC)];
    }
  } else if (length(tauParameters) == 1) {
    MM <- colnames(AllX)[substr(colnames(AllX),1, nchar(tauParameters[1])) ==
        tauParameters[1]];
    MCC <- match(MM, colnames(CodaChains[[1]]));
    listTauMiX <- match(MM[!is.na(MCC)], colnames(AllX))
    listTaufP[[1]] <- MCC[!is.na(MCC)];
  } else {
    listTaufP <- NULL;  listTauMiX <- NULL;
  }
  AllMiX <- c(idMiX, unlist(listTauMiX));
  AllfP <- c(idXfP, unlist(listTaufP));
  LVec <- list();
  YSqVec <- list();
  ResidSqVec <- list();
  nNoiseSqVec <- list();
  IdNoise <- (1:NCOL(CodaChains[[1]]))[colnames(CodaChains[[1]]) %in% c("Sigma", "Sigma:1", "sigma:1", "sigma")]
  for (iti in 1:length(CodaChains)) {
    LVec[[iti]] <-  CodaChains[[iti]][iters,AllfP]  *  (FakeCY[[iti]] %*% CentAllX[,AllMiX])
    colnames(LVec[[iti]]) <- colnames(AllX)[AllMiX];
    ##AB <- FakeCY[[iti]] %*% ImP;
    YSqVec[[iti]] <- rowSums(FakeCY[[iti]]^2);
    ResidSqVec[[iti]] <- abs(YSqVec[[iti]] - rowSums(LVec[[iti]]));
    nNoiseSqVec[[iti]] <- NCOL(FakeCY[[iti]]) * CodaChains[[iti]][iters,IdNoise]
  }
  pVec <- as.vector(t(CentAllX[,AllMiX]) %*% CentAllX[,AllMiX] %*% c(PointFixed, unlist(ListPointRandom)));
  names(pVec) <- colnames(AllX)[AllMiX];
  

  if (exists("TrueVector") && !is.null(TrueVector) && length(TrueVector) >= 1) {
    if (length(fixedParameters) >= 1) {
      TT = match(fixedParameters, names(TrueVector));
      TrueidFT <- TT[!is.na(TT)];
      TrueMatchiX <- match(names(TrueVector)[TrueidFT], colnames(AllX));
      TrueidFT <- TrueidFT[!is.na(TrueMatchiX)];
      TrueMatchiX <- TrueMatchiX[!is.na(TrueMatchiX)];    
    } else {
      TrueidFT <- NULL; TrueMatchiX <- NULL;
    }
    listTrueTauT <- list();  listTrueTauInX <- list();
    if (length(tauParameters) >= 1) {
      for (iti in 1:length(tauParameters)) {
        ANN <-colnames(AllX)[substr(colnames(AllX), 1, nchar(tauParameters[iti])) ==
          tauParameters[iti]];
        TT = match(ANN, names(TrueVector));
        idRT <- TT[!is.na(TT)];
        MatchRX <- match(names(TrueVector)[idRT], colnames(AllX));
        listTrueTauT[[iti]] <- idRT[!is.na(MatchRX)];
        listTrueTauInX[[iti]] <- MatchRX[!is.na(MatchRX)];
      }
    } else { listTrueTauT <- NULL;  listTrueTauInX <- NULL; }
    AllTrueInX <- c(TrueMatchiX, unlist(listTrueTauInX));
    AllTrueInTrue <- c(TrueidFT, unlist(listTrueTauT));
    TpVec <- as.vector(t(CentAllX[,AllTrueInX]) %*%  CentAllX[, AllTrueInX] %*% TrueVector[AllTrueInTrue]);
    names(TpVec) <- colnames(AllX)[AllTrueInX];
  } else {  TrueidFT <- NULL;  TrueMatchiX <- NULL;  listTrueTauT <- NULL;  listTrueTauInX <- NULL; 
    TpVec <- NULL; 
    TpVec <- NULL; 
  }
  
  AllNeedLength <- length(fixedParameters) + length(tauParameters);
  LPPSq = list();
  PPSq = rep(0, AllNeedLength + 2);
  PPSq[length(PPSq)] <- PointSigma * NROW(AllX);
  names(PPSq) <- c(fixedParameters, tauParameters, "total.explained", "Noise");
  for (iti in 1:length(CodaChains)) {
    LPPSq[[iti]] <-  matrix(0, length(iters), AllNeedLength+2);
    colnames(LPPSq[[iti]]) <- c(fixedParameters, tauParameters, "total.explained", "Noise");
  }
  if (length(fixedParameters) >= 1) {
    MML <- match(fixedParameters, colnames(LVec[[1]]));
    idfP <- (1:length(fixedParameters))[!is.na(MML)];
    idX <- MML[!is.na(MML)];
    PPSq[idfP] <- pVec[idX] * PointFixed[idfP];
    for (iti in 1:length(CodaChains)) {
      LPPSq[[iti]][,idfP] <- LVec[[iti]][, idX];
    }
  }
  if (length(tauParameters) >= 1) {
    listTauInLVec <- list();
    for (iti in 1:length(tauParameters)) {
      ALV <- (1:NCOL(LVec[[1]]))[ substr(colnames(LVec[[1]]), 1, nchar(tauParameters[iti])) == 
         tauParameters[iti]];
      ALP <- (1:length(pVec))[ substr(names(pVec), 1, nchar(tauParameters[iti])) == 
         tauParameters[iti]];
      if (length(ALP) >= 1) {
        PPSq[length(fixedParameters)+iti] <- sum( pVec[ALP] * ListPointRandom[[iti]] );
      }
      listTauInLVec[[iti]]  <- ALV;
    }
    for (iti in 1:length(LVec)) {
      for (jj in 1:length(tauParameters)) {
        LPPSq[[iti]][, length(fixedParameters)+jj] <- rowSums(LVec[[iti]][,listTauInLVec[[jj]]])
      }
     
    }
  }
  for (iti in 1:length(LVec)) {
    LPPSq[[iti]][,NCOL(LPPSq[[iti]])] <- nNoiseSqVec[[iti]]
  }
  PPSq[length(PPSq)-1] <- sum(PPSq[1:(length(PPSq)-2)]);
  SumPPSq <- sum(PPSq[1:(length(PPSq)-2)]) + PPSq[length(PPSq)];
  PPSq <- PPSq / SumPPSq;
  for (iti in 1:length(LPPSq)) {
    LPPSq[[iti]][, NCOL(LPPSq[[iti]])-1 ] <- rowSums(LPPSq[[iti]][,1:(NCOL(LPPSq[[iti]])-2)]);
    LPPSq[[iti]] <- LPPSq[[iti]] / ( rowSums(LPPSq[[iti]][, (NCOL(LPPSq[[iti]])-1):(NCOL(LPPSq[[iti]])) ] ) );
  }
  if (!is.null(TrueVector)) {
    TPSq <- rep(0, length(PPSq));
    names(TPSq) <- names(PPSq);
    if (length(fixedParameters) >= 1) {
      MiX <- match(fixedParameters, names(TpVec));
      idfP <- (1:length(tpVec))[!is.na(MiX)];
      MiX <- MiX[!is.na(MiX)];
      
      MtPointFixed <- match(fixedParameters[idfP], names(TrueVector));
      if (any(!is.na(MtPointFixed))) {
        TPSq[MiX[!is.na(MtPointFixed)]] <- TpVec[idfP[!is.na(MtPointFixed)]] * 
          tPointFixed[MtPointFixed[!is.na(MtPointFixed)]]
      }
      TPSq[MiX[is.na(MtPointFixed)]] <- 0;
    }
    if (length(tauParameters) >= 1) {
      for (iti in 1:length(tauParameters)) {
        NSS <- (1:length(names(TpVec)))[substr(names(TpVec), 1, nchar(tauParameters[[iti]])) ==
          tauParameters[[iti]]];
        ASS <- names(TpVec)[NSS]
        MtIn <- match(ASS, names(TrueVector));
        if (any(!is.na(MtIn))) {
          TPSq[length(fixedParameters)+iti] <- sum(
            TpVec[NSS[!is.na(MtIn)]] * TrueVector[MtIn[!is.na(MtIn)]]
            );
        }
      }   
    }
    TPSq[length(TPSq)-1] <- sum(TPSq[1:(length(TPSq)-2)]);
    TPSq[length(TPSq)] <- NROW(AllX) * TrueVector[names(TrueVector) %in% c("Sigma",
      "sigma", "Sigma:1", "sigma:1", "OnSigma", "onsigma", "Onsigma")]
    TPSq <- TPSq / sum(TPSq[(length(TPSq)-1):length(TPSq)]);
  } else {
    TPSq <- NULL;
  }
  
  for (ii in 1:length(LPPSq)) {
    try(LPPSq[[ii]] <- as.mcmc(LPPSq[[ii]]));
  }
  try(LPPSq <- as.mcmc.list(LPPSq));
  if (any(colnames(LPPSq[[1]]) %in% c("Mu", "mu", "mean", "Mean", "Treat:Mu", "Treat:mu", "treat:mu"))) {
    NewLPPSq <- list();
    ANN <- !(colnames(LPPSq[[1]]) %in% 
      c("Mu", "mu", "mean", "Mean", "Treat:Mu", "Treat:mu", "treat:mu"));
    LNN <- sum(ANN);
    for (iti in 1:length(LPPSq)) {
      ATO <- matrix(LPPSq[[iti]][,ANN], NROW(LPPSq[[iti]]), LNN);
      colnames(ATO) <- colnames(LPPSq[[1]])[ANN];
      NewLPPSq[[iti]] <- as.mcmc(ATO);
    }
    try(NewLPPSq <- as.mcmc.list(NewLPPSq));
    try(LPPSq <- NewLPPSq);
  }
  
  try(PPSq <- PPSq[!(names(PPSq) %in% c("Mu", "mu", "mean", "Mean", "Treat:Mu", "Treat:mu", "treat:mu"))]);
  
  try(TPSq <- TPSq[!(names(TPSq) %in% c("Mu", "mu", "mean", "Mean", "Treat:Mu", "Treat:mu", "treat:mu"))]);
  if (DoBS == FALSE) {
    this$.PosteriorPSqAll =  list(LPPSq = LPPSq, PointPSq = PPSq, PPSq = PPSq, tPointPSq = TPSq,
      TPSq = TPSq);
  } else {
    Retter <- list(LPPSq = LPPSq, PointPSq = PPSq, PPSq = PPSq, tPointPSq = TPSq,
      TPSq = TPSq);
    if (is.null(this$.AFD$.BSOther) || !is.list(this$.AFD$.BSOther)) {
      try(this$.AFD$.BSOther <- list());
    }
    try(this$.AFD$.BSOther$.PosteriorPSqAll <- Retter);
    return(Retter);
  }
  return(this$.PosteriorPSqAll);
});

## D Squareds
PosteriorHSq <- function(CodaChains = NULL, AllX, UseFixed=FALSE,
  ProperRatio=FALSE, AFD = NULL, startiter=1,thin=1,enditer=NULL, TrueVector = NULL,
  InbredSwitch = DefaultInbredSwitch, ...) {
  if (!exists("TrueVector")) { TrueVector = NULL; }
  if (!exists("InbredSwitch")) { InbredSwitch=DefaultInbredSwitch;}
  if (!is.null(CodaChains)) {
    tauParameters = GetRandomNames(colnames(CodaChains[[1]]));
    fixedParameters = GetFixedNames(colnames(CodaChains[[1]]));  
    indexSigma = (1:length(colnames(CodaChains[[1]])))[
    substr(colnames(CodaChains[[1]]),1, nchar("Sigma")) == "Sigma"];
  } else if (!is.null(TrueVector)) {
    tauParameters = GetRandomNames(names(TrueVector));
    fixedParameters = GetFixedNames(names(TrueVector));
    indexSigma = (1:length(names(TrueVector)))[
      substr( (TrueVector),1, nchar("Sigma")) == "Sigma"];
  } else {
    print("PosteriorHSq: Supply CodaChains/TrueVector or Not!"); flush.console();
  }
  if (length(fixedParameters) + length(tauParameters) == 0) {
    return(NULL);
  }

  ##indexSigma = 
  weights = rep(1, length(fixedParameters) + length(tauParameters));
  if (ProperRatio == TRUE) {
    weights[1:length(fixedParameters)] = 1;
    lF = length(fixedParameters);
    ns = length(colnames(AllX)[ substr(colnames(AllX),1, nchar("aj")) == "aj"])
    if (any(tauParameters == "aj")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="aj"]] =
        2 * (1+1/ns);
    }
    if (any(tauParameters == "Gender:aj")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="Gender:aj"]] =
        .5 * (1+1/ns);
    }
    if (any(tauParameters == "mj")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="mj"]] =
        .5 * (1-1/ns);
    }
    if (any(tauParameters == "Gender:mj")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="Gender:mj"]] =
        .125 * (1-1/ns);
    }
    if (any(tauParameters == "dominancej")) { 
      if (InbredSwitch == 1) {
         weights[lF + (1:length(tauParameters))[tauParameters=="dominancej"]] =
         1/ns;    
      } else {
        weights[lF + (1:length(tauParameters))[tauParameters=="dominancej"]] =
          (2/ns - 1/ns^2) * ns
      }
    }
    if (any(tauParameters == "Gender:dominancej")) {
      if (InbredSwitch == 1) {
        weights[lF + (1:length(tauParameters))[tauParameters=="Gender:dominancej"]] =
          .25 * (1/ns) ;
      } else {
         weights[lF + (1:length(tauParameters))[tauParameters=="Gender:dominancej"]] =
          .25 * ( 2/ns -1/ns^2) *ns ;     
      }
    }
    if (any(tauParameters == "SymCrossjk")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="SymCrossjk"]] =
        2 * ( 1 - 1/ns);
    }
    if (any(tauParameters == "Gender:SymCrossjk")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="Gender:SymCrossjk"]] =
        .5 * (1-1/ns);
    }
    if (any(tauParameters == "AllCrossjk")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="AllCrossjk"]] =
         (1-1/ns);
    }
    if (any(tauParameters == "Gender:AllCrossjk")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="Gender:AllCrossjk"]] =
         .25 * (1-1/ns);
    }
    if (any(tauParameters == "ASymCrossjkDkj")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="ASymCrossjkDkj"]] =
      .5 * ( 1- 1/ns);
    }
    if (any(tauParameters == "Gender:ASymCrossjkDkj")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="Gender:ASymCrossjkDkj"]] =
        .125 *(1-1/ns);
    }
  }
  if (!is.null(CodaChains)) {
  idFixed = (1:length(colnames(CodaChains[[1]])))[
    colnames(CodaChains[[1]]) %in% fixedParameters
  ]
  idTau = (1:length(colnames(CodaChains[[1]])))[
    colnames(CodaChains[[1]]) %in%
    paste("tau:", tauParameters, sep="")
  ]
  if (!exists("startiter")) { startiter = 1; }
  if (!exists("enditer")) { enditer = NULL;}
  if (!exists("thin")) { thin = 1; } 
  if (is.null(enditer)) { enditer = length(CodaChains[[1]][,1]) }
  if (enditer <= 0) { enditer = length(CodaChains[[1]][,1]); }
  if (enditer < startiter) {
    print("error, coda thin, startiter must be less than end iter");
    tryCatch(" end iter error!");
  }
  iters = startiter:enditer;
  if (is.null(thin)) {
    AT = (startiter+1):(enditer-1);
    AT = AT[(AT-startiter) %% thin == 0]
    iters = c(startiter, AT, enditer);
  }
  iters = iters[ iters %in% (1:length(CodaChains[[1]][,1])) ];
  } else {
  idFixed = (1:length(names(TrueVector)))[
    names(TrueVector) %in% fixedParameters
  ];
  idTau = (1:length(names(TrueVector)))[
    names(TrueVector) %in%
    paste("tau:", tauParameters, sep="")
  ];   
  }
  if (!is.null(TrueVector)) {
    tPointFixed = TrueVector[ names(TrueVector) %in% fixedParameters ];
    tPointSigma = TrueVector[substr(names(TrueVector), 1, nchar("Sigma")) == "Sigma"]
  }

  
  PointFixed = rep(0, length(fixedParameters));
  if (length(fixedParameters) >= 1) {
  for (ii in 1:length(CodaChains)) {
    if (sum(colnames(CodaChains[[ii]]) %in% fixedParameters) > 1) {
    PointFixed = PointFixed + colSums(  CodaChains[[ii]][iters,
      colnames(CodaChains[[ii]]) %in% fixedParameters]);
    } else if (sum(colnames(CodaChains[[ii]]) %in% fixedParameters) == 1) {
    PointFixed = PointFixed + sum(  CodaChains[[ii]][iters,
      colnames(CodaChains[[ii]]) %in% fixedParameters]);    
    } else {
      PointFixed = 0;
    }
  }
    PointFixed = PointFixed / (length(CodaChains) * length(iters));
  }

  PointRandom = rep(0, length(tauParameters));
  if (length(tauParameters) >= 1) {
  for (ii in 1:length(CodaChains)) {
    if (sum(colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters)) > 1) {
      PointRandom = PointRandom + colSums(  CodaChains[[ii]][iters,
        colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep="")]);
    } else if (sum(colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters))  == 1) {
      PointRandom = PointRandom + sum(  CodaChains[[ii]][iters,
        colnames(CodaChains[[ii]]) %in% paste("tau:", tauParameters,sep="")]);        
    }
  }
  PointRandom = PointRandom / (length(CodaChains) * length(iters)); 
  }
  if (!is.null(TrueVector)) {
    tPointRandom = rep(0, length(tauParameters));
    for (ii in 1:length(tauParameters)) {
      tPointRandom[ii] = sd(TrueVector[substr(names(TrueVector),1,nchar(tauParameters[ii])) == tauParameters[ii]])^2
    }
  }
  PointSigma = 0; 
  for (ii in 1:length(CodaChains)) {
    PointSigma = PointSigma + sum(  CodaChains[[ii]][iters, indexSigma]
     );
  }
  PointSigma = PointSigma / (length(CodaChains) * length(iters));
  
  if (!is.null(TrueVector)) { tPointSigma = TrueVector[indexSigma]; }
  LPHSq = list();
  for (ii in 1:length(CodaChains)) {   
    MyCoda = CodaChains[[ii]][iters,];
    PLT = NULL;
    for (jj in 1:length(fixedParameters)) {
      STT = MyCoda[,colnames(MyCoda) == fixedParameters[jj]] %*% 
        t(AllX[,colnames(AllX) == fixedParameters[jj]])
      STT = rowMeans((STT - rowMeans(STT))^2);
      PLT = cbind(PLT, STT);
    }
    IDCBind = cbind(PLT,
      MyCoda[,idTau]);
    colnames(IDCBind) = c(fixedParameters, tauParameters);
    IDCBind = t( weights * t(IDCBind));
    if (UseFixed == FALSE) {
      IDCBind = IDCBind[ ,!(colnames(IDCBind) %in% fixedParameters)]
    }
    ADCBind = IDCBind / (rowSums(IDCBind)+MyCoda[,indexSigma]);
    ADCBind[IDCBind==0] = 0;
    IDCBind = as.mcmc(ADCBind);
    LPHSq[[ii]] = IDCBind;
  }
  LPHSq = as.mcmc(LPHSq);
  MiX = match(fixedParameters, colnames(AllX));
  idXfP = (1:length(fixedParameters))[!is.na(MiX)];
  idMiX = MiX[!is.na(MiX)];
  idMiX = idMiX[sort(idXfP, index=TRUE)$ix];
  idXfP = sort(idXfP);
  PFD = NULL;
  if (length(idMiX) > 1) {
  PFD = t(t(AllX[,idMiX]) * PointFixed[idXfP]);
  PFD = rowMeans( (t(PFD) - colMeans(PFD))^2 );
  } else if (length(idMiX) == 1) {
  PFD = AllX[,idMiX] * PointFixed[idXfP];
  PFD = mean( (t(PFD) - mean(PFD))^2 );    
  }
  if (!is.null(TrueVector)) {
    tPFD = NULL;
    if (length(idMiX) > 1) {
      tPFD = t(t(AllX[,idMiX]) * tPointFixed[idXfP]);
      tPFD = rowMeans( (t(tPFD) - colMeans(tPFD))^2 );
    } else if (length(idMiX) == 1) {
      tPFD = AllX[,idMiX] * tPointFixed[idXfP];
      tPFD = mean( (t(tPFD) - mean(tPFD))^2 );    
    }
  }
  PointHSq = c(PFD, PointRandom);
  names(PointHSq) = c(fixedParameters, tauParameters);
  PointHSq = PointHSq * weights;
  if (UseFixed==FALSE) {
     PointHSq = PointHSq[!(names(PointHSq) %in% fixedParameters)];
  }
  APointHSq = PointHSq / (sum(PointHSq) + PointSigma);
  APointHSq[PointHSq == 0] = 0;
  PointHSq = APointHSq;
  
  if (!is.null(TrueVector)) {
    tPointHSq = c(tPFD, tPointRandom);
    names(tPointHSq) = c(fixedParameters, tauParameters);
    tPointHSq = tPointHSq * weights;
    if (UseFixed==FALSE) {
      tPointHSq = tPointHSq[!(names(tPointHSq) %in% fixedParameters)];
    }
    AtPointHSq = tPointHSq / (sum(tPointHSq) + tPointSigma);
    AtPointHSq[tPointHSq == 0] = 0;
    tPointHSq = AtPointHSq;
  } else {
    tPointHSq = NULL;
  }


  return(list(LPHSq = LPHSq, PointHSq = PointHSq, tPointHSq = tPointHSq));
}

setMethodS3("getPosteriorHSqTable", "DiallelOb", function(this, ...) {
  if (is.null(this$.PosteriorHSqAll) ||
    is.null(this$PosteriorHSqAll$LPHSq) || length(this$PosteriorHSqAll$LPHSq) == 0 || 
    !is.mcmc.list(this$.PosteriorHSqAll$LPHSq)) {
    this$.PosteriorHSqAll = this$PosteriorHSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  if (is.null(this$.PosteriorHSqTable)) {
    this$.PosteriorHSqTable = summary(this$.PosteriorHSqAll$LPHSq);
  }
  return(this$.PosteriorHSqTable);
});
setMethodS3("getPosteriorHSqAll", "DiallelOb", function(this, ...) {
  if (is.null(this$.PosteriorHSqAll) || 
    is.null(this$PosteriorHSqAll$LPHSq) || length(this$PosteriorHSqAll$LPHSq) == 0 || 
    !is.mcmc.list(this$.PosteriorHSqAll$LPHSq)) {
    this$.PosteriorHSqAll = this$PosteriorHSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorHSqAll);
});
setMethodS3("getPosteriorHSqPoint", "DiallelOb", function(this, ...) {
  if (is.null(this$.PosteriorHSqAll)) {
    this$.PosteriorHSqAll = this$PosteriorHSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorHSqAll$PointHSq);
});
setMethodS3("getPosteriorHSqTableImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorHSqAllImproper)) {
    this$.PosteriorHSqAllImproper = this$PosteriorHSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  if (is.null(this$.PosteriorHSqTableImproper)) {
    this$.PosteriorHSqTableImproper = summary(this$.PosteriorHSqAllImproper$LPHSq);
  }
  return(this$.PosteriorHSqTableImproper);
});
setMethodS3("getPosteriorHSqAllImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorHSqAllImproper)) {
    this$.PosteriorHSqAllImproper = this$PosteriorHSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorHSqAllImproper);
});
setMethodS3("getPosteriorHSqPointImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorHSqAllImproper)) {
    this$.PosteriorHSqAllImproper = this$PosteriorHSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorHSqAllImproper$PointHSq);
});

setMethodS3("getPosteriorHSqTableWithFixed", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorHSqAllWithFixed)) {
    this$.PosteriorHSqAllWithFixed = this$PosteriorHSq(UseFixed=TRUE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  if (is.null(this$.PosteriorHSqTableWithFixed)) {
    this$.PosteriorHSqTableWithFixed = summary(this$.PosteriorHSqAllWithFixed$LPHSq);
  }
  return(this$.PosteriorHSqTableWithFixed);
});

setMethodS3("getPosteriorHSqPointWithFixed", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorHSqAllWithFixed)) {
    this$.PosteriorHSqAllWithFixed = this$PosteriorHSq(UseFixed=TRUE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorHSqAllWithFixed$PointHSq);
});

setMethodS3("getPosteriorHSqChains", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorHSqAll) || 
    is.null(this$PosteriorHSqAll$LPHSq) || length(this$PosteriorHSqAll$LPHSq) == 0 || 
    !is.mcmc.list(this$.PosteriorHSqAll$LPHSq)) {
    this$.PosteriorHSqAll = this$PosteriorHSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorHSqAll$LPHSq);
});
setMethodS3("getPosteriorHSqChainsImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorHSqAllImproper) ||
  is.null(this$PosteriorHSqAllImproper$LPHSq) || length(this$PosteriorHSqAllImproper$LPHSq) == 0 || 
    !is.mcmc.list(this$.PosteriorHSqAllImproper$LPHSq)) {
    this$.PosteriorHSqAllImproper = this$PosteriorHSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorHSqAllImproper$LPHSq);
});
setMethodS3("getPosteriorHSqAllWithFixed", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorHSqAllWithFixed) || 
  is.null(this$PosteriorHSqAllFixed$LPHSq) || length(this$PosteriorHSqAllFixed$LPHSq) == 0 || 
    !is.mcmc.list(this$.PosteriorHSqAllFixed$LPHSq)) {
    this$.PosteriorHSqAllWithFixed = this$PosteriorHSq(UseFixed=TRUE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorHSqAllWithFixed);
});
setMethodS3("getPosteriorRSqTable", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorRSqAll) ||
    is.null(this$.PosteriorRSqAll$LPRSq) || length(this$.PosteriorRSqAll$LPRSq) == 0 || 
    !is.mcmc.list(this$.PosteriorRSqAll$LPRSq) ) {
    this$.PosteriorRSqAll = this$PosteriorRSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  if (is.null(this$.PosteriorRSqTable)) {
    this$.PosteriorRSqTable = summary(this$.PosteriorRSqAll$LPRSq);
  }
  return(this$.PosteriorRSqTable);
});
setMethodS3("getPosteriorRSqAll", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorRSqAll)  ||
    is.null(this$.PosteriorRSqAll$LPRSq) || length(this$.PosteriorRSqAll$LPRSq) == 0 || 
    !is.mcmc.list(this$.PosteriorRSqAll$LPRSq)) {
    this$.PosteriorRSqAll = this$PosteriorRSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorRSqAll);
});
setMethodS3("getPosteriorRSqPoint", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorRSqAll) ||
    is.null(this$.PosteriorRSqAll$LPRSq) || length(this$.PosteriorRSqAll$LPRSq) == 0 || 
    !is.mcmc.list(this$.PosteriorRSqAll$LPRSq)) {
    this$.PosteriorRSqAll = this$PosteriorRSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorRSqAll$PointRSq);
});
setMethodS3("getPosteriorRSqTableImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorRSqAllImproper) ||
    is.null(this$.PosteriorRSqAllImproper$LPRSq) || length(this$.PosteriorRSqAllImproper$LPRSq) == 0 || 
    !is.mcmc.list(this$.PosteriorRSqAllImproper$LPRSq)) {
    this$.PosteriorRSqAllImproper = this$PosteriorRSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  if (is.null(this$.PosteriorRSqTableImproper)) {
    this$.PosteriorRSqTableImproper = summary(this$.PosteriorRSqAllImproper$LPRSq);
  }
  return(this$.PosteriorRSqTableImproper);
});
setMethodS3("getPosteriorRSqAllImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorRSqAllImproper) ||
    is.null(this$.PosteriorRSqAllImproper$LPRSq) || length(this$.PosteriorRSqAllImproper$LPRSq) == 0 || 
    !is.mcmc.list(this$.PosteriorRSqAllImproper$LPRSq)) {
    this$.PosteriorRSqAllImproper = this$PosteriorRSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorRSqAllImproper);
});
setMethodS3("getPosteriorRSqPointImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorRSqAllImproper) || 
    is.null(this$.PosteriorRSqAllImproper$LPRSq) || length(this$.PosteriorRSqAllImproper$LPRSq) == 0 || 
    !is.mcmc.list(this$.PosteriorRSqAllImproper$LPRSq)) {
    this$.PosteriorRSqAllImproper = this$PosteriorRSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorRSqAllImproper$PointRSq);
});

setMethodS3("getPosteriorRSqTableWithFixed", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorRSqAllWithFixed) ||
    is.null(this$.PosteriorRSqAllWithFixed$LPRSq) || length(this$.PosteriorRSqAllWithFixed$LPRSq) == 0 || 
    !is.mcmc.list(this$.PosteriorRSqAllWithFixed$LPRSq)) {
    this$.PosteriorRSqAllWithFixed = this$PosteriorRSq(UseFixed=TRUE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  if (is.null(this$.PosteriorRSqTableWithFixed)) {
    this$.PosteriorRSqTableWithFixed = summary(this$.PosteriorRSqAllWithFixed$LPRSq);
  }
  return(this$.PosteriorRSqTableWithFixed);
});
setMethodS3("getPosteriorRSqAllWithFixed", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorRSqAllWithFixed)  ||
    is.null(this$.PosteriorRSqAllWithFixed$LPRSq) || length(this$.PosteriorRSqAllWithFixed$LPRSq) == 0 || 
    !is.mcmc.list(this$.PosteriorRSqAllWithFixed$LPRSq)) {
    this$.PosteriorRSqAllWithFixed = this$PosteriorRSq(UseFixed=TRUE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorRSqAllWithFixed);
});
setMethodS3("getPosteriorDSqPointWithFixed", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorDSqAllWithFixed) ||
    is.null(this$.PosteriorDSqAllWithFixed$LPDSq) || length(this$.PosteriorDSqAllWithFixed$LPDSq) == 0 || 
    !is.mcmc.list(this$.PosteriorDSqAllWithFixed$LPDSq)) {
    this$.PosteriorDSqAllWithFixed = this$PosteriorDSq(UseFixed=TRUE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorDSqAllWithFixed$PointDSq);
});

setMethodS3("getPosteriorDSqChains", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorDSqAll) ||
    is.null(this$.PosteriorDSqAll$LPDSq) || length(this$.PosteriorDSqAll$LPDSq) == 0 || 
    !is.mcmc.list(this$.PosteriorDSqAll$LPDSq)) {
    this$.PosteriorDSqAll = this$PosteriorDSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorDSqAll$LPDSq);
});

setMethodS3("getPosteriorPSqPointWithFixed", "DiallelOb", function(this,TrueVector=NULL,...) {
  if (is.null(this$.PosteriorPSqAllWithFixed) ||
    is.null(this$.PosteriorPSqAllWithFixed$LPDSq) || length(this$.PosteriorPSqAllWithFixed$LPDSq) == 0 || 
    !is.mcmc.list(this$.PosteriorPSqAllWithFixed$LPPSq)) {
    this$.PosteriorPSqAllWithFixed = this$PosteriorPSq(UseFixed=TRUE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = TrueVector);
  }
  return(this$.PosteriorPSqAllWithFixed$PointPSq);
});

setMethodS3("getPosteriorPSqChains", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorPSqAll) ||
    is.null(this$.PosteriorPSqAll$LPPSq) || length(this$.PosteriorPSqAll$LPPSq) == 0 || 
    !is.mcmc.list(this$.PosteriorPSqAll$LPPSq)) {
    this$.PosteriorPSqAll = this$PosteriorPSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorPSqAll$LPPSq);
});

setMethodS3("getPosteriorDSqChainsImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorDSqAllImproper)) {
    this$.PosteriorDSqAllImproper = this$PosteriorDSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorDSqAllImproper$LPDSq);
});


setMethodS3("getPosteriorPSqChainsImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorPSqAllImproper)) {
    this$.PosteriorPSqAllImproper = this$PosteriorPSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorPSqAllImproper$LPPSq);
});

NowStackChain <- function(AMcMc) {
  NewMcMc <- matrix(0, length(AMcMc) * NROW(AMcMc[[1]]), NCOL(AMcMc[[1]]) );
  AOn <- 0;
  library(coda);
  colnames(NewMcMc) <- colnames(AMcMc[[1]]);
  for (ii in 1:length(AMcMc)) {
     NewMcMc[AOn + 1:NROW(AMcMc[[ii]]),] <- AMcMc[[ii]]
     AOn <- AOn + NROW(AMcMc[[ii]]);
  }   
  try(NewMcMc <- as.mcmc(NewMcMc));
  return(NewMcMc);
}

WriteGetSubChains <-function(AType = "D") {
  GoText <- paste("this$.Posterior", AType, "SqAll ", sep="");
  MyText <- paste(
"
setMethodS3(\"getPosterior", AType, "DSqSubTable\", \"DiallelOb\", function(this, 
  NewSub = TRUE, DoBS = FALSE, ...) {
  if (DoBS == TRUE) {
    if (is.null(this$.AFD$.BSOther) || !is.list(this$.AFD$.BSOther) ||
      length(this$.AFD$.BSOther) <= 0) {
      this$.AFD$.BSOther <- list();    
    }
    this$.AFD$.BSOther$.Posterior", AType, "SqAll <- this$Posterior", AType, "Sq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL, DoBS = DoBS);
    PostPSq = this$.AFD$.BSOther$.Posterior", AType, "SqAll;   
  }
  if (is.null(this$.Posterior", AType, "SqAll) ||
    is.null(this$.Posterior", AType, "SqAll$LP", AType, "Sq) || 
    length(this$.Posterior", AType, "SqAll$LP", AType, "Sq) == 0 || 
    !is.mcmc.list(this$.Posterior", AType, "SqAll$LP", AType, "Sq) ) {
    this$.Posterior", AType, "SqAll = this$Posterior", AType, "Sq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL, DoBS = FALSE);
    PostPSq <- this$.Posterior", AType, "SqAll 
    if (DoBS == TRUE) {
      PostPSq <- this$.AFD$.BSOther$.Posterior", AType, "SqAll;
    }
  }
  AllConnectionNames <- rbind(
    c(\"AdditiveEffectLoc\", \"Additive inheritance (narrow-sense heritability)\"),
    c(\"FemaleEffectLoc\", \"Sex alone\"),
    c(\"FemaleAdditiveEffectLoc\", \"Sex by additive inheritance\"),
    c(\"NonSexOtherEffectsLoc\", \"Non-additive inheritance\"),
    c(\"SexOtherEffectsLoc\", \"Sex by non-additive inheritance\"),
    c(\"EpistasisLoc\", \"Epistasis specific inheritance\"),
    c(\"ParentOfOriginEffectsLoc\", \"Parent of origin splitting\"),
    c(\"SexEpistasisEffectsLoc\", \"Sex by epistasis specific inheritance\"),
    c(\"SexParentOfOriginEffectsLoc\", \"Sex by parent of origin splitting\"),
    c(\"NoiseLoc\", \"Total unexplained\"),
    c(\"TotalLoc\", \"Total explained\")  
  );
  if (DoBS == TRUE || is.null(this$.Posterior", AType, "SqSubTable)) {
    ACC <- colnames(PostPSq$LP", AType, "Sq);
    FemaleEffectLoc <- (1:length(ACC))[ACC %in% c(\"female.effect\", 
      \"Gender:Av\", \"GenderAv\", \"female.overall\", \"Female.Overall\", \"FEMALE.OVERALL\")];
    AdditiveEffectLoc <- (1:length(ACC))[ACC %in% c(\"aj\", 
      \"additive\", \"additivej\", \"AJ\")];
    FemaleAdditiveEffectLoc <- (1:length(ACC))[ACC %in% c(\"female.additive\", 
      \"sex.additive\", \"sex.additivej\", \"Gender:aj\")];
    ParentOfOriginEffectsLoc <-   (1:length(ACC))[ACC %in% c(
      \"maternal\", \"motherj\", \"maternalj\",
      \"Asym-SCA\", \"asymmetric\", \"w\",
      \"asymmetricjk\", \"ASymCrossjkDkj\", \"AllCrossjk\")]; 
    EpistasisLoc <- (1:length(ACC))[ACC %in% c(\"BetaInbred\", 
      \"BetaInbred:Av\",
      \"inbreed.overall\",\"Inbreed.overall\",
      \"inbreed\", \"inbreeding\", \"inbreedingj\", \"dominancej\",
      \"dominance\", \"Dominance\",
      \"symmetric\", \"symmetricj\", \"symmetricjk\", \"v\", \"Symmetric\",
      \"SymCrossjk\", \"Sym-SCA\", \"AllCrossjk\", \"cross\")]; 
    NonSexOtherEffectsLoc <- (1:length(ACC))[ACC %in% c(\"BetaInbred\", 
      \"BetaInbred:Av\",
      \"inbreed.overall\",\"Inbreed.overall\",
      \"inbreed\", \"inbreeding\", \"inbreedingj\", \"dominancej\",
      \"dominance\", \"Dominance\", \"maternal\", \"motherj\", \"maternalj\",
      \"symmetric\", \"symmetricj\", \"symmetricjk\", \"v\", \"Symmetric\",
      \"SymCrossjk\", \"Sym-SCA\", \"Asym-SCA\", \"asymmetric\", \"w\",
      \"asymmetricjk\", \"ASymCrossjkDkj\", \"AllCrossjk\", \"cross\")]; 
    SexParentOfOriginEffectsLoc <- (1:length(ACC))[ACC %in% c(\"Gender:motherj\",
      \"sex.maternal\", \"sex.motherj\",
      \"Sex*Asym-SCA\", \"sex.asymmetric\",
      \"sex.asymmetricjk\", \"Gender:ASymCrossjkDkj\")]; 
    SexEpistasisEffectsLoc <- (1:length(ACC))[ACC %in% c(\"BetaInbredTimesSex\", 
      \"BetaInbred:Gender:Av\",
      \"sex.inbreed\", \"sex.inbreed.overall\",
      \"sex.inbreed\", \"sex.inbreeding\", \"sex.inbreedingj\", \"sex.dominancej\",
      \"Gender:dominancej\", 
      \"sex.dominance\", \"sex.Dominance\",
      \"sex.symmetric\", \"sex.symmetricj\", \"sex.symmetricjk\", \"sex.v\", 
      \"sex.Symmetric\",
      \"Gender:SymCrossjk\", \"sex.SymCrossjk\", \"Sex*Sym-SCA\",
      \"Gender:AllCrossjk\", \"sex.cross\",
      \"Sex*Cross\", \"sex*cross\")];   
    SexOtherEffectsLoc <- (1:length(ACC))[ACC %in% c(\"BetaInbredTimesSex\", 
      \"BetaInbred:Gender:Av\",
      \"sex.inbreed\", \"sex.inbreed.overall\",
      \"sex.inbreed\", \"sex.inbreeding\", \"sex.inbreedingj\", \"sex.dominancej\",
      \"Gender:dominancej\", \"Gender:motherj\",
      \"sex.dominance\", \"sex.Dominance\", \"sex.maternal\", \"sex.motherj\",
      \"sex.maternalj\", \"sex.symmetric\", \"sex.symmetricj\", \"sex.symmetricjk\", \"sex.v\", \"sex.Symmetric\",
      \"Gender:SymCrossjk\", \"sex.SymCrossjk\", \"Sex*Sym-SCA\", \"Sex*Asym-SCA\", \"sex.asymmetric\",
      \"sex.asymmetricjk\", \"Gender:ASymCrossjkDkj\", \"Gender:AllCrossjk\", \"sex.cross\",
      \"Sex*Cross\", \"sex*cross\")];   
    NoiseLoc <- (1:length(ACC))[ACC %in% c(\"Noise\", \"noise\", \"Sigma\", \"Sigma:1\",
      \"Excess Variance\", \"Unexplained Variance\", \"Unexplained Response\")];
    TotalLoc <- (1:length(ACC))[ACC %in% c(\"total.explained\", \"Total.Explained\", \"Explained\", \"Total Explained\", \"tot.explained\",
      \"Broad Sense\", \"broad.sense\", \"total.sense\")];
    LG1 <- function(a) { if(!is.null(a) && length(a) >= 1) { return(1); }  else {return(0);} }
    NewSubTable <- list();
     SetNewSub <- c(\"AdditiveEffectLoc\", \"FemaleEffectLoc\", 
      \"FemaleAdditiveEffectLoc\", \"ParentOfOriginEffectsLoc\",
      \"EpistasisLoc\", \"SexParentOfOriginEffectsLoc\", \"SexEpistasisEffectsLoc\")
    SetOldSub <- c(\"AdditiveEffectLoc\", \"FemaleEffectLoc\", 
      \"FemaleAdditiveEffectLoc\", \"NonSexOtherEffectsLoc\", \"SexOtherEffectsLoc\")
    if (!exists(\"NewSub\") || (is.logical(NewSub) && NewSub == TRUE)) {
      OnSub = SetNewSub;
    } else {
      OnSub <- SetOldSub;
    }
    MyLenText <-
paste(\" 
    if (length(TotalLoc)  <= 0 || (length(TotalLoc) == 1 && TotalLoc == -1)) {
      TotalLoc = c( \", paste(OnSub, collapse=\", \"), \");
    }
\", sep=\"\"); ## Calculate TotalLoc is all terms here.
AllSub <- c(OnSub, \"NoiseLoc\", \"TotalLoc\");
try(eval(parse(text=MyLenText)));
MyMLenText <- paste(\"MLen <- \",
    paste(\"LG1(\", AllSub, \")\", collapse=\" + 
    \"), \";\", sep=\"\");     ## Set MLen to sub LG1 of all variables
try(eval(parse(text=MyMLenText)));
    
  for (ii in 1:length(PostPSq$LP", AType, "Sq)) {
    ANewTable <- matrix(0,NROW(PostPSq$LP", AType, "Sq[[ii]]),
        MLen);  AP = 1;
    ACN <- c();
    for (jj in 1:length(AllSub)) {
      ARD <- (1:NROW(AllConnectionNames))[AllConnectionNames[,1] == AllSub[jj]];
      MyText <- paste(\"
        if (LG1(\", AllSub[jj], \") == 1) {
          if (length(\", AllSub[jj], \") == 1) {
            ANewTable[,AP] <- 
              PostPSq$LP", AType, "Sq[[ii]][,\", AllSub[jj], \"];
          } else {
            ANewTable[,AP] <-
              rowSums(PostPSq$LP", AType, "Sq[[ii]][,\", AllSub[jj], \"]);
          }
          AP <- AP + 1; ACN <- c(ACN, \\\"\", AllConnectionNames[ARD,2], \"\\\");
        }
      \", sep=\"\"); 
      try(eval(parse(text=MyText)));
     }
      colnames(ANewTable) <- ACN;
      try(ANewTable <- as.mcmc(ANewTable));
      try(NewSubTable[[ii]] <- ANewTable);
    
    }  
    try(NewSubTable <- as.mcmc.list(NewSubTable));
    if (DoBS == FALSE) {
      try(this$.Posterior", AType, "SqAll$SubTable <- NewSubTable);
      this$.Posterior", AType, "SqSubTable = summary(NewSubTable);
    }
    if (DoBS == TRUE) {
      try(this$.AFD$.BSOther$.Posterior", AType, "SqAll$SubTable <- NewSubTable);
      try(this$.AFD$.BSOther$.Posterior", AType, "SqSubTable <- summary(NewSubTable));
      return(summary(NewSubTable));
    }
  }
  return(this$.Posterior", AType, "SqSubTable);
  });
  ", sep="");  
}

try(eval(parse(text=WriteGetSubChains("D"))));
try(eval(parse(text=WriteGetSubChains("D"))));
try(eval(parse(text=WriteGetSubChains("P"))));

WriteMyHPDTableFunction <- function(AType="D", DoSub=FALSE) {
 

  SubScript = "";  NewSubScript = ""; GetSubScript = "";

  TableGoalScript = paste("
    if (DoBS == TRUE) {
      Chain <- this$.AFD$.BSOther$.Posterior", AType, "SqAll$LP", AType, "Sq;
    } else {
      Chain <- this$.Posterior", AType, "SqAll$LP", AType, "Sq;
    }
   ", sep="");
  if (DoSub == TRUE) { 
    SubScript = "Sub"; NewSubScript = " NewSub = TRUE, ";
    GetSubScript = paste("SubTableOut <- this$getPosterior", AType, "SqSubTable(NewSub, DoBS=DoBS); ", sep="");
    TableGoalScript = paste("
      if (DoBS == FALSE) {
        Chain <- this$.Posterior", AType, "SqAll$SubTable
      } else {
        Chain <- this$.AFD$.BSOther$.Posterior", AType, "SqAll$SubTable  
      }
      ", sep="");
    
  }
  
  MyText <- paste("
    setMethodS3(\"getPosterior", AType, "SqHPD", SubScript, "Table\", \"DiallelOb\", 
      function(this, ", NewSubScript, " DoBS=FALSE, ...) {
  if (DoBS == TRUE) {
    PPMadeSq <- this$Posterior", AType, "Sq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL, DoBS=DoBS)  
  }
  if (is.null(this$.Posterior", AType, "SqAll) ||
    is.null(this$.Posterior", AType, "SqAll$LP", AType, "Sq) || length(this$.Posterior", AType, "SqAll$LP", AType, "Sq) == 0 || 
    !is.mcmc.list(this$.Posterior", AType, "SqAll$LP", AType, "Sq) ) {
    this$.Posterior", AType, "SqAll = this$Posterior", AType, "Sq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL, DoBS=DoBS);
  }
  ", GetSubScript,"
  ", TableGoalScript, "
  if (is.null(Chain) || length(Chain) <= 0) {
    print(paste(\"An Error in Posterior", AType, "SqHPD", SubScript, "Table\", sep=\"\"));
    flush.console();
    print(paste(\"The Chain we specified in command: \\\"", TableGoalScript, "\\\" is null! \", sep=\"\")); flush.console();
    print(\" We write some elements to global to inspect error \"); flush.console();
    try(eval(parse(text=SetGText(\"Chain\", \"globalenv()\", S=1))));
    return(-1);   
  }
  AStack <- NULL;
  try(AStack <- NowStackChain(Chain));
  if (is.null(AStack) || length(AStack) <= 0) {
    print(paste(\"An Error in Posterior", AType, "SqHPD", SubScript, "Table to generate AStack\", sep=\"\"));
    flush.console();
    print(paste(\"The Chain was faulty: \\\"", TableGoalScript, "\\\" is not good for AStack! \", sep=\"\")); flush.console();
    try(eval(parse(text=SetGText(\"Chain\", \"globalenv()\", S=1))));
    return(-1);   
  }
  Means <- colMeans(AStack);
  library(coda);
  HPDScore <- this$.AFD$HPDTarget;
  HPDTable <- HPDinterval(AStack, HPDScore);
  NewTable <- matrix(0, NCOL(AStack), 3);
  colnames(NewTable) <- c(\"mean\", paste(\"Low\", HPDScore, \"HPD\", sep=\"\"),
    paste(\"High\", HPDScore, \"HPD\", sep=\"\"));
  rownames(NewTable) <- colnames(AStack);
  NewTable[,1] <-Means;
  NewTable[,2] <- HPDTable[,1];
  NewTable[,3] <- HPDTable[,2];
  return(NewTable);
  });
  ", sep="");
  return(MyText);
}
try(eval(parse(text=WriteMyHPDTableFunction("D", TRUE))));
try(eval(parse(text=WriteMyHPDTableFunction("R", TRUE))));
try(eval(parse(text=WriteMyHPDTableFunction("P", TRUE))));
try(eval(parse(text=WriteMyHPDTableFunction("H", TRUE))));
try(eval(parse(text=WriteMyHPDTableFunction("D", FALSE))));
try(eval(parse(text=WriteMyHPDTableFunction("R", FALSE))));
try(eval(parse(text=WriteMyHPDTableFunction("P", FALSE))));
try(eval(parse(text=WriteMyHPDTableFunction("H", FALSE))));

setMethodS3("getPosteriorDSqSubTable", "DiallelOb", function(this, 
  NewSub = TRUE, ...) {
  if (is.null(this$.PosteriorDSqAll) ||
    is.null(this$.PosteriorDSqAll$LPDSq) || length(this$.PosteriorDSqAll$LPDSq) == 0 || 
    !is.mcmc.list(this$.PosteriorDSqAll$LPDSq) ) {
    this$.PosteriorDSqAll = this$PosteriorDSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  AllConnectionNames <- rbind(
    c("AdditiveEffectLoc", "Additive inheritance (narrow-sense heritability)"),
    c("FemaleEffectLoc", "Sex alone"),
    c("FemaleAdditiveEffectLoc", "Sex by additive inheritance"),
    c("NonSexOtherEffectsLoc", "Non-additive inheritance"),
    c("SexOtherEffectsLoc", "Sex by non-additive inheritance"),
    c("EpistasisLoc", "Epistasis specific inheritance"),
    c("ParentOfOriginEffectsLoc", "Parent of origin splitting"),
    c("SexEpistasisEffectsLoc", "Sex by epistasis specific inheritance"),
    c("SexParentOfOriginEffectsLoc", "Sex by parent of origin splitting"),
    c("NoiseLoc", "Total unexplained"),
    c("TotalLoc", "Total explained")  
  );
  if (is.null(this$.PosteriorDSqSubTable)) {
    ACC <- colnames(this$.PosteriorDSqAll$LPDSq[[1]]);
    FemaleEffectLoc <- (1:length(ACC))[ACC %in% c("female.effect", 
      "Gender:Av", "GenderAv", "female.overall", "Female.Overall", "FEMALE.OVERALL")];
    AdditiveEffectLoc <- (1:length(ACC))[ACC %in% c("aj", 
      "additive", "additivej", "AJ")];
    FemaleAdditiveEffectLoc <- (1:length(ACC))[ACC %in% c("female.additive", 
      "sex.additive", "sex.additivej", "Gender:aj")];
    ParentOfOriginEffectsLoc <-   (1:length(ACC))[ACC %in% c(
      "maternal", "motherj", "maternalj",
      "Asym-SCA", "asymmetric", "w",
      "asymmetricjk", "ASymCrossjkDkj", "AllCrossjk")]; 
    EpistasisLoc <- (1:length(ACC))[ACC %in% c("BetaInbred", 
      "BetaInbred:Av",
      "inbreed.overall","Inbreed.overall",
      "inbreed", "inbreeding", "inbreedingj", "dominancej",
      "dominance", "Dominance",
      "symmetric", "symmetricj", "symmetricjk", "v", "Symmetric",
      "SymCrossjk", "Sym-SCA", "AllCrossjk", "cross")]; 
    NonSexOtherEffectsLoc <- (1:length(ACC))[ACC %in% c("BetaInbred", 
      "BetaInbred:Av",
      "inbreed.overall","Inbreed.overall",
      "inbreed", "inbreeding", "inbreedingj", "dominancej",
      "dominance", "Dominance", "maternal", "motherj", "maternalj",
      "symmetric", "symmetricj", "symmetricjk", "v", "Symmetric",
      "SymCrossjk", "Sym-SCA", "Asym-SCA", "asymmetric", "w",
      "asymmetricjk", "ASymCrossjkDkj", "AllCrossjk", "cross")]; 
    SexParentOfOriginEffectsLoc <- (1:length(ACC))[ACC %in% c("Gender:motherj",
      "sex.maternal", "sex.motherj",
      "Sex*Asym-SCA", "sex.asymmetric",
      "sex.asymmetricjk", "Gender:ASymCrossjkDkj")]; 
    SexEpistasisEffectsLoc <- (1:length(ACC))[ACC %in% c("BetaInbredTimesSex", 
      "BetaInbred:Gender:Av",
      "sex.inbreed", "sex.inbreed.overall",
      "sex.inbreed", "sex.inbreeding", "sex.inbreedingj", "sex.dominancej",
      "Gender:dominancej", 
      "sex.dominance", "sex.Dominance",
      "sex.symmetric", "sex.symmetricj", "sex.symmetricjk", "sex.v", 
      "sex.Symmetric",
      "Gender:SymCrossjk", "sex.SymCrossjk", "Sex*Sym-SCA",
      "Gender:AllCrossjk", "sex.cross",
      "Sex*Cross", "sex*cross")];   
    SexOtherEffectsLoc <- (1:length(ACC))[ACC %in% c("BetaInbredTimesSex", 
      "BetaInbred:Gender:Av",
      "sex.inbreed", "sex.inbreed.overall",
      "sex.inbreed", "sex.inbreeding", "sex.inbreedingj", "sex.dominancej",
      "Gender:dominancej", "Gender:motherj",
      "sex.dominance", "sex.Dominance", "sex.maternal", "sex.motherj",
      "sex.maternalj", "sex.symmetric", "sex.symmetricj", "sex.symmetricjk", "sex.v", "sex.Symmetric",
      "Gender:SymCrossjk", "sex.SymCrossjk", "Sex*Sym-SCA", "Sex*Asym-SCA", "sex.asymmetric",
      "sex.asymmetricjk", "Gender:ASymCrossjkDkj", "Gender:AllCrossjk", "sex.cross",
      "Sex*Cross", "sex*cross")];   
    NoiseLoc <- (1:length(ACC))[ACC %in% c("Noise", "noise", "Sigma", "Sigma:1",
      "Excess Variance", "Unexplained Variance", "Unexplained Response")];
    TotalLoc <- (1:length(ACC))[ACC %in% c("total.explained", "Total.Explained", "Explained", "Total Explained", "tot.explained",
      "Broad Sense", "broad.sense", "total.sense")];
    LG1 <- function(a) { if(!is.null(a) && length(a) >= 1) { return(1); }  else {return(0);} }
    NewSubTable <- list();
    
    SetNewSub <- c("AdditiveEffectLoc", "FemaleEffectLoc", 
      "FemaleAdditiveEffectLoc", "ParentOfOriginEffectsLoc",
      "EpistasisLoc", "SexParentOfOriginEffectsLoc", "SexEpistasisEffectsLoc")
    SetOldSub <- c("AdditiveEffectLoc", "FemaleEffectLoc", 
      "FemaleAdditiveEffectLoc", "NonSexOtherEffectsLoc", "SexOtherEffectsLoc")
    if (!exists("NewSub") || (is.logical(NewSub) && NewSub == TRUE)) {
      OnSub = SetNewSub;
    } else {
      OnSub <- SetOldSub;
    }
    MyLenText <-
paste(" 
    if (length(TotalLoc)  <= 0 || (length(TotalLoc) == 1 && TotalLoc == -1)) {
      TotalLoc = c( ", paste(OnSub, collapse=", "), ");
    }
", sep=""); ## Calculate TotalLoc is all terms here.
AllSub <- c(OnSub, "NoiseLoc", "TotalLoc");
try(eval(parse(text=MyLenText)));
    MyMLenText <- paste("MLen <- ",
    paste("LG1(", AllSub, ")", collapse=" + 
    "), ";", sep="");     ## Set MLen to sub LG1 of all variables
try(eval(parse(text=MyMLenText)));
    
  for (ii in 1:length(this$.PosteriorDSqAll$LPDSq)) {
    ANewTable <- matrix(0,NROW(this$.PosteriorDSqAll$LPDSq[[ii]]),
        MLen);  AP = 1;
    ACN <- c();
    for (jj in 1:length(AllSub)) {
      ARD <- (1:NROW(AllConnectionNames))[AllConnectionNames[,1] == AllSub[jj]];
      MyText <- paste("
        if (LG1(", AllSub[jj], ") == 1) {
          if (length(", AllSub[jj], ") == 1) {
            ANewTable[,AP] <- 
              this$.PosteriorDSqAll$LPDSq[[ii]][,", AllSub[jj], "];
          } else {
            ANewTable[,AP] <-
              rowSums(this$.PosteriorDSqAll$LPDSq[[ii]][,", AllSub[jj], "]);
          }
          AP <- AP + 1; ACN <- c(ACN, \"", AllConnectionNames[ARD,2], "\");
        }
      ", sep=""); 
      try(eval(parse(text=MyText)));
     }
      colnames(ANewTable) <- ACN;
      try(ANewTable <- as.mcmc(ANewTable));
      try(NewSubTable[[ii]] <- ANewTable);
    
    }  
    try(NewSubTable <- as.mcmc.list(NewSubTable));
    try(this$.PosteriorDSqAll$SubTable <- NewSubTable);
    this$.PosteriorDSqSubTable = summary(NewSubTable);
  }
  return(this$.PosteriorDSqSubTable);
});

    


setMethodS3("getPosteriorPSqSubTable", "DiallelOb", function(this, TrueVector = NULL, DoBS=FALSE, ...) {
  if (is.null(this$.PosteriorPSqAll) ||
    is.null(this$.PosteriorPSqAll$LPPSq) || length(this$.PosteriorPSqAll$LPPSq) == 0 || 
    !is.mcmc.list(this$.PosteriorPSqAll$LPPSq) ) {
    this$.PosteriorPSqAll = this$PosteriorPSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL, DoBS = FALSE);
     PPSqAll <-   this$.PosteriorPSqAll;   
  } else{
     PPSqAll <-   this$.PosteriorPSqAll; 
  }
  if (DoBS == TRUE) {
    PPSqAll <-  this$PosteriorPSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL, DoBS=DoBS);
  }
  AllConnectionNames <- rbind(
    c("AdditiveEffectLoc", "Additive inheritance (narrow-sense heritability)"),
    c("FemaleEffectLoc", "Sex alone"),
    c("FemaleAdditiveEffectLoc", "Sex by additive inheritance"),
    c("NonSexOtherEffectsLoc", "Non-additive inheritance"),
    c("SexOtherEffectsLoc", "Sex by non-additive inheritance"),
    c("EpistasisLoc", "Epistasis specific inheritance"),
    c("ParentOfOriginEffectsLoc", "Parent of origin splitting"),
    c("SexEpistasisEffectsLoc", "Sex by epistasis specific inheritance"),
    c("SexParentOfOriginEffectsLoc", "Sex by parent of origin splitting"),
    c("NoiseLoc", "Total unexplained"),
    c("TotalLoc", "Total explained")  
  );
  if (DoBS == TRUE || is.null(this$.PosteriorPSqSubTable)) {
    ACC <- colnames(PPSqAll$LPPSq[[1]]);
    FemaleEffectLoc <- (1:length(ACC))[ACC %in% c("female.effect", 
      "Gender:Av", "GenderAv", "female.overall", "Female.Overall", "FEMALE.OVERALL")];
    AdditiveEffectLoc <- (1:length(ACC))[ACC %in% c("aj", 
      "additive", "additivej", "AJ")];
    FemaleAdditiveEffectLoc <- (1:length(ACC))[ACC %in% c("female.additive", 
      "sex.additive", "sex.additivej", "Gender:aj")];
    ParentOfOriginEffectsLoc <-   (1:length(ACC))[ACC %in% c(
      "maternal", "motherj", "maternalj",
      "Asym-SCA", "asymmetric", "w",
      "asymmetricjk", "ASymCrossjkDkj", "AllCrossjk")]; 
    EpistasisLoc <- (1:length(ACC))[ACC %in% c("BetaInbred", 
      "BetaInbred:Av",
      "inbreed.overall","Inbreed.overall",
      "inbreed", "inbreeding", "inbreedingj", "dominancej",
      "dominance", "Dominance",
      "symmetric", "symmetricj", "symmetricjk", "v", "Symmetric",
      "SymCrossjk", "Sym-SCA", "AllCrossjk", "cross")]; 
    NonSexOtherEffectsLoc <- (1:length(ACC))[ACC %in% c("BetaInbred", 
      "BetaInbred:Av",
      "inbreed.overall","Inbreed.overall",
      "inbreed", "inbreeding", "inbreedingj", "dominancej",
      "dominance", "Dominance", "maternal", "motherj", "maternalj",
      "symmetric", "symmetricj", "symmetricjk", "v", "Symmetric",
      "SymCrossjk", "Sym-SCA", "Asym-SCA", "asymmetric", "w",
      "asymmetricjk", "ASymCrossjkDkj", "AllCrossjk", "cross")]; 
    SexParentOfOriginEffectsLoc <- (1:length(ACC))[ACC %in% c("Gender:motherj",
      "sex.maternal", "sex.motherj",
      "Sex*Asym-SCA", "sex.asymmetric",
      "sex.asymmetricjk", "Gender:ASymCrossjkDkj")]; 
    SexEpistasisEffectsLoc <- (1:length(ACC))[ACC %in% c("BetaInbredTimesSex", 
      "BetaInbred:Gender:Av",
      "sex.inbreed", "sex.inbreed.overall",
      "sex.inbreed", "sex.inbreeding", "sex.inbreedingj", "sex.dominancej",
      "Gender:dominancej", 
      "sex.dominance", "sex.Dominance",
      "sex.symmetric", "sex.symmetricj", "sex.symmetricjk", "sex.v", 
      "sex.Symmetric",
      "Gender:SymCrossjk", "sex.SymCrossjk", "Sex*Sym-SCA",
      "Gender:AllCrossjk", "sex.cross",
      "Sex*Cross", "sex*cross")];   
    SexOtherEffectsLoc <- (1:length(ACC))[ACC %in% c("BetaInbredTimesSex", 
      "BetaInbred:Gender:Av",
      "sex.inbreed", "sex.inbreed.overall",
      "sex.inbreed", "sex.inbreeding", "sex.inbreedingj", "sex.dominancej",
      "Gender:dominancej", "Gender:motherj",
      "sex.dominance", "sex.Dominance", "sex.maternal", "sex.motherj",
      "sex.maternalj", "sex.symmetric", "sex.symmetricj", "sex.symmetricjk", "sex.v", "sex.Symmetric",
      "Gender:SymCrossjk", "sex.SymCrossjk", "Sex*Sym-SCA", "Sex*Asym-SCA", "sex.asymmetric",
      "sex.asymmetricjk", "Gender:ASymCrossjkDkj", "Gender:AllCrossjk", "sex.cross",
      "Sex*Cross", "sex*cross")];   
    NoiseLoc <- (1:length(ACC))[ACC %in% c("Noise", "noise", "Sigma", "Sigma:1",
      "Excess Variance", "Unexplained Variance", "Unexplained Response")];
    TotalLoc <- (1:length(ACC))[ACC %in% c("total.explained", "Total.Explained", "Explained", "Total Explained", "tot.explained",
      "Broad Sense", "broad.sense", "total.sense")];
    LG1 <- function(a) { if(!is.null(a) && length(a) >= 1) { return(1); }  else {return(0);} }
    NewSubTable <- list();
    
    SetNewSub <- c("AdditiveEffectLoc", "FemaleEffectLoc", 
      "FemaleAdditiveEffectLoc", "ParentOfOriginEffectsLoc",
      "EpistasisLoc", "SexParentOfOriginEffectsLoc", "SexEpistasisEffectsLoc")
    SetOldSub <- c("AdditiveEffectLoc", "FemaleEffectLoc", 
      "FemaleAdditiveEffectLoc", "NonSexOtherEffectsLoc", "SexOtherEffectsLoc")
    if (!exists("NewSub") || (is.logical(NewSub) && NewSub == TRUE)) {
      OnSub = SetNewSub;
    } else {
      OnSub <- SetOldSub;
    }
    MyLenText <-
paste(" 
    if (length(TotalLoc)  <= 0 || (length(TotalLoc) == 1 && TotalLoc == -1)) {
      TotalLoc = c( ", paste(OnSub, collapse=", "), ");
    }
", sep=""); ## Calculate TotalLoc is all terms here.
AllSub <- c(OnSub, "NoiseLoc", "TotalLoc");
try(eval(parse(text=MyLenText)));
    MyMLenText <- paste("MLen <- ",
    paste("LG1(", AllSub, ")", collapse=" + 
    "), ";", sep="");     ## Set MLen to sub LG1 of all variables
try(eval(parse(text=MyMLenText)));
    
  for (ii in 1:length(PPSqAll$LPPSq)) {
    ANewTable <- matrix(0,NROW(PPSqAll$LPPSq[[ii]]),
        MLen);  AP = 1;
    ACN <- c();
    for (jj in 1:length(AllSub)) {
      ARD <- (1:NROW(AllConnectionNames))[AllConnectionNames[,1] == AllSub[jj]];
      MyText <- paste("
        if (LG1(", AllSub[jj], ") == 1) {
          if (length(", AllSub[jj], ") == 1) {
            ANewTable[,AP] <- 
              PPSqAll$LPPSq[[ii]][,", AllSub[jj], "];
          } else {
            ANewTable[,AP] <-
              rowSums(PPSqAll$LPPSq[[ii]][,", AllSub[jj], "]);
          }
          AP <- AP + 1; ACN <- c(ACN, \"", AllConnectionNames[ARD,2], "\");
        }
      ", sep=""); 
      try(eval(parse(text=MyText)));
     }
      colnames(ANewTable) <- ACN;
      try(ANewTable <- as.mcmc(ANewTable));
      try(NewSubTable[[ii]] <- ANewTable);
    
    }  
    try(NewSubTable <- as.mcmc.list(NewSubTable));
    if (DoBS == FALSE) {
      try(this$.PosteriorPSqAll$SubTable <- NewSubTable);
    } else {
      if (is.null(this$.AFD$.BSOther) || !is.list(this$.AFD$.BSOther) ||
        length(this$.AFD$.BSOther) <= 0) {
        this$.AFD$.BSOther <- list();      
      }
      if (is.null(this$.AFD$.BSOther$.PosteriorPSqAll) || 
        !is.list(this$.AFD$.BSOther$.PosteriorPSqAll) ||
        length(this$.AFD$.BSOther$.PosteriorPSqAll) <= 0) {
        this$.AFD$.BSOther$.PosteriorPSqAll <- list();
      }   
      try(this$.AFD$.BSOther$.PosteriorPSqAll$SubTable  <- NewSubTable)
    }
    if (DoBS == FALSE) {
      this$.PosteriorPSqSubTable = summary(NewSubTable);
    }  else {
      try(this$.AFD$.BSOther$.PosteriorPSqAll$SubTable  <- NewSubTable)        
    }
    return(summary(NewSubTable));
  }
  return(this$.PosteriorPSqSubTable);
});

setMethodS3("getPosteriorDSqSumTable", "DiallelOb", function(this,...) {
   return(this$getPosteriorDSqSubTable());
});

setMethodS3("getPosteriorPSqSumTable", "DiallelOb", function(this,...) {
   return(this$getPosteriorPSqSubTable());
});


setMethodS3("getPosteriorDSqTable", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorDSqAll) ||
    is.null(this$.PosteriorDSqAll$LPDSq) || length(this$.PosteriorDSqAll$LPDSq) == 0 || 
    !is.mcmc.list(this$.PosteriorDSqAll$LPDSq) ) {
    this$.PosteriorDSqAll = this$PosteriorDSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  if (is.null(this$.PosteriorDSqTable)) {
    this$.PosteriorDSqTable = summary(this$.PosteriorDSqAll$LPDSq);
  }
  return(this$.PosteriorDSqTable);
});

setMethodS3("getPosteriorPSqTable", "DiallelOb", function(this,DoBS=FALSE,...) {
  if (DoBS == TRUE) {
    APSS = this$PosteriorPSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL, DoBS=DoBS);  
    SAPSS <- summary(APSS$LPPSq);
    return(SAPSS);  
  }
  if (is.null(this$.PosteriorPSqAll) ||
    is.null(this$.PosteriorPSqAll$LPPSq) || length(this$.PosteriorPSqAll$LPPSq) == 0 || 
    !is.mcmc.list(this$.PosteriorPSqAll$LPPSq) ) {   
    APSS = this$PosteriorPSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL, DoBS=DoBS);
    this$.PosteriorPSqAll  <- APSS;  
  } else {
    APSS <- this$.PosteriorPSqAll;
    if (is.null(this$.AFD$.BSOther) || !is.list(this$.AFD$.BSOther) ||
      length(this$.AFD$.BSOther) <= 0) {
      this$.AFD$.BSOther <- list();    
    }
    if (is.null(this$.AFD$.BSOther$.PosteriorPSqAll))  {
      this$.AFD$.BSOther$.PosteriorPSqAll <- APSS;  
    }
    this$.AFD$.BSOther$.PosteriorPSqTable <- summary(APSS$LPPSq);
    return(this$.AFD$.BSOther$.PosteriorPSqTable);
  }
  SAPSS <- summary(APSS$LPPSq);
  this$.PosteriorPSqTable <-SAPSS;   
  return(SAPSS);
});

setMethodS3("getPosteriorDSqAll", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorDSqAll)  ||
    is.null(this$.PosteriorDSqAll$LPDSq) || length(this$.PosteriorDSqAll$LPDSq) == 0 || 
    !is.mcmc.list(this$.PosteriorDSqAll$LPDSq)) {
    this$.PosteriorDSqAll = this$PosteriorDSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorDSqAll);
});

setMethodS3("getPosteriorPSqAll", "DiallelOb", function(this, TrueVector=NULL, ...) {
  if (is.null(this$.PosteriorPSqAll)  ||
    is.null(this$.PosteriorPSqAll$LPPSq) || length(this$.PosteriorPSqAll$LPPSq) == 0 || 
    !is.mcmc.list(this$.PosteriorPSqAll$LPPSq)) {
    this$.PosteriorPSqAll = this$PosteriorPSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = TrueVector);
  }
  return(this$.PosteriorPSqAll);
});

setMethodS3("getPosteriorDSqPoint", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorDSqAll) ||
    is.null(this$.PosteriorDSqAll$LPDSq) || length(this$.PosteriorDSqAll$LPDSq) == 0 || 
    !is.mcmc.list(this$.PosteriorDSqAll$LPDSq)) {
    this$.PosteriorDSqAll = this$PosteriorDSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorDSqAll$PointDSq);
});


setMethodS3("getPosteriorPSqPoint", "DiallelOb", function(this,TrueVector=NULL,...) {
  if (is.null(this$.PosteriorPSqAll) ||
    is.null(this$.PosteriorPSqAll$LPPSq) || length(this$.PosteriorPSqAll$LPPSq) == 0 || 
    !is.mcmc.list(this$.PosteriorPSqAll$LPPSq)) {
    this$.PosteriorPSqAll = this$PosteriorPSq(UseFixed=FALSE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = TrueVector);
  }
  return(this$.PosteriorPSqAll$PointPSq);
});

setMethodS3("getPosteriorDSqTableImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorDSqAllImproper) ||
    is.null(this$.PosteriorDSqAllImproper$LPDSq) || length(this$.PosteriorDSqAllImproper$LPDSq) == 0 || 
    !is.mcmc.list(this$.PosteriorDSqAllImproper$LPDSq)) {
    this$.PosteriorDSqAllImproper = this$PosteriorDSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  if (is.null(this$.PosteriorDSqTableImproper)) {
    this$.PosteriorDSqTableImproper = summary(this$.PosteriorDSqAllImproper$LPRSq);
  }
  return(this$.PosteriorDSqTableImproper);
});
setMethodS3("getPosteriorPSqTableImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorPSqAllImproper) ||
    is.null(this$.PosteriorPSqAllImproper$LPPSq) || length(this$.PosteriorPSqAllImproper$LPPSq) == 0 || 
    !is.mcmc.list(this$.PosteriorPSqAllImproper$LPPSq)) {
    this$.PosteriorPSqAllImproper = this$PosteriorPSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  if (is.null(this$.PosteriorPSqTableImproper)) {
    this$.PosteriorPSqTableImproper = summary(this$.PosteriorPSqAllImproper$LPRSq);
  }
  return(this$.PosteriorPSqTableImproper);
});

setMethodS3("getPosteriorDSqAllImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorDSqAllImproper) ||
    is.null(this$.PosteriorDSqAllImproper$LPDSq) || length(this$.PosteriorDSqAllImproper$LPDSq) == 0 || 
    !is.mcmc.list(this$.PosteriorDSqAllImproper$LPDSq)) {
    this$.PosteriorDSqAllImproper = this$PosteriorDSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorDSqAllImproper);
});
setMethodS3("getPosteriorPSqAllImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorPSqAllImproper) ||
    is.null(this$.PosteriorPSqAllImproper$LPPSq) || length(this$.PosteriorPSqAllImproper$LPPSq) == 0 || 
    !is.mcmc.list(this$.PosteriorPSqAllImproper$LPPSq)) {
    this$.PosteriorPSqAllImproper = this$PosteriorPSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorPSqAllImproper);
});

setMethodS3("getPosteriorDSqPointImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorDSqAllImproper) || 
    is.null(this$.PosteriorDSqAllImproper$LPDSq) || length(this$.PosteriorDSqAllImproper$LPDSq) == 0 || 
    !is.mcmc.list(this$.PosteriorDSqAllImproper$LPDSq)) {
    this$.PosteriorDSqAllImproper = this$PosteriorDSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorDSqAllImproper$PointDSq);
});

setMethodS3("getPosteriorPSqPointImproper", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorPSqAllImproper) || 
    is.null(this$.PosteriorPSqAllImproper$LPDSq) || length(this$.PosteriorPSqAllImproper$LPPSq) == 0 || 
    !is.mcmc.list(this$.PosteriorPSqAllImproper$LPPSq)) {
    this$.PosteriorPSqAllImproper = this$PosteriorPSq(UseFixed=FALSE, ProperRatio=FALSE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorPSqAllImproper$PointPSq);
});


setMethodS3("getPosteriorDSqTableWithFixed", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorDSqAllWithFixed) ||
    is.null(this$.PosteriorDSqAllWithFixed$LPRSq) || length(this$.PosteriorDSqAllWithFixed$LPRSq) == 0 || 
    !is.mcmc.list(this$.PosteriorDSqAllWithFixed$LPRSq)) {
    this$.PosteriorDSqAllWithFixed = this$PosteriorDSq(UseFixed=TRUE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  if (is.null(this$.PosteriorDSqTableWithFixed)) {
    this$.PosteriorDSqTableWithFixed = summary(this$.PosteriorDSqAllWithFixed$LPDSq);
  }
  return(this$.PosteriorDSqTableWithFixed);
});

setMethodS3("getPosteriorPSqTableWithFixed", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorPSqAllWithFixed) ||
    is.null(this$.PosteriorPSqAllWithFixed$LPPSq) || length(this$.PosteriorPSqAllWithFixed$LPPSq) == 0 || 
    !is.mcmc.list(this$.PosteriorPSqAllWithFixed$LPPSq)) {
    this$.PosteriorPSqAllWithFixed = this$PosteriorPSq(UseFixed=TRUE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  if (is.null(this$.PosteriorPSqTableWithFixed)) {
    this$.PosteriorPSqTableWithFixed = summary(this$.PosteriorPSqAllWithFixed$LPDSq);
  }
  return(this$.PosteriorPSqTableWithFixed);
});

setMethodS3("getPosteriorDSqAllWithFixed", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorDSqAllWithFixed)  ||
    is.null(this$.PosteriorDSqAllWithFixed$LPDSq) || length(this$.PosteriorDSqAllWithFixed$LPDSq) == 0 || 
    !is.mcmc.list(this$.PosteriorDSqAllWithFixed$LPDSq)) {
    this$.PosteriorDSqAllWithFixed = this$PosteriorDSq(UseFixed=TRUE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorDSqAllWithFixed);
});

setMethodS3("getPosteriorPSqAllWithFixed", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorPSqAllWithFixed)  ||
    is.null(this$.PosteriorPSqAllWithFixed$LPPSq) || length(this$.PosteriorPSqAllWithFixed$LPPSq) == 0 || 
    !is.mcmc.list(this$.PosteriorPSqAllWithFixed$LPPSq)) {
    this$.PosteriorPSqAllWithFixed = this$PosteriorPSq(UseFixed=TRUE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorPSqAllWithFixed);
});

setMethodS3("getPosteriorDSqPointWithFixed", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorDSqAllWithFixed) ||
    is.null(this$.PosteriorDSqAllWithFixed$LPDSq) || length(this$.PosteriorDSqAllWithFixed$LPDSq) == 0 || 
    !is.mcmc.list(this$.PosteriorDSqAllWithFixed$LPDSq)) {
    this$.PosteriorDSqAllWithFixed = this$PosteriorDSq(UseFixed=TRUE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorDSqAllWithFixed$PointDSq);
});

setMethodS3("getPosteriorPSqPointWithFixed", "DiallelOb", function(this,...) {
  if (is.null(this$.PosteriorPSqAllWithFixed) ||
    is.null(this$.PosteriorPSqAllWithFixed$LPPSq) || length(this$.PosteriorPSqAllWithFixed$LPDSq) == 0 || 
    !is.mcmc.list(this$.PosteriorPSqAllWithFixed$LPPSq)) {
    this$.PosteriorPSqAllWithFixed = this$PosteriorPSq(UseFixed=TRUE, ProperRatio=TRUE,
      AFD = this$.AFD, startiter = this$.AFD$burnin, thin = this$.AFD$thin, enditer=NULL,
      TrueVector = NULL);
  }
  return(this$.PosteriorPSqAllWithFixed$PointPSq);
});



############################################################################
##  HSq is an estimate using "tau" parameters of the heritability of each
##   trait.  It is an approximation using the the variability inherent in a
##   full complete diallel to define the weights that would be assigned to each
##   test subject
##
setMethodS3("PosteriorHSq", "DiallelOb", function(this, UseFixed = FALSE,
  ProperRatio = FALSE, AFD = NULL, burnin = 1, startiter =-1, thin = 1, enditer = NULL,
  TrueVector = NULL,...) {
  if (is.null(startiter) || !is.numeric(startiter) || startiter[1] == -1) {
    startiter = burnin;
  }
  CodaChains = this$CodaChains;
  if (is.null(AFD)) {
    AFD = this$.AFD;
  }
  if (startiter <= 0) {startiter = 1;}
  if (thin <= 1) { thin = 1;}
  thin = round(thin);
  if (is.null(enditer)) { try(enditer  <- NROW(CodaChains[[1]]))}
  Aout = NULL;
  try(Aout <- PosteriorHSq (CodaChains = this$CodaChains, AllX = AFD$X,
    UseFixed=UseFixed, ProperRatio=ProperRatio, AFD = NULL,
    startiter=1,thin=1,enditer=enditer, TrueVector = TrueVector));
    return(Aout);
  
  tauParameters = names(this$tau);
  fixedParameters = names(this$Beta);
  for (ii in 1:length(tauParameters)) {
    fixedParameters =
      fixedParameters[substr(fixedParameters, 1, nchar(tauParameters[ii])) !=
        tauParameters[ii]];
  }
  indexSigma = (1:length(colnames(this$CodaChains[[1]])))[
    substr(colnames(this$CodaChains[[1]]),1, nchar("Sigma")) == "Sigma"];
  LPHSq = list();
  weights = rep(1, length(fixedParameters) + length(tauParameters));
  if (ProperRatio == TRUE) {
    weights[1:length(fixedParameters)] = 1;
    lF = length(fixedParameters);
    ns = length(colnames(AllX)[ substr(colnames(AllX),1, nchar("aj")) == "aj"])
    if (any(tauParameters == "aj")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="aj"]] =
        2 * (1-1/ns);
    }
    if (any(tauParameters == "Gender:aj")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="Gender:aj"]] =
        2 * (1-1/ns);
    }
    if (any(tauParameters == "mj")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="mj"]] =
        1 * (1-1/ns);
    }
    if (any(tauParameters == "Gender:mj")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="Gender:mj"]] =
        1 * (1-1/ns);
    }
    if (any(tauParameters == "dominancej")) {
      if (InbredSwitch == 1) {
         weights[lF + (1:length(tauParameters))[tauParameters=="dominancej"]] =
         1/ns;    
      } else {
        weights[lF + (1:length(tauParameters))[tauParameters=="dominancej"]] =
          2 * (1-1/ns) * ( 1- 2/ns*(1-1/ns));
      }
    }
    if (any(tauParameters == "Gender:dominancej")) {
      if (InbredSwitch == 1) {
        weights[lF + (1:length(tauParameters))[tauParameters=="Gender:dominancej"]] =
          2 * (1/ns) * ( 1- 2/ns*(1-1/ns));
      } else {
         weights[lF + (1:length(tauParameters))[tauParameters=="Gender:dominancej"]] =
          2 * (1-1/ns) * ( 1- 2/ns*(1-1/ns));     
      }
    }
    if (any(tauParameters == "SymCrossjk")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="SymCrossjk"]] =
        (ns-1)/ns*(1-1/ns^2);
    }
    if (any(tauParameters == "Gender:SymCrossjk")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="Gender:SymCrossjk"]] =
        (ns-1)/ns*(1-1/ns^2);
    }
    if (any(tauParameters == "AllCrossjk")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="AllCrossjk"]] =
         (ns-1)/ns*(1-1/ns^2);
    }
    if (any(tauParameters == "Gender:AllCrossjk")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="Gender:AllCrossjk"]] =
         (ns-1)/ns*(1-1/ns^2);
    }
    if (any(tauParameters == "ASymCrossjkDkj")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="ASymCrossjkDkj"]] =
        (ns-1)/ns*(1-1/ns^2);
    }
    if (any(tauParameters == "Gender:ASymCrossjkDkj")) {
      weights[lF + (1:length(tauParameters))[tauParameters=="Gender:ASymCrossjkDkj"]] =
        (ns-1)/ns*(1-1/ns^2);
    }
  }
  idFixed = (1:length(colnames(this$CodaChains[[1]])))[
    colnames(this$CodaChains[[1]]) %in% fixedParameters
  ]
  idTau = (1:length(colnames(this$CodaChains[[1]])))[
    colnames(this$CodaChains[[1]]) %in%
    paste("tau:", tauParameters, sep="")
  ]
  if (!exists("startiter")) { startiter = 1; }
  if (!exists("enditer")) { enditer = NULL;}
  if (!exists("thin")) { thin = 1; } 
  if (is.null(enditer)) { enditer = length(this$CodaChains[[1]][,1]) }
  if (enditer < startiter) {
    print("error, coda thin, startiter must be less than end iter");
    tryCatch(" end iter error!");
  }
  iters = startiter:enditer;
  if (is.null(thin)) {
    AT = (startiter+1):(enditer-1);
    AT = AT[(AT-startiter) %% thin == 0]
    iters = c(startiter, AT, enditer);
  }
  iters = iters[iters %in% 1:length(this$CodaChains[[1]][,1])];
  for (ii in 1:length(this$CodaChains)) {   
    MyCoda = this$CodaChains[[ii]][iters,]
    if (is.null(colnames(this$XSubSetList))) {
    FixediX = (1:length(names(this$XSubSetList)))[
      names(this$XSubSetList) %in% fixedParameters];
    } else {
    FixediX = (1:length(colnames(this$XSubSetList)))[
      colnames(this$XSubSetList) %in% fixedParameters];               
    }
    FixedCodaChains = MyCoda[,FixediX];
    PLT = NULL;
    for (jj in 1:length(FixediX)) {
      STT = FixedCodaChains[,jj] %*% t(AFD$X[,this$XSubSetList[FixediX[jj]]])
      STT = rowMeans((STT - rowMeans(STT))^2);
      PLT = cbind(PLT, STT);
    }
    IDCBind = cbind(PLT,
      MyCoda[,idTau]);
    colnames(IDCBind) = c(fixedParameters, tauParameters);
    IDCBind = t( weights * t(IDCBind));
    if (UseFixed == FALSE) {
      IDCBind = IDCBind[ ,!(colnames(IDCBind) %in% fixedParameters)]
    }
    IDCBind = IDCBind / (rowSums(IDCBind)+MyCoda[,indexSigma]);
    IDCBind = as.mcmc(IDCBind);
    LPHSq[[ii]] = IDCBind;
  }
  LPHSq = as.mcmc(LPHSq);
  this$LPHSq = LPHSq;
  return(LPHSq);
});

#####################################################################
## RSq is an estimate using Coda chains of the amount of variance explained
##  by the Beta covariates (either fixed effects or random effects)
##
setMethodS3("PosteriorRSq", "DiallelOb", function(this,
  AFD = NULL, UseFixed = FALSE, ProperRatio = FALSE,
  burnin = 1, startiter =-1, enditer=NULL, thin = 1, TrueVector = NULL,...) {
  if (is.null(startiter) ||  !is.numeric(startiter) || startiter[1] == -1) {
    startiter = burnin;
  }
  CodaChains = this$CodaChains;
  AOut <- PosteriorRSq(CodaChains = this$CodaChains, AllX = AFD$X,
    UseFixed = UseFixed, ProperRatio = ProperRatio, AY = AFD$Y,
    startiter =startiter, enditer = enditer, thin = thin,
    TrueVector = TrueVector);
  return(AOut);
  
  tauParameters = names(this$tau);
  fixedParameters = names(this$Beta);
  for (ii in 1:length(tauParameters)) {
    fixedParameters =
      fixedParameters[substr(fixedParameters, 1, nchar(tauParameters[ii])) !=
        tauParameters[ii]];
  }
  idFixedCodaChain = (1:length(this$CodaChains[[1]][1,]))[
    colnames(this$CodaChains[[1]]) %in% fixedParameters
  ]
  if (!is.null(AFD)) {SumYSq = sum((AFD$Y-mean(AFD$Y)^2))} else {
    SumYSq = sum((this$.Y - mean(this$.Y))^2);
  }
  LPRSq = list();
  if (!exists("startiter")) { startiter = 1; }
  if (!exists("enditer")) { enditer = NULL;}
  if (!exists("thin")) { thin = 1; } 
  if (is.null(enditer)) { enditer = length(this$CodaChains[[1]][,1]) }
  if (enditer < startiter) {
    print("error, coda thin, startiter must be less than end iter");
    tryCatch(" end iter error!");
  }
  iters = startiter:enditer;
  if (is.null(thin)) {
    AT = (startiter+1):(enditer-1);
    AT = AT[(AT-startiter) %% thin == 0]
    iters = c(startiter, AT, enditer);
  }
  for (ii in 1:length(this$CodaChains)) {
    MyCoda = this$CodaChains[[ii]][iters,];
    LD = matrix(0, length(MyCoda[,1]),
      length(fixedParameters) + length(tauParameters));
    if (is.null(colnames(this$XSubSetList))) {
      IDNX = names(this$XSubSetList);
    } else {
      IDNX = colnames(this$XSubSetList);
    }
    mIDNX = match(IDNX, fixedParameters);
    NT = (1:length(IDNX))[!is.na(mIDNX)];  NmIDNX = mIDNX[!is.na(mIDNX)];
    FixedCodaChains = MyCoda[, idFixedCodaChain];
    NT = NT[sort(NmIDNX, index=TRUE)$ix];
    NmIDNX = sort(NmIDNX);
    PLT = NULL;
    for (jj in 1:length(NmIDNX)) {
      STT = FixedCodaChains[,MnIDNX[jj]] %*% t(AFD$X[,this$XSubSetList[NT[jj]]])
      STT = rowSums((STT - rowMeans(STT))^2);
      PLT = cbind(PLT, STT);
    }
    ##LD[,NmIDNX] = t(colSums( this$XSubSetList[,NT])^2 *
    ##  t((this$CodaChains[[ii]][,idFixedCodaChain])^2)) ;
    LD[,NmIDNX] = PLT;
    for (jj in 1:length(tauParameters)) {
      PRD = (1:length(colnames(this$CodaChains[[ii]])))[
        substr(colnames(this$CodaChains[[ii]]), 1, nchar(tauParameters[jj])) ==
          tauParameters[jj]
      ];
      if (is.null(colnames(this$XSubSetList))) {
        PRT = (1:length(names(this$XSubSetList)))[
          substr(names(this$XSubSetList),1,nchar(tauParameters[jj])) ==
          tauParameters[jj]
        ];
      } else {
        PRT = (1:length(names(this$XSubSetList)))[
          substr(colnames(this$XSubSetList),1,nchar(tauParameters[jj])) ==
          tauParameters[jj]
        ];              
      }
      STT = MyCoda[,PRD] %*% t(AFD$X[,this$XSubSetList[PRT]]);
      LD[, length(fixedParameters) + jj] = 
      LD[, length(fixedParameters) + jj] = 
        rowSums((STT - rowMeans(STT))^2);   
    }
    colnames(LD) = c(fixedParameters, tauParameters);
    LD = LD / SumYSq;
    LD = as.mcmc(LD);
    LPRSq[[ii]] = LD;
  }
  LPRSq = as.mcmc(LPRSq);
  this$LPRSq = LPRSq;
  return(this$LPRSq);
});

setMethodS3("getPosteriorPredictionsMeanSummary", "DiallelOb", function(this,DoBS=FALSE,...) {
    if (DoBS == TRUE) {
      if (is.null(this$.AFD$.BSOther) || length(this$.AFD$.BSOther) <= 0) {
        this$.AFD$.BSOther <- NULL;
      }  
      this$.AFD$.BSOther$.PosteriorPredictionsMeanSummary <- this$PosteriorPredSummary(AFD = this$.AFD,
      burnin = this$.AFD$burnin, thin = this$.AFD$thin, 
      keep=FALSE, plotdensity=FALSE,
      WithNoise = FALSE, DoBS=TRUE);  
      return(this$.AFD$.BSOther$.PosteriorPredictionsMeanSummary)
    }
  if (!is.null(this$.PosteriorPredictionsMeanSummary)) {
    return(this$.PosteriorPredictionsMeanSummary);
  } else {

    this$.PosteriorPredictionsMeanSummary = this$PosteriorPredSummary(AFD = this$.AFD,
    burnin = this$.AFD$burnin, thin = this$.AFD$thin, keep=FALSE, plotdensity=FALSE,
    WithNoise = FALSE);
    return(this$.PosteriorPredictionsMeanSummary);
  }
});
setMethodS3("getPosteriorPredictionsMeanSummary", "FullDiallelAnalyze", function(this, DoBS=FALSE, ...) {
  return(this$AllDiallelObs[[this$On]]$getPosteriorPredictionsMeanSummary(DoBS=DoBS));
});
setMethodS3("getPosteriorPredictionsErrorSummary", "DiallelOb", function(this, ...) {
  if (!is.null(this$.PosteriorPredictionsErrorSummary)) {
    return(this$.PosteriorPredictionsErrorSummary);
  } else {
    this$.PosteriorPredictionsErrorSummary = this$PosteriorPredSummary(AFD = this$.AFD,
    burnin = this$.AFD$burnin, thin = this$.AFD$thin, keep=FALSE, plotdensity=FALSE,
    WithNoise = TRUE);
    return(this$.PosteriorPredictionsErrorSummary);
  }
});
setMethodS3("getPosteriorPredictionsErrorSummary", "FullDiallelAnalyze", function(this, ...) {
  return(this$AllDiallelObs[[this$On]]$getPosteriorPredictionsErrorSummary());
});
setMethodS3("getPosteriorPredictionsMeanChains", "DiallelOb", function(this,...) {
  if (!is.null(this$.PosteriorPredictionsMeanChains)) {
    return(this$.PosteriorPredictionsMeanChains);
  } else {
    this$PostKeeper = NULL;
    AT = this$PosteriorPredSummary(AFD = this$.AFD,
    burnin = this$.AFD$burnin, thin = this$.AFD$thin, keep=TRUE, plotdensity=FALSE,
    WithNoise = FALSE);
    this$.PosteriorPredictionsMeanChains = this$PostKeeper$FakeCoda;
    return(this$.PosteriorPredictionsMeanChains);
  }
});
setMethodS3("getPosteriorPredictionsMeanChains", "FullDiallelAnalyze", function(this, ...) {
  return(this$AllDiallelObs[[this$On]]$getPosteriorPredictionsMeanChains());
});
setMethodS3("getPosteriorPredictionsErrorChains", "DiallelOb", function(this,...) {
  if (!is.null(this$.PosteriorPredictionsErrorChains)) {
    return(this$.PosteriorPredictionsErrorChains);
  } else {
    this$PostKeeper = NULL;
    AT = this$PosteriorPredSummary(AFD = this$.AFD,
    burnin = this$.AFD$burnin, thin = this$.AFD$thin, keep=TRUE, plotdensity=FALSE,
    WithNoise = TRUE);
    this$.PosteriorPredictionsErrorChains = this$PostKeeper$FakeCoda;
    return(this$.PosteriorPredictionsErrorChains);
  }
});

setMethodS3("getPosteriorPredictionsErrorChains", "FullDiallelAnalyze", function(this, ...) {
  return(this$AllDiallelObs[[this$On]]$getPosteriorPredictionsErrorChains());
});
setMethodS3("MakeFakeX", "DiallelOb", function(this, AFD=NULL, DoFirstCenter=NULL, DoBS = FALSE, ...) {
  if (is.null(AFD)) {
    AFD = this$.AFD;
  }
  if (is.null(DoFirstCenter)) {
    DoFirstCenter = this$DoFirstCenter;
  }
  FakeListjk = cbind( rep(1:this$.numj, this$.numj),
   rep(1:this$.numj, each=this$.numj) );
 if (this$.SexModel > 0) {
   FakeSexVector = c(rep(0, length(FakeListjk[,1])) ,
     rep(1,length(FakeListjk[,1])) );
   FakeListjk = rbind(FakeListjk, FakeListjk);
 } else {
   FakeSexVector = NULL;
 }
 if (any(substr(names(this$Beta), 1, nchar("FixedEffect")) == 
   "FixedEffect")) {
   if (is.null(dim(AFD$FixedEffects))) {
     NFixedEffects = matrix(0, length(FakeListjk[,1]),
      1);
     colnames(NFixedEffects) = "FixedEffect:1"
   } else {
     NFixedEffects = matrix(0, length(FakeListjk[,1]),
       dim(AFD$FixedEffects)[2]);   
     colnames(NFixedEffects) = colnames(AFD$FixedEffects);
   }  
 } else {
   NFixedEffects=NULL;
 }
 if (any(substr(names(this$Beta), 1, nchar("RandomEffect")) == 
   "RandomEffect")) {
   if (is.null(dim(AFD$RandomEffects))) {
     NRandomEffects = matrix(0, length(FakeListjk[,1]),
      1);
     colnames(NRandomEffects) = "RandomEffect:1";
   } else {
     NRandomEffects = matrix(0, length(FakeListjk[,1]),
       dim(AFD$RandomEffects)[2]);   
     colnames(NRandomEffects) = colnames(AFD$RandomEffects);
   }  
 }  else {
   NRandomEffects=NULL;
 }
 if (!exists("DoBS") || is.null(DoBS) || DoBS == FALSE) {
   XFake = ConstructXJK(this$.numj, ajModel = this$.ajModel,
   MotherModel = this$.MotherModel,
   CrossModel=this$.CrossModel, SexModel=this$.SexModel, 
   BetaInbredLevel=this$.BetaInbredLevel, 
   BetaInbredTimesSex=this$.BetaInbredTimesSex, 
   SexVector = FakeSexVector, 
   Listjk=FakeListjk, 
   CO = AFD$ACrossLocations, FixedEffects=NFixedEffects,
   RandomEffectsGroups = AFD$RandomEffectsGroups,
   RandomEffects=NRandomEffects,
   DoFirstCenter = DoFirstCenter);
   return(XFake);
 }
 MyMat <- matrix(0, length(this$.AFD$AllDiallelObs), 6);
 colnames(MyMat) <- c("ajModel", "MotherModel", "CrossModel", "SexModel",
   "BetaInbredLevel", "BetaInbredTimesSex");
 for (ii in 1:length(this$.AFD$AllDiallelObs)) {
   MyMat[ii,1] <- this$.AFD$AllDiallelObs[[ii]]$.ajModel;
   MyMat[ii,2] <- this$.AFD$AllDiallelObs[[ii]]$.MotherModel;
   MyMat[ii,3] <- this$.AFD$AllDiallelObs[[ii]]$.CrossModel;
   MyMat[ii,4] <- this$.AFD$AllDiallelObs[[ii]]$.SexModel;
   MyMat[ii,5] <- this$.AFD$AllDiallelObs[[ii]]$.BetaInbredLevel;
   MyMat[ii,6] <- this$.AFD$AllDiallelObs[[ii]]$.BetaInbredTimesSex;    
 }
 MyMax <- rep(0, 6);
 for (ii in 1:length(MyMax)) { 
   MyMax[ii] = max(MyMat[,ii]);
 }
 if (MyMax[4] >= 1 && this$.SexModel == 0) {
   FakeSexVector = c(rep(0, length(FakeListjk[,1])) ,
     rep(1,length(FakeListjk[,1])) );
   FakeListjk = rbind(FakeListjk, FakeListjk);
 }
   XFake = ConstructXJK(this$.numj, ajModel = MyMax[1],
   MotherModel = MyMax[2],
   CrossModel= MyMax[3], SexModel=MyMax[4], 
   BetaInbredLevel=MyMax[5], 
   BetaInbredTimesSex=MyMax[6], 
   SexVector = FakeSexVector, 
   Listjk=FakeListjk, 
   CO = AFD$ACrossLocations, FixedEffects=NFixedEffects,
   RandomEffectsGroups = AFD$RandomEffectsGroups,
   RandomEffects=NRandomEffects,
   DoFirstCenter = DoFirstCenter);
   return(XFake);
});
setMethodS3("PosteriorPredSummary", "DiallelOb", function(this, AFD = NULL,
  burnin = -1, thin = 1, keep = FALSE, plotdensity=FALSE,
  WithNoise = FALSE, DoBS=FALSE, ...) {
 if (!exists("AFD") || is.null(AFD)) {
   AFD = this$.AFD;
 }
 if (is.null(this$CodaChains)) {
   throw("Error, no extant CodaChains");
 }
 if (is.null(AFD)) {
   throw("PosteriorPredSummary desires AFD"); 
 }
 if (is.null(burnin)) { burnin = -1; }
 if (burnin < 0) {
   burnin = round(.2 * dim(this$CodaChains[[1]])[1]);
 }
 
 ##SubSetChains = mcmc.subset(this$CodaChains, burnin=burnin, thin=thin);
 ##MySummary =  summary(SubSetChains);
 FakeListjk = cbind( rep(1:this$.numj, this$.numj),
   rep(1:this$.numj, each=this$.numj) );
 
 if (this$.SexModel > 0) {
   FakeSexVector = c(rep(0, length(FakeListjk[,1])) ,
     rep(1,length(FakeListjk[,1])) );
   FakeListjk = rbind(FakeListjk, FakeListjk);
 } else {
   FakeSexVector = NULL;
 }
 if (any(substr(names(this$Beta), 1, nchar("FixedEffect")) == 
   "FixedEffect")) {
   if (is.null(dim(AFD$FixedEffects))) {
     NFixedEffects = matrix(0, length(FakeListjk[,1]),
      1);
     colnames(NFixedEffects) = "FixedEffect:1"
   } else {
     NFixedEffects = matrix(0, length(FakeListjk[,1]),
       dim(AFD$FixedEffects)[2]);   
     colnames(NFixedEffects) = colnames(AFD$FixedEffects);
   }  
 } else {
   NFixedEffects=NULL;
 }
 if (any(substr(names(this$Beta), 1, nchar("RandomEffect")) == 
   "RandomEffect")) {
   if (is.null(dim(AFD$RandomEffects))) {
     NRandomEffects = matrix(0, length(FakeListjk[,1]),
      1);
     colnames(NRandomEffects) = "RandomEffect:1";
   } else {
     NRandomEffects = matrix(0, length(FakeListjk[,1]),
       dim(AFD$RandomEffects)[2]);   
     colnames(NRandomEffects) = colnames(AFD$RandomEffects);
   }  
 }  else {
   NRandomEffects=NULL;
 }
 if (is.null(AFD)) { AFD = this$AFD; }
 
 XFake = ConstructXJK(this$.numj, ajModel = this$.ajModel,
   MotherModel = this$.MotherModel,
   CrossModel=this$.CrossModel, SexModel=this$.SexModel, 
   BetaInbredLevel=this$.BetaInbredLevel, 
   BetaInbredTimesSex=this$.BetaInbredTimesSex, 
   SexVector = FakeSexVector, 
   Listjk=FakeListjk, 
   CO = AFD$ACrossLocations, FixedEffects=NFixedEffects,
   RandomEffectsGroups = AFD$RandomEffectsGroups,
   RandomEffects=NRandomEffects,
   DoFirstCenter = this$DoFirstCenter);
 FakeCoda = list();
 CodaChains = this$CodaChains;
 if (DoBS == TRUE && !is.null(this$.AFD$.BS)) {
   CodaChains <- this$getBSUnCent.chains();
 }
 for (chi in 1:length(CodaChains)) {
   if (is.null(AFD$DDO1) || is.null(AFD$DDO2)) {
     NeedChain = CodaChains[[chi]][,1:length(this$Beta)] %*% t(XFake);
   } else {
     NeedChain = (AFD$DDO1[[this$.iOb]]$CodaChains[[chi]][,1:length(this$Beta)] -
       AFD$DDO2[[this$.iOb]]$CodaChains[[chi]][,1:length(this$Beta)]) %*% t(XFake);
   }
   if (WithNoise == TRUE) {
     SigIter = (1:length(CodaChains[[chi]][1,]))[
       colnames(CodaChains[[chi]]) %in% c("Sigma", "sigma", "sigma:1", "Sigma:1")];
     NSim = length(NeedChain[1,]) * length(NeedChain[,1]);
     if (is.null(this$dfTNoise) || this$dfTNoise <= 0) {
       for (tt in 1:NROW(NeedChain)) {
         NeedChain[tt,] <- NeedChain[tt,] +
          sqrt(CodaChains[[chi]][tt,SigIter]) * 
          rnorm(NCOL(NeedChain),0,1); 
       }
     } else {
       for (tt in 1:NROW(NeedChain)) {
         NeedChain[tt,] <- NeedChain[tt,] +
          sqrt(CodaChains[[chi]][tt,SigIter]) * 
          rt(NCOL(NeedChain),df = this$dfTNoise); 
       } 
     }
   }
   NeedChain = NeedChain[burnin:length(NeedChain[,1]),];
    if (is.null(FakeSexVector)) {
      try(colnames(NeedChain) <- paste("i:", FakeListjk[,1], ";k:", FakeListjk[,2], sep="")); 
    } else {
      try(colnames(NeedChain) <- paste("S:", FakeSexVector, ";i:", 
        FakeListjk[,1], ";k:", FakeListjk[,2], sep=""));
    }
   FakeCoda[[chi]] = as.mcmc(NeedChain);
 }
 FakeCoda = as.mcmc.list(FakeCoda);
 SummaryOfChains = summary(FakeCoda);
 if (!is.null(FakeSexVector) && 
   length(FakeSexVector) == length(FakeListjk[,1])) {
   RetTab = cbind (FakeListjk,   FakeSexVector,
     SummaryOfChains$statistics[,1], SummaryOfChains$quantiles[,c(3,1,5)]);
   colnames(RetTab) = c("mother.strain", "father.strain",
    "is.female",
    "Mean Posterior", "Median Posterior", "q.025", "q.975")
 } else {
   RetTab = cbind (FakeListjk,
     SummaryOfChains$statistics[,1], SummaryOfChains$quantiles[,c(3,1,5)]); 
   colnames(RetTab) = c("mother.strain", "father.strain",
    "Mean Posterior",
    "Median Posterior", "q.025", "q.975");
 }
 if (DoBS==FALSE && keep == TRUE) {
   this$PostKeeper = list(FakeListjk = FakeListjk, 
     FakeSexVector = FakeSexVector, FakeCoda = FakeCoda,
     FakeX = XFake, WithNoise = WithNoise)
 
 } else if (DoBS==TRUE) {
    if (is.null(this$.AFD$.BSOther)) {
      this$.AFD$.BSOther <- list();
    }
    this$.AFD$.BSOther$PostKeeper <-  list(FakeListjk = FakeListjk, 
     FakeSexVector = FakeSexVector, FakeCoda = FakeCoda,
     FakeX = XFake, WithNoise = WithNoise, RetTab=RetTab);
    return(as.data.frame(RetTab));
 }
  return(as.data.frame(RetTab));
});

Willsrename4hpd=function(x)
{
  x=sub("Gender", "female", x)
  x=sub("BetaInbred:female:Av", "female.inbreed.overall", x)
  x=sub("BetaInbred:Av", "inbreed.overall", x)
  x=sub("female:Av", "female.overall", x)
  x=sub("ASymCrossjkDkj", "w:", x)
  x=sub("SymCrossjk", "v:", x)
  x=sub("dominancej", "inbreed", x)
  x=sub("motherj", "maternal", x)
  x=sub("aj", "additive", x)
  x=sub(":j", ":", x)
  x=sub(";k:", ":", x)
  x=sub("::", ":", x)
  x=sub("Mu", "mu", x)
  x=sub("B6AJ9", "129", x)
  x=sub("Sigma:1", "sigma", x)
  x
}

setMethodS3("PlotStrawPlot", "DiallelOb", function(this,
  DoCentered=TRUE,DoRaw=TRUE,
  wanted=NULL,prob.wide=NULL,prob.narrow=NULL,
  DoMedian = FALSE, DoMu = FALSE, xlim = NULL, GiveHeadings = TRUE,
  ylab = "range(data)", yline=2, DoCC = 0, ...) {
  Verbose = 0;
  if (!exists("DoMedian")) { DoMedian = FALSE; }
  if (!exists("DoMu")) { DoMu = FALSE; }
  if (!exists("xlim")) { xlim = NULL; }
  if (!exists("GiveHeadings")) { GiveHeadings=TRUE; }
  if (!exists("ylab")) { ylab = "range(data)"; }
  if (!is.null(this$.AFD$Verbose)) {
    if (is.logical(this$.AFD$Verbose)) {
      if (this$.AFD$Verbose == TRUE) {
        Verbose = 2;
      }
    } else {
      Verbose = as.numeric(this$.AFD$Verbose);
    }
  }
  if (Verbose > 0) {
    print("PlotStrawPlot: Starting"); flush.console();
  }
  RC = this$getMyCent.Summary();
  OldNameRC = rownames(RC[[1]]);
  AST = strsplit(OldNameRC, "-");
  ATT = rep(0, length(AST));
  for (ii in 1:length(AST)) {
    AT1 = paste(unlist( strsplit(AST[[ii]][1], " ")), collapse="");
    ATT[ii] = AT1;
    ## ATT[ii] = Willsrename4hpd(AT1);
  }
  for (ii in 1:length(RC)) {           
    try(rownames(RC[[ii]]) <- ATT, silent=TRUE);
  }
  if (DoMedian == TRUE) {
    MyF = RC[[1]]; MCC = 3;
  } else {
    MyF = RC[[1]]; MCC = 1;
  }
  
  if (Verbose > 0) {
    print("PlotStrawPlot: Generating summary names"); flush.console();
  }
  A1 = length(rownames(MyF)[substr(rownames(MyF), 1, nchar("aj:")) == "aj:"]);
  AtK = (1:NROW(MyF))[ substr(rownames(MyF), 1, nchar("aj:")) == "aj:"];
   WinName = rownames(MyF)[AtK];
   WinName = substr(WinName, nchar("aj:")+1,nchar(WinName));
  if (Verbose > 1) {
    print(paste("PlotStrawPlot: The WinNames are ", 
      paste(WinName, collapse=", "), sep="")); flush.console();
  }  
   
  if (this$.SexModel > 0) {
    MyDataMatrix = matrix(0, 12, A1);
  } else {
    MyDataMatrix = matrix(0,6,A1);
  }
  
  try(InbreedEffect <- 0);
  if (sum(rownames(MyF) == "BetaInbred:Av") >= 1) {
    try(InbreedEffect <- MyF[rownames(MyF) == "BetaInbred:Av",MCC], silent=TRUE);
  }
  
  if (this$.SexModel > 0) {
    GenderEffect = 0;  GenderInbreedEffect = 0;
    try(GenderEffect <- MyF[rownames(MyF) == "Gender:Av",MCC], silent=TRUE);
    try(GenderInbreedEffect <- MyF[rownames(MyF) == "BetaInbred:Gender:Av",MCC], silent=TRUE);
  }  else {
    GenderEffect = 0;  GenderInbreedEffect = 0;
  }
  colnames(MyDataMatrix) = WinName;
  try(MyDataMatrix[1,] <- rep(MyF[rownames(MyF) == "Mu",MCC], A1)); 
  if (this$.SexModel > 0) {
    try(MyDataMatrix[2,] <- rep(GenderEffect, A1));
    try(MyDataMatrix[3,] <- rep(InbreedEffect, A1));
    try(MyDataMatrix[4,] <- rep(GenderInbreedEffect, A1)); 
  } else {
    try(MyDataMatrix[2,] <- rep(InbreedEffect, A1)); 
  }
  AtK = (1:NROW(MyF))[ substr(rownames(MyF), 1, nchar("aj:")) == "aj:"];
   NewN = rownames(MyF)[AtK];
   NewN = substr(NewN, nchar("aj:")+1,nchar(NewN));
  AM = match(WinName, NewN); ABD = AtK[(1:length(AM))[!is.na(AM)]]; AM = AM[!is.na(AM)]; 
  AddEffects = rep(0, length(WinName));
  if (length(ABD) > 0) {
  AddEffects[AM] = MyF[ABD,MCC];
  }
  
  AtK = (1:NROW(MyF))[ substr(rownames(MyF), 1, nchar("motherj:")) == "motherj:"];
   NewN = rownames(MyF)[AtK];
   NewN = substr(NewN, nchar("motherj:")+1,nchar(NewN));
  AM = match(WinName, NewN); ABD = AtK[(1:length(AM))[!is.na(AM)]]; AM = AM[!is.na(AM)]; 
  MotherEffects = rep(0, length(WinName));
  if (length(ABD) > 0) {
  MotherEffects[AM] = MyF[ABD,MCC];
  }

  AtK = (1:NROW(MyF))[ substr(rownames(MyF), 1, nchar("dominancej:")) == "dominancej:"];
   NewN = rownames(MyF)[AtK];
   NewN = substr(NewN, nchar("dominancej:")+1,nchar(NewN));
  AM = match(WinName, NewN); ABD = AtK[(1:length(AM))[!is.na(AM)]]; AM = AM[!is.na(AM)]; 
  InbreedEffects = rep(0, length(WinName));
  if (length(ABD > 0)) {
  InbreedEffects[AM] = MyF[ABD,MCC]; } 

  if (this$.SexModel > 0) {  
  AtK = (1:NROW(MyF))[ substr(rownames(MyF), 1, nchar("Gender:aj:")) == "Gender:aj:"];
   NewN = rownames(MyF)[AtK];
   NewN = substr(NewN, nchar("Gender:aj:")+1,nchar(NewN));
  AM = match(WinName, NewN); ABD = AtK[(1:length(AM))[!is.na(AM)]]; AM = AM[!is.na(AM)]; 
  GenderAdditiveEffects = rep(0, length(WinName));
  if (length(ABD) > 0) {
  GenderAdditiveEffects[AM] = MyF[ABD,MCC]; }     

  AtK = (1:NROW(MyF))[ substr(rownames(MyF), 1, nchar("Gender:motherj:")) == "Gender:motherj:"];
   NewN = rownames(MyF)[AtK];
   NewN = substr(NewN, nchar("Gender:motherj:")+1,nchar(NewN));
  AM = match(WinName, NewN); ABD = AtK[(1:length(AM))[!is.na(AM)]]; AM = AM[!is.na(AM)]; 
  GenderMotherEffects = rep(0, length(WinName));
  if (length(ABD) > 0) {
  GenderMotherEffects[AM] = MyF[ABD,MCC];}

  AtK = (1:NROW(MyF))[ substr(rownames(MyF), 1, nchar("Gender:dominancej:")) == "Gender:dominancej:"];
   NewN = rownames(MyF)[AtK];
   NewN = substr(NewN, nchar("Gender:dominancej:")+1,nchar(NewN));
  AM = match(WinName, NewN); ABD = AtK[(1:length(AM))[!is.na(AM)]]; AM = AM[!is.na(AM)]; 
  GenderInbreedEffects = rep(0, length(WinName));
  if (length(ABD) > 0) {
  GenderInbreedEffects[AM] = MyF[ABD,MCC];  }
  } 
  strain.map = this$.AFD$strain.map;

  if (Verbose > 1) {
    print("PlotStrawPlot: We are adding in learned effects to matrix."); flush.console();
  }
  if (this$.SexModel > 0) {
  try(MyDataMatrix[5,] <- AddEffects, silent=TRUE); 
  try(MyDataMatrix[6,] <- GenderAdditiveEffects, silent=TRUE);  
  try(MyDataMatrix[7,] <- MotherEffects, silent=TRUE);  
  try(MyDataMatrix[8,] <- GenderMotherEffects, silent=TRUE);  
  try(MyDataMatrix[9,] <- InbreedEffects, silent=TRUE); 
  try(MyDataMatrix[10,] <- GenderInbreedEffects, silent=TRUE);
  try(MyDataMatrix[11,] <- AddEffects *2 + 
    2 * InbreedEffects +  GenderInbreedEffects + 
    GenderAdditiveEffects + .5*GenderEffect + InbreedEffect + .5*GenderInbreedEffect, silent=TRUE); 
  try(MyDataMatrix[12,] <-  AddEffects *2 + 
    2 * InbreedEffects - GenderInbreedEffects - 
    GenderAdditiveEffects - .5 *GenderEffect + InbreedEffect - .5*GenderInbreedEffect, silent=TRUE);  
   try(rownames(MyDataMatrix) <- c("overall.mean", "sex.effect", "inbreed.effect",
    "sex.inbreed",
    "additive", "sex.additive", "maternal", 
    "sex.maternal","inbreeding",
     "sex.inbreed",
    "female.inbred.predicted", "male.inbred.predicted"), silent=TRUE);
  } else {
  try(MyDataMatrix[3,] <- AddEffects, silent=TRUE); 
  try(MyDataMatrix[4,] <- MotherEffects, silent=TRUE); 
  try(MyDataMatrix[5,] <- InbreedEffects, silent=TRUE); 
  try(MyDataMatrix[6,] <- AddEffects *2 + 
    2 * InbreedEffects + InbreedEffect, silent=TRUE); 
    try(rownames(MyDataMatrix) <- c("overall.mean",  "inbreed.effect",
    "additive", "maternal", "inbreeding",
    "inbred.predicted"), silent=TRUE);
  }
  if (DoMu == FALSE) {
    MyDataMatrix = MyDataMatrix[rownames(MyDataMatrix) != "overall.mean",];
  }

  

  if ((is.logical(DoCC) && DoCC == FALSE) || DoCC != 1) { 
    DoCC = 0;
  AM = match(WinName,c("AJ", "B6", "129","NOD","NZO","CAST","PWK","WSB"));
  if (!(any(is.na(AM)))) {
    DoCC = 1;
  } else if (!(any(is.na(match(strain.map[,1], c("AJ", "B6", "129","NOD","NZO","CAST","PWK","WSB")))))) {
    DoCC = 1;
    colnames(MyDataMatrix) = strain.map[match(as.character(WinName), as.character(strain.map[,2])),1];
  } else if (!is.null(strain.map)) {
    colnames(MyDataMatrix) = strain.map[match(as.character(WinName), as.character(strain.map[,2])),1];
  }
    if (Verbose > 0) {
      print(paste("PlotStrawPlot: Learning whether to DoCC version: DoCC = ", 
        DoCC, sep="")); flush.console();
    }
  } else if ((is.logical(DoCC) && DoCC == TRUE) || DoCC == 1 ) {
    DoCC = 1;
    if (Verbose > 0) {
      print("PlotStrawPlot: User Set DoCC = 1."); flush.console();
    }
  }
  
  if (Verbose > 0) {
    print("PlotStrawPlot: now conducting plots."); flush.console();
  }
  ##library(BayesDiallelGraphics);
  ##OldPlt = par("plt");
  ##par(plt = c( .26, .98,.19,.85))
  MyDataMatrix = t(MyDataMatrix);
  if (GiveHeadings == FALSE) {
    colnames(MyDataMatrix) = rep("", NCOL(MyDataMatrix));
  }
  if (DoCC == 1) {
  if (exists("plot.straws")) {
    plot.straws(data=MyDataMatrix,xlim=xlim, GiveHeadings = GiveHeadings,ylab="", 
      col=ccfounder.colors, strain.names=ccfounder.short.names, ...);
  } else {
    old.plot.straws.cc(data=MyDataMatrix, strain.names=ccfounder.short.names,
    strain.cols=ccfounder.colors,xlim=xlim,GiveHeadings = GiveHeadings, ylab="", ...);
  }   
  } else {
  if (exists("plot.straws")) {
    plot.straws(data=MyDataMatrix,xlim=xlim,GiveHeadings = GiveHeadings, ylab="", ...);
  } else {
    old.plot.straws(data=MyDataMatrix,xlim=xlim,GiveHeadings = GiveHeadings, ylab="", ...)
  }       
  }
  if (ylab != "") {
    xnlab = ylab;
    title(xlab=xnlab, line = yline);
  }
  ##par(plt = OldPlt);
  return(1);
});

old.plot.straws.cc=function(data,
		strain.names=ccfounder.short.names,
		strain.cols=ccfounder.colors, xlim=NULL, GiveHeadings = TRUE, ylab="", 
		...)
{
  correct.order=c("AJ", "B6", "129","NOD","NZO","CAST","PWK","WSB")
  if (!all(sub("additive:", "", rownames(data))==correct.order))
  {
    stop("strain names out of order")
  }
  
  plot.straws(data, col=ccfounder.colors, GiveHeadings = GiveHeadings, ylab=ylab, xlim=xlim, ...)
}

old.plot.straws=function(data,
    col=rainbow(nrow(data)),
    axes=sides(default=FALSE, bottom=TRUE, left=TRUE),
    axes.update=sides(),
    axes.lty=1,
    mar=sides(bottom=5,left=10,top=4,right=2),
    mar.update=sides(),
    name.line=0,
		lwd=3,
		type="l", GiveHeadings = TRUE, xlim=NULL, ylab="",
		...)
{
	oldmar <- par("mar")
	on.exit(par(mar=oldmar))
	
	num.stats <- ncol(data)
	num.straws <- nrow(data)
	if (GiveHeadings == TRUE) {
        
        } else {
          
        }
	par(mar=update.sides(mar, mar.update))
	axes=update.sides(axes, axes.update)
        if (is.null(xlim)) {
	  plot(range(data), c(1,num.stats), type="n", axes=FALSE, ylab=ylab,  ...)
        } else {
          plot(range(data), c(1,num.stats), type="n", axes=FALSE, ylab=ylab,  xlim=xlim,...)
        }
	if ((!is.logical(GiveHeadings) || GiveHeadings == TRUE) && axes["left"])
	{
	  axis(2, at=1:num.stats, labels=rev(colnames(data)), las=1, lty=axes.lty, line=name.line)
	}
	if (axes["bottom"])
	{
	  axis(1)
	}
	if ("l"==type)
	{
	  for (i in 1:num.straws)
  	{
  		lines(data[i,], num.stats:1, col=col[i], lwd=lwd)
  	}
  }
}


setMethodS3("GiveGrid", "FullDiallelSimulate", function(this,...) {

 if (is.null(this$ADiallelOb)) {
   throw("You Must simulate Values first"); 
 }
 
 

 FakeListjk = cbind( rep(1:this$.numj, this$.numj),
   rep(1:this$.numj, each=this$.numj) );
 
 if (this$ADiallelOb$.SexModel > 0) {
   FakeSexVector = c(rep(0, length(FakeListjk[,1])) ,
     rep(1,length(FakeListjk[,1])) );
   FakeListjk = rbind(FakeListjk, FakeListjk);
 } else {
   FakeSexVector = NULL;
 }
 if (any(substr(names(this$ADiallelOb$Beta), 1, nchar("FixedEffect")) == 
   "FixedEffect")) {
   if (is.null(dim(this$FixedEffects))) {
     NFixedEffects = matrix(0, length(FakeListjk[,1]),
      1);
     colnames(NFixedEffects) = "FixedEffect:1"
   } else {
     NFixedEffects = matrix(0, length(FakeListjk[,1]),
       dim(AFD$FixedEffects)[2]);   
     colnames(NFixedEffects) = colnames(AFD$FixedEffects);
   }  
 } else {
   NFixedEffects = NULL;
 }
 if (any(substr(names(this$ADiallelOb$Beta), 1, nchar("RandomEffect")) == 
   "RandomEffect")) {
   if (is.null(dim(this$RandomEffects))) {
     NRandomEffects = matrix(0, length(FakeListjk[,1]),
      1);
     colnames(NRandomEffects) = "RandomEffect:1";
   } else {
     NRandomEffects = matrix(0, length(FakeListjk[,1]),
       dim(this$RandomEffects)[2]);   
     colnames(NRandomEffects) = colnames(this$RandomEffects);
   }  
 } else {
   NRandomEffects = NULL;
 }
 XFake = ConstructXJK(this$.numj, ajModel = this$ADiallelOb$.ajModel,
   MotherModel = this$ADiallelOb$.MotherModel,
   CrossModel=this$ADiallelOb$.CrossModel, SexModel=this$ADiallelOb$.SexModel, 
   BetaInbredLevel=this$ADiallelOb$.BetaInbredLevel, 
   BetaInbredTimesSex=this$ADiallelOb$.BetaInbredTimesSex, 
   SexVector = FakeSexVector, 
   Listjk=FakeListjk, 
   CO = this$ACrossLocations, FixedEffects=NFixedEffects,
   RandomEffectsGroups = this$RandomEffectsGroups,
   RandomEffects=NRandomEffects,
   DoFirstCenter = this$DoFirstCenter);
 TrueMeanValues = XFake %*% this$ADiallelOb$Beta;
 if (exists("this$ADiallelOb$dfTNoise") &&
     !is.null(this$ADiallelOb$dfTNoise) &&
     this$ADiallelOb$dfTNoise > 0) {
   quantilesNoise = sqrt(this$ADiallelOb$Sigma) *
     qt(c(.025,.975),df=this$ADiallelOb$dfTNoise);    
 } else {
   quantilesNoise = sqrt(this$ADiallelOb$Sigma) * 
     qnorm(c(.025,.975),0,1);
 }
 if (!is.null(FakeSexVector)) {
   RetTab = cbind (FakeListjk,   FakeSexVector,
     TrueMeanValues, TrueMeanValues + quantilesNoise[1],
     TrueMeanValues + quantilesNoise[2]);
   colnames(RetTab) = c("mother.strain", "father.strain",
    "Female/Male",
    "Mean.Simulated", "q-.025", "q.975")
 } else {
   RetTab = cbind (FakeListjk,
     TrueMeanValues, TrueMeanValues + quantilesNoise[1],
     TrueMeanValues + quantilesNoise[2]); 
   colnames(RetTab) = c("mother.strain", "father.strain",
    "Mean.Simulated", "q-.025", "q.975");
   return(RetTab);
 }
 return(as.data.frame(RetTab));
});



                    
MatchStringsList = c("mu", "S", "m", "B", "SB", "ms", "a", 
  "as", "d", "ds", "v", "vs", "w", "ws", "x", "xs");         
StringsList = c("mu", "gender", "mother", "inbred", 
 "gender-inbred", "gender-mother",
 "strain", "gender-strain", "inbred-strain",
 "gender-inbred-strain", "symmetric-cross",
 "asymmetric-cross", "gender-symmetric-cross", 
 "gender-asymmetric-cross", "all-cross",
 "all-gender-cross");
 
StringForCrossList <- function(ModelsVec) {
  ajModel=ModelsVec[1]; MotherModel = ModelsVec[2];
  CrossModel = ModelsVec[3];  SexModel = ModelsVec[4];
  BetaInbredLevel = ModelsVec[5];  BetaInbredTimesSex = ModelsVec[6];
  mylist = c();
  if (CrossModel >= 8) {
    if (SexModel >= 5) {
      mylist = c(mylist, "xs")
    } else { mylist = c(mylist, "x"); }
  } else if (CrossModel >= 5) {
    if (SexModel >= 5) {
      mylist = c(mylist, "vs", "ws");
    }  else if (SexModel >= 4) {
      mylist = c(mylist, "vs", "w");
    }  else {
      mylist = c(mylist, "v","w");
    }
  } else if (CrossModel >= 2) {
    if (SexModel >= 4) {
      mylist = c(mylist, "vs");
    } else {
      mylist = c(mylist, "v");
    }
  }
  if (BetaInbredLevel >= 2) {
    if (BetaInbredLevelTimesSex >= 2 || SexModel >= 3) {
      mylist = c("Ds", "ds", mylist);
    } else if (BetaHyridLevelTimesSex >= 1) {
      mylist = c("Ds", "d", mylist);
    } else {
      mylist = c("D", "d", mylist);
    }
  } else if (BetaInbredLevel >= 1) {
    if (BetaHyrbidLevelTimesSex >= 1 || SexModel >= 3) {
      mylist = c("Ds", mylist);
    } else {
      mylist = c("D", mylist);
    }
  }
  if (MotherModel >= 1) {
    if (SexModel >= 2) {
      mylist = c("ms", mylist);
    } else {
      mylist = c("m", mylist);
    }
  }
  if (ajModel >= 1) {
    if (SexModel >= 1) {
      mylist = c("as", mylist);
    } else {
      mylist = c("a", mylist);
    }
  }
  if (length(ModelsVec) >= 7 && ModelsVec[7] > 0) {
    mylist = c(mylist, paste("O", tSeq(ModelsVec[7]), sep="") );
  }
  return(mylist);
}
GenCrossList  <- function(AStringList) {
  ajModel = 0;  SexModel = 0; CrossModel = 0; 
  BetaInbredLevel = 0;  BetaInbredTimesSex = 0;
  MotherModel = 0;
  if (any(tolower(AStringList) == "gender")) {
    SexModel =1;
  }             
  if (any(tolower(AStringList) == "mother")) {
    MotherModel = 1;
  }
  if (any(tolower(AStringList) == "gender-mother"))  {
    SexModel = 2;
  }
  if (any(tolower(AStringList) == "hybrid")) {
    BetaInbredLevel = 1;
  }
  if (any(tolower(AStringList) == "gender-hybrid")) {
    BetaInbredLevel = 1;  BetaInbredTimesSex = 1;
  }
  if (any(tolower(AStringList) == "strain")) {
    ajModel = 1;
  }
  if (any(tolower(AStringList) == "hybrid-strain")) {
    BetaInbredLevel = 3;
  }
  if (any(tolower(AStringList) == "gender-hybrid-strain")) {
    BetaInbredLevel = 3;  BetaInbredTimesSex = 3;
  }
  if (any(tolower(AStringList) == "symmetric-cross")) {
    CrossModel = 2;
  }
  if (any(tolower(AStringList) == "gender-symmetric-cross")) {
    SexModel = 5;  CrossModel = 2;
  }
  if (any(tolower(AStringList) == "asymmetric-cross")) {
    CrossModel = 5;
  }
  if (any(tolower(AStringList) == "gender-asymmetric-cross")) {
    CrossModel = 5;  SexModel = 6;
  }
  if (any(tolower(AStringList) == "all-cross")) {
    CrossModel = 8;
  }
  if (any(tolower(AStringList) == "gender-all-cross")) {
    CrossModel = 8;  SexModel = 7;
  }
  MyDf = -1;
  if (any(substr(AStringList,1,1) == "O")) {
    MyT = min((1:length(AStringList))[substr(AStringList,1,1) == "O"]);
    MyDf = as.numeric(substr(AStringList[MyT],2,nchar(AStringList[MyT])));
  }
  return(c(ajModel, MotherModel, CrossModel, SexModel, 
    BetaInbredLevel, BetaInbredTimesSex, MyDf));

}

######################################################
##  ProcessAFull
##
##  function is designed to process "fulls" or "fullu" data
##
##   default is actually "fulls"
##
##
##
ProcessAFull <- function(FullString) {
  ANum = "";
  if (substr(FullString, 1, nchar("fulls, df_")) %in% c("fullu, df_", "fulls, df_")) {
     ANum = substr(FullString, nchar("fulls, df_")+1, nchar(FullString));
  } else if (substr(FullString, 1, nchar("fulls,df_")) %in% c("fullu,df_", "fulls,df_")) {
     ANum = substr(FullString, nchar("fulls,df_")+1, nchar(FullString));
  } else if (substr(FullString, 1, nchar("fullsdf_")) %in% c("fulludf_", "fullsdf_")) {
     ANum = substr(FullString, nchar("fullsdf_")+1, nchar(FullString));
  } else if (substr(FullString, 1, nchar("fulls_df_")) %in% c("fullu_df_", "fulls_df_")) {
     ANum = substr(FullString, nchar("fulls_df_")+1, nchar(FullString));
  } else if (substr(FullString, 1, nchar("fullsdf")) %in% c("fulludf", "fullsdf")) {
     ANum = substr(FullString, nchar("fullsdf")+1, nchar(FullString));
  } else if (substr(FullString, 1, nchar("fulls, df")) %in% c("fullu, df", "fulls, df")) {
     ANum = substr(FullString, nchar("fulls, df")+1, nchar(FullString));
  } else if (substr(FullString, 1, nchar("fulls,df")) %in% c("fullu,df", "fulls,df")) {
     ANum = substr(FullString, nchar("fulls,df")+1, nchar(FullString));
  } else if (substr(FullString, 1, nchar("fulls_df")) %in% c("fullu_df", "fulls_df")) {
     ANum = substr(FullString, nchar("fulls_df")+1, nchar(FullString));
  } else if (length(grep("df", FullString)) > 0) {
    ANum = strsplit(FullString, "df")[[1]][2];
    ANum = paste(unlist(strsplit(ANum, "_")), collapse="");  
    ANum = paste(unlist(strsplit(ANum, ",")), collapse="");
    ANum = paste(unlist(strsplit(ANum, ";")), collapse="");
    ANum = paste(unlist(strsplit(ANum, " ")), collapse="");
  }
  ANum = paste(unlist(strsplit(ANum, "_")), collapse="");  
  ANum = paste(unlist(strsplit(ANum, ",")), collapse="");
  ANum = paste(unlist(strsplit(ANum, ";")), collapse="");
  ANum = paste(unlist(strsplit(ANum, " ")), collapse="");
  ATrNum = NULL;
  try(ATrNum <- as.numeric(ANum));
  if (!is.null(ATrNum) && !is.na(ATrNum) && is.numeric(ATrNum)  &&
    ATrNum > 0) {
    df = ATrNum;  
  } else {
    df = 0;
  }
  if (substr(FullString,1, nchar("fullu")) == "fullu") {
    return(c(1,1,5,0,3,0,df));
  } else {
    return(c(1,1,5,7,3,3,df));
  }
}

StringInput = list(
  "a,as,w",
  "s,d,D,as",
  "ds, a, O4");

ReadModels <- function(filename = NULL, StringInput = "", MyLines = "Fulls") {

if (!is.null(MyLines)) {
  MyLines = MyLines;
} else if (!is.null(filename)) {
##MyPt = file(filename, open="rt");
##if(is.null(MyPt)) {
##  print("Sorry No Models in the Given File")
##  return(NULL);
##}
try(MyLines <- unlist(readLines(filename, n=-1, warn = FALSE)));
##close(MyPt);
} else {
  try(MyLines <- unlist(strsplit(StringInput,"\n")));
}
if (is.null(MyLines) || (length(MyLines) == 1 && MyLines == "")) {
  MyLines = filename;
}
if (length(MyLines) == 1 && MyLines == "") {
  print("ReadModels: Please Give Me Some models to work with");
  return(NULL);
}
ModelTable = matrix(0, length(MyLines), 7);
for (ii in 1:length(MyLines)) {
  AT = NULL
  if (substr(MyLines[ii], 1, nchar("full")) == "full") {
    AT <-  ProcessAFull(MyLines[ii]);
  } else {
    MySplit = unlist(strsplit(MyLines[ii], " *\t*,+ *\t*"));
    GoList = MySplit;
    GoList[MySplit %in% MatchStringsList ] = StringsList[ match( MySplit[MySplit %in% MatchStringsList],
      MatchStringsList)];
    try(AT <- GenCrossList(GoList));
    if (is.null(AT) || length(AT) == 7 && sum(abs(AT-c(0,0,0,0,0,0,-1))) == 0) {
      try(AT <- WalkAndReadCrossList(MyLines[ii]));
    }
    if (any(substr(MySplit,1,nchar("df")) %in% c("df", "Df", "DF", "dF"))) {
      AB <- (1:length(MySplit))[substr(MySplit,1,nchar("df")) %in% c("df", "Df", "DF", "dF")];
      SF <- paste(unlist(strsplit(MySplit[AB[1]],"df")), collapse="");
      SF <- paste(unlist(strsplit(SF,"DF")), collapse="");  
      SF <- paste(unlist(strsplit(SF,"Df")), collapse="");    
      SF <- paste(unlist(strsplit(SF,"dF")), collapse="");  
      SF <- paste(unlist(strsplit(SF,"_")), collapse="");  
      DFF <- suppressWarnings(as.numeric(SF));
      if (DFF > 0.0) {
        AT[7] <- DFF;
      }
    }
  }
  ModelTable[ii,] = AT; 
}
return(ModelTable);

}

WalkAndReadCrossList <- function(MyL) {
  repVec = rep(0,7);
  it = 1;
  ATU = paste(unlist(strsplit(MyL, ",")), collapse="");
  if (substr(ATU, 1, nchar("fulls_df")) == "fulls_df") {
    ATR = as.numeric(substr(ATU, 1+nchar("fulls_df"), nchar(ATU)));
    if (ATR > 0) {
      return(c(1,1,5,7,3,3,ATR));
    } else if (ATR %in%c(-1, 0)) {
      return(c(1,1,5,7,3,3,-1));
    } else {
      print(paste("I believe you wanted full model, but you gave: ", ATU));
      return(c(1,1,5,7,3,3,-1));
    }
  } else if  (substr(ATU, 1, nchar("fullsdf")) == "fullsdf") {
    ATR = as.numeric(substr(ATU, 1+nchar("fullsdf"), nchar(ATU)));
    if (ATR > 0) {
      return(c(1,1,5,7,3,3,ATR));
    } else if (ATR %in%c(-1, 0)) {
      return(c(1,1,5,7,3,3,-1));
    } else {
      print(paste("I believe you wanted full model, but you gave: ", ATU));
      return(c(1,1,5,7,3,3,-1));
    }
  } else if (ATU  == "fulls") {
    return(c(1,1,5,7,3,3,-1));
  } else if  (substr(ATU, 1, nchar("fulludf")) == "fulludf") {
    ATR = as.numeric(substr(ATU, 1+nchar("fulludf"), nchar(ATU)));
    if (ATR > 0) {
      return(c(1,1,5,0,3,0,ATR));
    } else if (ATR %in%c(-1, 0)) {
      return(c(1,1,5,0,3,0,-1));
    } else {
      print(paste("I believe you wanted full model, but you gave: ", ATU, sep=""));
      return(c(1,1,5,0,3,0,-1));
    }
  } else if  (substr(ATU, 1, nchar("fullu_df")) == "fullu_df") {
    ATR = as.numeric(substr(ATU, 1+nchar("fullu_df"), nchar(ATU)));
    if (ATR > 0) {
      return(c(1,1,5,0,3,0,ATR));
    } else if (ATR %in%c(-1, 0)) {
      return(c(1,1,5,0,3,0,-1));
    } else {
      print(paste("I believe you wanted full model, but you gave: ", ATU, sep=""));
      return(c(1,1,5,0,3,0,-1));
    }
  } else if (ATU  == "fullu") {
    return(c(1,1,5,0,3,0,-1));
  }

  while(it <= nchar(MyL)) {
    if (substr(MyL,it,it+1) == "df") {
      As = ""; wit = it+2;
      while(wit <= nchar(MyL) && 
        substr(MyL,wit,wit)  %in% 
          c("0","1","2","3","4","5","6","7","8","9",".")) {
        As = paste(As, substr(MyL,wit,wit), sep="");  wit = wit+1;
      }
      repVec[7] = max(repVec[7],as.numeric(As)); it = wit;
    } else if (substr(MyL,it,it+3) == "d.f.") {
      As = ""; wit = it+2;
      while(wit <= nchar(MyL) && 
        substr(MyL,wit,wit)  %in% 
          c("0","1","2","3","4","5","6","7","8","9",".")) {
        As = paste(As, substr(MyL,wit,wit), sep="");  wit = wit+1;
      }
      repVec[7] = max(repVec[7],as.numeric(As)); it = wit;
    } else if (substr(MyL,it,it) == "S") {
       repVec[4] = max(repVec[4],1); it = it+1;
    } else if (substr(MyL,it,it) == "B") {
      if (substr(MyL,it+1,it+1) %in% c("s", "S")) {
        repVec[5] = max(repVec[5],1);  repVec[4] = max(repVec[4],1); 
        repVec[6] = max(repVec[6],1); it = it+2;
      } else if (substr(MyL,it+1,it+2) %in% c("_s","_S") ) {
        repVec[4] = max(repVec[4],1); repVec[5] = max(repVec[5],1); 
        repVec[6] = max(repVec[6],1); it=it+3;
      } else {
        repVec[5] = max(repVec[5],1); it = it+1;
      }
    } else if (substr(MyL,it,it) == "s") {
       repVec[4] = max(repVec[4], 2); it = it+1
    } else if (substr(MyL,it,it) == "a") {
      if (substr(MyL,it+1,it+1) == "s") {
        repVec[4] = max(repVec[4],2);  repVec[1] = max(repVec[1],1); it = it+2;
      } else if (substr(MyL,it+1,it+2) == "_s" ) {
        repVec[4] = max(repVec[4],2); repVec[1] = max(repVec[1],1); it=it+3;
      } else {
        repVec[1] = max(repVec[1],1); it = it+1;
      }
    } else if (substr(MyL,it,it) == "m") {
      if (substr(MyL,it+1,it+1) == "s") {
        repVec[4] = max(repVec[4],3);  repVec[2] = max(repVec[2],1); it = it+2;
      } else if (substr(MyL,it+1,it+2) == "_s" ) {
        repVec[4] = max(repVec[4],3); repVec[2] = max(repVec[2],1); it=it+3;
      } else {
        repVec[2] = 1; it = it+1; repVec[2] = max(repVec[2],1);
      }
    } else if (substr(MyL,it,it) == "b") {
      if (substr(MyL,it+1,it+1) == "s") {
        repVec[5] = 3;  repVec[4] = max(repVec[4],4); repVec[6] = 3; it = it+2;
      } else if (substr(MyL,it+1,it+2) == "_s" ) {
        repVec[5] = 3;  repVec[4] = max(repVec[4],4); repVec[6] = 3; it=it+3;
      } else {
        repVec[1] = 1; it = it+1; repVec[5] = max(repVec[5],3);
      }
    } else if (substr(MyL,it,it) == "v") {
      if (substr(MyL,it+1,it+1) == "s") {
        repVec[3] = max(repVec[3],2);   
        repVec[4] = max(repVec[4],5); it = it+2;
      } else if (substr(MyL,it+1,it+2) == "_s" ) {
        repVec[3] = max(repVec[3],2);   repVec[4] = max(repVec[4],5); it=it+3;
      } else {
        repVec[3] = max(repVec[3],2); it = it+1;
      }
    } else if (substr(MyL,it,it) == "w") {
      if (substr(MyL,it+1,it+1) == "s") {
        repVec[3] = max(repVec[3],5);   repVec[4] = max(repVec[4],5); it = it+2;
      } else if (substr(MyL,it+1,it+2) == "_s" ) {
        repVec[3] = max(repVec[3],5);   repVec[4] = max(repVec[4],5); it=it+3;
      } else {
        repVec[1] = 1; it = it+1; repVec[3] = max(repVec[3],5);
      }
    } else if (substr(MyL,it,it) == "x") {
      if (substr(MyL,it+1,it+1) == "s") {
        repVec[3] = max(repVec[3],8);   repVec[4] = max(repVec[4],5); it = it+2;
      } else if (substr(MyL,it+1,it+2) == "_s" ) {
        repVec[3] = max(repVec[3],8);   repVec[4] = max(repVec[4],5); it=it+3;
      } else {
        repVec[1] = 1; it = it+1; repVec[3] = max(repVec[3],5);
      }
    } else {
      it = it +1;
    }
  }
  return(repVec);
}

DiallelAnalyzer <- function(
  data = NULL,
  father.strain="father.strain",
  mother.strain="mother.strain",
  phenotype="phenotype",
  is.female="is.female", Y = NULL,
  FixedEffects=NULL, nameFixedEffects = NULL, 
  RandomEffects=NULL, nameRandomEffects=NULL,
  RandomEffectsGroups = NULL,
  Models=NULL, tauPriorFile = NULL, 
  sep=",", na.strings="NA", 
  sigmasq.start = 1, numChains =3, lengthChains = 2000,
  Verbose = TRUE, LogTransform = FALSE, SqrtTransform = FALSE,
  burnin = 1, thin = 1, DIC.Only = FALSE,
  DoBayesSpike = FALSE, PriorProbTau = NULL,
  PriorProbFixed = NULL, 
  BSSaveDir = NULL, BSVerbose = NULL, strain.map = NULL,SaveAFDFile = "",
  ProbUnknownGender = NULL, ListUnknownGender = NULL, NoChainsUnknownGender = FALSE, 
  phenotype.name = "", DoGelman = TRUE, 
  MissingYIndices=NULL, LowCensorBound=NULL,
  UpCensorBound = NULL, NoChainsImputeY=FALSE,DataFile=NULL, DoFirstCenter = NULL,
  BSLengthChains=3000, BSNumChains=4, TestEndBayesSpikeAutoDiallel = -1, ...) {
  
  mother.strain.initial = mother.strain;  father.strain.initial = father.strain;
  AOMap <- NULL;
  if (is.null(data) && is.null(DataFile)) {
    tryCatch("-- Diallel Analyzer Error, no data supplied! ");
  } else if (!is.null(data)) {
    DataFile = data;
  } else {
    data = DataFile;
  }
  if ((!exists("Y") || is.null(Y)) && is.numeric(phenotype) && length(phenotype) > 1) {
    Y = phenotype; 
  }
  if (DoBayesSpike == TRUE && is.null(BSSaveDir)) {
    print("DiallelAnalyzer: Please supply an accessible, non-null, BSSaveDir if choosing DoBayesSpike mode");
    flush.console();
    return(-1);
  } else if (DoBayesSpike == TRUE) {
    AT = matrix(0,4,4);
    dir.create(BSSaveDir, showWarnings=FALSE, recursive=TRUE);
    MyTF = paste(BSSaveDir, "//", "TestFile.csv", sep="");
    NewS = FALSE;
    MyAText = "try(write.table(AT, file=MyTF, sep=\",\", eol=\"\n\"));  NewS = TRUE";
    eval(parse(text=MyAText));
    if (is.null(BSVerbose)) { BSVerbose = Verbose; }
    if (is.logical(BSVerbose) && BSVerbose == FALSE) {  BSVerbose = 0; }
    if (is.logical(BSVerbose) && BSVerbose == TRUE)  { BSVerbose = 1; }
    if (NewS == FALSE) {
      print("DiallelAnalyzer: Please supply an accessible BSSaveDir if choosing BayesSpike mode");
      print(paste("  ", BSSaveDir, " is not accessible.", sep=""));
      flust.console(); return(-1);
    }
    unlink(MyTF);
  }
  if (exists("DoBayesSpike")  && !is.null(DoBayesSpike) &&
    ((is.logical(DoBayesSpike) && DoBayesSpike == TRUE) || 
     (is.numeric(DoBayesSpike) && DoBayesSpike >= 1)) ) {
    if (!is.null(BSSaveDir)  && is.character(BSSaveDir) && BSSaveDir != "") {
      if (exists("DoFirstCenter") && !is.null(DoFirstCenter) && is.logical(DoFirstCenter) && DoFirstCenter == FALSE) {
        DoFirstCenter <- FALSE;  
      } else if (exists("DoFirstCenter") && !is.null(DoFirstCenter) && is.numeric(DoFirstCenter) && DoFirstCenter < 1) {
        DoFirstCenter <- FALSE;
      } else if (exists("DoFirstCenter") && !is.null(DoFirstCenter) && is.logical(DoFirstCenter) && DoFirstCenter == TRUE) {
        DoFirstCenter <- TRUE;
      } else if (!exists("DoFirstCenter") || is.null(DoFirstCenter)) {
        DoFirstCenter <- TRUE;
      }
    }  
  }
  if (!exists("DoFirstCenter") || is.null(DoFirstCenter)) {
    DoFirstCenter <- FALSE;
  } else if (is.logical(DoFirstCenter) && DoFirstCenter == TRUE) {
    DoFirstCenter <- TRUE;
  } else if (is.logical(DoFirstCenter) && DoFirstCenter == FALSE) {
    DoFirstCenter <- FALSE;
  } else if (is.numeric(DoFirstCenter) && DoFirstCenter < 1) {
    DoFirstCenter <- FALSE;
  } else if (is.numeric(DoFirstCenter) && DoFirstCenter >= 1) {
    DoFirstCenter <- TRUE;
  }
  if (is.null(DataFile)) {
    print("*****************************************************");
    print("DiallelAnalyzer Error, DataFile is NULL, can't do!\n");
    flush.console();
    return(DataFile);
  } else if (!is.null(DataFile)) {

    if (is.data.frame(DataFile)  || is.matrix(DataFile)) {
      if (Verbose > 1) {
        print("DiallelAnalyzer: You supplied a Dataframe for Datafile");
      }
      Mouse.data.frame = as.data.frame(DataFile, stringsAsFactors = FALSE);
      if (is.character(phenotype) && length(phenotype) == 1) {
        Y = Mouse.data.frame[, colnames(Mouse.data.frame) %in% phenotype];
        phenotype.name = as.character(phenotype);
      } else if (is.character(phenotype) && length(phenotype) <= 0) {
        print("Diallelanalyzer: Error, Phenotype is charater but length 0");
        flush.console();
        tryCatch("Try Again");
      } else if (is.character(phenotype)) {
        pY = rep(NA, length(phenotype));
        for (ii in 1:length(phenotype)) {
          pFF = paste(unlist(strsplit(phenotype[ii], " ")), sep="");
          if (pFF %in% c("NA", " NA", "Na", "na")) {
            pY[ii] = NA;
          } else {
            try(pY[ii] <- as.numeric(pFF), silent=TRUE)
        }
      }
      Y = pY;
      }
    
    } else if (is.character(DataFile)) {
      if (!is.null(Verbose) && Verbose == TRUE) {
        print("**********************************************************");
        print("DiallelAnalyzer:  Reading in Data from File")
      }
        Mouse.data.frame = NULL;
        try(Mouse.data.frame <- read.table(DataFile, sep=sep,
          na.strings=na.strings, header=TRUE));
    } else {
        Mouse.data.frame = NULL;
        print("Error: We tried to load in Mouse Dataframe but it was fautly");
        print("Here is faulty DataFile!");
        return(DataFile);
    }
    if (is.null(Mouse.data.frame)) {
      print("DiallelAnalyze:  Error, Datafile is corrupted");
     return(NULL);
    }
    if (Verbose > 2) {
      print(paste("DiallelAnalzyer: We're going to process Data.frame of dim =(",
        paste(dim(Mouse.data.frame), collapse=", "), ")", sep=""));
        flush.console();
      print(paste("Which has colnames = ", paste(colnames(Mouse.data.frame),
        collapse=", "), sep="")); flush.console();
    }
    if (is.character(phenotype) && length(phenotype) == 1) {
      Y = Mouse.data.frame[, colnames(Mouse.data.frame) %in% phenotype];
      phenotype.name = as.character(phenotype);
    } else if (is.character(phenotype) && length(phenotype) <= 0) {
        print("DiallelAnalyzer: Error, Phenotype is charater but length 0");
        flush.console();
        tryCatch("Try Again");
    } else if (is.character(phenotype)) {
       pY = rep(NA, length(phenotype));
       for (ii in 1:length(phenotype)) {
         pFF = paste(unlist(strsplit(phenotype[ii], " ")), sep="");
         if (pFF %in% c("NA", " NA", "Na", "na")) {
           pY[ii] = NA;
         } else {
           try(pY[ii] <- as.numeric(pFF), silent=TRUE)
        }
      }
      Y = pY;
    }    
    if (is.factor(FixedEffects) && length(FixedEffects) != length(Y)) {
      if (Verbose > 2) {
        print("DiallelAnalyzer: note we were supplied Factor FixedEffects!");
      }
      FixedEffects = as.character(FixedEffects);
    }
    if (is.numeric(FixedEffects) && length(FixedEffects) %% length(Y) != 0) {
      nameFixedEffects = FixedEffects;
      FixedEffects = colnames(Mouse.data.frame)[FixedEffects];
      if (Verbose > 2) {
        print("DiallelAnalyzer: note Fixed effects were supplied numeric but of wrong length");
        print(paste("We were looking for columns ", paste(FixedEffects, collapse=", "), " of Mouse.data.frame", sep=""));
        flush.console();
      }
    }
    if (is.numeric(FixedEffects) && length(FixedEffects) %% length(Y) == 0) {
      if (Verbose > 2) {
        print("DiallelAnalzyer: note Fixed Effects were supplied as satisfactory numeric vector: ");
        print(paste(" length(FixedEffects) = ", length(FixedEffects), ", dimFixedEffects = (",
        paste(dim(FixedEffects), collapse=", "), ") and length(Y) = ", length(Y), sep=""));
        flush.console();
      }
    } else if (is.character(FixedEffects)) {
      if (Verbose > 2) {
        print("**************************************************************");
        print("DiallelAnalyzer: We are reading in FixedEffects from Mouse.data.frame");
        flush.console();
      }
      nameFixedEffects = FixedEffects;
      AFFixedEffects = FixedEffects;
      FixedEffects = Mouse.data.frame[,
        colnames(Mouse.data.frame) %in% AFFixedEffects];
      NCFixedEffects = length(AFFixedEffects);
      lFixedEffects = 0;
      try(lFixedEffects <- length(as.numeric(unlist(FixedEffects))));
      if (lFixedEffects == 0 || lFixedEffects %% length(Y) != 0) {
        try(lFixedEffects <- NROW(FixedEffects) * NCOL(FixedEffects));
      }
      if (length(FixedEffects) == 0 || lFixedEffects == 0) {
        print(paste("DiallelAnalyzer:  Dataframe FixedEffects Read In Error, ",
          "we have supplied fixed Effects = ", sep=""));
        print(paste(AFFixedEffects, collapse=", "));
        print(" But colnames(Mouse.data.frame) are: ");
        print(paste(colnames(Mouse.data.frame), collapse=", ")); flush.console(); 
        return(-1);
      } else if (lFixedEffects %% length(Y) != 0) {
        print(paste("DiallelAnalyzer: lFixedEffects Fail, Dataframe Fixed Effects Read In Error", sep=""));
        print(paste("  We got dim(FixedEffects) = (", 
          paste(dim(FixedEffects), collapse=", "), "), Length FixedEffects = ",
          lFixedEffects, " but length(Y) = ",
          length(Y), sep="")); flush.console();
        return(-1);
      } else if (length(AFFixedEffects) > 1  && NCOL(FixedEffects) != length(AFFixedEffects)) {
        print(paste("DiallelAnalyzer:  Error, I believe you were seeking Fixed Effects: "));
        print(paste(AFFixedEffects, collapse=", "));
        print(" But colnames(Mouse.data.frame) are: ");
        print(paste(colnames(Mouse.data.frame), collapse=", ")); flush.console(); 
        print("Returning FixedEffects we fit: ");  flush.console();
        return(FixedEffects); 
      }
      if (is.data.frame(FixedEffects) && NCOL(FixedEffects) == 1) {
        try(FixedEffects <- matrix(as.numeric(FixedEffects),
          NROW(FixedEffects),1), silent=TRUE);
        try(colnames(FixedEffects) <- AFFixedEffects[1], silent=TRUE)
      } else if (is.data.frame(FixedEffects) && NCOL(FixedEffects) > 1) {
        NewFixedEffects = matrix(0, NROW(FixedEffects), NCOL(FixedEffects));
        for (ii in 1:NCOL(FixedEffects)) {
          NewFixedEffects[,ii] = as.numeric(FixedEffects[,ii]);
        }
        try(colnames(NewFixedEffects) <- colnames(FixedEffects), silent=TRUE);
        FixedEffects=NewFixedEffects;
      }
      if (Verbose > 2) {
        print(paste("   Formatted Fixed Effects to have length=", length(FixedEffects),
          " and now dim(FixedEffects) = (", paste(dim(FixedEffects), collapse=", "),
          sep="")); flush.console();
      }
    }
    ############################################################################
    ##  Configure BayesDiallel to take in RandomEffects
    ##
    ##
    ##
    if (is.list(RandomEffectsGroups)) {
      RandomOrderIndices <- list();
      for (ii in 1:length(RandomEffectsGroups)) {
        if (is.character(RandomEffectsGroups[[ii]])) {
          RandomOrderIndices[[ii]] <- (1:NCOL(Mouse.data.frame))[
            colnames(Mouse.data.frame) %in% RandomEffectsGroups[[ii]] ];
        } else if (is.numeric(RandomEffectsGroups[[ii]])) {
          AT <- RoundRandomEffectsGroups[[ii]]
          RandomOrderIndices[[ii]] <- AT[AT >= 1 && AT <= NCOL(Mouse.data.frame)];
        }
      }
      names(RandomOrderIndices) <- names(RandomEffectsGroups);
      TwoRandomOrderIndices <- list();  AOn <- 1;
      NumRandomEffectsColumns <- 0;
      for (ii in 1:length(RandomOrderIndices)) {
         if (length(RandomOrderIndices[[ii]]) > 1 ) {
           TwoRandomOrderIndices[[AOn]] <- RandomOrderIndices[[ii]];
           try(names(TwoRandomOrderIndices)[AOn] <- names(RandomOrderIndices)[ii]);
           NumRandomEffectsColumns <- NumRandomEffectsColumns + length(RandomOrderIndices[[ii]]);
           AOn <- AOn +1;
         } else if (length(RandomOrderIndices[[ii]]) == 1) {
            TwoRandomOrderIndices[[AOn]] <- RandomOrderIndices[[ii]];
           try(names(TwoRandomOrderIndices)[AOn] <- names(RandomOrderIndices)[ii]);
            FactorCount <- length(unique(Mouse.data.frame[,RandomOrderIndices[[ii]]]));
            NumRandomEffectsColumns <- NumRandomEffectsColumns + FactorCount;
            AOn <- AOn+1;
         }
      }
      RandomEffects = matrix(0, NROW(Mouse.data.frame), NumRandomEffectsColumns);
      AK <-0;
      RandomEffectsGroups <- rep(0, length(TwoRandomOrderIndices));
      names(RandomEffectsGroups) <- names(TworandomOrderIndices);
      for (ii in 1:length(TwoRandomOrderIndices)) {
        if (length(TwoRandomOrderIndices) > 1) {
          RandomEffects[, AK + 1:length(TwoRandomOrderIndices[[ii]])] <- 
            as.numeric(unlist(Mouse.data.frame[,TwoRandomOrderIndices[[ii]]]))
          colnames(RandomEffects)[AK + 1:length(TwoRandomOrderIndices[[ii]])] <-
            colnames(Mouse.data.frame)[TwoRandomOrderIndices[[ii]]];
          AK <- AK + length(TwoRandomOrderIndices[[ii]]);
          RandomEffectsGroups[ii] = length(TwoRandomOderIndices[[ii]]);
        } else {
          ATT <- sort(
            unique(Mouse.data.frame[,TwoRandomOrderIndices[[ii]]]));
          for (jj in 1:length(ATT)) {
            RandomEffects[Mouse.data.frame[,TwoRandomOrderIndices[[ii]]] ==
              ATT[jj],AK+jj] <- 1;
          }
          colnames(RandomEffects)[AK + 1:length(ATT)] <- 
            paste(colnames(Mouse.data.frame)[TwoRandomOrderIndices[[ii]]],
              ":", ATT, sep="");
          AK <- AK + length(ATT);
          RandomEffectsGroups[ii] <- length(ATT);
        }
      }
    } else if (is.list(RandomEffects) && is.character(unlist(RandomEffects)) &&
      length(unlist(RandomEffects)) %% NROW(Mouse.data.frame) != 0 ) {
      ARandomEffects = unlist(RandomEffects);
      nameRandomEffects = unlist(RandomEffects);
      RandomEffects = Mouse.data.frame[,
        colnames(Mouse.data.frame) %in% ARandomEffects];
      if (length(RandomEffects) <= 0) {
        print("DiallelAnalyzer: RandomEffects read in error you gave RandomEffects = ");
        print(paste(ARandomEffects, collapse=", ")); flush.console();
        print("  But colnames(Mouse.data.frame) = ");
        print(paste(colnames(Mouse.data.frame), collapse=", ")); flush.console();
        return(-1);
      } else if (length(unlist(RandomEffects)) %% length(Y) != 0) {
        print(paste("DiallelAnalyzer: RandomEffects read in error, dim(RandomEffects) = (",
          paste(dim(RandomEffects), collapse=", "), ") and length(Y) = ",
          length(Y), sep="")); flush.console();
        print("Returning RandomEffects");
        return(RandomEffects);
      }
    } else if (is.character(RandomEffects)) {
      ARandomEffects = RandomEffects;
      nameRandomEffects = RandomEffects;
      RandomEffects = Mouse.data.frame[,
        colnames(Mouse.data.frame) %in% RandomEffects];
      if (length(RandomEffects) <= 0) {
        print("DiallelAnalyzer: RandomEffects read in error you gave RandomEffects = ");
        print(paste(ARandomEffects, collapse=", ")); flush.console();
        print("  But colnames(Mouse.data.frame) = ");
        print(paste(colnames(Mouse.data.frame), collapse=", ")); flush.console();
        return(-1);
      } else if (length(unlist(RandomEffects)) %% length(Y) != 0) {
        print(paste("DiallelAnalyzer: RandomEffects read in error, dim(RandomEffects) = (",
          paste(dim(RandomEffects), collapse=", "), ") and length(Y) = ",
          length(Y), sep="")); flush.console();
        print("Returning RandomEffects");
        return(RandomEffects);
      }
    }
    if (!is.data.frame(RandomEffects) && !is.vector(RandomEffects) &&
      !is.matrix(RandomEffects)) {
      if (is.null(RandomEffects)) {
      } else {
        print("Error: RandomEffects is Defective, returning RandomEffects."); flush.console();
        return(RandomEffects);
      }
    }  
    if (is.null(is.female) || 
      (is.logical(is.female) && length(is.female)==1 && is.female == FALSE) ||
      (is.character(is.female) && length(is.female) == 1) &&
       is.female[1] %in% c("FALSE", "FALSE ", " FALSE")) {
      SexVector <- NULL;
      is.female=NULL;
    }
    if (is.factor(is.female)) {
      female = as.character(is.female);
    } 
    if (is.null(is.female) || (is.logical(is.female) && length(is.female)==1 && is.female == FALSE) ||
      (is.character(is.female) && length(is.female) == 1) &&
       is.female[1] %in% c("FALSE", "FALSE ", " FALSE")) {
      SexVector <- NULL; is.female=NULL;
    } else if (is.character(is.female) && length(is.female) == 1) {
      SexVector= Mouse.data.frame[, colnames(Mouse.data.frame) %in% is.female];
      if (is.character(SexVector)) {
        ASS <- strsplit(SexVector, " ");
        for (ii in 1:length(SexVector)) {
          SexVector[ii] <- paste(ASS[[ii]], collapse="");
        }
      }
      NewSex <- rep(NA, length(Y));
      if (all( SexVector %in% c("NA", "F", "T"))) {
        NewSex[is.female == "T"] = 1;
        NewSex[is.female == "F"] = 0;
        NewSex[is.female == "NA"] = NA;
      } else {
        NewSex[SexVector %in% c("female", "Female", " female", " Female",
          "FEMALE", " FEMALE", "TRUE", " TRUE ", "F", "1", " 1")] = 1;
        NewSex[SexVector %in% c("male", "Male", " male", " Male",
          "MALE", " MALE", "FALSE", " FALSE ", "F", "0", " 0")] = 0;
      }   
      SexVector <- NewSex;
      is.female <- NewSex;  
    } else if (is.character(is.female) && length(is.female) == length(Y)) {
      SexVector = rep(NA, length(Y));
      if (all( is.female %in% c("NA", "F", "T"))) {
        SexVector[is.female == "T"] = 1;
        SexVector[is.female == "F"] = 0;
        SexVector[is.female == "NA"] = NA;
      } else {
        SexVector[is.female %in% c("female", "Female", " female", " Female",
          "FEMALE", " FEMALE", "TRUE", "F", "1", " 1")] = 1;
        SexVector[is.female %in% c("male", "Male", " male", " Male",
          "MALE", " MALE", "FALSE", "F", "0", " 0")] = 0;
      }          
    } else if (is.character(is.female)) {
      print(paste("We have an error, length(is.female) == ", length(is.female),
        " but length Phenotype or length(Y) == ", length(Y), sep="")); flush.console();
      tryCatch("Change that please!");
    }
    if (is.numeric(is.female) && length(is.female) == length(Y)) {
      SexVector = is.female;
    }
    if (is.factor(SexVector)) {
      SexVector = as.character(SexVector);
    }
    if (is.logical(SexVector)) {
      ASexVector = rep(0, length(SexVector));
      ASexVector[SexVector == TRUE]  = 1;
      ASexVector[is.na(SexVector)] = NA;
      SexVector = ASexVector;
    } else if (is.character(SexVector)) {
      ASexVector = rep(0, length(SexVector));
      if (all(SexVector %in% c("M", "F", "NA", "na", "Na", "NaN", "Unknown", "UnKnown", "U"))) {
        ASexVector[SexVector == "M"] = 0;
        ASexVector[SexVector == "F"] = 1;
        ASexVector[SexVector %in% c("NA", "na", "Na", "NaN", "Unknown", "UnKnown", "U")] = NA;
      } else if (all(SexVector %in% c("T", "F", "NA", "na", "Na", "NaN", "Unknown", "UnKnown", "U"))) {
        ASexVector[SexVector == "T"] = 1;
        ASexVector[SexVector == "F"] = 0;
        ASexVector[SexVector %in% c("NA", "na", "Na", "NaN", "Unknown", "UnKnown", "U")] = NA;      
      } else {
        ASexVector[SexVector %in% c("1", "True", "t","T", "TRUE", "1.0", "F", "Female", "FEMALE")] = 1;
        ASexVector[SexVector %in% c("0", "False", "FALSE","M", "Male", "0.0", "male", "MALE", "FEMALE")] = 0;
        ASexVector[SexVector %in% c("NA", "na", "Na", "NaN", "Unknown", "UnKnown")] = NA;
      }
      SexVector = ASexVector;
    }
    if (!is.data.frame(is.female) && !is.vector(is.female) &&
      !is.matrix(is.female)) {
      if (is.null(is.female)) {
      } else {
        print("Error: is.female is Defective, returning!"); flush.console();
        return(is.female);
      }
    }      

    if (is.character(mother.strain) && length(mother.strain) == 1) {
      print("Using the mother.strain");
      mother.strain = as.character(Mouse.data.frame[, colnames(Mouse.data.frame) == mother.strain]);
      AD <- strsplit(mother.strain, " ");
      for (jj in 1:length(AD)) {
        AD[[jj]] <- paste(AD[[jj]], ".");
      }
      mother.strain = unlist(AD);
      print(paste("Unique Mother Strains are: ", paste(sort(unique(mother.strain)), collapse=", "), sep=""));
    }
    if (is.character(father.strain) && length(father.strain) == 1) {
      print("Using the father.strain");
      father.strain = as.character(Mouse.data.frame[, colnames(Mouse.data.frame) == father.strain]);
      AD <- strsplit(father.strain, " ");
      for (jj in 1:length(AD)) {
        AD[[jj]] <- paste(AD[[jj]], ".");
      }
      father.strain = unlist(AD);
      print(paste("Unique Father Strains are: ", paste(sort(unique(father.strain)), collapse=", "), sep=""));
    }
    if (is.character(mother.strain) && is.character(father.strain)) {
       AU = sort(unique(c(mother.strain,father.strain)));
       strain.map = cbind(AU, 1:length(AU));
       AOMap <- strain.map;
       Listjk = cbind(match(mother.strain, AU), match(father.strain, AU));
       if (!is.null(Verbose) && (is.logical(Verbose)  && Verbose == TRUE) ||
         (is.numeric(Verbose) && Verbose > 0) ) {
         print("DiallelAnalyzer: mother.strain/father.strain are character vectors, we created map:");
         print(t(strain.map));  
         print(paste("Length(mother.strain) is ", 
           length(mother.strain), " and length",
           "(father.strain) is ", length(father.strain), sep="")); flush.console();
       }
       mother.strain <- Listjk[,1];  father.strain <- Listjk[,2];
    } else if (is.numeric(mother.strain)  && is.numeric(father.strain) && 
      length(mother.strain) == length(father.strain)) {
      strains = unique(c(mother.strain, father.strain));
      if (min(strains) < 1 && max(strains) > length(strains)) {
        print("DiallelAnalyzer: Note, mother.strain/father.strain are disjoint numeric sets: "); flush.console();
        print(paste(" Strains are : ", paste(strains, collapse=", "), sep="")); flush.console();
        strain.map = cbind(as.character(strains), as.character(1:length(strains)));
        mother.strain = as.numeric(match(as.character(mother.strain), strain.map[,1]));
        father.strain = as.numeric(match(as.character(father.strain), strain.map[,1]));
      } else {
        strain.map = cbind(as.character(sort(strains)), as.character(sort(strains)));
        if (!is.null(Verbose) && (is.logical(Verbose)  && Verbose == TRUE) ||
         (is.numeric(Verbose) && Verbose > 0) ) {
         print("DiallelAnalyzer: mother.strain/father.strain supplied as complete numeric set:");
         print(t(strain.map));  
       }
      }
      Listjk = cbind(mother.strain, father.strain);  
      if (!is.null(Verbose) && (is.logical(Verbose)  && Verbose == TRUE) ||
         (is.numeric(Verbose) && Verbose > 0) ) {
         print("DiallelAnalyzer: mother.strain/father.strain are numeric vectors, we created map:");
         print(t(strain.map));  
      }
    } else if (length(mother.strain) == length(father.strain)) {

      mother.strain = as.character(mother.strain);
      father.strain = as.character(father.strain);
      AllStrains = sort(unique(c(mother.strain, father.strain)));
      strain.map = cbind(AllStrains,1:length(AllStrains));
      MyMatch = 1:length(AllStrains);
      mother.strain = match(mother.strain, AllStrains);
      father.strain = match(father.strain, AllStrains);
      Listjk = cbind(mother.strain, father.strain);
      if (!is.null(Verbose) && (is.logical(Verbose)  && Verbose == TRUE) ||
        (is.numeric(Verbose) && Verbose > 0) ) {
         print("DiallelAnalyzer: mother.strain/father.strain are factors, we created map:");
         print(t(strain.map));  
      }
    } else {
      print("DiallelAnalyze, poor mother.strain and father.strain");
      if (exists("Mouse.data.frame") && !is.null(Mouse.data.frame)) {
        print(paste("colnames of Mouse.data.frame, c(",
          paste(colnames(Mouse.data.frame), collapse = ", "), ")",
          sep=""));  
      }
      flush.console(); return(NULL);
    }
  if (!is.data.frame(FixedEffects) && !is.vector(FixedEffects) &&
      !is.matrix(FixedEffects)) {
      if (is.null(FixedEffects)) {
      } else {
        print("Error: FixedEffects is Of some very strange format (we don't take lists), returning!"); flush.console();
        return(FixedEffects);
      }
    } else if (!is.matrix(FixedEffects) && !is.data.frame(FixedEffects) &&
      is.vector(FixedEffects)) {
      if (length(FixedEffects) %% length(Y) != 0) {
        print(paste("Error:FixedEffects does not have correct length as Y",
          " which is length ", length(Y), sep=""));
        return(FixedEffects);
      }
    } else if (length(dim(FixedEffects)) != 2) {
      tryCatch(paste("Messed up dimension for FixedEffects = (", 
        paste(dim(FixedEffects), collapse=", "), ")!",sep=""));
    } else if (dim(FixedEffects)[1] != length(Y)) {
       print(paste("Error:FixedEffects(", dim(FixedEffects)[1], ", ",
         dim(FixedEffects)[2], ") does not have correct dimension as Y",
          " which is length ", length(Y), sep=""));
       return(FixedEffects);   
    }
  }
  if (is.null(Models) || length(Models) == 0) {
    print("DiallelAnalyze: Please Supply Models, Default will be big Guy");
    MyModels = matrix(c(1,1,5,7,3,3,-1),1,7);  
  } else if (is.vector(Models)) {
    if (is.character(Models)[1]) {
      MyModels = ReadModels(MyLines = Models);
    } else if (is.numeric(Models) && length(Models) %in% c(6,7)) {
      MyModels = Models;
    } else {
      print("Error: Models is a strange vector!");  return(Models);
    }
  } else if (is.character(Models)) {
    if (!is.null(Verbose) && Verbose == TRUE) {
     print("**********************************************************");
     print("DiallelAnalyze: Reading in proposed models")
    }
    MyF = NULL;
    try(MyF <- file(Models, "rt"), silent=TRUE);
    if (is.null(MyF)) {
      MyModels = ReadModels(StringInput = Models);
    }  else {
      close(MyF);
      
      if (!is.null(Verbose) && Verbose == TRUE) {
       print("**********************************************************");
       print("DiallelAnalyze: Going to read from Model File")
      }
      MyModels = ReadModels(filename=Models);
    }
  } else {
    if (length(dim(Models)) == 2 && dim(Models)[2] == 6) {
      MyModels = Models
    } else {
      print("DiallelAnalyze: Please Supply Models, Default will be big Guy");
      MyModels = matrix(c(1,1,5,7,3,3,-1),1,7);
    }
  }
if (!is.null(Verbose) && (is.logical(Verbose) && Verbose == TRUE) ||
  (is.numeric(Verbose) && Verbose > 0)) {
  print("**********************************************************");
  print("** DiallelAnalyze: Models Table under consideration");
  print(MyModels);
}  
if (!is.null(Verbose) && (is.logical(Verbose) && Verbose == TRUE) ||
  (is.numeric(Verbose) && Verbose > 0)) {
  print("***********************************************************");
  print("** DiallelAnalyze: checking strains one more time "); flush.console();  
}
if (is.numeric(mother.strain) && length(mother.strain) == 1 &&
  is.numeric(father.strain) && length(father.strain) == 1) {
  mother.strain = Mouse.data.frame[,mother.strain];
  father.strain = Mouse.data.frame[,father.strain];
}

if (!is.null(AOMap)) {
  for (iii in 1:length(AOMap)) {
    AOMap[iii] <- paste(unlist(strsplit(AOMap[iii], " ")), collapse="");
    AOMap[iii] <- paste(unlist(strsplit(AOMap[iii], "\\.")), collapse="");
  }
}
if (is.numeric(mother.strain)  && is.numeric(father.strain) && 
  length(mother.strain) == length(father.strain)) {
  strains = unique(c(mother.strain, father.strain));
  if (min(strains) < 1 && max(strains) > length(strains)) {
     print("DiallelAnalyzer: Note, mother.strain/father.strain are disjoint numeric sets: "); flush.console();
     print(paste(" Strains are : ", paste(strains, collapse=", "), sep="")); flush.console();
     strain.map = cbind(as.character(strains), as.character(1:length(strains)));
     mother.strain = as.numeric(match(as.character(mother.strain), strain.map[,1]));
     father.strain = as.numeric(match(as.character(father.strain), strain.map[,1]));     
  } else {
     strain.map = cbind(as.character(sort(strains)), as.character(sort(strains)));        
     if (!is.null(Verbose) && (is.logical(Verbose)  && Verbose == TRUE) ||
        (is.numeric(Verbose) && Verbose > 0) ) {
        print("DiallelAnalyzer: mother.strain/father.strain supplied as complete numeric set:");
        print(t(strain.map));  
     }      
  }
  Listjk = cbind(mother.strain, father.strain); 
  if (!is.null(Verbose) && (is.logical(Verbose) && Verbose == TRUE) ||
    (is.numeric(Verbose) && Verbose > 0)) {
    print("   : Listjk generated as numeric vector"); 
  } 
} else if (length(mother.strain) == length(father.strain)) {
  mother.strain = as.character(mother.strain);
  father.strain = as.character(father.strain);
  AllStrains = sort(unique(c(mother.strain, father.strain)));
  strain.map = cbind(AllStrains, 1:length(AllStrains));
  MyMatch = 1:length(AllStrains);
  mother.strain = match(mother.strain, AllStrains);
  father.strain = match(father.strain, AllStrains);
  Listjk = cbind(mother.strain, father.strain);
  if (!is.null(Verbose) && (is.logical(Verbose) && Verbose == TRUE) ||
    (is.numeric(Verbose) && Verbose > 0)) {
    print("   : Listjk generated as cbind of numeric conversion of character vectors");
    print("   : strain.map is now: ");
    print(t(strain.map)); flush.console();
  }
} else {
  print("DiallelAnalyze, poor mother.strain and father.strain");
  if (exists("Mouse.data.frame") && !is.null(Mouse.data.frame)) {
    print(paste("colnames of Mouse.data.frame, c(",
      paste(colnames(Mouse.data.frame), collapse = ", "), ")",
      sep="")); flush.console(); 
  }
  print(paste("mother.stain is ", paste(mother.strain, collapse=", "), sep=""));
  print(paste("father.stain is ", paste(father.strain, collapse=", "), sep=""));
  print(paste("length(mother.strain) is ", length(mother.strain), sep=""));
  print(paste("length(father.strain) is ", length(father.strain), sep=""));
  flush.console();
  flush.console(); return(NULL);
}

if (is.numeric(is.female) && length(is.female) == length(mother.strain)) {
  SexVector = is.female;
}
if (exists("LogTransform") && 
 ((is.logical(LogTransform) && LogTransform == TRUE) ||
 (is.numeric(LogTransform) && LogTransform != 0.0)) ) {
  try(Y <- log(Y));
  phenotype.name = paste("log.", phenotype.name, sep="");
} else if (
  exists("SqrtTransform") && 
  ((is.logical(SqrtTransform) && SqrtTransform == TRUE) ||
   (is.numeric(SqrtTransform) && SqrtTransform != 0.0) ) ) {
  try(Y <- sqrt(Y));
  phenotype.name = paste("sqrt.", phenotype.name, sep="");
}

MissingYIndices = NULL;
if (any(is.na(Y))) {
  MissingYIndices = (1:length(Y))[is.na(Y)];
}
if (exists("MissingYIndices") && !is.null(MissingYIndices) &&
  length(MissingYIndices) > 0) {
  print("**********************************************************************");
  print(paste("DiallelAnalyzer::  WARNING : note, we having NA Y values at: ",
    paste(MissingYIndices, collapse=", "), sep="")); flush.console();
}
##if (length(Y[is.na(Y)]) >= 1) {
#3  NeedMarks = (1:length(Y))[!is.na(Y)];
##  Y = Y[NeedMarks];
##  SexVector = SexVector[NeedMarks];
##  Listjk = Listjk[NeedMarks,];
##}
dfTNoise = NULL;

if (length(dim(MyModels)) == 2 && dim(MyModels)[1] > 1) {
    if(any(rowSums(abs(MyModels[,1:6])) == 0)) {
      try(MyModels <- MyModels[ rowSums(abs(MyModels[,1:6])) != 0, ]);
    }
} else if (sum(abs(MyModels[1:6])) == 0) {
   MyModels =  matrix(c(1,1,5,7,3,3,-1),1,7);   
}

if (length(MyModels) == 7) {
  dfTNoise = MyModels[7];
  MyModels = MyModels[1:6];
}  
if (length(dim(MyModels)) == 2 && dim(MyModels)[2] == 7) {
  dfTNoise = MyModels[,7]
  MyModels = MyModels[,1:6];
}
numj = length(sort(unique(Listjk)));
if (numj <= 2) {
  print("--------------------------------------------------------------------");
  print("--  DiallelAnalyzer-error, there are <= 2 distinct groups in Lisjk"); flush.console();
  print(paste(" Unique Listjk Groups = (", paste(sort(unique(Listjk)), sep=", "),
    "). ", sep="")); flush.console();
  print("--  Try different Mother/Father Strain ");
  print("-----------------------------------------------------------------------");
  flush.console();
  tryCatch("DiallelAnalyzer Error");
}
if (is.logical(Verbose) && Verbose == TRUE) {
  iVerbose = 1;
} else if (is.logical(Verbose) && Verbose == FALSE) {
  iVerbose = FALSE;
} else {
  iVerbose = Verbose;
}

KeepY = (1:length(Y));
#Y = Y[KeepY];
if (exists("SexVector") && !is.null(SexVector)) {
SexVector = SexVector[KeepY]
}
Listjk = Listjk[KeepY,];
if (!is.null(ListUnknownGender)) {
   NL = match(ListUnknownGender, KeepY);
   ProbUnknownGender = ProbUnknownGender[!is.na(NL)];
   ListUnknownGender = NL[!is.na(NL)];
}
if (!exists("MissingYIndices") || 
  (is.null(MissingYIndices) && any(is.na(Y))) )  {
  if (any(is.na(Y))) {
    MissingYIndices=(1:length(Y))[is.na(Y)];
  }  else {
    MissingYIndices = NULL;
  }
} else if (exists("MissingYIndices") && !is.null(MissingYIndices)) {

} else {
  MissingYIndices=NULL;
}
if (!exists("strain.map")) {
  strain.map=NULL;
}
if (!exists("LogTransform")) {
  LogTransform=FALSE;
}
if (!exists("SqrtTransform")) {
  SqrtTransform=FALSE;
}
if (!exists("phenotype.name")) {
  phenotype.name=NULL;
}
if (!exists("LowCensorBound")) { LowCensorBound=NULL; }
if (!exists("UpCensorBound")) { UpCensorBound=NULL; }
if (!exists("NoChainsImputeY")) { NoChainsImputeY=NULL; }
if (!exists("DoGelman")) { DoGelman=TRUE; }

if (length(Y) <= 0) {
  print("DiallelAnalyzer: Error, we tried our best to process Y but received Y = ");
  print(Y);
  print("  Something is wrong with input. "); flush.console();
  return(-1);
}
if (!is.null(FixedEffects) && (length(FixedEffects) >= 1) &&
  (length(FixedEffects) %% length(Y) != 0)) {
  print("DiallelAnalyzer: Error, we tried our best process your FixedEffects inputs");
  print(paste(" but length(FixedEffects) %% length(Y) = ", length(FixedEffects) %% length(Y), sep=""));
  print(paste("Since length(FixedEffects) = ", length(FixedEffects), " and length(Y) = ", length(Y), sep=""));
  print(" Here's a printout of FixedEffects:");
  if (!is.null(dim(FixedEffects)) && NROW(FixedEffects) > 10) {
    print(FixedEffects[1:10,])
    print("....");
    print(FixedEffects[NROW(FixedEffects),]); flush.console();
  } else if (length(FixedEffects) > 10) {
    print(paste(paste(FixedEffects[1:10], collapse=", "), " ..., ", FixedEffects(length(FixedEffects)), sep=""));
  } else {
    print(FixedEffects);
  }
  print(paste("  And it seems that Y has length ", length(Y), " but FixedEffects have length = ", length(FixedEffects), sep=""));
  print("  Something is wrong with input. ");  flush.console();  
  return(FixedEffects);
} else if (!is.null(FixedEffects)) {
  if (length(dim(FixedEffects)) == 2) {
    NFixedEffects = matrix(0, dim(FixedEffects)[1], dim(FixedEffects)[2]);
    for (ii in 1:NCOL(FixedEffects)) {
      NFixedEffects[,ii] = as.numeric(FixedEffects[,ii]);
    }
    try(colnames(NFixedEffects) <- colnames(FixedEffects));
  } else if (length(FixedEffects) == length(Y)) {
    FixedEffects = as.numeric(FixedEffects);
  }
}
if (!is.numeric(Listjk)) {
  print("DiallelAnalyzer: Error, we tried to process Listjk, but it is no longer numeric!"); flush.console();
  print(Listjk);
  print(paste("Dim(Listjk) = (", paste(dim(Listjk), collapse=", "), ") but length(Y) = ", length(Y), sep=""));
  flush.console();
  return(-1);
}

if (!is.null(FixedEffects) && length(FixedEffects) > 1 &&
  (any(is.na(FixedEffects)) || any(is.nan(FixedEffects))) ) {
  print("DiallelAnalyzer: Fixed Effects are problementatic ");
  print(paste(" indices ",
    paste((1:length(FixedEffects))[is.na(FixedEffects) | is.nan(FixedEffects)],
    collapse=", "), " are NA!  ", sep=""));
  print("Please delete or choose new FixedEffects records!"); flush.console();
  return(-1);    
}
if (!is.null(RandomEffects) && length(RandomEffects) > 1 &&
  (any(is.na(unlist(RandomEffects))) || any(is.nan(unlist(RandomEffects)))) ) {
  print("DiallelAnalyzer: Random Effects are problementatic due to NA/NAN present ");
  print(paste(" indices ",
    paste((1:length(unlist(RandomEffects)))[is.na(unlist(RandomEffects)) | is.nan(unlist(RandomEffects))],
    collapse=", "), " are NA!  ", sep=""));
  print("Please delete or choose new RandomEffects records!"); flush.console();  
  return(-1);  
}



#######################################################3
## Setup Analysis
##
## Allocate AFD : FullDiallelAnalyze Object
AFD  <- FullDiallelAnalyze(Y = Y, 
  SexVector = SexVector, Listjk = Listjk, dfStart = .5, mStart = .5,
  InFixedEffects = FixedEffects, InRandomEffects = RandomEffects,
  InRandomEffectsGroups = RandomEffectsGroups,
  Verbose=iVerbose, strain.map = strain.map, 
  ListUnknownGender = ListUnknownGender,
  ProbUnknownGender=ProbUnknownGender, NoChainsUnknownGender=NoChainsUnknownGender,
  LogTransformedFlag = LogTransform, SqrtTransformedFlag = SqrtTransform,
  phenotype.name = phenotype.name, 
  MissingYIndices=MissingYIndices,
  LowCensorBound=LowCensorBound, UpCensorBound=UpCensorBound,
  NoChainsImputeY = NoChainsImputeY,  nameFixedEffects=nameFixedEffects,
  nameRandomEffects=nameRandomEffects,
  DoGelman = DoGelman, numj = numj, DoFirstCenter = DoFirstCenter);
  if (!is.null(AOMap)) {
    try(AFD$strain.map <- AOMap);
  }

  if (!exists("tauPriorFile")) { tauPriorFile = NULL; }
  if (!is.null(tauPriorFile)) {
    if (length(tauPriorFile) == 1 && is.character("tauPriorFile")) {
      tauPriorFile = read.table(tauPriorFile, sep=sep, header=TRUE);
    }
    if (row.names(tauPriorFile)[1] != "m" ||
      row.names(tauPriorFile)[2] != "df" ) {
      print("Error, for tauPriorFile input must be matrix with rows \"m\" and \"df\" or a file with this info!")
      return(-1); flush.console();
    }
    if (any(colnames(tauPriorFile) %in% c("All", "all", "ALL"))) {
      AC = (1:length(colnames(tauPriorFile)))[colnames(tauPriorFile) %in% c("All", "all", "ALL")];
      AC = AC[1];
      for (ii in 1:length(names(AFD$m))) {
        AS = paste("try(AFD$m$", names(AFD$m)[ii], " <- tauPriorFile[1,AC], silent=TRUE)", sep="");
        eval(parse(text=AS));
        AS = paste("try(AFD$df$", names(AFD$df)[ii], " <- tauPriorFile[2,AC], silent=TRUE)", sep="");
        eval(parse(text=AS));
      }
    } else {
      for (ii in 1:length(tauPriorFile[1,])) {
        if (!is.null(AFD$m[[colnames(tauPriorFile)[ii]]])) {
          try(AFD$m[[colnames(tauPriorFile)[ii]]] <- tauPriorFile[1,ii], silent=TRUE);
          try(AFD$df[[colnames(tauPriorFile)[ii]]] <- tauPriorFile[2,ii], silent=TRUE);
        }  else {
          Ato = paste(unlist(strsplit(colnames(tauPriorFile)[ii], ":")), collapse="");
          Ato = paste(unlist(strsplit(Ato, " ")), collapse="");
          if (!is.null(AFD$m[[Ato]])) {
          try(AFD$m[[Ato]] <- tauPriorFile[1,ii], silent=TRUE);
          try(AFD$df[[Ato]] <- tauPriorFile[2,ii], silent=TRUE);
        }
      }
    }    
  }
  }
  
###############################################################################
## Produce a warning about bad priors
##
## Detects whether prior is within 1/1000 to 1000 of  prior "median"
##
##
  ARMinMean <- 1; ARMaxMean <- 1;
  ARText <- "
  LM <- ListRList(AFD$m);
  LDF <- ListRList(AFD$df);
  MyMedians <- rep(1,length(AFD$m));
  for (mMm in 1:length(LM)) {
     MyMedians[mMm] <- LM[mMm]/LDF[mMm];
     ##MyMedians[mMm] <- AFD$m[[mMm]]/AFD$df[[mMm]]
  }
  try(ARMinMean <- min(MyMedians, na.rm=TRUE));
  try(ARMaxMean <- max(MyMedians, na.rm=TRUE));  
  ";
  try(eval(parse(text=ARText)));
  sdY <- 1;
  try(sdY <- sd(AFD$Y[!is.na(AFD$Y)]));
  if (sdY / ARMaxMean > 500) {
    print("*********************************************************************");
    print("***   A WARNING-WARNING-WARNING-WARNING-WARNING-WARNING    **********");
    print(paste("***  Standard deviation of Y = ", sdY, " and Prior Variability max level is ", ARMaxMean, sep=""));
    print(paste("***  You would like to transform Y optimally so that this relationship is closer to 1.   "), sep="");
    print(paste("***  Consult Residuals of analysis to see if estimator is Stable, possibly decreasing scale of Y"));
    print("*** Please consider changing \"tauPriorFile\" for improved analysis. ")
    print("*********************************************************************");
  } 
  if (sdY[1] / ARMinMean < .005) {
    print("*********************************************************************");
    print("***   A WARNING-WARNING-WARNING-WARNING-WARNING-WARNING    **********");
    print(paste("***  Standard deviation of Y = ", sdY, " and Prior Variability min level is ", ARMinMean, sep=""));
    print(paste("***  You would like to transform Y optimally so that this relationship is closer to 1.   "), sep="");
    print(paste("***  Consult Residuals of analysis to see if estimator is Stable, possibly increasing scale of Y"));
    print("*** Please consider changing \"tauPriorFile\" for improved analysis. ")
    print("*********************************************************************");
  } 
  if (sdY[1] == 0) {
    print("********************************************************************");
    print("*** DiallelAnalyze: BayesDiallel: No variation of Phenotype Y is 0, we're not going to run this phenotype");
    print("***    Possibly there has been an issue in collecting the Phenotype.");
    print("***   We will quit now so that you can identify issue with the data."); 
    print("********************************************************************"); flush.console();
    return(AFD);
  }
## Assemble a List of models to be considered by AFD
##  This is a k * 6 matrix;
##
## In our case, let k = 1, and supply AFD the "true" simulation model 

  if (!exists("sigmasq.start")) { sigmasq.start = 1; }
  Sigma = sigmasq.start;  
  names(Sigma) = "SigmaAll";
  AFD$DoGelman = DoGelman;
  
if (!is.null(Verbose) && Verbose == TRUE) {
  print("**********************************************************");
  print("DiallelAnalyze:  Setting up Chains")
  flush.console();
}                                                  
## Setup Analysis Methods for AFD, including allocating for MCMC chains
## "Sigma" is starting Sigma anticipated noise value
SetupAnalysisMethods(AFD, ModelsList = MyModels, Sigma = Sigma,
  numChains = numChains, lengthChains = lengthChains, 
  dfTNoise = dfTNoise);

if (!is.null(Verbose) && Verbose == TRUE) {
  print("**********************************************************");
  print("DiallelAnalyze:  About to run all Chains");
  flush.console();
}
#######################################################
## This will run the MCMC sampler on Model of choice
AOut = NULL;
t1 = proc.time();
try(AOut <- RunChains(AFD));
t2 = proc.time();

if (is.null(AOut)) {
  print("Uh Oh, error in MCMC Sampler, we'll return AFD in Error!"); flush.console();
  return(AFD);
}
if (AOut == -1) {
  print("Seems like we received an AFD error in the MCMC sampler!");
  flush.console();
  return(AFD);
}
if (!is.null(Verbose) && Verbose == TRUE) {
  print("***************************************************");
  print(paste("DiallelAnalyze:  All Chains are run, in time: ", sep=""));
  print(t2-t1); flush.console();         
}
if (!is.null(Verbose) && Verbose == TRUE) {
  print("***************************************************");
  print(paste("DiallelAnalyze:  Running DIC Calculations", sep="")); 
  flush.console();               
}
try(AFD$DIC <- PrintDICCAll(AFD, start = burnin, end = lengthChains,
  thin = thin), silent=TRUE);
if (!is.null(DIC.Only) && is.logical(DIC.Only) && DIC.Only == TRUE) {
  if (!is.null(Verbose) && Verbose == TRUE) {
    print("DIC.Only is True, so we're going to set old CodaChains to NULL"); flush.console();
  }
  for (ii in 1:length(AFD$AllDiallelObs)) {
    try(AFD$AllDiallelObs$CodaChains <- NULL);
  }
  gc();
}
if (!is.null(Verbose) && Verbose == TRUE) {
  print("Checking BayesSpike"); flush.console();
}
if (!is.null(SaveAFDFile) && is.character(SaveAFDFile) && SaveAFDFile[1] !="") {
  print(paste("--  Saving completed AFD to ", SaveAFDFile, sep="")); flush.console();
  try(save(AFD=AFD, file=SaveAFDFile));
}
if (DoBayesSpike == TRUE) {
  if (!exists("BSLengthChains") || is.null(BSLengthChains)) { 
    eval(parse(text=GetG0Text("BSLengthChains", "globalenv()", S=1  )));
    if (BSLengthChains <= 0) { BSLengthChains = 3000; }
  }
  if (!exists("BSNumChains")|| is.null(BSNumChains)) { 
    eval(parse(text=GetG0Text("BSNumChains", "globalenv()", S=1)));
    if (BSNumChains <= 0) { BSNumChains = 4; }
  }
   if (exists("tauPriorFile") && !is.null(tauPriorFile)  && 
    ((!exists("PriorProbTau")|| is.null(PriorProbTau)) || 
     (!exists("PriorProbFixed") || is.null(PriorProbFixed)))){
    if (is.character(tauPriorFile) && length(tauPriorFile) == 1) {
      tauPriorFile <- read.table(tauPriorFile, header=TRUE, sep=",");
    }
    if (!is.null(dim(tauPriorFile)) && dim(tauPriorFile)[1] >= 3) {
      if (is.null(PriorProbTau) || length(PriorProbTau) <= 0) {
        SuccEval <- 0;
        MyTextEval <- "
        PriorProbTau = rep(-1.0, length(AFD$.AllRandomVariables));
        names(PriorProbTau) <- AFD$.AllRandomVariables;
        if (any(colnames(tauPriorFile) %in% c(\"All\", \"ALL\", \"all\"))) {
          AC = (1:length(colnames(tauPriorFile)))[
            colnames(tauPriorFile) %in% c(\"All\", \"ALL\", \"all\") ];
          AC = AC[1];
          for (ii in 1:length(PriorProbTau)) {
            PriorProbTau[ii] = tauPriorFile[3,AC];
          }
        }
        OtherPP <- tauPriorFile[3,];
        NNP <- colnames(tauPriorFile);
        ColnamesTauPriorFile <- NNP;
        MMatch <- match(NNP,AFD$.AllRandomVariables);
        nMatch <- match(NNP,paste(1:length(AFD$.AllRandomVariables), sep=\"\"));
        nMatch2 <- match(NNP,paste(\"tau:\", 1:length(AFD$.AllRandomVariables), sep=\"\"));
        nMatch3 <- match(NNP,paste(\"RandomEffect:\", 1:length(AFD$.AllRandomVariables), sep=\"\"));
        nMatch4 <- match(NNP,paste(\"tau:\", AFD$.AllRandomVariables, sep=\"\"));
        nMatch5 <- match(NNP,paste(\"RandomEffect:\", AFD$.AllRandomVariables, sep=\"\"));
        MMatch[is.na(MMatch) & !is.na(nMatch)] <- nMatch[is.na(MMatch) & !is.na(nMatch)];
        MMatch[is.na(MMatch) & !is.na(nMatch2)] <- nMatch2[is.na(MMatch) & !is.na(nMatch2)];
        MMatch[is.na(MMatch) & !is.na(nMatch3)] <- nMatch3[is.na(MMatch) & !is.na(nMatch3)];
        MMatch[is.na(MMatch) & !is.na(nMatch4)] <- nMatch4[is.na(MMatch) & !is.na(nMatch4)];
        MMatch[is.na(MMatch) & !is.na(nMatch5)] <- nMatch5[is.na(MMatch) & !is.na(nMatch5)];
        try(NewAllRandom <- match(MapChainNamesHPD[,1], AFD$.AllRandomVariables));
        try(ANN <- 1:length(NewAllRandom));
        NewAllRandom[is.na(NewAllRandom)] <- -1;
        SomeRandom <- -1*(1:length(MMatch));
          for (ii in 1:length(SomeRandom)) {
            ART <- ANN[!is.na(NewAllRandom) & NewAllRandom == ii];
            if (length(ART) >= 1) {
              SomeRandom[ii] <- NewAllRandom[ART[1]]
            }
          }
        ##SomeRandom[NewAllRandom[!is.na(NewAllRandom)]] <- MapChainNamesHPD[!is.na(NewAllRandom),2]
        nMMatch6 <- match(NNP, SomeRandom); 
        MMatch[is.na(MMatch) & !is.na(nMMatch6)] <- nMMatch6[is.na(MMatch) & !is.na(nMMatch6)]
        NewAllRandom <- match(MapChainNames1[,1], AFD$.AllRandomVariables);
        try(ANN <- 1:length(NewAllRandom));
        NewAllRandom[is.na(NewAllRandom)] <- -1;
        SomeRandom <- -1*(1:length(MMatch));
          for (ii in 1:length(SomeRandom)) {
            ART <- ANN[!is.na(NewAllRandom) & NewAllRandom == ii];
            if (length(ART) >= 1) {
              SomeRandom[ii] <- NewAllRandom[ART[1]]
            }
          }
        nMMatch6 <- match(NNP, SomeRandom); 
        MMatch[is.na(MMatch) & !is.na(nMMatch6)] <- nMMatch6[is.na(MMatch) & !is.na(nMMatch6)]
        if (!is.null(AFD$nameRandomEffects)) {
          nAFD <- c(AFD$nameRandomEffects, -1*
           1:(length(AFD$.AllRandomVariables) - length(AFD$nameRandomEffects)));
          NewMatch <- match(NNP, nAFD);
          MMatch[is.na(MMatch) & !is.na(NewMatch)] <- NewMatch[is.na(MMatch) & !is.na(NewMatch)];
          NewMatch <- match(NNP, paste(\"tau:\", nAFD, sep=\"\"));
          MMatch[is.na(MMatch) & !is.na(NewMatch)] <- NewMatch[is.na(MMatch) & !is.na(NewMatch)];          
          NewMatch <- match(NNP, paste(\"RandomEffect:\", nAFD, sep=\"\"));
          MMatch[is.na(MMatch) & !is.na(NewMatch)] <- NewMatch[is.na(MMatch) & !is.na(NewMatch)];
        }        
        PriorProbTau[MMatch[!is.na(MMatch)]] <- OtherPP[!is.na(MMatch)];
        PriorProbTau <- unlist(PriorProbTau);
        SuccEval <- 1;
        ";
        try(eval(parse(text=MyTextEval)));
        if (SuccEval == 0) {
          print("*********************************************************************");
          print("**** DiallelAnalyze BayesSpike Start Error ");
          print("**** You supplied no PriorProbTau, but a tauPriorFile");
          print("*** Failure trying to construct PriorProbTau from tauPriorFile");
          eval(parse(text=SetGText("tauPriorFile", "globalenv()", S=1)));
          eval(parse(text=SetGText("AFD", envir="globalenv()", S=1))); 
          eval(parse(text=SetGText("PriorProbTau", envir="globalenv()", S=1))); 
          AllRandomVariables <- AFD$.AllRandomVariables;
          eval(parse(text=SetGText("AllRandomVariables", envir="globalenv()", S=1)));  
          nameRandomEffects <- AFD$nameRandomEffects;    
          NNP <- colnames(tauPriorFile); 
          ColnamesTauPriorFile <- NNP;
          eval(parse(text=SetGText("ColnamesTauPriorFile", envir="globalenv()", S=1))); 
          eval(parse(text=SetGText("nameRandomEffects", envir="globalenv()", S=1)));
          print("*** Quit and Return in Error, AFD, tauPriorFile, PriorProbTau, AllRandomVariables saved to global!");
          flush.console();
          return(AFD);  
        }
      }
      if (!exists("PriorProbFixed") || is.null(PriorProbFixed))  {
        SuccEval <- 0;
        MyTextEval <- "
        PriorProbFixed = rep(-1.0, length(AFD$.AllFixedVariables));
        names(PriorProbFixed) <- AFD$.AllFixedVariables;
        if (any(colnames(tauPriorFile) %in% c(\"All\", \"ALL\", \"all\"))) {
          AC = (1:length(colnames(tauPriorFile)))[
            colnames(tauPriorFile) %in% c(\"All\", \"ALL\", \"all\") ];
          AC = AC[1];
          for (ii in 1:length(PriorProbFixed)) {
            PriorProbFixed[ii] = tauPriorFile[3,AC];
          }
        }
        OtherPP <- tauPriorFile[3,];
        NNP <- colnames(tauPriorFile);
        MMatch <- match(NNP,AFD$.AllFixedVariables);
        nMatch <- match(NNP,paste(1:length(AFD$.AllFixedVariables), sep=\"\"));
        nMatch2 <- match(NNP,paste(\"FixedEffect:\", 1:length(AFD$.AllFixedVariables), sep=\"\"));
        nMatch3 <- match(NNP,paste(\"Beta:\", 1:length(AFD$.AllFixedVariables), sep=\"\"));
        nMatch4 <- match(NNP,paste(\"Beta:\", AFD$.AllFixedVariables, sep=\"\"));
        nMatch5 <- match(NNP,paste(\"FixedEffect:\", AFD$.AllFixedVariables, sep=\"\"));
        MMatch[is.na(MMatch) & !is.na(nMatch)] <- nMatch[is.na(MMatch) & !is.na(nMatch)];
        MMatch[is.na(MMatch) & !is.na(nMatch2)] <- nMatch2[is.na(MMatch) & !is.na(nMatch2)];
        MMatch[is.na(MMatch) & !is.na(nMatch3)] <- nMatch3[is.na(MMatch) & !is.na(nMatch3)];
        MMatch[is.na(MMatch) & !is.na(nMatch4)] <- nMatch4[is.na(MMatch) & !is.na(nMatch4)];
        MMatch[is.na(MMatch) & !is.na(nMatch5)] <- nMatch5[is.na(MMatch) & !is.na(nMatch5)];
        NewAllFixed <- match(MapChainNamesHPD[,1], AFD$.AllFixedVariables);
        try(ANN <- 1:length(NewAllFixed));
        NewAllFixed[is.na(NewAllFixed)] <- -1;
        SomeFixed <- -1*(1:length(MMatch));
          for (ii in 1:length(SomeFixed)) {
            ART <- ANN[!is.na(NewAllFixed) & NewAllFixed == ii];
            if (length(ART) >= 1) {
              SomeFixed[ii] <- NewAllFixed[ART[1]]
            }
          }
        nMMatch6 <- match(NNP, SomeFixed); 
        MMatch[is.na(MMatch) & !is.na(nMMatch6)] <- nMMatch6[is.na(MMatch) & !is.na(nMMatch6)];
        NewAllFixed <- match(MapChainNames1[,1], AFD$.AllFixedVariables);
        NewAllFixed[is.na(NewAllFixed)] <- -1;
        SomeFixed <- -1*(1:length(MMatch));
          for (ii in 1:length(SomeFixed)) {
            ART <- ANN[!is.na(NewAllFixed) & NewAllFixed == ii];
            if (length(ART) >= 1) {
              SomeFixed[ii] <- NewAllFixed[ART[1]]
            }
          }
        nMMatch6 <- match(NNP, SomeFixed); 
        MMatch[is.na(MMatch) & !is.na(nMMatch6)] <- nMMatch6[is.na(MMatch) & !is.na(nMMatch6)];
        if (!is.null(AFD$nameFixedEffects)) {
          nAFD <- c(AFD$nameFixedEffects, -1*
           1:(length(AFD$.AllFixedVariables) - length(AFD$nameFixedEffects)));
          NewMatch <- match(NNP, nAFD);
          MMatch[is.na(MMatch) & !is.na(NewMatch)] <- NewMatch[is.na(MMatch) & !is.na(NewMatch)];
          NewMatch <- match(NNP, paste(\"Beta:\", nAFD, sep=\"\"));
          MMatch[is.na(MMatch) & !is.na(NewMatch)] <- NewMatch[is.na(MMatch) & !is.na(NewMatch)];          
          NewMatch <- match(NNP, paste(\"FixedEffect:\", nAFD, sep=\"\"));
          MMatch[is.na(MMatch) & !is.na(NewMatch)] <- NewMatch[is.na(MMatch) & !is.na(NewMatch)];
        }        
        PriorProbFixed[MMatch[!is.na(MMatch)]] <- OtherPP[!is.na(MMatch)];
        SuccEval <- 1;
        ";
        try(eval(parse(text=MyTextEval)));
        if (SuccEval == 0) {
          print("*********************************************************************");
          print("**** DiallelAnalyze BayesSpike Start Error ");
          print("**** You supplied no PriorProbFixed, but a tauPriorFile");
          print("*** Failure trying to construct PriorProbFixed from tauPriorFile");
          eval(parse(text=SetGText("tauPriorFile", "globalenv()", S=1)));
          eval(parse(text=SetGText("AFD", envir="globalenv()", S=1))); 
          eval(parse(text=SetGText("PriorProbFixed", envir="globalenv()", S=1))); 
          AllFixedVariables <- AFD$.AllFixedVariables;
          eval(parse(text=SetGText("AllFixedVariables", envir="globalenv()", S=1)));  
          nameFixedEffects <- AFD$nameRandomEffects;      
          eval(parse(text=SetGText("ColnamesTauPriorFile", envir="globalenv()", S=1))); 
          eval(parse(text=SetGText("nameFixedEffects", envir="globalenv()", S=1)));
          print("*** Quit and Return in Error, AFD, tauPriorFile, PriorProbFixed, AllFixedVariables saved to global!");
          flush.console();
          return(AFD);  
        }  
        
      }
    }
  }
  if (exists("PriorProbFixed") && !is.null(PriorProbFixed) && length(PriorProbFixed) >= 1) {
     if (length(PriorProbFixed) == 1 && abs(PriorProbFixed[1] +1) <= .00001) {
        PriorProbFixed <- NULL;
     } else if (length(PriorProbFixed) == length(AFD$.AllFixedVariables)) {
     } else if (length(PriorProbFixed) == 2*length(AFD$.AllFixedVariables)) {
     } else if (!is.null(names(PriorProbFixed))) {
        SuccEval <- 0;
        MyEvalText <- "
        mMMatch <- match(names(PriorProbFixed), AFD$.AllFixedVariables);
        NewAllFixed <- match(MapChainNames1[,1], AFD$.AllFixedVariables);
        NewAllFixed[is.na(NewAllFixed)] <- -1;
        SomeFixed <- -1*(1:length(mMMatch));
          for (ii in 1:length(SomeFixed)) {
            ART <- ANN[!is.na(NewAllFixed) & NewAllFixed == ii];
            if (length(ART) >= 1) {
              SomeFixed[ii] <- NewAllFixed[ART[1]]
            }
          }
        nMMatch1 <-match(names(PriorProbFixed), 
          paste(1:length(AFD$.AllFixedVariables), sep=\"\")); 
        nMMatch2 <-match(names(PriorProbFixed), 
          paste(\"Beta:\", 1:length(AFD$.AllFixedVariables), sep=\"\")); 
        nMMatch3 <-match(names(PriorProbFixed), 
          paste(\"FixedEffect:\", 1:length(AFD$.AllFixedVariables), sep=\"\")); 
        nMMatch4 <-match(names(PriorProbFixed), 
          paste(\"Beta:\", AFD$.AllFixedVariables, sep=\"\")); 
        nMMatch5 <-match(names(PriorProbFixed), 
          paste(\"FixedEffect:\", AFD$.AllFixedVariables, sep=\"\")); 
        nMMatch6 <- match(names(PriorProbFixed), SomeFixed);      
        mMMatch[is.na(mMMatch) & !is.na(nMMatch1)] <- nMMatch1[is.na(mMMatch) & !is.na(nMMatch1)];
        mMMatch[is.na(mMMatch) & !is.na(nMMatch2)] <- nMMatch2[is.na(mMMatch) & !is.na(nMMatch2)];
        mMMatch[is.na(mMMatch) & !is.na(nMMatch3)] <- nMMatch3[is.na(mMMatch) & !is.na(nMMatch3)];
        mMMatch[is.na(mMMatch) & !is.na(nMMatch4)] <- nMMatch4[is.na(mMMatch) & !is.na(nMMatch4)];
        mMMatch[is.na(mMMatch) & !is.na(nMMatch5)] <- nMMatch5[is.na(mMMatch) & !is.na(nMMatch5)];  
        mMMatch[is.na(mMMatch) & !is.na(nMMatch6)] <- nMMatch6[is.na(mMMatch) & !is.na(nMMatch6)];
        NewAllFixed <- match(MapChainNamesHPD[,1], AFD$.AllFixedVariables);
        NewAllFixed[is.na(NewAllFixed)] <- -1;
        SomeFixed <- -1*(1:length(mMMatch));
          for (ii in 1:length(SomeFixed)) {
            ART <- ANN[!is.na(NewAllFixed) & NewAllFixed == ii];
            if (length(ART) >= 1) {
              SomeFixed[ii] <- NewAllFixed[ART[1]]
            }
          }
        nMMatch6 <- match(names(PriorProbFixed), SomeFixed); 
        mMMatch[is.na(mMMatch) & !is.na(nMMatch6)] <- nMMatch6[is.na(mMMatch) & !is.na(nMMatch6)];
        if (!is.null(AFD$nameFixedEffects)) {
          ALLnRE <- c(-1*(1:(length(AFD$.AllFixedVariables)-length(AFD$nameFixedEffects))),
            AFD$nameFixedEffects);
          NewMMatch <- match(names(PriorProbFixed), ALLnRE);
          mMMatch[is.na(mMMatch) & !is.na(NewMMatch)] <- NewMMatch[is.na(mMMatch) & !is.na(NewMMatch)];
          NewMMatch <- match(names(PriorProbFixed), paste(\"FixedEffect:\", ALLnRE, sep=\"\"));
          mMMatch[is.na(mMMatch) & !is.na(NewMMatch)] <- NewMMatch[is.na(mMMatch) & !is.na(NewMMatch)]          
        }  
        nPriorProbFixed <- rep(-1, length(AFD$.AllFixedVariables));
        nPriorProbFixed[mMMatch[!is.na(mMMatch)]] <- PriorProbFixed[!is.na(mMMatch)];
        PriorProbFixed <- nPriorProbFixed;  
        SuccEval <- 1;
        "; 
        try(eval(parse(text=MyEvalText)));
        if (SuccEval == 0) {
          print("*****************************************************************");
          print("***DiallelAnalyzer: Issue PriorProbFixed not able to be applied");
          print("***  Please supply names to PriorProbFixed or be length of AllFixedVariables!");
          print("***  Writing AllFixedVariables to globalenv as well as PriorProbFixed.");
          print(paste("*** Supplied names PriorProbFixed was (", 
            paste(names(PriorProbFixed), collapse=", "), ")", sep="")); flush.console();
          AllFixedVariables <- AFD$.AllFixedVariables;
          eval(parse(text=SetGText("AllFixedVariables", "globalenv()", S=1)));
          eval(parse(text=SetGText("PriorProbFixed", "globalenv()", S=1)));
          eval(parse(text=SetGText("AFD", "globalenv()", S=1)));
          print("***  Sorry Quit early without BayesSpike on Error!"); flush.console();
          return(AFD);         
        }       
     } else {
        print("*****************************************************************");
        print("***DiallelAnalyzer: Issue PriorProbFixed not able to be applied");
        print("***  Please supply names to PriorProbFixed or be length of AllFixedVariables!");
        print("***  Writing AllFixedVariables to globalenv as well as PriorProbFixed.");
        AllFixedVariables <- AFD$.AllFixedVariables;
        eval(parse(text=SetGText("AllFixedVariables", "globalenv()", S=1)));
        eval(parse(text=SetGText("PriorProbFixed", "globalenv()", S=1)));
        eval(parse(text=SetGText("AFD", "globalenv()", S=1)));
        print("***  Sorry Quit early without BayesSpike on Error!"); flush.console();
        return(AFD);      
     }    
  } else {
    PriorProbFixed <- NULL;
  }
  if (exists("PriorProbTau") && !is.null(PriorProbTau) && length(PriorProbTau) >= 1) {
     if (length(PriorProbTau) == 1 && abs(PriorProbTau[1]+1) <= .000001) {
       PriorProbTau <- NULL;
     } else if (length(PriorProbTau) == length(AFD$.AllRandomVariables)) {
     } else if (length(PriorProbTau) == 2*length(AFD$.AllRandomVariables)) {
     } else if (!is.null(names(PriorProbTau))) {
        SuccEval <- 0;
        MyMatchGameText  <- "
        mMMatch <- match(names(PriorProbTau), AFD$.AllRandomVariables);
        nMMatch1 <-match(names(PriorProbTau), 
          paste(1:length(AFD$.AllRandomVariables), sep=\"\")); 
        nMMatch2 <-match(names(PriorProbTau), 
          paste(\"tau:\", 1:length(AFD$.AllRandomVariables), sep=\"\")); 
        nMMatch3 <-match(names(PriorProbTau), 
          paste(\"RandomEffect:\", 1:length(AFD$.AllRandomVariables), sep=\"\")); 
        nMMatch4 <-match(names(PriorProbTau), 
          paste(\"tau:\", AFD$.AllRandomVariables, sep=\"\")); 
        nMMatch5 <-match(names(PriorProbTau), 
          paste(\"RandomEffect:\", AFD$.AllRandomVariables, sep=\"\")); 
        mMMatch[is.na(mMMatch) & !is.na(nMMatch1)] <- nMMatch1[is.na(mMMatch) & !is.na(nMMatch1)];
        mMMatch[is.na(mMMatch) & !is.na(nMMatch2)] <- nMMatch2[is.na(mMMatch) & !is.na(nMMatch2)];
        mMMatch[is.na(mMMatch) & !is.na(nMMatch3)] <- nMMatch3[is.na(mMMatch) & !is.na(nMMatch3)];
        mMMatch[is.na(mMMatch) & !is.na(nMMatch4)] <- nMMatch4[is.na(mMMatch) & !is.na(nMMatch4)];
        mMMatch[is.na(mMMatch) & !is.na(nMMatch5)] <- nMMatch5[is.na(mMMatch) & !is.na(nMMatch5)];  
        NewAllRandom <- match(MapChainNames1[,1], AFD$.AllRandomVariables);
        try(ANN <- 1:length(NewAllRandom));
        NewAllRandom[is.na(NewAllRandom)] <- -1;
        SomeRandom <- -1*(1:length(mMMatch));
          for (ii in 1:length(SomeRandom)) {
            ART <- ANN[!is.na(NewAllRandom) & NewAllRandom == ii];
            if (length(ART) >= 1) {
              SomeRandom[ii] <- NewAllRandom[ART[1]]
            }
          }
        nMMatch6 <- match(names(PriorProbTau), SomeRandom); 
        mMMatch[is.na(mMMatch) & !is.na(nMMatch6)] <- nMMatch6[is.na(mMMatch) & !is.na(nMMatch6)];
        NewAllRandom <- match(MapChainNamesHPD[,1], AFD$.AllRandomVariables);
        try(ANN <- 1:length(NewAllRandom));
        NewAllRandom[is.na(NewAllRandom)] <- -1;
        SomeRandom <- -1*(1:length(mMMatch));
          for (ii in 1:length(SomeRandom)) {
            ART <- ANN[!is.na(NewAllRandom) & NewAllRandom == ii];
            if (length(ART) >= 1) {
              SomeRandom[ii] <- NewAllRandom[ART[1]]
            }
          }
        nMMatch6 <- match(names(PriorProbTau), SomeRandom); 
        mMMatch[is.na(mMMatch) & !is.na(nMMatch6)] <- nMMatch6[is.na(mMMatch) & !is.na(nMMatch6)]
        if (!is.null(AFD$nameRandomEffects)) {
          ALLnRE <- c(AFD$nameRandomEffects, 
            -1*(1:(length(AFD$.AllRandomVariables)-length(AFD$nameRandomEffects))));
          NewMMatch <- match(names(PriorProbTau), ALLnRE);
          mMMatch[is.na(mMMatch) & !is.na(NewMMatch)] <- NewMMatch[is.na(mMMatch) & !is.na(NewMMatch)];
        }
        nPriorProbTau <- rep(-1, length(AFD$AllDiallelObs[[1]]$tau));
        nPriorProbTau[mMMatch[!is.na(mMMatch)]] <- PriorProbTau[!is.na(mMMatch)];
        PriorProbTau <- unlist(nPriorProbTau);
        SuccEval <- 1; 
        "; 
        try(eval(parse(text=MyMatchGameText))); 
        if (SuccEval == 0) {
          print("***************************************************************");
          print("***DiallelAnalye: Error Faulty PriorProbTau Input."); flush.console();
          print("*** We are saving bad PriorProbTau and AllRandomVariables to globalenv");
          print(paste("*** Bad PriorProbTau is (", paste(PriorProbTau, collapse=", "), ")", sep=""));
          flush.console();
          print("*** Will return AFD");  flush.console();
          try(eval(parse(text=SetGText("AFD", envir="globalenv()", S=1))));
          AllRandomVariables <- AFD$.AllRandomVariables;
          try(eval(parse(text=SetGText("AllRandomVariables", envir="globalenv()", S=1))));
          try(eval(parse(text=SetGText("PriorProbTau", envir="globalenv()", S=1))));  
          return(AFD);          
        }   
     } else {
        print("****************************************************************");
        print("***  DiallelAnalyze: Error Faulty PriorProbTau Input.  "); flush.console();
        print("***    Length AFD .AllRandomVariables is ", length(AFD$.AllRandomVariables), sep="");
        try(AllRandomVariables <- AFD$.AllRandomVariables);
        try(eval(parse(text=SetGText("AllRandomVariables", "globalenv()", S=1))))
        try(eval(parse(text=SetGText("AFD", "globalenv()", S=1))))
        try(eval(parse(text=SetGText("PriorProbTau", "globalenv()", S=1))))
        try(eval(parse(text=SetGText("PriorProbFixed", "globalenv()", S=1))))
        print("***  Well we wrote material to the global environment are returning AFD early exit!");
        flush.console();
        return(AFD);
     }
  } else {
    PriorProbTau <- NULL;
  }
  
  if (!exists("BSSaveDir")|| is.null(BSSaveDir)||BSSaveDir == "") { 
    eval(parse(text=GetG0Text("BSSaveDir", "globalenv()", S=1)));
    if (BSSaveDir == 0) { BSSaveDir = ""; }
  }
  GetdfTNoiseMin <- function(AFD) {
  dfTNoiseMin = -1;
  for(ii in 1:length(AFD$AllDiallelObs)) {
    if (!is.null(AFD$AllDiallelObs[[ii]]$dfTNoise) && 
      AFD$AllDiallelObs[[ii]]$dfTNoise > 0) {
      if (dfTNoiseMin < 0) {
        dfTNoiseMin = AFD$AllDiallelObs[[ii]]$dfTNoise;
      } else if (dfTNoiseMin > AFD$AllDiallelObs[[ii]]$dfTNoise) {
        dfTNoiseMin = AFD$AllDiallelObs[[ii]]$dfTNoise;
      }
    }
  }
  return(dfTNoiseMin);
  }
  dfTNoiseMin = NULL
  try(dfTNoiseMin <- GetdfTNoiseMin(AFD));
  if (is.null(dfTNoiseMin)) {
    print("Error in looking for dfTNoiseMin, returning AFD"); flush.console();
    return(AFD);
  }
  if (!exists("tauFixed") || is.null(tauFixed) || tauFixed < 0) {
    tauFixed = 30;
  }
  if (!is.null(tauPriorFile)) {
    tauPriordf = -2;  tauPriorMean = -2;
  }
  if (!exists("tauPriordf") || is.null(tauPriordf)) {
    tauPriordf = -2;
  }
  if (!exists("tauPriorMean") || is.null(tauPriorMean)) {
    tauPriorMean = -2;
  }
  if (!is.null(PriorProbFixed) && is.list(PriorProbFixed)) { PriorProbFixed <- unlist(PriorProbFixed);  }
  if (!is.null(PriorProbFixed) && length(PriorProbFixed) >= 1) {
    PriorProbFixed[is.na(PriorProbFixed)] <- -1;
    PriorProbFixed[is.nan(PriorProbFixed)] <- -1;
  }
  if (is.null(PriorProbFixed) || all(PriorProbFixed < 0)) {
    try(PriorProbFixed <- NULL);
  }
  if (!is.null(PriorProbTau) && is.list(PriorProbTau)) { PriorProbTau <- unlist(PriorProbTau);  }
  if (!is.null(PriorProbTau) && length(PriorProbTau) >= 1) {
    PriorProbFixed[is.na(PriorProbTau)] <- -1;
    PriorProbFixed[is.nan(PriorProbTau)] <- -1;
  }
  if (is.null(PriorProbTau) || all(PriorProbTau < 0)) {
    try(PriorProbTau <- NULL);
  }
  try(AFD$PriorProbFixed <- unlist(PriorProbFixed));
  try(AFD$PriorProbTau <- unlist(PriorProbTau));
  if (!exists("BSVerbose") || is.null(BSVerbose)) {
    BSVerbose = as.numeric(Verbose);
  }
  if (!exists("TestEndBayesSpikeAutoDiallel")) { TestEndBayesSpikeAutoDiallel = -1; }
  library(BayesSpike)
    try(BSAFD <- NULL);
    try(BSAFD <- BayesSpike:::BayesSpikeFromAutoDiallel(AFD,
      LengthChains=BSLengthChains, NumChains = BSNumChains,
      Verbose = BSVerbose, DoRecord=c(1,1,1,0,0,1,1), 
      SigmaPrior = c(1,Sigma), PiAPrior = PiAPrior,
      tauPriordf = tauPriordf, tauPriorMean = tauPriorMean, Run=FALSE, 
      SaveDir=BSSaveDir, tauFixed = 30, dfTNoise = dfTNoiseMin,
      PriorProbTau = PriorProbTau, PriorProbFixed=PriorProbFixed,
      ZeroOutBeforeSample = FALSE,
      TestEndBayesSpikeAutoDiallel = TestEndBayesSpikeAutoDiallel));
    if (TestEndBayesSpikeAutoDiallel >= 1 && TestEndBayesSpikeAutoDiallel <= 6) {
      print("***************************************************************************************");
      print(paste("** DiallelAnalyze(BayesDiallel): TestEndBayesSpikeAutoDiallel = ", 
        TestEndBayesSpikeAutoDiallel, ", we quit before save.", sep="")); 
      AFD$.BS <- BSAFD;
      flush.console();
      return(AFD);
    }
    if (!is.null(BSAFD)  && !is.null(BSAFD$p)) {
      try(BSAFD$SSave());
    }
    if (is.null(BSAFD)) {
      print("*****************************************************************");
      print("***  DiallelAnalyer:  Error on BSAFD Finish                      ");
      print(paste("*** BSAFD Creation Error, returning current model without.")); flush.console();
      return(AFD);
    }
    if ((is.logical(Verbose) && Verbose == TRUE) || (is.numeric(Verbose) && Verbose > 0)) {
      print("About to assign BSAFD To Global Environment"); flush.console();
    }
    eval(parse(text=SetGText("BSAFD", "globalenv()", S=1)));
    BSAFD$Verbose = 1;
    try(TrueInVector <- as.vector(BSAFD$AFD$AllDiallelObs[[1]]$CodaChains[[1]][1,]));
    try(names(TrueInVector) <- colnames(BSAFD$AFD$AllDiallelObs[[1]]$CodaChains[[1]]));

    if (TestEndBayesSpikeAutoDiallel == 7) {
      print("***************************************************************************************");
      print("** DiallelAnalyze(BayesDiallel): TestEndBayesSpikeAutoDiallel = 7, we quit before RenameBSAFDCodaList."); 
      AFD$.BS <- BSAFD;
      flush.console();
      return(AFD);
    }    
    ## Try hard to rename BSAFD CodaList
    try(BayesSpike:::RenameBSAFDCoda(BSAFD, TrueParametersList=TrueInVector));


    if (TestEndBayesSpikeAutoDiallel == 8) {
      print("***************************************************************************************");
      print("** DiallelAnalyze(BayesDiallel): TestEndBayesSpikeAutoDiallel = 8, we quit before RunRegression."); 
      AFD$.BS <- BSAFD;
      flush.console();
      return(AFD);
    } 
    if ((is.logical(Verbose) && Verbose == TRUE) || (is.numeric(Verbose) && Verbose > 0)) {
      print("About to run BSAFD Regression"); flush.console();
    }
    bst1 = proc.time();
    try(BayesSpike:::RunRegression(BSAFD)); 
    bst2 = proc.time();
    if (!is.null(BSAFD$CodaList) && is.null(colnames(BSAFD$CodaList[[1]]) ) && !is.null(BSAFD$OtherNameCodaList) &&
      length(BSAFD$OtherNameCodaList) == NCOL(BSAFD$CodaList[[1]])) {
      NewL <- list();
      for (ii in 1:length(BSAFD$CodaList)) {
        try(NewM <- matrix(BSAFD$CodaList[[ii]], NROW(BSAFD$CodaList[[ii]]),
          NCOL(BSAFD$CodaList[[ii]])));
        try(colnames(NewM) <- BSAFD$OtherNameCodaList);
        try(NewL[[ii]] <- as.mcmc(NewM))
      }
      try(NewL <- as.mcmc.list(NewL));
      try(BSAFD$CodaList <- NewL);  
    }

    if (TestEndBayesSpikeAutoDiallel == 9) {
      print("***************************************************************************************");
      print("** DiallelAnalyze(BayesDiallel): TestEndBayesSpikeAutoDiallel = 9, we quit before Save."); 
      AFD$.BS <- BSAFD;
      flush.console();
      return(AFD);
    } 
    try(BSAFD$Save());
    AFD$.BS = BSAFD;
  }
   if (!is.null(SaveAFDFile) && is.character(SaveAFDFile) && SaveAFDFile[1] !="") {
     print(paste("--  Saving completed AFD to ", SaveAFDFile, sep="")); flush.console();
     try(save(AFD=AFD, file=SaveAFDFile));
   }
  return(AFD);
}

setMethodS3("getBSAFD", "FullDiallelAnalyze", function(this,...)  {
  return(this$.BS);
});
setMethodS3("getBS", "FullDiallelAnalyze", function(this,...)  {
  return(this$.BS);
});
setMethodS3("getBayesSpike", "FullDiallelAnalyze", function(this,...)  {
  return(this$.BS);
});

tSeq = function(Number) 
{
    CN <- sub("e", "e", as.character(Number))
    CN <- sub("-", "n", as.character(CN))
    CN <- sub("\\+", "f", as.character(CN))
    CN <- sub("\\.", "p", as.character(CN))
    CN <- sub("0p", "p", as.character(CN))
    return(CN)
}
setMethodS3("getSigmaChains", "FullDiallelAnalyze", function(this,...) {
  return(this$AllDiallelObs[[this$OnObs]]$getSigmaChains());
});
setMethodS3("getSigmaChains", "DiallelOb", function(this,...) {
  if (is.null(this$CodaChains)) {
    return(NULL);
  }
  MyC = list();
  for (ii in 1:length(this$CodaChains)) {
    if (any(colnames(this$CodaChains) %in% c("Sigma", "Sigma:1", "sigma") ) ) {
      MyC[[ii]] = as.mcmc(this$CodaChains[[ii]][,colnames(this$CodaChains[[ii]]) %in% c("Sigma", "Sigma:1", "sigma")])
    }
  }
  AText = "try(MyC <- as.mcmc.list(MyC), silent=TRUE)";
  eval(parse(text=AText));
  return(MyC);
});

setMethodS3("getRaw.DiallelChains", "DiallelOb", function(this,...) {
  Chain = this$raw.chains;  library(coda);
  RSet = c();
  for (jj in 1:length(BayesDiallel:::.DefaultAllRandomVariables)) {
    RSet = c(RSet, (1:NCOL(Chain[[1]]))[
      substr(colnames(Chain[[1]]), 1, nchar(BayesDiallel:::.DefaultAllRandomVariables[jj])) ==
      BayesDiallel:::.DefaultAllRandomVariables[jj]])
  }
  FSet = c();
  for (jj in 1:length(BayesDiallel:::.DefaultAllFixedVariables)) {
    RSet = c(RSet, (1:NCOL(Chain[[1]]))[
      substr(colnames(Chain[[1]]), 1, nchar(BayesDiallel:::.DefaultAllFixedVariables[jj])) ==
      BayesDiallel:::.DefaultAllFixedVariables[jj]])
  }  
  MyC = list();
  for (ii in 1:length(this$CodaChains)) {
      MyC[[ii]] = as.mcmc(this$CodaChains[[ii]][,c(FSet, RSet)])
  }
  AText = "try(MyC <- as.mcmc.list(MyC), silent=TRUE)";
  eval(parse(text=AText));
  return(MyC);
})

setMethodS3("getHPDTable", "DiallelOb", function(this,DoBS=FALSE,...) {
  CC <- this$getCent.chains();
  if (DoBS == TRUE && !is.null(this$.AFD$.BS)) {
    if (is.null(this$.AFD$.BS$CenteredColumns)) {
        NewCodaList <- list();
        nTau <- sum(substr(colnames(AFD$.BS$CodaList[[1]]), 1,nchar("tau")) == "tau");
        nBeta <- sum(substr(colnames(AFD$.BS$CodaList[[1]]), 1,nchar("beta")) %in% c("beta", "Beta"));  
        NeedNames <- 1:(nTau+nBeta+1);
        OtherNameCodaList <- AFD$.BS$OtherNameCodaList;
        for (ii in 1:length(AFD$.BS$CodaList)) {
          NewCodaList[[ii]] <- matrix(AFD$.BS$CodaList[[ii]][,NeedNames],
            NROW(AFD$.BS$CodaList[[1]]), length(NeedNames));
          colnames(NewCodaList[[ii]]) = OtherNameCodaList[NeedNames];
          NewCodaList[[ii]] <- as.mcmc(NewCodaList[[ii]]);
        }
        ACodaList = NewCodaList; ARawList = NewCodaList;
        DoRawAnyWay = TRUE;
        AllN <- colnames(NewCodaList[[1]]);
        CC <- ACodaList;
      } else {
    
        NewCodaList <- list();
        RenameDeCenteredBSAFDCoda(BSAFD= this$.AFD$.BS);
        DCList <- this$.AFD$.BS$DeCenteredCodaList;
        eval(parse(text=SetGText("DCList", "globalenv()", S=1)));
        nTau <- sum(substr(colnames(DCList[[1]]), 1,nchar("tau")) == "tau");
        nBeta <- min((1:NCOL(DCList[[1]]))[substr(colnames(DCList[[1]]), 1,nchar("tau")) %in% c("Tau", "tau")])-1; 
        NeedNames <- 1:(nTau+nBeta+1);         
        OCNames <- AFD$.BS$OtherDeCenterCodaNames;
        for (ii in 1:length(DCList)) {
          NewCodaList[[ii]] <- matrix(DCList[[ii]][,NeedNames],
            NROW(DCList[[1]]), length(NeedNames));
          colnames(NewCodaList[[ii]]) = OCNames[NeedNames];
          NewCodaList[[ii]] <- as.mcmc(NewCodaList[[ii]]);
        }
        DoRawAnyWay = FALSE;
        ACodaList = NewCodaList;
        DoRawAnyWay = FALSE;
        AllN <- colnames(NewCodaList[[1]])
        ARawList <- NewCodaList
        CC <- NewCodaList;
      }
  }
  eval(parse(text=SetGText("CC", "globalenv()", S=1)));
  if (is.null(CC)) {
    print("getHPDTable: Error, we were not able to retrieve Centered CodaChains");
    flush.console(); return(-1);
  }
  if (length(CC) <= 0) {
    print("getHPDTable: Error, we generated Centered CodaChains of zero length");
    flush.console(); return(-1);
  }
  if (is.null(dim(CC[[1]])) || length(dim(CC[[1]])) != 2 || NROW(CC[[1]]) <= 0) {
    print("getHPDTable: Error, we generated Centered CodaChains of zero Row numbers");
    if (is.null(dim(CC[[1]]))) {
      print("getHPDTable: We have Null dimension to first item!"); flush.console();
    }
    if (length(dim(CC[[1]])) != 2) {
      print("getHPDTable: CC[[1]] is not of dimension 2"); flush.console();
    }
    if (NROW(CC[[1]]) <= 0) {
      print(paste("getHPDTable:  CC has rows of length ", NROW(CC[[1]]), sep=""));
      flush.console();
    }
    flush.console(); return(-1);
  }
  if (this$.AFD$burnin > 1) {
     MyTab <-matrix(0, (NROW(CC[[1]]) - this$.AFD$burnin +1) * length(CC), NCOL(CC[[1]]));
     AS <- 0;
     for (ii in 1:length(CC)) {
        MyTab[AS+1:(NROW(CC[[1]]) - this$.AFD$burnin +1),] <- 
          CC[[ii]][(this$.AFD$burnin):NROW(CC[[ii]]),]
        AS <- AS + (NROW(CC[[1]]) - this$.AFD$burnin +1);
     }
     colnames(MyTab) <- colnames(CC[[1]])
  } else {
     MyTab <-matrix(0, (NROW(CC[[1]])) * length(CC), NCOL(CC[[1]]) );
     AS <- 0;
     for (ii in 1:length(CC)) {
        MyTab[AS+1:NROW(CC[[1]]),] <- 
          CC[[ii]][1:NROW(CC[[ii]]),]
        AS <- AS +  NROW(CC[[1]]);
     }
     colnames(MyTab) <- colnames(CC[[1]])   
  }
  if ((is.logical(this$.AFD$Verbose) && this$.AFD$Verbose == TRUE)  ||
    (is.numeric(this$.AFD$Verbose) && this$.AFD$Verbose >= 1)) {
    print(paste("Performing HPDTable, MyTab has dim (", 
      paste(dim(MyTab), collapse=", "), ")", sep="")); 
      flush.console();    
  }
  try(Means <- colMeans(MyTab, na.rm=TRUE));
  try(Medians <- rep(0, length(Means)));
  if ((is.logical(this$.AFD$Verbose) && this$.AFD$Verbose == TRUE)  ||
    (is.numeric(this$.AFD$Verbose) && this$.AFD$Verbose >= 1)) {
    print(paste("   HPDTable, MyTab has mean and median", sep="")); 
      flush.console();    
  }
  for (jj in 1:length(Medians)) {
    try(Medians[jj] <- median(MyTab[,jj], na.rm=TRUE));
  }
  try(library(coda));
  try(MyTab <- as.mcmc(MyTab));
  if ((is.logical(this$.AFD$Verbose) && this$.AFD$Verbose == TRUE)  ||
    (is.numeric(this$.AFD$Verbose) && this$.AFD$Verbose >= 1)) {
    print(paste("   HPDTable,Give me HPDinterval.", sep="")); 
      flush.console();    
  }
  try(Hpds <- HPDinterval(MyTab, this$.AFD$HPDTarget));
  if ((is.logical(this$.AFD$Verbose) && this$.AFD$Verbose == TRUE)  ||
    (is.numeric(this$.AFD$Verbose) && this$.AFD$Verbose >= 1)) {
    print(paste("   HPDTable, Set A NewTableToreturn.", sep="")); 
      flush.console();    
  }
  try(ANewTableToReturn <- cbind(Means, Medians, Hpds));
  try(rownames(ANewTableToReturn) <- colnames(CC[[1]]));
  if ((is.logical(this$.AFD$Verbose) && this$.AFD$Verbose == TRUE)  ||
    (is.numeric(this$.AFD$Verbose) && this$.AFD$Verbose >= 1)) {
    print(paste("   Set Colnames.", sep="")); 
      flush.console();    
  }
  try(colnames(ANewTableToReturn) <- c("Posterior-Mean", "Posterior-Median", "Low-HPD95", "High-HPD95"));
  eval(parse(text=SetGText("ANewTableToReturn", "globalenv()", S=1)));
  MySetText <- "
  AGo <- 0;
  if (DoBS == FALSE || is.null(this$.AFD) || is.null(this$.AFD$.BS)) {
    try(this$.HPDTable <- ANewTableToReturn);
  } 
  AGo <- 1;
  ";
  try(eval(parse(text=MySetText)));
  if (AGo == 0) {
    print(paste("AGo = 0: Doh!")); flush.console();
  } else if (AGo == 1) {
    print(paste("AGo == 1: Well, let's finish!")); flush.console();
  }
  eval(parse(text=SetGText("ANewTableToReturn", "globalenv()", S=1)));
  return(ANewTableToReturn);
});
setMethodS3("getHPDTable", "FullDiallelAnalyze", function(this,...) {
   return(this$AllDiallelObs[[this$OnObs]]$HPDTable); 
});
setMethodS3("getCent.DiallelChains", "DiallelOb", function(this,...) {
  Chain = this$cent.chains;
  RSet = c();
  for (jj in 1:length(BayesDiallel:::.DefaultAllRandomVariables)) {
    RSet = c(RSet, (1:NCOL(Chain[[1]]))[
      substr(colnames(Chain[[1]]), 1, nchar(BayesDiallel:::.DefaultAllRandomVariables[jj])) ==
      BayesDiallel:::.DefaultAllRandomVariables[jj]])
  }
  FSet = c();
  for (jj in 1:length(BayesDiallel:::.DefaultAllFixedVariables)) {
    RSet = c(RSet, (1:NCOL(Chain[[1]]))[
      substr(colnames(Chain[[1]]), 1, nchar(BayesDiallel:::.DefaultAllFixedVariables[jj])) ==
      BayesDiallel:::.DefaultAllFixedVariables[jj]])
  }  
  MyC = list();
  for (ii in 1:length(this$CodaChains)) {
      MyC[[ii]] = as.mcmc(this$CodaChains[[ii]][,c(FSet, RSet)])
  }
  AText = "try(MyC <- as.mcmc.list(MyC), silent=TRUE)";
  eval(parse(text=AText));
  return(MyC);
})
setMethodS3("getCent.OtherRandomEffectChains", "DiallelOb", function(this,...) {
  Chain = this$cent.chains;
  RSet = c();
  OtherRandomEffects = this$.AFD$.AllRandomVariables[
    !(this$.AFD$.AllRandomVariables %in% BayesDiallel:::.DefaultAllRandomVariables)]
  if (length(OtherRandomEffects) == 0) { return(NULL); }
  for (jj in 1:length(OtherRandomEffects)) {
    RSet = c(RSet, (1:NCOL(Chain[[1]]))[
      substr(colnames(Chain[[1]]), 1, nchar(OtherRandomEffects[jj])) ==
      OtherRandomEffects[jj]])
  } 
  MyC = list();
  for (ii in 1:length(this$CodaChains)) {
      MyC[[ii]] = as.mcmc(this$CodaChains[[ii]][,c(RSet)])
  }
  AText = "try(MyC <- as.mcmc.list(MyC), silent=TRUE)";
  eval(parse(text=AText));
  return(MyC);
})
setMethodS3("getRaw.OtherRandomEffectChains", "DiallelOb", function(this,...) {
  Chain = this$raw.chains;
  RSet = c();
  OtherRandomEffects = this$.AFD$.AllRandomVariables[
    !(this$.AFD$.AllRandomVariables %in% BayesDiallel:::.DefaultAllRandomVariables)]
  if (length(OtherRandomEffects) == 0) { return(NULL); }
  for (jj in 1:length(OtherRandomEffects)) {
    RSet = c(RSet, (1:NCOL(Chain[[1]]))[
      substr(colnames(Chain[[1]]), 1, nchar(OtherRandomEffects[jj])) ==
      OtherRandomEffects[jj]])
  } 
  MyC = list();
  for (ii in 1:length(this$CodaChains)) {
      MyC[[ii]] = as.mcmc(this$CodaChains[[ii]][,c(RSet)])
  }
  AText = "try(MyC <- as.mcmc.list(MyC), silent=TRUE)";
  eval(parse(text=AText));
  return(MyC);
})

setMethodS3("getFixedChains", "DiallelOb", function(this,...) {
  Chain = this$raw.chains;

  FSet = c();
  for (jj in 1:length(BayesDiallel:::.DefaultAllFixedVariables)) {
    RSet = c(RSet, (1:NCOL(Chain[[1]]))[
      substr(colnames(Chain[[1]]), 1, nchar(BayesDiallel:::.DefaultAllFixedVariables[jj])) ==
      BayesDiallel:::.DefaultAllFixedVariables[jj]])
  }  
  MyC = list();
  for (ii in 1:length(this$CodaChains)) {
      MyC[[ii]] = as.mcmc(this$CodaChains[[ii]][,c(FSet)])
  }
  AText = "try(MyC <- as.mcmc.list(MyC), silent=TRUE)";
  eval(parse(text=AText));
  return(MyC);
})

setMethodS3("getFixedChains", "FullDiallelAnalyze", function(this,...) {
  return(this$AllDiallelObs[[this$OnObs]]$getFixedChains());
});
setMethodS3("getRaw.DiallelChains", "FullDiallelAnalyze", function(this,...) {
  return(this$AllDiallelObs[[this$OnObs]]$getRaw.DiallelChains());
});
setMethodS3("getCent.DiallelChains", "FullDiallelAnalyze", function(this,...) {
  return(this$AllDiallelObs[[this$OnObs]]$getCent.DiallelChains());
});
setMethodS3("getRaw.OtherRandomEffectChains", "FullDiallelAnalyze", function(this,...) {
  return(this$AllDiallelObs[[this$OnObs]]$getFixedChains());
});
setMethodS3("getCent.OtherRandomEffectChains", "FullDiallelAnalyze", function(this,...) {
  return(this$AllDiallelObs[[this$OnObs]]$getFixedChains());
});

setMethodS3("getTauChains", "FullDiallelAnalyze", function(this,...) {
  return(this$AllDiallelObs[[this$OnObs]]$getTauChains());
});
setMethodS3("getTauChains", "DiallelOb", function(this,...) {
  if (is.null(this$CodaChains)) {
    return(NULL);
  }
  MyC = list();
  for (ii in 1:length(this$CodaChains)) {
    if (any(substr(colnames(this$CodaChains[[ii]]), 1, nchar("tau:")) == "tau:") ) {
      MyC[[ii]] = as.mcmc(this$CodaChains[[ii]][,substr(colnames(this$CodaChains[[ii]]), 1, nchar("tau:")) == "tau:"])
    }
  }
  AText = "try(MyC <- as.mcmc.list(MyC), silent=TRUE)";
  eval(parse(text=AText));
  return(MyC);
});
