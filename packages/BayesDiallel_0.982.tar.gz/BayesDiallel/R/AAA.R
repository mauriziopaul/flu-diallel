

SetRSIText <- function(AText) {
  paste("TryO = NULL; try( TryO <- bindingIsActive(\"", AText, "\", RSIMNAMESPACE), silent=TRUE);
    if (!is.null(TryO) && (TryO == TRUE || TryO == FALSE)) {
      unlockBinding( \"", AText, "\", RSIMNAMESPACE ) 
    }
    assign( \"", AText, "\", ", AText, ", RSIMNAMESPACE);
    ", sep="");
}

SetGText <- function(AText, envir = "globalenv()", S=0) {
  if (S==0) {
  return(paste("TryO = NULL; try( TryO <- bindingIsActive(\"", AText, "\", ", envir, " ), silent=TRUE);
    if (!is.null(TryO) && (TryO == TRUE || TryO == FALSE)) {
      unlockBinding( \"", AText, "\", ", envir, " ); 
    }
    try(unlockBinding( \"", AText, "\", ", envir, " ), silent=FALSE); 
    assign( \"", AText, "\", ", AText, ", ", envir, " );
    ", sep=""));
  } else {
   return(paste("TryO = NULL; try( TryO <- bindingIsActive(\"", AText, "\", ", envir, " ), silent=TRUE);
    if (!is.null(TryO) && (TryO == TRUE || TryO == FALSE)) {
      unlockBinding( \"", AText, "\", ", envir, " ); 
    }
    try(unlockBinding( \"", AText, "\", ", envir, " ), silent=TRUE); 
    assign( \"", AText, "\", ", AText, ", ", envir, " );
    ", sep="")); 
  }
}


SetRSIText <- function(AText) {
  paste("TryO = NULL; try( TryO <- bindingIsActive(\"", AText, "\", RSIMNAMESPACE ), silent=TRUE);
    if (!is.null(TryO) && (TryO == TRUE || TryO == FALSE)) {
      unlockBinding( \"", AText, "\", RSIMNAMESPACE ) 
    }
    assign( \"", AText, "\", ", AText, ", RSIMNAMESPACE) ;
    lockBinding( \"", AText, "\", RSIMNAMESPACE );
    ", sep="");
}

LockRSIText <- function(AText) {
  paste("TryO = NULL; try( TryO <- bindingIsActive(\"", AText, "\", RSIMNAMESPACE), silent=TRUE);
    if (!is.null(TryO) && (TryO == TRUE || TryO == FALSE)) {
      unlockBinding( \"", AText, "\", RSIMNAMESPACE ) 
    }
    try(unlockBinding( \"", AText, "\", RSIMNAMESPACE ), silent=TRUE); 
    assign( \"", AText, "\", ", AText, ", RSIMNAMESPACE);
    lockBinding( \"", AText, "\", RSIMNAMESPACE);
    ", sep="");
}


LockGText <- function(AText, envir="globalenv()", S=1)  {
  if (S==0) {
    return(paste("TryO = NULL; try( TryO <- bindingIsActive(\"", AText, "\", ", envir, "), silent=FALSE);
    if (!is.null(TryO) && (TryO == TRUE || TryO == FALSE)) {
      unlockBinding( \"", AText, "\", ", envir, "  ) 
    }
    try(unlockBinding( \"", AText, "\", ", envir, "  ), silent=FALSE); 
    assign( \"", AText, "\", ", AText, ", ", envir, " );
    lockBinding( \"", AText, "\", ", envir, " );
    ", sep=""));
  } else {
    return(paste("TryO = NULL; try( TryO <- bindingIsActive(\"", AText, "\", ", envir, "), silent=TRUE);
    if (!is.null(TryO) && (TryO == TRUE || TryO == FALSE)) {
      unlockBinding( \"", AText, "\", ", envir, "  ) 
    }
    try(unlockBinding( \"", AText, "\", ", envir, "  ), silent=TRUE); 
    assign( \"", AText, "\", ", AText, ", ", envir, " );
    lockBinding( \"", AText, "\", ", envir, " );
    ", sep=""));   
  }
}

GetRSIText <- function(AText) {
  paste("TryO = NULL; try( TryO <- bindingIsActive(\"", AText, "\", RSIMNAMESPACE), silent=TRUE);
    if (!is.null(TryO) && (TryO == TRUE || TryO == FALSE)) {
      unlockBinding( \"", AText, "\", RSIMNAMESPACE ) 
    }
    ", AText, " <- get(\"", AText, "\", RSIMNAMESPACE);
    ", sep="");
}
GetGText <- function(AText, envir = "globalenv()",S=0) {
  
  paste("TryO = NULL; try( TryO <- bindingIsActive(\"", AText, "\", ", envir, " ), silent=TRUE);
    if (!is.null(TryO) && (TryO == TRUE || TryO == FALSE)) {
      unlockBinding( \"", AText, "\", ", envir, " ) 
    }
    try(unlockBinding( \"", AText, "\", ", envir, " ), silent=FALSE); 
    ", AText, " <- get(\"", AText, "\", ", envir, " );
    ", sep="");
}

GetG0Text <- function(AText, envir = "globalenv()", S=0) {
  if (S== 0) {
    return(paste("TryO = NULL; try( TryO <- bindingIsActive(\"", AText, "\",  ", envir, " ), silent=TRUE);
    if (!is.null(TryO) && (TryO == TRUE || TryO == FALSE)) {
      try(unlockBinding( \"", AText, "\", ", envir, " ), silent=FALSE);
    }
    try(unlockBinding( \"", AText, "\", ", envir, " ), silent=FALSE); 
    if (exists(\"", AText, "\", ", envir, " )) {
    ", AText, " <- get(\"", AText, "\", ", envir, " );
    } else {
      ", AText, " = 0;
    }
    ", sep=""));
  } else {
    return(paste("TryO = NULL; try( TryO <- bindingIsActive(\"", AText, "\",  ", envir, " ), silent=TRUE);
    if (!is.null(TryO) && (TryO == TRUE || TryO == FALSE)) {
      try(unlockBinding( \"", AText, "\", ", envir, " ), silent=TRUE);
    }
    try(unlockBinding( \"", AText, "\", ", envir, " ), silent=TRUE); 
    if (exists(\"", AText, "\", ", envir, " )) {
    ", AText, " <- get(\"", AText, "\", ", envir, " );
    } else {
      ", AText, " = 0;
    }
    ", sep=""));   
  }
}

g=1;
eval(parse(text=SetGText("g", S=1)));