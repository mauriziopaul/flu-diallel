
 setMethodS3("GetGoAll", "DiallelOb", function(this, GoTau= NULL, GoBeta = NULL,...) {
    if (is.null(GoTau)) {
      GoTau = (1:length(this$tau))  + length(this$Beta);
      if (length(GoTau) >7) {
        GoTau = GoTau[1:7];
      }
    }
    if (is.null(GoBeta)) {
      GoBetaFirst = this$CollapsedXSubSetList[this$NeedF];
      if (length(GoBetaFirst) > length(GoTau)) {
        GoBetaFirst = GoBetaFirst[1:length(GoTau)]
      };
      NotNeedF = !( (1:length(this$CollapsedXSubSetList)) %in% this$NeedF);
      GoBetaSecond =this$CollapsedXSubSetList[NotNeedF];
      if (length(GoBetaSecond) +
          length(GoBetaFirst) > 2* length(GoTau)) {
        GoBetaSecond = GoBetaSecond[1:(2 * length(GoTau) - length(GoBetaFirst))]
      }
    }
    return(c(GoTau, GoBetaFirst, GoBetaSecond))
 
 });
 
 setMethodS3("HistNewItersSample", "DiallelOb", function(this, Start = 1, End = 0,
  GoAll = NULL, GoTau = NULL, GoBeta = NULL,...) {
  if (End <= 0 || End >= length(this$CodaChains[,1])) {
    End = length(this$CodaChains[[1]][,1]);
  }
  if (is.null(GoAll)) {
    GoAll = GetGoAll(this, GoTau, GoBeta)
  }
  par(mfrow=c(3, ceiling(length(GoAll)/3)))
  tt = Start:End;
  LCoda = length(this$CodaChains);
  MST = rep(tt, LCoda)
  ColChains=c("black", "brown", "purple", "grey","green")
  for (ii in 1:length(GoAll)) {
    if (GoAll[ii] > length(this$Beta)) {
      if (GoAll[ii] > length(this$CodaChains[[1]][1,])) {
        throw("Sorry, you did not supply a satifactory sequence")
      }
      MSP = this$CodaChains[[1]][,GoAll[ii]]
      if (LCoda > 1) {
        for (jj in 2:length(this$CodaChains)) {
	  MSP = c(MSP, this$CodaChains[[jj]][Start:End,GoAll[ii]])
	}
      }
      hist(MSP, main=names(this$tau)[GoAll[ii]-length(this$Beta)],
        xlab="tau", ylab="Probability", freq=FALSE);
      ##for (jj in 1:length(this$CodaChains)) {
      ##  lines(tt~this$CodaChains[[jj]][,GoAll[ii]], col=ColChains[jj], lwd=2);
      ##}
      MeanChain = mean(MSP, na.rm=TRUE);
      tN = c(0, 10^9);
      lines(y=tN, x=c(MeanChain, MeanChain),
        lwd =2, col="red", lty = 2);
      Median = median(MSP, na.rm=TRUE);
      lines(y=tN, x=c(Median, Median),
        lwd =2, col="blue", lty = 3);
      qtile = quantile(MSP, .025, na.rm=TRUE);
      lines(y=tN, x=c(qtile, qtile),
        lwd =1, col="orange", lty = 5);
      qtile = quantile(MSP, .975, na.rm=TRUE);
      lines(y=tN, x=c(qtile, qtile),
        lwd =1, col="orange", lty = 5);		
    } else {
      MSP = this$CodaChains[[1]][,GoAll[ii]];
      if (LCoda > 1) {
        for (jj in 2:length(this$CodaChains)) {
	  MSP = c(MSP, this$CodaChains[[jj]][Start:End,GoAll[ii]])
	}
      }
      hist(MSP, main=names(this$XSubSetList)[GoAll[ii]],
        xlab="Beta", ylab="Frequency", freq=FALSE);
      ##for (jj in 1:length(this$CodaChains)) {
      ##  lines(tt~this$CodaChains[[jj]][,GoAll[ii]], col=ColChains[jj], lwd=2);
      ##}
      MeanChain = mean(MSP, na.rm=TRUE);
      tN = c(0, 10^9);
      lines(y=tN, x=c(MeanChain, MeanChain),
        lwd =2, col="red", lty = 2);
      Median = median(MSP, na.rm=TRUE);
      lines(y=tN, x=c(Median, Median),
        lwd =2, col="blue", lty = 3);
      qtile = quantile(MSP, .025, na.rm=TRUE);
      lines(y=tN, x=c(qtile, qtile),
        lwd =1, col="orange", lty = 5);
      qtile = quantile(MSP, .975, na.rm=TRUE);
      lines(y=tN, x=c(qtile, qtile),
        lwd =1, col="orange", lty = 5);		
    
    }
  }
});

 setMethodS3("PrintNewItersSamples", "DiallelOb", function(this, Start = 1, End = 0,
  GoAll = NULL, GoTau = NULL, GoBeta = NULL, PrintMeans = NULL, ...) {
  if (End <= 0 || End >= length(this$CodaChains[,1])) {
    End = length(this$CodaChains[[1]][,1]);
  }
  if (is.null(GoAll)) {
    GoAll = GetGoAll(this, GoTau, GoBeta)
  }
  par(mfrow=c(3, ceiling(length(GoAll)/3)))
  tt = Start:End;
  LCoda = length(this$CodaChains);
  MST = rep(tt, LCoda)
  ColChains=c("black", "brown", "purple", "grey","green")
  for (ii in 1:length(GoAll)) {
    if (GoAll[ii] > length(this$Beta)) {
      if (GoAll[ii] > length(this$CodaChains[[1]][1,])) {
        throw("Sorry, you did not supply a satifactory sequence")
      }
      MSP = this$CodaChains[[1]][,GoAll[ii]]
      if (LCoda > 1) {
        for (jj in 2:length(this$CodaChains)) {
	  MSP = c(MSP, this$CodaChains[[jj]][Start:End,GoAll[ii]])
	}
      }
      plot(MST~MSP, type="n", main=names(this$tau)[GoAll[ii]-length(this$Beta)],
        xlab="tau", ylab="sample");
      for (jj in 1:length(this$CodaChains)) {
        lines(tt~this$CodaChains[[jj]][,GoAll[ii]], col=ColChains[jj], lwd=2);
      }
      MeanChain = mean(MSP);
      lines(y=c(tt[1], tt[length(tt)]), x=c(MeanChain, MeanChain),
        lwd =2, col="red", lty = 2);
      Median = median(MSP);
      if (!is.null(PrintMeans) && length(PrintMeans) >= GoAllii) {
        lines(y=c(tt[1], tt[length(tt)]), x=c(PrintMeans[ii], PrintMeans[ii]),
	col="green", lwd=3);
      }
      lines(y=c(tt[1], tt[length(tt)]), x=c(Median, Median),
        lwd =2, col="blue", lty = 3);
      qtile = quantile(MSP, .025);
      lines(y=c(tt[1], tt[length(tt)]), x=c(qtile, qtile),
        lwd =1, col="orange", lty = 5);
      qtile = quantile(MSP, .975);
      lines(y=c(tt[1], tt[length(tt)]), x=c(qtile, qtile),
        lwd =1, col="orange", lty = 5);		
    } else {
      MSP = this$CodaChains[[1]][,GoAll[ii]]
      if (LCoda > 1) {
        for (jj in 2:length(this$CodaChains)) {
	  MSP = c(MSP, this$CodaChains[[jj]][Start:End,GoAll[ii]])
	}
      }
      plot(MSP~MST, type="n", main=names(this$XSubSetList)[GoAll[ii]],
        xlab="sample", ylab="Beta");
      for (jj in 1:length(this$CodaChains)) {
        lines(this$CodaChains[[jj]][,GoAll[ii]]~tt, col=ColChains[jj], lwd=2);
      }
      MeanChain = mean(MSP);
      lines(x=c(tt[1], tt[length(tt)]), y=c(MeanChain, MeanChain),
        lwd =2, col="red", lty = 2);
      if (!is.null(PrintMeans) && length(PrintMeans) >= GoAllii) {
        lines(x=c(tt[1], tt[length(tt)]), y=c(PrintMeans[ii], PrintMeans[ii]),
	col="green", lwd=3);
      }	
      Median = median(MSP);
      lines(x=c(tt[1], tt[length(tt)]), y=c(Median, Median),
        lwd =2, col="blue", lty = 3);
      qtile = quantile(MSP, .025);
      lines(x=c(tt[1], tt[length(tt)]), y=c(qtile, qtile),
        lwd =1, col="orange", lty = 5);
      qtile = quantile(MSP, .975);
      lines(x=c(tt[1], tt[length(tt)]), y=c(qtile, qtile),
        lwd =1, col="orange", lty = 5);	   
    
    }
  }
});

