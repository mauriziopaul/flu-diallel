## CombineDiallels.R
CombineDiallels <- function(AFDIn=NULL,...) {
 ALDL <- NULL;
 if (is.list(AFDIn)) {
   ADO <- NULL;
   try(ADO <- AFDIn[[1]]$AllDiallelObs);
   if (!is.null(ADO)) {
     ALDL <- AFDIn;
   }
 } 
 if (is.null(ALDL)) {
   ALDL <- FeedMeListDiallels(AFDIn, ...);
 }
 if (is.null(ALDL) || length(ALDL) <= 1) {
   print("CombineDiallels: Sorry we only operate with Multiple Copies");
 }
 FullCopy <- Copy(ALDL[[1]]);
 try(FullCopy$.AllFixedVariables <- ALDL[[1]]$.AllFixedVariables)
 try(FullCopy$.AllRandomVariables <- ALDL[[1]]$.AllRandomVariables)
 FullCopy$strain.map = ALDL[[1]]$strain.map;
 try(FullCopy$DoFirstCenter <- ALDL[[1]]$DoFirstCenter);
 for (ii in 1:length(FullCopy$AllDiallelObs)) {
   FullCopy$AllDiallelObs[[ii]]$.AFD <- FullCopy;
   try(FullCopy$AllDiallelObs[[ii]]$DoFirstCenter <- ALDL[[1]]$AllDiallelObs[[ii]]$DoFirstCenter)
 }
 if (is.null(ALDL[[1]])) {
   try(FullCopy$Verbose <- 0);  try(FullCopy$verbose <- 0);
 }
 YM <- FullCopy$Y * 0;
 SM <- FullCopy$Y * 0;
 for (jj in 1:length(ALDL)) {
    AMT = .Call("DoMeAMatrixMatch", FullCopy$X, ALDL[[jj]]$X)
    if (any(AMT >= 1)) {
      YM[AMT >= 1] <- YM[AMT >= 1] + ALDL[[jj]]$Y[AMT[AMT>=1]]
      SM[AMT >= 1] <- SM[AMT >= 1] + 1;
    }
 }
 try(YMean <- YM / SM);
 try(FullCopy$Y <- YMean);
 for (ii in 1:length(FullCopy$AllDiallelObs)) {
    NewCodaLabels <- colnames(FullCopy$AllDiallelObs[[ii]]$CodaChains[[1]])
    try(FullCopy$AllDiallelObs[[ii]]$.centered.chains <- NULL);
    try(FullCopy$AllDiallelObs[[ii]]$.raw.chains <- NULL);  
    ATL <- 0;
    NewCodaChains <- list();   
    for (tt in 1:length(ALDL)) {
      for (bj in 1:length(ALDL[[tt]]$AllDiallelObs[[ii]]$CodaChains)) {
        if (NCOL(ALDL[[tt]]$AllDiallelObs[[ii]]$CodaChains[[bj]]) ==
          NCOL(FullCopy$AllDiallelObs[[ii]]$CodaChains[[1]])) {
          try(AP <-ALDL[[tt]]$AllDiallelObs[[ii]]$CodaChains[[bj]]);
          try(colnames(AP) <- NewCodaLabels); 
          try(NewCodaChains[[ATL+1]]  <- as.mcmc(AP));
          ATL <- ATL+1;
        }
      }
    } 
    try(NewCodaChains <- as.mcmc.list(NewCodaChains));
    try(FullCopy$AllDiallelObs[[ii]]$CodaChains <- NewCodaChains); 
 }
 if (!is.null(ALDL[[1]]$BSAFD)) {
   try(FullCopy$.BS <- ALDL[[1]]$BSAFD$copy);
   if (is.null(FullCopy$.BS)) {
     print("Oops, ALDL original copy does not work, just move!"); flush.console();
     try(FullCopy$.BS <- ALDL[[1]]$BSAFD);
   }
   NewCodaLabels <- ALDL[[1]]$OtherCodaNames
   NewCodaList <- list();  
   ATL <- 0; 
   NeedRecord <- 0;
   try(NeedRecord <- FullCopy$.BS$NeedRecord);
   if (is.null(ALDL[[1]]$Verbose) || (is.logical(ALDL[[1]]$Verbose) &&
      ALDL[[1]]$Verbose  == TRUE) || (is.numeric(ALDL[[1]]$Verbose) &&
      ALDL[[1]]$Verbose[1] >= -4)) {
      if (is.null(ALDL[[1]]$Verbose) || (is.logical(ALDL[[1]]$Verbose) &&
      ALDL[[1]]$Verbose == TRUE)) {
       ALDL[[1]]$Verbose <= 2;     
      }
      print(paste("AFDCombine: BSAFD starts with NeedRecord in first object = ",
         NeedRecord, sep=""));  flush.console();
  }
   
   TotalRun <- NULL;  TotalCount <- NULL;
   if (!is.null(ALDL[[1]]$BSAFD$RunProbVector)) {
     TotalRun <- ALDL[[1]]$BSAFD$RunProbVector* 0;
     TotalCount <- ALDL[[1]]$BSAFD$TotEveryProbVector * 0;
   }
   ColLens <- c();
   AO <- 0;
   for (tt in 1:length(ALDL)) {
     if (length(ALDL[[tt]]$BSAFD$CodaList) >= 1) {
       for (jj in 1:length(ALDL[[tt]]$BSAFD$CodaList)) {
         if (AO == 0) { 
           ColLens <- NCOL(ALDL[[tt]]$BSAFD$CodaList[[jj]])
         } else {
           ColLens <- c(ColLens, NCOL(ALDL[[tt]]$BSAFD$CodaList[[jj]]));         
         }
         AO <- AO+1;
       }
     }
   }
   try(eval(parse(text=SetGText("ColLens", "globalenv()", S=1))));
   if (length(ColLens) <= 0) {
     print("CombineDiallel: Uh Oh, no BSAFDCodaLists!"); flush.console();
   } else if (!all(ColLens == NeedRecord)) {
     print("CombineDiallel: Uh Oh, we have colLengths that won't fit!");
       flush.console();
     print(paste("  NeedRecord, what we want is ", NeedRecord, sep=""));
       flush.console();
     print(paste("  However, the ColLens are (",
       paste(ColLens, collapse=", "), ")", sep="")); flush.console();
   }
   for (tt in 1:length(ALDL)) {
      if (!is.null(TotalRun) && !is.null(ALDL[[tt]]$BSAFD$RunProbVector)) {
        TotalRun <- TotalRun + ALDL[[tt]]$BSAFD$RunProbVector;
        TotalCount <- TotalCount + ALDL[[tt]]$BSAFD$TotEveryProbVector;
      }
      if (!is.null(ALDL[[tt]]$BSAFD)  &&
        !is.null(ALDL[[tt]]$BSAFD$CodaList)) {
      ARNeedRecord <- 0;
      try(ARNeedRecord <- ALDL[[tt]]$BSAFD$NeedRecord);
      if (ARNeedRecord == NeedRecord && NeedRecord > 0  && ARNeedRecord > 0) {
        for (bj in 1:length(ALDL[[tt]]$BSAFD$CodaList)) {
          ATBJ <- NCOL(ALDL[[tt]]$BSAFD$CodaList[[bj]]);
          if (ATBJ ==
            NeedRecord) {
            try(AP <- matrix(as.numeric(ALDL[[tt]]$BSAFD$CodaList[[bj]]), 
              NROW(ALDL[[tt]]$BSAFD$CodaList[[bj]]),
              NeedRecord));
            try(colnames(AP) <- NewCodaLabels); 
            try(NewCodaList[[ATL+1]]  <- as.mcmc(AP));
            ATL <- ATL+1;
          } else {
            print(paste("Note BSAFD Combine coda lists  ALDL",
              "[[tt=", tt, "]]BSAFD$CodaList[[bj=", bj, "]] has columns ",
               ATBJ, " but we need ", NeedRecord, " columns !  We are skipping this one!", sep="")); flush.console();
          }
        }
      } else {
        print(paste("Note, ALDL[[tt=", tt, "]] actually has its own Need Record = ", 
          ARNeedRecord, " which is not ", NeedRecord, ".", sep="")); flush.console();
      }
    }
   } 
   if (!is.null(TotalRun)) {
     try(FullCopy$BSAFD$FillRunProbVector(TotalRun, as.integer(TotalCount)));
   }
   if (length(NewCodaList) >= 1) { 
     try(ColNumEachChain <- rep(0, length(NewCodaList)));
     for (iti in 1:length(NewCodaChains)) {
       try(ColNumEachChain[iti] <-  NCOL(NewCodaList[[iti]]));
     }
     if (!all(ColNumEachChain == NeedRecord)) {
       print(paste("Load BSAFD, Error, we have NeedRecord = ", NeedRecord, sep=""));
       flush.console();
       print(paste("However Columns in each chain are (", paste(ColNumEachChain, collapse=", "),
         ")", sep="")); flush.console();
     }
   }

   
    try(NewCodaList <- as.mcmc.list(NewCodaList));
    if (FullCopy$BSAFD$Verbose >= -4) {
      print(paste("AFDCombine: Trying to insert NewCodaList length=",
        length(NewCodaList), " with columns=", NeedRecord, sep=""));
      flush.console();
    }
    try(FullCopy$BSAFD$CodaList <- NewCodaList); 
    if (FullCopy$BSAFD$Verbose >= -4) {
      print(paste("AFDCombine: PreInsert NULL in for MIP to force recalculation"));
      flush.console();
    }
    try(FullCopy$BSAFD$MIP <- NULL);
    if (FullCopy$BSAFD$Verbose >= -4) {
      print(paste("AFDCombine: Attempting to recalculate MIP from available data.")); 
      flush.console();
    }
    MIP <- NULL;
    try(MIP <- FullCopy$BSAFD$MIP);
    if (FullCopy$BSAFD$Verbose >= -4 && !is.null(MIP)) {
      print(paste("AFDCombine: Good news, MIP was recalculated to NON NULL vector (",
        paste(MIP, collapse=", "), ")", sep="")); flush.console();
    } else if (is.null(MIP)) {
      print(paste("AFDCombine: NeedRecord = ", NeedRecord, ", we have error in regenerating MIP. ", sep=""));
      flush.console();
    }
 }
 return(FullCopy);
}
if (FALSE) {
ABS1 <- list(AllDiallelObs= list(cent.chains = 1, BS = 2), ST = 1);
ABS2 <- list(AllDiallelObs= list(cent.chains = 2, BS = 3), ST = 1);
ABS3 <- list(AllDiallelObs= list(cent.chains = 3, BS = 4), ST = 1);
ABS4 <- list(AllDiallelObs= list(cent.chains = 4, BS = 5), ST = 1);
ALD <- FeedMeListDiallels(ABS1, ABS2, ABS3, ABS4);
}
FeedMeListDiallels <- function(ATO = NULL, ...) {
  if (is.null(ATO) || is.null(ATO$AllDiallelObs) ||
    is.null(ATO$AllDiallelObs[[1]]$cent.chains)) {
    return(NULL);
  }
  MyL <- list();
  ABL <- FeedMeListDiallels(...);
  if (is.null(ABL)) {
    MyL[[1]] <- ATO;  return(MyL);
  } else {
    MyL[[1]] <- ATO;
    for (ii in 1:length(ABL)) {
      MyL[[1+ii]] <- ABL[[ii]]
    }
    return(MyL);
  }
}
