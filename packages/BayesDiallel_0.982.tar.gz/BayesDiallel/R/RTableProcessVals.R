
## Lister = c("L2", "L1", "L0", "Type1", "Type2", "OutQuant",
##  "CIWidth", "time", "DIC", "PID", "BarD", "DofMeanFlag");
##setMethodS3("ReportErrorL2", "OutSimAnalyses", function(this, MeanOrMedian)

L2OfFunction <- function(VecOrMat) {

}
setMethodS3("PlotMIPTau", "ASim", function(this,...) {
   PlotMIP(this$MyOA);
});

EatFingColons <- function(StV) {
  NStV = rep("", length(StV));
  for (ii in 1:length(StV)) {
    NStV[ii] = paste(unlist(strsplit(StV[ii], ":")), collapse="");
  }
  return(NStV)
}
srainbow=function(...){sample(rainbow(...), replace=FALSE)}

setMethodS3("PlotTauV", "OutSimAnalyses", function(this, subfraction=1,DoLog = FALSE,
  TauVOrdered = NULL, mainadd="", AddFixedToo = FALSE, GoSqrt = FALSE, DoAbs = FALSE,
  RealVec = NULL, AxisTitle = TRUE, ...) {
   if (is.null(this$MeanVals$ReadTable)) {
     print("Error: Please Have ReadTable"); flush.console();
   }
   ITT = (1:length(this$MeanVals$ReadTable[,1]));
   if (length(subfraction)> 1) {
     ITT = ITT[ITT %in% subfraction];
   } else if (subfraction > 0 && subfraction < 1.0) {
     ITT = sort(sample(ITT, size = round(length(ITT) * subfraction),
      replace=FALSE));
   }
   FN = GetFixedNames(colnames(this$MeanVals$ReadTable));
   RN = GetRandomNames(colnames(this$MeanVals$ReadTable));
   if (!is.null(TauVOrdered) && any(EatFingColons(TauVOrdered) %in% EatFingColons(FN))) {
     AddFixedToo = TRUE;
   }
   if (AddFixedToo == FALSE) {
     idc = colnames(this$MeanVals$ReadTable);
     idt = (1:length(idc))[substr(idc,1,3) == "tau"];
     TDD = this$MeanVals$ReadTable[,idt];
     if (GoSqrt == TRUE) {
       TDD = sqrt(abs(TDD));
     }
   } else {
     idc = colnames(this$MeanVals$ReadTable);
     idt = (1:length(idc))[substr(idc,1,3) == "tau" | idc %in% FN]
     TDD = this$MeanVals$ReadTable[,idt];
     CNTDD = colnames(TDD);
     TDD = as.matrix(TDD); colnames(TDD) = CNTDD;
     Keycols = (1:length(colnames(TDD)))[substr(colnames(TDD),1,3) == "tau"]
     TDD[, Keycols] =
       sqrt(abs(TDD[, Keycols] ))
     if (DoAbs == TRUE) {TDD = abs(TDD);}
     if (!is.null(RealVec)) {
       cnRealVec = names(RealVec);
       cnRealVec[substr(cnRealVec,1,3) == "tau"] =
         substr(cnRealVec[substr(cnRealVec,1,3) == "tau"],4,
           nchar(cnRealVec[substr(cnRealVec,1,3) == "tau"]));
       cnRealVec = EatFingColons(cnRealVec);
       RealVec[cnRealVec %in% EatFingColons(RN)] = sqrt(abs(RealVec[cnRealVec %in% EatFingColons(RN)]))
       if (DoAbs == TRUE) {RealVec = abs(RealVec);}
     }
   }
   MM = colMeans(TDD);
   MNames = names(MM);
   MNames[substr(MNames,1,nchar("tau:")) == "tau:"] =
     substr(MNames[substr(MNames,1,nchar("tau:")) == "tau:"],
       5, nchar(MNames[substr(MNames,1,nchar("tau:")) == "tau:"]) );
   MX = max(this$MeanVals$ReadTable[,idt]);
   MN = min(this$MeanVals$ReadTable[,idt]);
   TT = length(MM);
   TDD = TDD[,sort(MM, index=TRUE, decreasing=TRUE)$ix]
   MNames = MNames[sort(MM, index=TRUE,decreasing=TRUE)$ix];
   MM = colMeans(TDD);
   if (!is.null(TauVOrdered)) {
      ATauVOrdered = TauVOrdered
      ATauVOrdered[substr(ATauVOrdered,1,nchar("tau:"))=="tau:"] =
         substr(ATauVOrdered[substr(ATauVOrdered,1,nchar("tau:")) == "tau:"],
           nchar("tau:")+1, nchar(ATauVOrdered[substr(ATauVOrdered,1,nchar("tau:")) == "tau:"]));
         idAT = ATauVOrdered;
         idAT = EatFingColons(idAT); idc = EatFingColons(MNames);
         MyMatch = match( idAT, idc);
         ATauVOrdered = ATauVOrdered[!is.na(MyMatch)];
         MNames = MNames[MyMatch[!is.na(MyMatch)]];
         TDD = TDD[,MyMatch[!is.na(MyMatch)]];
      if (!is.null(RealVec)) {
        RealVec = RealVec[!is.na(MyMatch)];
      }
   } else {
     MM - colMeans(TDD);
     stMM = sort(abs(MM), index=TRUE, decreasing = TRUE)$ix
     TDD = TDD[,stMM ]
     MNames = MNames[stMM ];
     MM = colMeans(TDD);   
   }
   MM = colMeans(TDD)
   mainer = "Mean Tau Estimated"
   if (mainadd != "") {
     mainer = paste(mainer, " - ", mainadd, sep="")
   }
   TT = length(TDD[1,])
   if (DoLog == FALSE) {
    LM = min(TDD); if (min(TDD) > 0) { LM = 0;}
    MX = max(TDD)
   plot(y=c(LM,MX), x=c(.5,TT+.5), type="n", main=mainer,
     axes=FALSE, xlab="Tau Parameter", ylab="Estimated Tau Mean");
   Cols = srainbow(length(TDD[ITT,1]));
     for (ii in  ITT) {
       lines(x=(1:TT), y = (TDD[ii,]),
         lwd = 2, col=Cols[ii]);
     }
   maxer = max(TDD[ITT,]);
     MySeq = c(10000,5000,2000,1000,500,200,100,50,20,10,5,2,1,.5,.2,.1,.05,.02,.01,.005,.002,.001);
   iti = 1;
   UseFrac = .01;  MultiPlies = 5;
   while( iti < length(MySeq)  && maxer / MySeq[iti] < 4){
     if (maxer / MySeq[iti] >= 4) {
        break;
     } else {
        iti = iti +1;
     }
   }
   UseFrac = MySeq[iti]; MultiPlies = ceiling(maxer / MySeq[iti]);
   if (min(TDD) < 0) {
     MinF = -floor(abs(min(TDD)) / UseFrac);
   } else {MinF = 0;}
   axis(2, UseFrac * ((MinF:MultiPlies)), las=1);
   if (AxisTitle == TRUE) {
     AxisTitleMap(MNames);
   } else {
     axis(1, 1:TT, labels = MNames, las=1);
   }
   lines(x=(1:TT), y=MM, col="green", lwd=3, lty=2);
   if (!is.null(RealVec)) {
     lines(x=(1:TT), y = RealVec, col="black", lwd=3, lty=1)
   }
   
   } else {
     TDD = abs(TDD);  MX = max(TDD);  MN = min(TDD);
     MM = colMeans(TDD);
     if (MN == 0) { TN = TDD;
       LMN = min(TN[TN > 0]); } else { LMN = MN; }
     plot(y = c(floor(log(LMN,10)), ceiling(log(MX,10))), x=c(.5,TT+.5), type="n", main=mainer,
       axes=FALSE, xlab="Tau Parameter", ylab="Estimated Tau Mean");
     Cols = srainbow(length(TDD[ITT,1]));
     for (ii in ITT) {
       lines(x=(1:TT), y = log(TDD[ii,],10),
         lwd = 2, col=Cols[ii]);
     }
     AAStops =  round( log(LMN,10) + (0:4)/5 * (log(MX,10) - log(LMN,10)),0);
     AAStops = c(AAStops, ceiling(log(MX,10)));
     axis(2, AAStops , labels = 
       10^(AAStops), las=1);
   if (AxisTitle == TRUE) {
     AxisTitleMap(MNames);
   } else {
     axis(1, 1:TT, labels = MNames, las=1);
   }
   lines(x=(1:TT), y=log(MM,10), col="green", lwd=3, lty = 2);
     if (!is.null(RealVec)) {
       RealVec = abs(RealVec);
       lines(x=(1:TT), y = log(RealVec,10), col="black", lwd=3, lty=1)
     }  
   }
});


setMethodS3("PlotSDV", "OutSimAnalyses", function(this, subfraction=1,DoLog = FALSE,
  TauVOrdered = NULL, mainadd="", AddFixedToo = FALSE, GoSqrt = FALSE, DoAbs = FALSE,
  RealVec = NULL, DoMedian = FALSE, AxisTitle = TRUE, ...) {
  if (DoMedian == TRUE) {
    UseTable = this$MedianVals$ReadTable;
  } else {
    UseTable = this$MeanVals$ReadTable;
  }
   if (is.null(UseTable)) {
     print("Error: Please Have ReadTable"); flush.console();
   }
   ITT = (1:length(UseTable[,1]));
   if (length(subfraction)> 1) {
     ITT = ITT[ITT %in% subfraction];
   } else if (subfraction > 0 && subfraction < 1.0) {
     ITT = sort(sample(ITT, size = round(length(ITT) * subfraction),
      replace=FALSE));
   }
   FN = GetFixedNames(colnames(UseTable));
   RN = GetRandomNames(colnames(UseTable));
   MatchFN = match( FN, colnames(UseTable));
     idFN = (1:length(FN))[ !is.na(MatchFN)];
     
   ATDFD = UseTable[, MatchFN[!is.na(MatchFN)] ];
   colnames(ATDFD) = FN[idFN];
   
   nLen = length(UseTable[,1]);

   ATDRD = NULL; ATDRDCN = NULL;
    for (jj in 1:length(RN)) {
       RG = UseTable[, substr(colnames(UseTable),1, nchar(RN[jj])) == RN[jj] ];
       if (is.null(RG) || length(RG) == 0) {
       
       } else {
       ATT =  sd(t(RG));
       if (length(ATT) != nLen) {
         print("PlotSDV: we could not get ATT the right shape"); flush.console();
       }
       if (is.null(ATDRD)) {
         ATDRD = as.matrix(ATT, nLen, 1)
       } else if (length(ATDRD) == nLen) {
         ATDRD = cbind(as.vector(ATDRD), as.vector(ATT));
       } else {
         ATDRD = cbind(ATDRD, ATT);
       }
       ATDRDCN = c(ATDRDCN, RN[jj]);
       if (!is.null(dim(ATDRD)) && length(dim(ATDRD)) == 2) {
         colnames(ATDRD) = ATDRDCN;
       }
       }
    }
    TDD = cbind(ATDFD, ATDRD);
    colnames(TDD) = c(colnames(ATDFD), ATDRDCN);
   if (!is.null(TauVOrdered) && any(EatFingColons(TauVOrdered) %in% EatFingColons(FN))) {
     AddFixedToo = TRUE;
   }
   if (AddFixedToo == FALSE) {
     TDD = TDD[, colnames(TDD) %in% RN];
   } else {
     if (DoAbs == TRUE) {TDD = abs(TDD);}
     if (!is.null(RealVec) && GoSqrt == TRUE) {
       cnRealVec = names(RealVec);
       cnRealVec[substr(cnRealVec,1,3) == "tau"] =
         substr(cnRealVec[substr(cnRealVec,1,3) == "tau"],4,
           nchar(cnRealVec[substr(cnRealVec,1,3) == "tau"]));
       cnRealVec = EatFingColons(cnRealVec);
       RealVec[cnRealVec %in% EatFingColons(RN)] = sqrt(abs(RealVec[cnRealVec %in% EatFingColons(RN)]))
       if (DoAbs == TRUE) {RealVec = abs(RealVec);}
     }
   }
   MM = colMeans(TDD);
   MNames = names(MM);
   MNames[substr(MNames,1,nchar("tau:")) == "tau:"] =
     substr(MNames[substr(MNames,1,nchar("tau:")) == "tau:"],
       5, nchar(MNames[substr(MNames,1,nchar("tau:")) == "tau:"]) );
   MX = max(TDD)
   MN = min(TDD);
   TT = length(MM);

   if (!is.null(TauVOrdered)) {
      ATauVOrdered = TauVOrdered
      ATauVOrdered[substr(ATauVOrdered,1,nchar("tau:"))=="tau:"] =
         substr(ATauVOrdered[substr(ATauVOrdered,1,nchar("tau:")) == "tau:"],
           nchar("tau:")+1, nchar(ATauVOrdered[substr(ATauVOrdered,1,nchar("tau:")) == "tau:"]));
         idAT = ATauVOrdered;
         idAT = EatFingColons(idAT); idc = EatFingColons(MNames);
         MyMatch = match( idAT, idc);
         ATauVOrdered = ATauVOrdered[!is.na(MyMatch)];
         MNames = MNames[MyMatch[!is.na(MyMatch)]];
         TDD = TDD[,MyMatch[!is.na(MyMatch)]];
      if (!is.null(RealVec)) {
        RealVec = RealVec[!is.na(MyMatch)];
      }
   } else {
     MM - colMeans(TDD);
     stMM = sort(abs(MM), index=TRUE, decreasing = TRUE)$ix
     TDD = TDD[,stMM ]
     MNames = MNames[stMM ];
     MM = colMeans(TDD);   
   }
   
   MM = colMeans(TDD)
   TT = length(MM)
   if (AddFixedToo == FALSE) {
     mainer = paste("Sd of estimated Random Effects Groups \n ", length(ITT), " simulations", sep=""); 
   } else {
     mainer = paste("Fixed Beta Estimates and Sd of estimated Random Effects Groups \n ", length(ITT), " simulations", sep="");
   }
   if (mainadd != "") {
     mainer = paste(mainer, " - ", mainadd, sep="")
   }
   TT = length(TDD[1,])
   if (DoLog == FALSE) {
    LM = min(TDD); if (min(TDD) > 0) { LM = 0;}
    MX = max(TDD)
   plot(y=c(LM,MX), x=c(.5,TT+.5), type="n", main=mainer,
     axes=FALSE, xlab="Parameter or Parameter Group", ylab="Estimated Mean");
   Cols = srainbow(length(TDD[ITT,1]));
     for (ii in  ITT) {
       lines(x=(1:TT), y = (TDD[ii,]),
         lwd = 2, col=Cols[ii]);
     }
   maxer = max(TDD[ITT,]);
     MySeq = c(10000,5000,2000,1000,500,200,100,50,20,10,5,2,1,.5,.2,.1,.05,.02,.01,.005,.002,.001);
   iti = 1;
   UseFrac = .01;  MultiPlies = 5;
   while( iti < length(MySeq)  && maxer / MySeq[iti] < 4){
     if (maxer / MySeq[iti] >= 4) {
        break;
     } else {
        iti = iti +1;
     }
   }
   UseFrac = MySeq[iti]; MultiPlies = ceiling(maxer / MySeq[iti]);
   if (min(TDD) < 0) {
     MinF = -floor(abs(min(TDD)) / UseFrac);
   } else {MinF = 0;}
   axis(2, UseFrac * ((MinF:MultiPlies)), las=1);
   if (AxisTitle == TRUE) {
     AxisTitleMap(MNames);
   } else {
     axis(1, 1:TT, labels = MNames, las=1 );
   }
   lines(x=(1:TT), y=MM, col="green", lwd=3, lty=2);
   if (!is.null(RealVec)) {
     lines(x=(1:TT), y = RealVec, col="black", lwd=3, lty=1)
   }
   
   } else {
     TDD = abs(TDD);  MX = max(TDD);  MN = min(TDD);
     MM = colMeans(TDD);
     if (MN == 0) { TN = TDD;
       LMN = min(TN[TN > 0]); } else { LMN = MN; }
     plot(y = c(floor(log(LMN,10)), ceiling(log(MX,10))), x=c(.5,TT+.5), type="n", main=mainer,
       axes=FALSE, xlab="Parameter or Parameter Group", ylab="Estimated Mean");
     Cols = srainbow(length(TDD[ITT,1]));
     for (ii in ITT) {
       lines(x=(1:TT), y = log(TDD[ii,],10),
         lwd = 2, col=Cols[ii]);
     }
     AAStops =  round( log(LMN,10) + (0:4)/5 * (log(MX,10) - log(LMN,10)),0);
     AAStops = c(AAStops, ceiling(log(MX,10)));
     axis(2, AAStops , labels = 
       10^(AAStops) , las=1);
   if (AxisTitle == TRUE) {
     AxisTitleMap(MNames);
   } else {
     axis(1, 1:TT, labels = MNames , las=1);
   };
   lines(x=(1:TT), y=log(MM,10), col="green", lwd=3, lty = 2);
     if (!is.null(RealVec)) {
       RealVec = abs(RealVec);
       lines(x=(1:TT), y = log(RealVec,10), col="black", lwd=3, lty=1)
     }  
   }
});

GetAllFixedFromV <- function(ASource) {
 .defaultFixed = c("Mu", "Gender:Av", "BetaHybrid:Av", "BetaHybrid:Gender:Av");
 return(.defaultFixed);
}
GetAllRandomFromV <- function(ASource) {
.defaultRandom = c("aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej",
  "Gender:dominancej", "SymCrossjk", "Gender:SymCrossjk",
  "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
  "AllCrossjk", "Gender:AllCrossjk");
  return(.defaultRandom);
}

colMedians <- function(AMat) {
  apply(AMat,2, function(x){median(as.numeric(x), na.rm = TRUE)});
}

MakeRealVec <- function(TauVOrdered, SourceBeta = NULL) {
  if (!exists("SourceBeta") || is.null(SourceBeta)) {
    eval(parse(text=GetG0Text("AFDS")));
    if (is.null(AFDS) || (is.numeric(AFDS) && length(AFDS) <= 1)){
      print("Make Real Vec, no Source Beta for real beta! "); flush.console();
    }
    SourceBeta = AFDS$ADiallelOb$Beta
  }
   FN = GetAllFixedFromV(names(SourceBeta));
   RN = GetAllRandomFromV(names(SourceBeta));
   ATauVOrdered = TauVOrdered;
   ATauVOrdered[substr(ATauVOrdered,1,nchar("tau:"))=="tau:"] =
      substr(ATauVOrdered[substr(ATauVOrdered,1,nchar("tau:")) == "tau:"],
      nchar("tau:")+1, nchar(ATauVOrdered[substr(ATauVOrdered,1,nchar("tau:")) == "tau:"]));   
   RealVec = rep(0, length(ATauVOrdered));
   for (jj in 1:length(ATauVOrdered)) {
     if (ATauVOrdered[jj] %in% FN) {
       if (sum(EatFingColons(names(SourceBeta)) == EatFingColons(ATauVOrdered[jj])) == 1) {
         RealVec[jj] = SourceBeta[EatFingColons(names(SourceBeta)) == EatFingColons(ATauVOrdered[jj])];
       }
     } else {
       if (length(SourceBeta[substr(EatFingColons(names(SourceBeta)), 1, nchar(EatFingColons(ATauVOrdered[jj])))
           == EatFingColons(ATauVOrdered[jj])]) > 0) {
         RealVec[jj] = sd(SourceBeta[substr(EatFingColons(names(SourceBeta)), 1, nchar(EatFingColons(ATauVOrdered[jj])))
           == EatFingColons(ATauVOrdered[jj])])
       }
     }
   }
   names(RealVec) = EatFingColons(ATauVOrdered);
   return(RealVec)

}



setMethodS3("PlotBayesFactorTau", "OutSimAnalyses", function(this, subfraction =1,
  DoLog = TRUE, ProbVOrdered = NULL, NoFixed = TRUE, mainadd="", AxisTitle = TRUE, ...) {


   if (is.null(this$BayesFactorTable$ReadTable)) {
     print("Error: Please Have Bayes Factor ReadTable"); flush.console();
   }
   ITT = (1:length(this$BayesFactorTable$ReadTable[,1]));
   if (length(subfraction) > 1) {
     ITT = ITT[ITT %in% subfraction];
   } else if (subfraction > 0 && subfraction < 1.0) {
     ITT = sort(sample(ITT, size = round(length(ITT) * subfraction),
      replace=FALSE));
   }

   
   FN = GetFixedNames(colnames(this$MeanVals$ReadTable));
   RN = GetRandomNames(colnames(this$MeanVals$ReadTable));
   if (!is.null(ProbVOrdered) && any(EatFingColons(ProbVOrdered) %in% EatFingColons(FN))) {
     AddFixedToo = TRUE;
   }
   if (AddFixedToo == FALSE) {
     idc = colnames(this$BayesFactorTable$ReadTable);
     IdN = idc[substr(idc,1,nchar("BayesFactor:")) == "BayesFactor:"];
     idt = (1:length(idc))[substr(idc,1,nchar("BayesFactor")) == "BayesFactor"];
   } else  {
     idc = colnames(this$BayesFactorTable$ReadTable);
     IdN = idc[substr(idc,1,nchar("BayesFactor:")) == "BayesFactor:"];
     idt = (1:length(idc))[substr(idc,1,nchar("BayesFactor")) == "BayesFactor"];
     NoFixed = FALSE
   }
   
   if (NoFixed == TRUE) {
     NNames = this$MeanVals$NamesColumns;
     NNames = NNames[NNames != "SimID"]; NNames = NNames[NNames != "SimId"];
     FN <- GetFixedNames(NNames);
     RN <- GetRandomNames(NNames);
     Killer = (1:length(idt))[ IdN %in% FN |
       IdN %in% paste("BayesFactor:", FN, sep="")]
     IdN = IdN[ (1:length(idt))[!(idt %in% idt[Killer])]];
     idt = idt[!(idt %in%idt[Killer])]
   }
   MM = colMeans(this$BayesFactorTable$ReadTable[,idt]);
   MNames = colnames(this$BayesFactorTable$ReadTable)[idt];
   MNames2 = strsplit(MNames, "BayesFactor:"); for (ii in 1:length(MNames)) {
     MNames[ii] = MNames2[[ii]][length(MNames2[[ii]])] }
   TT = length(MM);
   rDD = sort(MM, index=TRUE, decreasing=TRUE)$ix
   TDD = this$BayesFactorTable$ReadTable[, idt];
   TDD[TDD == 100] = max(TDD);
   TDD[is.na(TDD)] = 0;

   
      if (!is.null(TauVOrdered)) {
       AProbVOrdered = ProbVOrdered
         AProbVOrdered[substr(AProbVOrdered,1,nchar("tau:")) == "tau:"] =
           substr(AProbVOrdered[substr(AProbVOrdered,1,nchar("tau:")) == "tau:"],
             nchar("tau:")+1, nchar(AProbVOrdered[substr(AProbVOrdered,1,nchar("tau:"))=="tau:"]));
          AProbVOrdered[substr(AProbVOrdered,1,nchar("Prob:")) == "Prob:"] =
           substr(AProbVOrdered[substr(AProbVOrdered,1,nchar("Prob:")) == "Prob:"],
             nchar("Prob:")+1, nchar(AProbVOrdered[substr(AProbVOrdered,1,nchar("Prob:")) == "Prob:"]));
          AProbVOrdered[substr(AProbVOrdered,1,nchar("BayesFactor:")) == "BayesFactor:"] =
           substr(AProbVOrdered[substr(AProbVOrdered,1,nchar("BayesFactor:")) == "BayesFactor:"],
             nchar("BayesFactor:")+1, nchar(AProbVOrdered[substr(AProbVOrdered,1,nchar("BayesFactor:")) == "BayesFactor:"]));
         idAT = AProbVOrdered;
         idAT = EatFingColons(idAT); idc = EatFingColons(MNames);
         MyMatch = match( idAT, idc);
         AProbVOrdered = AProbVOrdered[!is.na(MyMatch)];
         MNames = MNames[MyMatch[!is.na(MyMatch)]];
         TDD = TDD[,MyMatch[!is.na(MyMatch)]];
      if (!is.null(RealVec)) {
        RealVec = RealVec[!is.na(MyMatch)];
      }
     } else {
       MM - colMeans(TDD);
       stMM = sort(abs(MM), index=TRUE, decreasing = TRUE)$ix
       TDD = TDD[,stMM ]
       MNames = MNames[stMM ];
       MM = colMeans(TDD);   
     }
       
   MM = colMedians(TDD);
   GM = min( TDD[TDD>0 ]);
   mainer = "Bayes Factor";
   if (mainadd != "") {
     mainer = paste(mainer, " - ", mainadd, sep="");
   }
   TT = length(TDD[1,]);
   if (DoLog == FALSE) {
   plot(y=c(0,max(this$BayesFactorTable$ReadTable[,idt])), x=c(.5,TT+.5), type="n", main=mainer,
     axes=FALSE, xlab="Tau Group", ylab="R-B BF");
   Cols = srainbow(length(this$BayesFactorTable$ReadTable[,1]));

     for (ii in ITT) {
       lines(x=(1:TT), y = (TDD[ii,]),
         lwd = 2, col=Cols[ii]);
     }
   axis(2, (0:5)/5, las=1);
   if (AxisTitle == TRUE) {
     AxisTitleMap(MNames);
   } else {
     axis(1, 1:TT, labels = MNames );
   }
   lines(x=(1:TT), y=MM, col="black", lwd=2);
   } else {
   plot(y=log(c(GM,max(TDD)),10), x=c(.5,TT+.5), type="n", main=mainer,
     axes=FALSE, xlab="Tau Group", ylab="log10 Bayes Factor");
   Cols = srainbow(length(this$BayesFactorTable$ReadTable[,1]));
     for (ii in ITT) {
       lines(x=(1:TT), y = log(TDD[ii,],10),
         lwd = 2, col=Cols[ii]);
     }
   AKA = round(log(GM,10):log(max(TDD),10));
   if (length(AKA) > 8) {
     LT = length(AKA) / 8;
     AKA = AKA[c(1,  (1:7) * LT, length(AKA))]
   }
   axis(2, AKA,
     labels=(AKA), las=1);
   if (AxisTitle == TRUE) {
     AxisTitleMap(MNames);
   } else {
     axis(1, 1:TT, labels = MNames );
   }
   lines(x=(1:TT), y=log(MM,10), col="black", lwd=2); 
    
   }
});

AxisTitleMap <- function(ListOfMNames) {
  AStuff = c("Mu", "Gender:Av", "BetaHybrid:Av", "BetaHybrid:Gender:Av",
    "aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej",
    "Gender:dominancej", "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk");
  BStuff = c("mu", "S", "B", "B[s]", "a", "a[s]", "m", "m[s]",
    "b", "b[s]", "v", "v[s]", "w", "w[s]", "u", "u[s]");
  MTI = match(EatFingColons(ListOfMNames), EatFingColons(AStuff));
  MyExpression = paste("axis(1, 1:", length(ListOfMNames), ",  labels = expression(",
    paste(BStuff[MTI[!is.na(MTI)]], collapse=", "), "));", sep="");
  eval(parse(text=MyExpression))
}

DeLogit <- function( X, sign = 1.0) {
  if (is.list(X)) {
    Y = list();
    for (ii in 1:length(X)) {
      Y[[ii]] = DeLogit(X[[ii]], sign = sign);
      if (is.mcmc(X[[ii]])) { Y[[ii]] = as.mcmc(Y[[ii]])}
    }
    if (is.mcmc.list(X)) {
      Y = as.mcmc.list(Y);
    }
    return(Y)
  }
  Y = X * 0;
  if (sign == 1.0) {
    if (length(X[X > -10 & X < 10]) > 0) {
      Y[ X > -10 & X < 10] = exp( X[X > -10 & X < 10]) / ( 1.0 + exp( X[X > -10 & X < 10]) )
    }
    Y[ X <= -10] = exp( X[X < -10]);
    Y[ X >= 10] =  1.0-exp(- X[X >= 10]);  
  } else {
    if (length(X[X > -10 & X < 10]) > 0) {
      Y[ X > -10 & X < 10] = 1.0 / ( 1.0 + exp( X[X > -10 & X < 10]) )
  }
    Y[ X <= -10] = 1.0 - exp(X[X < -10]);
    Y[ X >= 10] =  exp(-X[X >= 10]);
  
  }
  

  return(Y);

}
setMethodS3("PlotMIPTau", "OutSimAnalyses", function(this, subfraction =1,
  DoLog = TRUE, ProbVOrdered = NULL, mainadd="", AddFixedToo = FALSE,
  AxisTitle = TRUE, ...) {
   if (is.null(this$MIPVal$ReadTable)) {
     print("Error: Please Have ReadTable"); flush.console();
   }
   ITT = (1:length(this$MIPVal$ReadTable[,1]));
   if (length(subfraction) > 1) {
     ITT = ITT[ITT %in% subfraction];
   } else if (subfraction > 0 && subfraction < 1.0) {
     ITT = sort(sample(ITT, size = round(length(ITT) * subfraction),
      replace=FALSE));
   }
   FN = GetFixedNames(colnames(this$MeanVals$ReadTable));
   RN = GetRandomNames(colnames(this$MeanVals$ReadTable));
   if (!is.null(ProbVOrdered) && any(EatFingColons(ProbVOrdered) %in% EatFingColons(FN))) {
     AddFixedToo = TRUE;
   }
   if (AddFixedToo == FALSE) {
     idc = colnames(this$MIPVal$ReadTable);
     idtA = (1:length(idc))[substr(idc,1,5) == "a:tau"];
     idtB = (1:length(idc))[substr(idc,1,5) == "b:tau"];
   } else {
     idc = colnames(this$MIPVal$ReadTable);
     idtA = (1:length(idc))[substr(idc,1,5) == "a:tau" | (substr(idc,1,2) == "a:" & substr(idc,3,nchar(idc)) %in% FN)];
     idtB = (1:length(idc))[substr(idc,1,5) == "b:tau" | (substr(idc,1,2) == "b:" & substr(idc,3,nchar(idc)) %in% FN)];   
   }
   MM = colMeans(this$MIPVal$ReadTable[,idtA]);
   MNames = colnames(this$MIPVal$ReadTable)[idtA]
   MNames2 = strsplit(MNames, "a:tau:"); for (ii in 1:length(MNames)) {
     MNames[ii] = MNames2[[ii]][length(MNames2[[ii]])] }
   MNames2 = strsplit(MNames, "a:"); for (ii in 1:length(MNames)) {
     MNames[ii] = MNames2[[ii]][length(MNames2[[ii]])] }   
   TT = length(MM);
   TDD = this$MIPVal$ReadTable[,idtA];
   TDD[TDD == 1] = 1.0 - (this$MIPVal$ReadTable[,idtB])[TDD == 1];
   GM = min( TDD[TDD>0 ]); 
   rDD = sort(MM, index=TRUE, decreasing=TRUE)$ix
      if (!is.null(TauVOrdered)) {
       AProbVOrdered = ProbVOrdered
         AProbVOrdered[substr(AProbVOrdered,1,nchar("tau:")) == "tau:"] =
           substr(AProbVOrdered[substr(AProbVOrdered,1,nchar("tau:")) == "tau:"],
             nchar("tau:")+1, nchar(AProbVOrdered[substr(AProbVOrdered,1,nchar("tau:"))=="tau:"]));
          AProbVOrdered[substr(AProbVOrdered,1,nchar("Prob:")) == "Prob:"] =
           substr(AProbVOrdered[substr(AProbVOrdered,1,nchar("Prob:")) == "Prob:"],
             nchar("Prob:")+1, nchar(AProbVOrdered[substr(AProbVOrdered,1,nchar("Prob:")) == "Prob:"]));
          AProbVOrdered[substr(AProbVOrdered,1,nchar("BayesFactor:")) == "BayesFactor:"] =
           substr(AProbVOrdered[substr(AProbVOrdered,1,nchar("BayesFactor:")) == "BayesFactor:"],
             nchar("BayesFactor:")+1, nchar(AProbVOrdered[substr(AProbVOrdered,1,nchar("BayesFactor:")) == "BayesFactor:"]));
         idAT = AProbVOrdered;
         idAT = EatFingColons(idAT); idc = EatFingColons(MNames);
         MyMatch = match( idAT, idc);
         AProbVOrdered = AProbVOrdered[!is.na(MyMatch)];
         MNames = MNames[MyMatch[!is.na(MyMatch)]];
         TDD = TDD[,MyMatch[!is.na(MyMatch)]];
      if (!is.null(RealVec)) {
        RealVec = RealVec[!is.na(MyMatch)];
      }
     } else {
       MM - colMeans(TDD);
       stMM = sort(abs(MM), index=TRUE, decreasing = TRUE)$ix
       TDD = TDD[,stMM ]
       MNames = MNames[stMM ];
       MM = colMeans(TDD);   
     }
       
   TT = length(TDD[1,]);
   MM = colMeans(TDD);
   
   mainer = "Model Inclusion Probabilities";
   if (mainadd != "") {
    mainer = paste(mainer, " - ", mainadd, sep="");
   }
   if (DoLog == FALSE) {
   plot(y=c(0,1), x=c(.5,TT+.5), type="n", main=mainer,
     axes=FALSE, xlab="Tau Parameter", ylab="R-B MIP");
   Cols = srainbow(length(this$MIPVal$ReadTable[,1]));
     for (ii in ITT) {
       lines(x=(1:TT), y = (TDD[ii,]),
         lwd = 2, col=Cols[ii]);
     }
   axis(2, (0:5)/5, las=1);
   if (AxisTitle == TRUE) {
     AxisTitleMap(MNames);
   } else {
     axis(1, 1:TT, labels = MNames );
   }
   lines(x=(1:TT), y=MM, col="black", lwd=2);
   } else {
   plot(y=round(log(c(GM,1),2)), x=c(.5,TT+.5), type="n", main=mainer,
     axes=FALSE, xlab="Tau Parameter", ylab="R-B MIP");
   Cols = srainbow(length(this$MIPVal$ReadTable[,1]));
     for (ii in ITT) {
       lines(x=(1:TT), y = log(TDD[ii,],2),
         lwd = 2, col=Cols[ii]);
     }
     labels = paste("2^",((round(log(GM,2))):0),sep="")
     labels[labels == "2^0"] = 1;  labels[labels == "2^-1"] = .5;
     labels[labels == "2^-2"] = .25;
   axis(2, (round(log(GM,2))):0, labels = labels, las=1);
   if (AxisTitle == TRUE) {
     AxisTitleMap(MNames);
   } else {
     axis(1, 1:TT, labels = MNames);
   }
   lines(x=(1:TT), y=log(MM,2), col="black", lwd=2); 
    
   }
});

MakeEHat <- function(InputGroupName)  {
  IGN = InputGroupName;
  if (length(IGN) > 1) {
    St = c();
    for (ii in 1:length(IGN)) {
      St = c(St, MakeEHat(IGN[ii]));
    }
  }
  if (IGN == "aj") {
    return("a_{j}");
  } else if (IGN == "motherj") {
    return("m_{j}");
  } else if (IGN == "Gender:aj") {
    return("a_{j}^{S}");
  } else if (IGN == "Gender:motherj") {
    return("m_{j}^{S}");
  } else  if (IGN == "dominancej") {
    return("d_{j}");
  } else if (IGN == "Gender:dominancej") {
    return("d_{j}^{S}");
  } else if (IGN == "SymCrossjk")  {
    return("v_{jk}")
  } else if (IGN == "Gender:SymCrossjk") {
    return("v_{jk}^{S}");
  } else if (IGN == "ASymCrossjkDkj") {
    return("w_{jk}");
  } else if (IGN == "Gender:ASymCrossjkDkj") {
    return("w_{jk}^{S}")
  } else if (IGN == "AllCrossjk") {
    return("H_{jk}");
  } else if (IGN == "Gender:AllCrossjk") {
    return("H_{jk}^{S}")
  } else if (IGN == "Fixed")  {
    return("\\theta^{\\mbox{\\tiny{fixed}}}");
  } else {
    print(paste("MakeEHat, no corresponding value for : ", IGN, sep=""));
    return(NULL);
  }
  
}
NumericMe <- function(ATable) {
 if (is.numeric(ATable)) {
   return(ATable);
 }
 if (is.character(ATable)) {
   ATable[ ATable == "NA" ] = NA;
 }
 if (is.data.frame(ATable)) {
   NTable = matrix(0, dim(ATable)[1], dim(ATable)[2]);
   for (ii in 1:length(ATable[1,])) {
    if (is.factor(ATable[,ii])) {
      ATAL = as.character(ATable[,ii]);
      ATAL[ATAL == "NA"] = NA;
      try(NTable[,ii] <- as.numeric(ATAL));
    } else {
      NTable[,ii] = as.numeric(ATable[,ii]);
    }
   }
   if (!is.null(rownames(ATable))) {rownames(NTable) = rownames(ATable);}
   if (!is.null(colnames(ATable))) {colnames(NTable) = colnames(ATable);}
   return(NTable);
   ##print("Fuck you you fucking piece of shit R fuck fuck fuck fuck you!"); flush.console();
 }
 if (is.null(dim(ATable))) {
   RA = as.numeric(unlist(ATable));
   if (!is.null(names(ATable))) { names(RA) = names(ATable); }
   return(RA);
 }
 RA = matrix(0, dim(ATable)[1], dim(ATable)[2]);
 RA[1:(prod(dim(ATable)))] = as.numeric(unlist(ATable));
 if (!is.null(rownames(ATable))) { rownames(RA) = rownames(ATable);}
 if (!is.null(colnames(ATable))) { colnames(RA) = colnames(ATable);}
 return(RA);
}
setMethodS3( "ProcessAverageError", "OutSimAnalyses", function(this, L2OrL1 = "L2",
  MeanOrMedian=NULL, ParamGroup = NULL, ParamVal = NULL, AllFixed = NULL,
  ITERS = NULL, NonNAIters = FALSE,
   Denominator = c("None","T1", "T2")[1], ShiftDiff = TRUE,
  quantiles=c(.025,.975),...) {
  NameV = "";
  if (is.null(MeanOrMedian)) {
    if (!is.null(this$PreferMeanMedian)  && this$PreferMeanMedian == "Median") {
      MeanOrMedian = "MEDIAN"
    } else {
      MeanOrMedian = "MEAN"
    }
  }
 
  if (is.null(ParamGroup) && is.null(ParamVal) && !is.null(AllFixed)) {
    ParamGroup = BayesDiallel:::.DefaultAllFixedVariables
    NameV = "Fixed"
  }
  if (!is.null(ParamGroup)) {
    NN = colnames(this$TrueParamTable$ReadTable);
    if (is.null(NN)) {
      NN = names(TrueParametersList);
    }
    MySubSet = NULL;
    if (length(ParamGroup) > 1) {
      MySubSet = match(ParamGroup, NN);
      MySubSet = MySubSet[!is.na(MySubSet)];
    } else {
      MySubSet = (1:length(NN))[ substr(NN, 1,nchar(ParamGroup)) %in% ParamGroup];
      NameV = ParamGroup;
    }
    if (is.null(MySubSet) || length(MySubSet) == 0) {
      print(paste("Error processing Average Error for ", this$ModelName, sep="" ));
      print(paste(" No Values (", paste(ParamGroup, collapse=", "), ")", sep=""));
      print(paste("  Instead (", paste(NN, collapse=", "), ")", sep="")); flush.console();
      return(-1);
    }
  } else if (!is.null(ParamVal) ){
    NN = colnames(this$TrueParamTable$ReadTable);
    if (is.null(NN)) {
      NN = names(TrueParametersList);
    }
    ParamVal = ParamVal[ParamVal %in% NN];
    if (is.null(ParamGroup) || length(ParamGroup) == 0) {
      print(paste("Error processing Average Error for ", this$ModelName, sep=""));
      print(paste(" No Value (", paste(ParamVal, collapse=", "), ")", sep=""));
      print(paste("  Instead (", paste(NN, collapse=", "), ")", sep="")); flush.console();
      return(-1);
    }
    MySubSet = (1:length(NN))[NN == ParamVal];
  } else {
    print("Process Average Error: You never supplied what you wanted Processed");
  }
  
  if (is.null(this$TrueParamTable$ReadTable) ||
    length(this$TrueParamTable$ReadTable) <= 0) {
    if (is.null(ITERS)) {
    ITERS = 1:length(this$MeanVals$ReadTable[,1]);
    }
    if (NonNAIters == TRUE) {
      ITERS = ITERS[
        apply(NumericMe(this$MeanVals$ReadTable[ITERS, MySubSet]),
        1, function(V) {!any(is.na(V))})
        ]
    }
    TT = t(matrix(rep(TrueParametersList[MySubSet], length(ITERS)),
      length(MySubSet), length(ITERS)));
  } else {
    if (is.null(ITERS)) {
      ITERS = 1:length(this$TrueParamTable$ReadTable[,1])
     }
    if (NonNAIters == TRUE) {
      ITERS = ITERS[
        apply(NumericMe(this$TrueParamTable$ReadTable[ITERS, MySubSet]),
        1, function(V) {!any(is.na(V))})
        ]
    }
    TT = this$TrueParamTable$ReadTable[ITERS,MySubSet];   
  }

  if (MeanOrMedian == "MEDIAN") {
    if (NonNAIters == TRUE) {
      ITERS = ITERS[
        apply(NumericMe(this$MedianVals$ReadTable[ITERS, MySubSet]), 1, function(V) {!any(is.na(V))})]
      if (ShiftDiff == TRUE) {
        DD = NumericMe(this$MedianVals$ReadTable[ITERS, MySubSet]) -
          NumericMe(this$TrueParamTable$ReadTable[ITERS,MySubSet]);
      } else {
        DD = NumericMe(this$MedianVals$ReadTable[ITERS, MySubSet]);
      }
    } else {
      MyD = NumericMe(this$MedianVals$ReadTable[ITERS,MySubSet]);  MyD[is.na(MyD)] = 0; 
      if (ShiftDiff == TRUE) {
        DD = MyD -  NumericMe(TT);
      } else {
        DD = MyD;
      }
    }    
  } else {
    if (NonNAIters == TRUE) {
      ITERS = ITERS[
        apply(NumericMe(this$MeanVals$ReadTable[ITERS, MySubSet]), 1, function(V) {!any(is.na(V))})]
     if (ShiftDiff == TRUE) {
        DD = NumericMe(this$MeanVals$ReadTable[ITERS, MySubSet]) -
          NumericMe(TT);
      } else {
        DD = NumericMe(this$MeanVals$ReadTable[ITERS, MySubSet]);
      }  
    } else {
      MyD = NumericMe(this$MeanVals$ReadTable[ITERS,MySubSet]);  MyD[is.na(MyD)] = 0;
      if (ShiftDiff == TRUE) {
        DD = MyD -  NumericMe(TT);
      } else {
        DD = MyD;
      }     
    } 
  }
  if (L2OrL1 == "L2") {
    if (length(MySubSet) == 1) {
      if (Denominator %in% c("T1", "T2")) {
        DD = (DD / TT)^2
        return(list(mean=mean(DD), median=quantile(DD,.5), quantiles=quantile(DD, quantiles)));
      } else {
        return(list(mean=mean(DD^2), median=quantile(DD^2,.5), quantiles=quantile(DD^2, quantiles)));
      }
    } else {
      if (Denominator == "T1") {
        DD = rowSums(DD^2) / colSums(TT^2);
        return(list(mean=mean(DD), median=quantile(DD,.5), quantiles=quantile(DD, quantiles)));
      } else if (Denominator == "T2") {
        DD = rowSums(DD^2 / TT^2);
        return(list(mean=mean(DD), median=quantile(DD,.5), quantiles=quantile(DD, quantiles)));
      } else {
        DD = rowSums(DD^2);
        return(list(mean=mean(DD), median=quantile(DD,.5), quantiles=quantile(DD, quantiles)));
      }
    }
  } else if (L2OrL1 == "L1")  {
    if (length(MySubSet) == 1) {
      if (Denominator %in% c("T1", "T2")) {
        DD = abs(DD / TT)
        return(list(mean=mean(DD), median=quantile(DD,.5), quantiles=quantile(DD, quantiles)));
      } else {
        DD = abs(DD)
        return(list(mean=mean(DD), median=quantile(DD,.5), quantiles=quantile(DD, quantiles)));
      }
    } else {
      if (Denominator == "T1") {
        DD = rowSums(abs(DD)) / colSums(abs(TT));
        return(list(mean=mean(DD), median=quantile(DD,.5), quantiles=quantile(DD, quantiles)));
      } else if (Denominator == "T2") {
        DD = rowSums(abs(DD) / abs(TT));
        return(list(mean=mean(DD), median=quantile(DD,.5), quantiles=quantile(DD, quantiles)));
      } else {
        DD = rowSums(abs(DD));
        return(list(mean=mean(DD), median=quantile(DD,.5), quantiles=quantile(DD, quantiles)));
      }
    }  
  
  }

}
)