
AllTauCrossModels = c(3,4,6,7,9,10);
##########################################################################
##  "SetupTauCrosses"
##
##      "TauCrosses"  are tau effects that add prior structure to the
##           "W_jk"  and "V_jk" terms in the model
##   
##      That is, if model is
##
##     Y_t = Mu + .5 s_i + (BetaInbred) + A_i + .5 M_[j(i)] + Dominance_j
##               + V_jk (Symmetric) + .5 W_kj  (AntiSymmetric) + Error
##
##     Then the "TauCrosses" are tau variance parameters that
##       act upon V_jk and W_kj.  
##
##     For example if we are setting 3 then
##             V_jk ~ N(0, tauSymCrossj * tauSymCrosk)
##
##      If we are setting 4 then
##            V_jk ~ N(0, tauSymCrossj + tauSymCrosk)
##
##      Setting 6, and 7 simulate the W_jk asymmetric terms
##           similarly off of Asymmetric parameters
##      
##      Settings 9 and 10 simulate fully non symmetric effects.
##
setMethodS3("SetupTauCrosses", "DiallelOb", function(this, Im, Idf,...) {
  .numj = this$.numj;
  ##print(paste("SetupTauCrosses: numj = ", .numj, sep=""));
	this$tauCrosses <- NULL; this$dfCrosses <- NULL; 
    this$mCrosses <- NULL;  
    this$tauCrossName <- NULL;
	if (this$.CrossModel %in% c(3,4,6,7)) {
		this$tauCrosses <- c(this$tauCrosses, rep(Im$SymCrossajk / Idf$SymCrossajk,.numj));
		this$dfCrosses <- c(this$dfCrosses, Idf$SymCrossajk); 
    this$mCrosses <- c(this$mCrosses, Im$SymCrossajk);
		this$tauCrossName <- c(this$tauCrossName, "SymCrossjk");
		if (this$.SexModel >=5 ) {
			this$tauCrosses <- c(this$tauCrosses, rep(Im$SymCrossajk / Idf$SymCrossajk,.numj));
			this$dfCrosses <- c(this$dfCrosses, Idf$SymCrossajk); 
      this$mCrosses <- c(this$mCrosses, Im$SymCrossajk);			
			this$tauCrossName <- c(this$tauCrossName, "GendSymCrossjk");
		}
		if (this$.CrossModel %in% c(6,7) ) {
			this$tauCrosses <- c(this$tauCrosses, 
            rep(Im$ASymCrossajkdjai / Idf$ASymCrossajkdjkj,this$.numj));
			this$dfCrosses <- c(this$dfCrosses, Idf$ASymCrossajkdkj); 
      this$mCrosses <- c(this$mCrosses, Im$ASymCrossajkdkj);		
			this$tauCrossName <- c(this$tauCrossName, "ASymCrossjkDkj");
			if (SexModel >= 5) {
				this$tauCrosses <- c(this$tauCrosses, 
              rep(Im$GendASymCrossjkDkj / Idf$GendASymCrossajkdkj,.numj));
				this$dfCrosses <- c(this$dfCrosses, Idf$GendASymCrossajkdjkj); 
        this$mCrosses <- c(this$mCrosses, Im$GendASymCrossajkdjkj);		
				this$tauCrossName <- c(this$tauCrossName, "GendSymCrossjkDkj");
			}
		}
	}
	if (this$.CrossModel %in% c(9,10)) {
		this$tauCrosses <- c(this$tauCrosses, 
         rep(Im$AllCrossajk / Idf$AllCrossajk,.numj));
		this$dfCrosses <- c(this$dfCrosses, Idf$AllCrossajk);
    this$mCrosses <- c(this$mCrosses, Im$AllCrossajk);
		this$tauCrossName = c(this$tauCrossName, "AllCrossjk");
		if (this$.SexModel >= 5) {
			this$tauCrosses <- c(this$tauCrosses, 
         rep(Im$GendAllCrossajk / Idf$GendAllCrossajk,numj));
			this$dfCrosses = c(this$dfCrosses, Idf$GendAllCrossajk);
      this$mCrosses = c(this$mCrosses, Im$GendAllCrossajk);		
			this$tauCrossName = c(this$tauCrossName, "GendAllCrossjk");
		}		
	}
  names(this$tauCrosses) = paste( rep(this$tauCrossName, each=this$.numj),":", 
                                 rep(1:this$.numj, length(this$tauCrossName)), sep="" );
});  

################################################################################
###    SimCrossMethods
###
###      -- Necessary for simulating epistasis terms and taus
###
setMethodS3("SimCrossBeta", "DiallelOb", function(this, CO, ...) {
  .numj = this$.numj;
	this$tauCrosses[1:length(this$tauCrosses)] = rep(this$mCrosses,.numj) / rgamma( 
         this$.numj * length(this$mCrosses), rep(this$dfCrosses, this$.numj));	
	Onumj = 0; 
	if (this$.BetaInbredLevel >= 2) { UseDiag = FALSE; } else { UseDiag = TRUE;}
	
	
	SimFuncs = list(Sim36Cross, Sim47Cross, Sim9Cross, Sim10Cross);
	if (this$.CrossModel %in% c(3,6)) { Group  = 1; 
	} else if (this$.CrossModel %in% c(4,7)) { Group  = 2; 
	} else if (this$.CrossModel %in% c(9)) { Group  = 3; 
 	} else if (this$.CrossModel %in% c(10)) { Group  = 4; 
  } else { return; } 

  Func = SimFuncs[[Group]];

  for (ii in 1:length(this$tauCrossName)) {
     Func = SimFuncs[[Group]];
     Func(this, this$tauCrosses, this$.TDLenBeta[this$.TAUUseNames == this$tauCrossName[ii]],
          Onumj + .numj, UseDiag, this$tauCrossName[ii], CO);
     Onumj = Onumj + .numj;
  }
});

###############################################################################
##   Sim36Cross
##
##        CrossModel type "3"  (Symmetric Effect only) 
##           and type "6" (Symmetric and Asymmetric Effect) are terms
##           where the standard error "multiplies", that is
##           We'll have that V_jk sim N(0, tau^2_j * tau^2_k)
##        The following code simulates those V_jk or W_jk
##           Note, that "Sim9Cross" does the same for all off-diagonal
##           terms independent
setMethodS3("Sim36Cross", "DiallelOb",
     function(this, tauCrossesProp, EndRelBetas, 
              EndToggle, UseDiag = FALSE, OntauCrossName, CO, ...) {
    .numj = this$.numj;

	   Fun1 = (EndToggle-.numj+1):EndToggle;
	   tauUse = tauCrossesProp[Fun1];
	   if (UseDiag == TRUE && OntauCrossName %in% c("SymCrossjk", "GendSymCrossjk"))  {
		    RBetas = sqrt( tauUse[CO$jCross] * tauUse[CO$kCross] ) * rnorm( length(CO$jCross), 0, 1);
		    this$Beta[(EndRelBetas - (.numj)*(.numj+1)/2+1):EndRelBetas] <- RBetas;
	   } else {
		    RBetas = sqrt( tauUse[CO$jCrossO] * tauUse[CO$kCrossO] ) * rnorm( length(CO$jCrossO), 0, 1);
		    this$Beta[(EndRelBetas - (.numj)*(.numj-1)/2+1):EndRelBetas] <- RBetas;
	   }
});

###############################################################################
##   Sim47Cross
##
##        CrossModel type "4"  (Symmetric Effect only) 
##           and type "7" (Symmetric and Asymmetric Effect) are terms
##           where the standard error "adds", that is
##           We'll have that V_jk sim N(0, tau^2_j + tau^2_k)
##        The following code simulates those V_jk or W_jk
##           Note, that "Sim9Cross" does the same for all off-diagonal
##           terms independent
setMethodS3("Sim47Cross", "DiallelOb",
     function(this, tauCrossesProp, EndRelBetas, 
              EndToggle, UseDiag = FALSE, OntauCrossName, CO, ...) {
	   .numj = this$.numj;
	   Fun1 = (EndToggle-.numj+1):EndToggle;
	   tauUse = tauCrossesProp[Fun1];
	   if (UseDiag == TRUE && OntauCrossName %in% c("SymCrossjk", "GendSymCrossjk"))  {
		    RBetas = sqrt( tauUse[CO$jCross] + tauUse[CO$kCross] ) * rnorm( length(CO$jCross), 0, 1);
		    this$Beta[(EndRelBetas - (.numj)*(.numj+1)/2+1):EndRelBetas] <- RBetas;
	   } else {
		    RBetas = sqrt( tauUse[CO$jCrossO] + tauUse[CO$kCrossO] ) * rnorm( length(CO$jCrossO), 0, 1);
		    this$Beta[(EndRelBetas - (.numj)*(.numj-1)/2+1):EndRelBetas] = RBetas;
	   }
});
 
setMethodS3("Sim9Cross", "DiallelOb",
     function(this, tauCrossesProp, EndRelBetas, 
              EndToggle, UseDiag = FALSE, OntauCrossName , CO, ...) { 
  Fun1 = (EndToggle-numj+1):EndToggle;
	tauUse = tauCrossesProp[Fun1];
	.numj = this4.numj;
	if (UseDiag == TRUE) {
		RBetas = sqrt( tauUse[c(CO$jCross, CO$kCrossO)] * 
                     tauUse[c(CO$kCross, CO$jCrossO)] ) *
                      rnorm( length(c(CO$jCross, CO$kCrossO)), 0, 1);
		this$Beta[(EndRelBetas - .numj^2+1):EndRelBetas] <- RBetas;
	} else {
		RBetas = sqrt( tauUse[c(CO$jCrossO, CO$kCrossO)] *
                   tauUse[c(CO$kCrossO, CO$jCrossO)] ) *
                    rnorm( length(c(CO$jCrossO, CO$kCrossO)), 0, 1);
		this$Beta[(EndRelBetas - (.numj)^2 + 1+.numj):EndRelBetas] <- RBetas;
	}
});

setMethodS3("Sim10Cross", "DiallelOb",
     function(this, tauCrossesProp, EndRelBetas, 
              EndToggle, UseDiag = FALSE, OntauCrossName , CO, ...) { 
  Fun1 = (EndToggle-numj+1):EndToggle;
	tauUse = tauCrossesProp[Fun1];
	.numj = this$.numj;
	if (UseDiag == TRUE) {
		RBetas = sqrt( tauUse[c(CO$jCross, CO$kCrossO)] +
                     tauUse[c(CO$kCross, CO$jCrossO)] ) *
                      rnorm( length(c(CO$jCross, CO$kCrossO)), 0, 1);
		this$Beta[(EndRelBetas - .numj^2+1):EndRelBetas] <- RBetas;
	} else {
		RBetas = sqrt( tauUse[c(CO$jCrossO, CO$kCrossO)] +
                   tauUse[c(CO$kCrossO, CO$jCrossO)] ) *
                    rnorm( length(c(CO$jCrossO, CO$kCrossO)), 0, 1);
		this$Beta[(EndRelBetas - (.numj)^2 + 1+.numj):EndRelBetas] <- RBetas;
	}
}); 


################################################################################
###    Cross Impute Methods
###
###      -- Gibbs Sampler inputes "tau_j" and "tau_k" specific effects
###     for off diagonals.
###
##setMethodS3("CrossImpute", "DiallelOb", function(this, CO, ...) {
## .numj = this$.numj;
##	Onumj = 0; 
##	if (this$.BetaInbredLevel >= 2) { UseDiag = FALSE; } else { UseDiag = TRUE;}
##	
##	
##	ImputeFuncs = list(Cross36Impute, Cross47Impute, Cross9Impute, Cross10Impute);
##	if (this$.CrossModel %in% c(3,6)) { Group  = 1; 
##	} else if (this$.CrossModel %in% c(4,7)) { Group  = 2; 
##	} else if (this$.CrossModel %in% c(9)) { Group  = 3; 
## 	} else if (this$.CrossModel %in% c(10)) { Group  = 4; 
##  } else { return; } 
##
##  Func = ImputeFuncs[[Group]];
##
## for (ii in 1:length(this$tauCrossName)) {
##     Func(this, EndRelBetas =this$.TDLenBeta[this$.TAUUseNames == this$tauCrossName[ii]],
##          EndToggle=Onumj + .numj, UseDiag=UseDiag, CrossName=this$tauCrossName[ii], 
##          intCross = ii, CO=CO);
##     Onumj = Onumj + .numj;
##  }
##}); 


setMethodS3("Cross36Impute", "DiallelOb",  
    function(this, EndRelBetas, 
               EndToggle, UseDiag = FALSE, 
               CrossName = "SymCrossjk", 
               intCross = 1, CO=NULL,...) {
	Fun1 = (EndToggle-this$.numj+1):EndToggle;
	FunDiag1 = 1/this$tauCrosses[Fun1];
	ZCross3 = matrix( this$Beta[EndRelBetas - 
                   (this$.numj * (this$.numj+1))/2 + 
                   CO$KDAlt], this$.numj, this$.numj);
	if (UseDiag == TRUE &&  
        CrossName %in% c("SymCrossjk", "GendSymCrossjk")) {
		this$tauCrosses[Fun1] <- (this$mCrosses[intCross] 
                    + colSums(FunDiag1 * ZCross3^2)/2) /
		rgamma(length(Fun1), this$dfCrosses[intCross] 
             + this$.numj/2);
	} else {
		diag(ZCross3) = 0;	
		this$tauCrosses[Fun1] <- (this$mCrosses[intCross] + 
        colSums(FunDiag1 * ZCross3^2)/2) /
		    rgamma(length(Fun1), this$dfCrosses[intCross] 
          + (this$.numj-1)/2);		
	}
});
 
setMethodS3("Cross10Impute", "DiallelOb", 
  function(tauCrosses, EndRelBetas, EndToggle, 
  UseDiag = FALSE, CrossName="AllCrossjk", 
  intCross = 1, CO = NULL,...) {
	  Fun1 = (EndToggle - numj+1): EndToggle;
	  ZCross4a = matrix( 
       this$Beta[EndRelBetas - this$.numj^2 + CO$KDAll],
       this$.numj, this$.numj);
	  ZCross4b = matrix( 
        this$Beta[EndRelBetas - this$.numj^2 
           + t(CO$KDAll)], this$.numj, this$.numj);	
    FMAT = 1 / matrix( 
         rep(this$tauCrosses[Fun1], each=this$.numj) 
         + rep(this$tauCrosses[Fun1], this$.numj),
           this$.numj, this$.numj,...);
    ZCross4a = this$tauCrosses[Fun1] * ZCross4a  * FMAT +
	  sqrt (  
      ( this$tauCrosses[Fun1] 
         %*% t(this$tauCrosses[Fun1])  ) * FMAT ) * 
	  matrix(rnorm(this$.numj * this$.numj), 
            this$.numj, this$.numj);
    ZCross4b = this$tauCrosses[Fun1] * ZCross4b  * FMAT +
	  sqrt (  ( this$tauCrosses[Fun1] %*% 
            t(this$tauCrosses[Fun1])  ) * FMAT ) * 
	  matrix(rnorm(this$.numj * this$.numj), 
                 this$.numj, this$.numj);	
	  if (UseDiag == TRUE) {
		   diag(ZCross4a) = this$Beta[ 
          EndRelBetas - (this$.numj^2) 
           + diag(CO$KDAll) ] / 2;
		   diag(ZCross4b) = 0;
		   this$tauCrosses[Fun1] <- (
         this$mCrosses[intCross] +  
            rowSums(ZCross4a^2) / 2 
            + rowSums(ZCross4b^2) /2 ) /
		   rgamma(length(Fun1), this$dfCrosses[intCross] 
           + (this$.numj+this$.numj-1)/2);
	   } else {
		    diag(ZCross4a) = 0;	diag(ZCross4b) = 0;	
		    this$tauCrosses[Fun1] <- 
         (this$mCrosses[intCross] +  
            rowSums(ZCross4a^2) / 2 
            + rowSums(ZCross4b^2) /2 ) /
		    rgamma(length(Fun1), this$dfCrosses[intCross] 
            + (this$.numj-1 + this$.numj-1)/2);		
	  }
});

setMethodS3("Cross47Impute", "DiallelOb", 
   function(this, EndRelBetas, EndToggle, 
            UseDiag = FALSE, CrossName = "SymCrossjk",
            intCross = 1, CO=NULL,...) {
	  Fun1 = (EndToggle-this$.numj+1):EndToggle;
    ZCross4A = matrix( this$Beta[
               EndRelBetas - 
               (this$.numj * (this$.numj+1))/2 
               + t(CO$KDAlt)], this$.numj, this$.numj);
    FMAT = 1 / matrix( 
        rep(this$tauCrosses[Fun1], each=this$.numj) 
         + rep(this$tauCrosses[Fun1], this$.numj), 
         this$.numj, this$.numj);
    ZCross4A = this$tauCrosses[Fun1] * ZCross4A  * FMAT +
	      sqrt (  (this$tauCrosses[Fun1] %*% 
                   t(this$tauCrosses[Fun1])  ) * FMAT ) * 
	      matrix(rnorm(this$.numj * this$.numj), 
                     this$.numj, this$.numj);
	  if (UseDiag == TRUE && CrossName %in% 
                     c("SymCrossjk", "GendSymCrossjk")) {
		  diag(ZCross4A) = this$Beta[ EndRelBetas 
               - (this$.numj * (this$.numj+1))/2 
               + diag(CO$KDAlt) ] / 2;
		  this$tauCrosses[Fun1] <- (this$mCrosses[intCross] 
           +  rowSums(ZCross4A^2) / 2 ) /
		  rgamma(length(Fun1), this$dfCrosses[intCross] 
           + (this$.numj)/2);
	  } else {
		  diag(ZCross4A) = 0;		
		  this$tauCrosses[Fun1] <- (this$mCrosses[intCross] 
         +  rowSums(ZCross4A^2) / 2 ) /
		  rgamma(length(Fun1), this$dfCrosses[intCross] 
         + (this$.numj-1)/2);		
	  }
});

setMethodS3("Cross9Impute", "DiallelOb",
    function(this, EndRelBetas, EndToggle, 
    UseDiag = FALSE, CrossName="AllCrossjk",
    intCross = 1,...) {
	  Fun1 = (EndToggle-this$.numj+1):EndToggle;
	  FunDiag1 = 1/this$tauCrosses[Fun1];
  	ZCross3a = matrix( this$Beta[
         EndRelBetas - this$.numj^2 + CO$KDAll], 
         this$numj, this$numj);
    ZCross3b = matrix( this$Beta[EndRelBetas - 
         this$.numj^2 + t(CO$KDAll)], 
         this$.numj, this$.numj);	
	  if (UseDiag == TRUE) {
		   diag(ZCross3b) = 0;
		   this$tauCrosses[Fun1] <- (this$mCrosses[intCross] 
        + colSums(FunDiag1 * ZCross3a^2)/2 
        + colSums(FunDiag1 * ZCross3b^2)/2 ) /
		  rgamma(length(Fun1), this$dfCrosses[intCross] 
        + (this$.numj+this$.numj-1)/2);
	 } else {
	  	diag(ZCross3a) = 0; diag(ZCross3b) = 0;	
		  this$tauCrosses[Fun1] <- (this$mCrosses[intCross] 
         + colSums(FunDiag1 * ZCross3a^2)/2 
         + colSums(FunDiag1 * ZCross3b^2)/2) /
		  rgamma(length(Fun1), this$dfCrosses[intCross] 
         + (this$.numj-1+this$.numj-1)/2);		
	 }
});

setMethodS3("FillCrossWantDiag", "DiallelOb", function(this, CO, ...) {
  .numj = this$.numj;
	Onumj = 0; 
	if (this$.BetaInbredLevel >= 2) { UseDiag = FALSE; } else { UseDiag = TRUE;}
	
	
	FillFuncs = list(Fill36Diag, Fill47Diag, Fill9Diag, Fill10Diag);
	if (this$.CrossModel %in% c(3,6)) { Group  = 1; 
	} else if (this$.CrossModel %in% c(4,7)) { Group  = 2; 
	} else if (this$.CrossModel %in% c(9)) { Group  = 3; 
 	} else if (this$.CrossModel %in% c(10)) { Group  = 4; 
  } else { return; } 

  Func = FillFuncs[[Group]];

  for (ii in 1:length(this$tauCrossName)) {
     Func(this, this$.TDLenBeta[this$.TAUUseNames == this$tauCrossName[ii]],
          Onumj + .numj, UseDiag, this$tauCrossName[ii], 
          intCross = ii, CO);
     Onumj = Onumj + .numj;
  }
}); 

 

setMethodS3("Fill9Diag", "DiallelOb", function(
  this, EndRelBetas, EndToggle, UseDiag = FALSE, CrossName,
  intCross, CO, ...) {
	Fun1 = (EndToggle-this$.numj+1):EndToggle;
	tauUse = this$tauCrosses[Fun1];
	MtauUse = matrix(tauUse,length(tauUse),1) %*% 
              matrix(tauUse,1,length(tauUse));
	if (UseDiag == TRUE) {
		this$MyWantDiag[(EndRelBetas - 
       (this$.numj)^2+1):EndRelBetas] =
       1 / MtauUse[cbind( c(CO$iCross, CO$jCrossO), 
                         c(CO$jCross, CO$iCrossO))];
	} else {
    this$MyWantDiag[(EndRelBetas - (this$.numj)^2 
        + this$.numj+1):EndRelBetas] = 
          1 / MtauUse[cbind( c(CO$iCrossO, CO$jCrossO), 
                             c(CO$jCrossO, CO$iCrossO))];
	}		
});


setMethodS3("Fill36Diag", "DiallelOb",
   function(this, EndRelBetas, EndToggle, 
   UseDiag = FALSE, 
   CrossName = "SymCrossjk", CO = NULL,...) {
	Fun1 = (EndToggle-this$.numj+1):EndToggle;
	tauUse = this$tauCrosses[Fun1];
	MtauUse = matrix(tauUse,length(tauUse),1) %*%
                 matrix(tauUse,1,length(tauUse));
	if (UseDiag == TRUE && CrossName %in% 
                 c("SymCrossjk", "GendSymCrossjk") ) {
		this$MyWantDiag[(EndRelBetas - 
        (this$.numj)*(this$.numj+1)/2 +1):EndRelBetas] =
            1 / MtauUse[idCross];
	} else {
    this$MyWantDiag[(EndRelBetas -
            (this$.numj)*(this$.numj-1)/2 +1):EndRelBetas]=
               1 / MtauUse[CO$idCrossO];
	}		
}    );
setMethodS3("Fill10Diag", "DiallelOb", 
   function(this, EndRelBetas, EndToggle, 
              UseDiag = FALSE, 
              CrossName="AllCrossjk", 
              CO = NULL,...) {
	Fun1 = (EndToggle-this$.numj+1):EndToggle;
	tauUse = this$tauCrosses[Fun1];
	MtauUse =  matrix(rep(tauUse, length(tauUse)),
              length(tauUse),length(tauUse)) + 
	             t(matrix(rep(tauUse, length(tauUse)),
                   length(tauUse),length(tauUse)));	
	if (UseDiag == TRUE) {
		this$MyWantDiag[(EndRelBetas -
                (this$.numj)^2+1):EndRelBetas] =
         1 / MtauUse[cbind( c(CO$iCross, CO$jCrossO), 
                            c(CO$jCross, CO$iCrossO))];
	} else {
    this$MyWantDiag[(EndRelBetas -
            (this$.numj)*(this$.numj-1) +1):EndRelBetas] =
         1 / MtauUse[cbind( c(CO$iCrossO, CO$jCrossO), 
                            c(CO$jCrossO, CO$iCrossO))];
	}		
}  );

setMethodS3("Fill47Diag", "DiallelOb",  
    function(this, EndRelBetas, EndToggle, 
             UseDiag = FALSE, CrossName="SymCrossjk",
             CO = NULL, ...) {
	Fun1 = (EndToggle-this$.numj+1):EndToggle;
	tauUse = this$tauCrosses[Fun1];
	MtauUse = matrix(rep(tauUse, length(tauUse)),
            length(tauUse),length(tauUse)) + 
	           t(matrix(rep(tauUse, length(tauUse)),
                length(tauUse),length(tauUse)));
	if (UseDiag == TRUE && "SymCrossjk") {
		this$MyWantDiag[(EndRelBetas - 
       (this$.numj)*(this$.numj+1)/2 +1):EndRelBetas] =
           1 / MtauUse[CO$idCross];
	} else {
    this$MyWantDiag[(EndRelBetas - 
          (this$.numj)*(this$.numj-1)/2 +1):EndRelBetas] = 
             1 / MtauUse[CO$idCrossO];
	}		
});

setMethodS3("EMImpute", "DiallelOb", function(this, CO, ...) {
  .numj = this$.numj;
	Onumj = 0; 
	if (this$.BetaInbredLevel >= 2) { UseDiag = FALSE; } else { UseDiag = TRUE;}
	
	
	ImputeFuncs = list(EM36Impute, EM47Impute, EM9Impute, EM10Impute);
	if (this$.CrossModel %in% c(3,6)) { Group  = 1; 
	} else if (this$.CrossModel %in% c(4,7)) { Group  = 2; 
	} else if (this$.CrossModel %in% c(9)) { Group  = 3; 
 	} else if (this$.CrossModel %in% c(10)) { Group  = 4; 
  } else { return; } 

  Func = ImputeFuncs[[Group]];

  for (ii in 1:length(this$tauCrossName)) {
     Func(this, EndRelBetas =this$.TDLenBeta[this$.TAUUseNames == this$tauCrossName[ii]],
          EndToggle=Onumj + .numj, UseDiag=UseDiag, CrossName=this$tauCrossName[ii], 
          intCross = ii, CO=CO);
     Onumj = Onumj + .numj;
  }
}); 


setMethodS3("EM36Impute", "DiallelOb",  
    function(this, EndRelBetas, 
               EndToggle, UseDiag = FALSE, 
               CrossName = "SymCrossjk", 
               intCross = 1, CO=NULL,...) {
	Fun1 = (EndToggle-this$.numj+1):EndToggle;
	FunDiag1 = 1/this$tauCrosses[Fun1];
	ZCross3 = matrix( this$Beta[EndRelBetas - 
                   (this$.numj * (this$.numj+1))/2 + 
                   CO$KDAlt], this$.numj, this$.numj);
	if (UseDiag == TRUE &&  
        CrossName %in% c("SymCrossjk", "GendSymCrossjk")) {
		this$tauCrosses[Fun1] <- (this$mCrosses[intCross] 
                    + colSums(FunDiag1 * ZCross3^2)/2) /
		rgamma( this$dfCrosses[intCross] 
             + this$.numj/2 );
	} else {
		diag(ZCross3) = 0;	
		this$tauCrosses[Fun1] <- (this$mCrosses[intCross] + 
        colSums(FunDiag1 * ZCross3^2)/2) /
		    (this$dfCrosses[intCross] 
          + (this$.numj-1)/2);		
	}
});

setMethodS3("Cross10Impute", "DiallelOb", 
  function(tauCrosses, EndRelBetas, EndToggle, 
  UseDiag = FALSE, CrossName="AllCrossjk", 
  intCross = 1, CO = NULL,...) {
	  Fun1 = (EndToggle - numj+1): EndToggle;
	  ZCross4a = matrix( 
       this$Beta[EndRelBetas - this$.numj^2 + CO$KDAll],
       this$.numj, this$.numj);
	  ZCross4b = matrix( 
        this$Beta[EndRelBetas - this$.numj^2 
           + t(CO$KDAll)], this$.numj, this$.numj);	
    FMAT = 1 / matrix( 
         rep(this$tauCrosses[Fun1], each=this$.numj) 
         + rep(this$tauCrosses[Fun1], this$.numj),
           this$.numj, this$.numj,...);
    ZCross4a = this$tauCrosses[Fun1] * ZCross4a  * FMAT +
	  sqrt (  
      ( this$tauCrosses[Fun1] 
         %*% t(this$tauCrosses[Fun1])  ) * FMAT ) * 
	  matrix(rnorm(this$.numj * this$.numj), 
            this$.numj, this$.numj);
    ZCross4b = this$tauCrosses[Fun1] * ZCross4b  * FMAT +
	  sqrt (  ( this$tauCrosses[Fun1] %*% 
            t(this$tauCrosses[Fun1])  ) * FMAT ) * 
	  matrix(rnorm(this$.numj * this$.numj), 
                 this$.numj, this$.numj);	
	  if (UseDiag == TRUE) {
		   diag(ZCross4a) = this$Beta[ 
          EndRelBetas - (this$.numj^2) 
           + diag(CO$KDAll) ] / 2;
		   diag(ZCross4b) = 0;
		   this$tauCrosses[Fun1] <- (
         this$mCrosses[intCross] +  
            rowSums(ZCross4a^2) / 2 
            + rowSums(ZCross4b^2) /2 ) /
		   rgamma(length(Fun1), this$dfCrosses[intCross] 
           + (this$.numj+this$.numj-1)/2);
	   } else {
		    diag(ZCross4a) = 0;	diag(ZCross4b) = 0;	
		    this$tauCrosses[Fun1] <- 
         (this$mCrosses[intCross] +  
            rowSums(ZCross4a^2) / 2 
            + rowSums(ZCross4b^2) /2 ) /
		    rgamma(length(Fun1), this$dfCrosses[intCross] 
            + (this$.numj-1 + this$.numj-1)/2);		
	  }
});

setMethodS3("Cross47Impute", "DiallelOb", 
   function(this, EndRelBetas, EndToggle, 
            UseDiag = FALSE, CrossName = "SymCrossjk",
            intCross = 1, CO=NULL,...) {
	  Fun1 = (EndToggle-this$.numj+1):EndToggle;
    ZCross4A = matrix( this$Beta[
               EndRelBetas - 
               (this$.numj * (this$.numj+1))/2 
               + t(CO$KDAlt)], this$.numj, this$.numj);
    FMAT = 1 / matrix( 
        rep(this$tauCrosses[Fun1], each=this$.numj) 
         + rep(this$tauCrosses[Fun1], this$.numj), 
         this$.numj, this$.numj);
    ZCross4A = this$tauCrosses[Fun1] * ZCross4A  * FMAT +
	      sqrt (  (this$tauCrosses[Fun1] %*% 
                   t(this$tauCrosses[Fun1])  ) * FMAT ) * 
	      matrix(rnorm(this$.numj * this$.numj), 
                     this$.numj, this$.numj);
	  if (UseDiag == TRUE && CrossName %in% 
                     c("SymCrossjk", "GendSymCrossjk")) {
		  diag(ZCross4A) = this$Beta[ EndRelBetas 
               - (this$.numj * (this$.numj+1))/2 
               + diag(CO$KDAlt) ] / 2;
		  this$tauCrosses[Fun1] <- (this$mCrosses[intCross] 
           +  rowSums(ZCross4A^2) / 2 ) /
		  ( this$dfCrosses[intCross] 
           + (this$.numj)/2);
	  } else {
		  diag(ZCross4A) = 0;		
		  this$tauCrosses[Fun1] <- (this$mCrosses[intCross] 
         +  rowSums(ZCross4A^2) / 2 ) /
		  ( this$dfCrosses[intCross] 
         + (this$.numj-1)/2);		
	  }
});

setMethodS3("EM9Impute", "DiallelOb",
    function(this, EndRelBetas, EndToggle, 
    UseDiag = FALSE, CrossName="AllCrossjk",
    intCross = 1,...) {
	  Fun1 = (EndToggle-this$.numj+1):EndToggle;
	  FunDiag1 = 1/this$tauCrosses[Fun1];
  	ZCross3a = matrix( this$Beta[
         EndRelBetas - this$.numj^2 + CO$KDAll], 
         this$numj, this$numj);
    ZCross3b = matrix( this$Beta[EndRelBetas - 
         this$.numj^2 + t(CO$KDAll)], 
         this$.numj, this$.numj);	
	  if (UseDiag == TRUE) {
		   diag(ZCross3b) = 0;
		   this$tauCrosses[Fun1] <- (this$mCrosses[intCross] 
        + colSums(FunDiag1 * ZCross3a^2)/2 
        + colSums(FunDiag1 * ZCross3b^2)/2 ) /
		   (this$dfCrosses[intCross] 
        + (this$.numj+this$.numj-1)/2);
	 } else {
	  	diag(ZCross3a) = 0; diag(ZCross3b) = 0;	
		  this$tauCrosses[Fun1] <- (this$mCrosses[intCross] 
         + colSums(FunDiag1 * ZCross3a^2)/2 
         + colSums(FunDiag1 * ZCross3b^2)/2) /
		  ( this$dfCrosses[intCross] 
         + (this$.numj-1+this$.numj-1)/2);		
	 }
});



