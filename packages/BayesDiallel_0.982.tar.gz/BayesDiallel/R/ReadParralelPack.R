## ReadParralelPack.R
DefaultInputDirectory = 
  "/n/scratch06/airoldi_scratch/alenarcic/DiallelSims/TableTests";
  
ReadAndProcessCovCI <- function(InputDirectory = DefaultInputDirectory 
) {
  print(paste("Reading In Files in: ", InputDirectory, sep=""))
  TotDir = unlist(list.files(InputDirectory, all.files=TRUE));
  print(paste("Length Of TotDir = ", length(TotDir), sep=""));
  MyText = "MyResponses = list(); \n";
  for (jj in 1:length(TotDir)) {
    MyTotalDir = paste(InputDirectory, "//", TotDir[jj], sep="");
    print(paste("Reading In Directory: ", MyTotalDir, sep=""));
    FilesInTotalDir = unlist(list.files(MyTotalDir));
    if (any(FilesInTotalDir == "CovCI.csv")) {
      MyTab = NULL;
      try(MyTab <- read.table(paste(MyTotalDir, "//CovCI.csv", sep=""), sep=",",
        header=TRUE));

      if (is.null(MyTab) && length(dim(MyTab)) != 2) {
        print(paste("Table Bad for MytotalDir = ", TotDir[jj], sep=""));
      } else {
      Mydim = dim(MyTab);
      ##print(MyTab[1:5,1:12]);
      MyNumericTab = MyTab[,2:Mydim[2]];
      ##MyNumericTab = matrix(MyTab[,2:Mydim[2]],
      ##  Mydim[1], Mydim[2]-1);
      print(paste("MyNumericTab dim = c(",
        paste(dim(MyNumericTab), collapse=", "), ")", sep=""));
      RepPerformance = colMeans(MyNumericTab)  
      ColNamesRep = colnames(MyTab);
      MyText = paste(MyText, "\n  MyResponses[[", jj, "]] = list(); \n", sep="");
      MyText = paste(MyText,
        " MyResponses[[", jj, "]]$N = ", length(MyTab[,1]), ";\n", sep="");
      if (any(FilesInTotalDir == "IdentifierList.R")) {
        con <- file(paste(MyTotalDir, "//", "IdentifierList.R", sep=""), 
          "r", blocking = FALSE)
        MyLines = unlist(readLines(con));  close(con);
        MyLines[substr(MyLines, nchar(MyLines), nchar(MyLines))== ";"] = 
          substr(MyLines[substr(MyLines, nchar(MyLines), nchar(MyLines))== ";"],
            1,
            nchar(
            MyLines[substr(MyLines, nchar(MyLines), nchar(MyLines))== ";"])
             - 1);
        MyText = paste(MyText, "\n  MyResponses[[", jj, "]]$Inputs = list(",
          paste(MyLines[2:length(MyLines)], collapse = ", "),
          "); \n ");
      }  else {
        
      }
      MyText = paste(MyText, 
          "MyResponses[[", jj, "]]$ColNames = ",
          "c(\"", 
          paste(  ColNamesRep, collapse="\", \""),
          "\") ",
          "\n", sep="");
      MyText = paste(MyText, 
          "MyResponses[[", jj, "]]$MeanCovCI = ",
          "c(", 
          paste(RepPerformance, collapse=", "),
          ") \n", sep="");    
      }       
    }  
  }
  return(MyText);
}

##eval(parse(text=MyText));


SummarizeMultipleModels <- function(listOutSimAnalyses,
  ListRFlags = NULL, ListsdRFlags = NULL,
  SaveDir = "", verbose=FALSE, CaptionString = "",
  FileString = "",
  L2Flag  = TRUE, L1Flag = TRUE, L0Flag = TRUE,
  Type1Flag = FALSE, Type2Flag = FALSE, 
  OutQuantFlag = FALSE, CIWidthFlag = FALSE, 
  TimeFlag=FALSE, DICFlag=FALSE,
  PIDFlag = FALSE, BarDFlag = FALSE, DofMeanFlag = FALSE,
  HLineList = NULL,na.rm=TRUE, TrueParams = NULL,
  TargetL2OnlyOn =FALSE,
  TargetColErrorNames = NULL, ExtraName = ""
  ) {
  if (verbose == TRUE) {
    print(paste("Start SummarizeMultipleModels for caption:",
      CaptionString, sep="")); flush.console();
  }
  if (is.null(ListRFlags)) {
    ListRFlags <- Flagger(L2Flag, L1Flag, L0Flag, Type1Flag,
      Type2Flag, OutQuantFlag, CIWidthFlag, TimeFlag, DICFlag,
      PIDFlag, BarDFlag, DofMeanFlag);
  }
  if (is.null(ListsdRFlags)) {
     ListsdRFlags = ListRFlags;
  }
  
  NameSummaryFile <- paste(FileString, ExtraName, "Sum", 
    paste(ListRFlagsBit(ListRFlags), collapse=""),sep="");
  for (ii in 1:length(listOutSimAnalyses)) {
    KName = listOutSimAnalyses[[ii]]$MethodName;
    print(paste("For OutSimAnalysis ii = ", ii, ", KName = ",
      paste(KName, collapse=""), sep=""));
    KName = paste(unlist(strsplit(KName, " ")), collapse="");
    KName = paste(unlist(strsplit(KName, "\\(")), collapse="");
    KName = paste(unlist(strsplit(KName, "\\)")), collapse="");    
    NameSummaryFile = paste(NameSummaryFile, 
      paste(KName,collapse=""), sep="");
  }
  FNameSummaryFile = paste(NameSummaryFile, ".tex",sep="");
  print(paste("Save to FNameSummaryFile = ", FNameSummaryFile, sep=""));
  flush.console();
  FirstLine = "\\begin{table*}[htbp] \n";
  SecondLine = paste("\\begin{tablular*}{l",
    paste(rep("|c", length(ListRFlags)), collapse=""), "|} \n", sep="");
  Caption=paste("\\caption{", 
    CaptionString, "} \n", sep="");
  LabelLine = paste("\\label{tabl:", NameSummaryFile, "} \n", sep="");
  LastLine = "\\end{table*}"
  
  BoxString = "\\hline ";
  for (ii in 1:length(listOutSimAnalyses)) {
    if (!is.null(HLineList) && 
      length(HLineList) == length(listOutSimAnalyses)  &&
      HLineList[ii] == 1) {
      BoxString = paste(BoxString, " \\hline ")
    }
    NewBoxLine =  BoxedOneLine(listOutSimAnalyses[[ii]], ListRFlags = ListRFlags, 
     ListsdRFlags = ListsdRFlags,na.rm=na.rm, TrueParams = TrueParams,
     TargetColErrorNames = TargetColErrorNames);
    BoxString = paste(BoxString, " \n ", NewBoxLine
     , sep="");
  }
  BoxString = paste(BoxString, " \\hline \n", sep="");
  MyF <- NULL;
  try(MyF <- file(paste(SaveDir, "//", FNameSummaryFile, sep=""), "wt"));
  if (is.null(MyF)) {
    print(paste("Error opening ", paste(SaveDir, "//", FNameSummaryFile, sep=""),
      " cannot save the file so quitting \n"));
    return(-1);
  }
  LabelLine = paste( ListRFlags, collapse = " & " );
  LabelLine = paste( LabelLine, "\\\\ \\hline", sep="");
  writeLines(text=FirstLine, con = MyF);
  writeLines(text=SecondLine, con = MyF);
  writeLines(text=LabelLine, con=MyF);
  writeLines(text=BoxString, con = MyF);
  writeLines(text="\\end{tabular}", con = MyF);
  writeLines(text=Caption, con = MyF);
  writeLines(text=LabelLine, con = MyF);
  writeLines(text=LastLine, con = MyF);
  close(MyF);
  if (verbose == TRUE) {
    print("Finished Printing to file."); flush.console();
  }
  return;
}                                     
ListRFlagsBit <- function(ListRFlags) {
  MyAns = rep(0, length(Lister));
  MyAns[match(ListRFlags, Lister)] = 1;
  return(MyAns);
}
Flagger <- function(L2Flag  = TRUE, L1Flag = TRUE, L0Flag = TRUE,
  Type1Flag = FALSE, Type2Flag = FALSE, 
  OutQuantFlag = FALSE, CIWidthFlag = FALSE, TimeFlag = FALSE,
  DICFlag=FALSE,
  PIDFlag = FALSE, BarDFlag = FALSE, DofMeanFlag = FALSE) {
  SubList = c();
  if (L2Flag == TRUE) {SubList = c(SubList, "L2");}
  if (L1Flag == TRUE) {SubList = c(SubList, "L1");}
  if (L0Flag == TRUE) {SubList = c(SubList, "L0");}
  if (Type1Flag == TRUE) {SubList = c(SubList, "Type1");}
  if (Type2Flag == TRUE) {SubList = c(SubList, "Type2");}
  if (OutQuantFlag == TRUE) {SubList = c(SubList, "OutQuant");}
  if (CIWidthFlag == TRUE) {SubList = c(SubList, "CIWidth");}
  if (TimeFlag == TRUE) {SubList = c(SubList, "time");}
  if (DICFlag == TRUE) {SubList = c(SubList, "L2");}
  if (PIDFlag == TRUE) {SubList = c(SubList, "PID");}
  if (BarDFlag == TRUE) {SubList = c(SubList, "BarDFlag");}
  if (DofMeanFlag == TRUE) {SubList = c(SubList, "DofMeanFlag");}  
  return(SubList);
}
Lister = c("L2", "L1", "L0", "Type1", "Type2", "OutQuant",
  "CIWidth", "time", "DIC", "PID", "BarD", "DofMeanFlag");



SummarizeString <- function(column,na.rm=TRUE, giveSD = TRUE) {
  if (is.null(column) || length(column) == 0) {
    return(" -- ")
  }
  MCol = rd0(mean(column,na.rm = na.rm));
  sdCol = rd0(sd(column,na.rm = na.rm));
  if (giveSD == TRUE) {
    return(paste("$", MCol,"$","(", "$", sdCol, "$", ")", sep="")); 
  } else {
    return(paste("$", MCol, "$", sep=""));
  }
}
#####################################################################################
###  rd0 is a function for Latex formatting of numbers to reduce their space occupied in tables
###
###
rd0 <- function(RoundNumber) {
  
if (length(RoundNumber) == 1) {
  if (is.null(RoundNumber)) {
    return("Nil");
  } 
  if (is.na(RoundNumber) || is.nan(RoundNumber)) {
    return("NA");
  }
  if (RoundNumber >= .001 && RoundNumber < 1) {
       MSSplit <- unlist(strsplit(as.character(round(RoundNumber,2)), "\\."));
       if (length(MSSplit) == 1) {  
          MSSplit <- c(MSSplit,"0");
       }
     return( paste( ".", 
       (MSSplit)[2], sep=""));
  } else if (RoundNumber >= 100) {
     L2 <- floor(log(RoundNumber,10));
     MSSplit <- unlist(strsplit(as.character(round(RoundNumber/10^(L2),1)), "\\."));
     if (length(MSSplit) == 1) {
        MSSplit <- c( MSSplit,"0");
     }
      return( paste("\\mbox{", MSSplit[1],".","{\\footnotesize", MSSplit[2],
            "e", L2, "", "\\normalsize}}", sep="") );
  } else if (RoundNumber >= 10) {
     MSSplit <- unlist(strsplit(as.character(round(RoundNumber,1)), "\\."));
     if (length(MSSplit) == 1) {  
          MSSplit <- c(MSSplit,"0");
       }
    return( paste("\\mbox{", MSSplit[1],".","{\\footnotesize", MSSplit[2],"\\normalsize}}", sep="") );
  }  else if (RoundNumber >= 1 && RoundNumber < 10) {
    MSSplit <- unlist(strsplit(as.character(round(RoundNumber,2)), "\\."));
     if (length(MSSplit) == 1) {  
          MSSplit <- c(MSSplit,"0");
       }    
    return( paste("\\mbox{", MSSplit[1],".","{\\footnotesize", MSSplit[2],"\\normalsize}}", sep="") );    
  } else if (RoundNumber > 0 && RoundNumber < .001) {
     L2 <- floor(log(RoundNumber,10));
     MSSplit <- unlist(strsplit(as.character(round(RoundNumber/10^(L2),1)), "\\."));
     if (length(MSSplit) == 1) {
        MSSplit <- c( MSSplit,"0");
     }
      return( paste("\\mbox{", MSSplit[1],".","{\\footnotesize", MSSplit[2],
            "e", L2, "", "\\normalsize}}", sep="") ); 
  } else if (RoundNumber == 0) {
     return("\\mbox{0.\\footnotesize{0}}");  
  } else {
     return(as.character(round(RoundNumber,2)));
    }
  } else {
    RTV <- RoundNumber;
    for (ii in 1:length(RoundNumber)) {
       RTV[ii] = rd0(RoundNumber[ii]);
    }
    return(RTV);
    RTV[RoundNumber >= 0 & RoundNumber < 1] <- 
      paste( ".", (unlist(strsplit(as.character(
      RoundNumber[RoundNumber >= 0 & RoundNumber < 1]), "\\."))[2]), 
      sep="")
     MSSplit <- unlist(strsplit(as.character(round(RoundNumber[RoundNumber 
       >= 1 & RoundNumber < 10],2)), "\\."));
     RTV[RoundNumber >= 1 & RoundNumber < 10] <- paste("\\mbox{", 
       MSSplit[1],".","{\\footnotesize", MSSplit[2],"\\normalsize}}", sep="");       
     MSSplit <- unlist(strsplit(as.character(round(RoundNumber[
       RoundNumber >= 10],1)), "\\."));
     RTV[RoundNumber >= 10] <- paste("\\mbox{", MSSplit[1],".",
       "{\\footnotesize", MSSplit[2],"\\normalsize}}", sep="");
     return(RTV);
  }
}


