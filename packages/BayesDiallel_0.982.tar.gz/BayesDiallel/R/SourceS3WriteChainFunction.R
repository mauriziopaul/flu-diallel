##
## SourceS3WriteChainFunction.R
##
##
## Created by Alan Lenarcic on 9/10/10.
## Copyright 2010 __MyCompanyName__. All rights reserved.
##
##
##   WriteAndRunChain
##
##    This attempts to defy the usual limits of R code by creating a precompiled file
##    It is about a 50% runtime improvment, for the penalty of extremely unreadable code.
##
setMethodS3("WriteAndRunChain", "DiallelOb", function(this, AFD =NULL, ChainIter=1, ...) {
  functiontext = paste("this$RunWrittenChain = function(ChainIter, CO) { ");
##  functiontext = "";
##functiontext= paste(functiontext, "}", sep="\n");
  ChainLength = length(this$CodaChains[[1]][,1]);
  preamble = paste("this$T1[[ChainIter]] = proc.time();", sep="");
  if (!is.null(this$dfTNoise) && this$dfTNoise > 0) {
  preamble =  paste(preamble, 
  "     VecOWeights = rep(1, length(AFD$Y));
        X = AFD$X[,this$XSubSetList]
        Y = AFD$Y", sep="\n");
  }
  dfTNoise = this$dfTNoise;
  preamble = paste(preamble,
     paste("nnn = ", length(AFD$Y), sep=""), sep="\n");
  if (is.null(AFD$XtX)) {
    AFD$XtX = t(AFD$X) %*% AFD$X;
  }
  preamble =  paste(preamble, " XtX = AFD$XtX[this$XSubSetList, this$XSubSetList] ", sep="\n"); 
  if (is.null(AFD$XtY)) {
    AFD$XtY = t(AFD$X) %*% AFD$Y;
  }
  preamble = paste(preamble, " XtY = matrix(AFD$XtY[this$XSubSetList],length(this$XSubSetList),1); ", sep="\n"); 
  if (is.null(AFD$sumYSq)) {
    AFD$sumYSq = sum(AFD$Y^2);
  }  
  preamble = paste(preamble, " sumYSq = AFD$sumYSq ", sep="\n"); 
  
  if (length(this$NetBetas) <= 0) { CreateNetBetas(this); }
  if(is.null(this$CodaChains)) {
    throw("Error, Coda Chains are Null")
  }
  
  preamble = paste(preamble, 
                   "        this$Beta[is.nan(this$Beta)] = 0;
                   this$tau[is.nan(this$tau)] = 1;
                   this$Sigma[is.nan(this$Sigma)] = 1;", sep="\n");
  preamble = paste(preamble, 
                   "        ChainLength = 
                   length( (this$CodaChains[[ChainIter]])[,1] );", sep="\n");
  if (!is.null(this$WeightsChains)) {
      preamble = paste(preamble,
        "FakeWeightsChains = this$WeightsChains[[ChainIter]];", sep="\n");
  }
  
  TempData = ""
  TempData = paste(TempData, 
"          Beta = this$Beta;
          otau = this$tau;
          oSigma = this$Sigma
          oDpBeta = this$DpBeta
          otau = this$tau
          dftau = this$dftau
          mtau = this$mtau
          NeedF = this$NeedF
          colSumsDpBeta = this$colSumsDpBeta;
          tauFixed = this$.tauFixed;
          mSigma = AFD$m$Sigma;
          dfSigma = AFD$df$Sigma;
          FakeChain = this$CodaChains[[ChainIter]];",
##    "print(paste(\"tauFixed: \", paste(tauFixed, collapse=\", \"), sep=\"\"))",
                  sep="\n");
  if (is.null(this$tauCrosses)) {
TempData =   paste(TempData, 
"         tauCrosses = this$tauCrosses;
         jCross = CO$jCross;
         kCross = CO$kCross;
         jCrossO = CO$jCrossO;
         KDAll = CO$KDAll;
         KDAlt = CO$KDAlt;", sep="\n");
  }
  if (!is.null(this$NetBetas)) {
  TempData = paste(TempData,
"         NetBetas = this$NetBetas ", sep="\n");
  }
  
  if (length(this$Beta) != dim(this$DpBeta)[1]) {
    throw("Beta and DpBeta not Compatible, sorry");
  }
    
  InForLoop = 
"     Beta[is.nan(Beta)] = 0; "
if (!is.null(this$dfTNoise) && this$dfTNoise > 0) {
  InForLoop = paste(InForLoop,
"     sumYSq = sum(VecOWeights * Y^2);
      VecOWeights = as.numeric(VecOWeights);
      XtX = t(X) %*% (VecOWeights * X);
      XtY = t(X) %*% (VecOWeights * Y);", sep="\n");
}
  ##    print(paste(\"Length VecOWeights = \", length(VecOWeights), sep=\"\"));
  ##    print(paste(\"Dim X = \", 
  ##       paste(dim(X), collapse=\", \"), sep=\"\"));

if (!is.null(this$Hacktau)) { this$tau = this$HackTau; } else {
  InForLoop = paste(InForLoop,
"    otau = (mtau + (Beta^2 %*% oDpBeta / 2)[NeedF])/
    rgamma( length(dftau), dftau + colSumsDpBeta[NeedF] / 2)",
                    sep="\n");
}
##InForLoop = paste(InForLoop,
## "print(paste(\"NeedF: \", paste(NeedF, collapse=\", \"), sep=\"\"))",
## "print(paste(\"Beta: \", paste(Beta, collapse=\", \"), sep=\"\"))",
## "print(paste(\"colSumsDpBeta: \", paste(colSumsDpBeta, collapse=\", \"), sep=\"\"))", 
## "print(paste(\"dftau: \", paste(dftau, collapse=\", \"), sep=\"\"))", 
## sep="\n")
 
InForLoop = paste(InForLoop,
"    MyWantDiag = as.vector( oDpBeta %*%
      as.vector(1/c(tauFixed, otau)));", sep="\n");
InForLoop = paste(InForLoop,
  WriteFillCrossWantDiag(this, CO), sep="\n");

if (MaxInv < length(this$Beta)) {
InForLoop = paste(InForLoop,
"    XtYResid = XtY - XtX %*% Beta;
", 
paste(
"     for (jjGroup in 1:", length(this$NetBetas), ") {", sep=""),
paste("  if (length(NetBetas[[jjGroup]]) == 0) {
         } else if (length(NetBetas[[jjGroup]]) <= 0) {
             SSet = NetBetas[[jjGroup]];
             QSmall = XtX[SSet,SSet] + Sigma * diag( MyWantDiag[SSet] );
			       SQSmall = try(solve(QSmall), silent=TRUE);
			       if (length(SQSmall) <= 4 || is.null(dim(SQSmall))) {
		 			     SQSmall = pseudoinverse(QSmall);	
		  	     }
	 		       SimMatSmall = try( sqrt(Sigma) * t(chol(SQSmall)) );
			       if (length(SimMatSmall) <= 4 || is.null(dim(SimMatSmall))) {
				       SimMatSmall = diag(sqrt(Sigma *diag(SQSmall)));
			       }
			       BetaNew = SQSmall %*% (
					       XtYResid[SSet] + XtX[SSet,SSet] %*% Beta[SSet]) +
					       SimMatSmall  %*% rnorm( length(SimMatSmall[,1]),0,1);
			       XtYResid = XtYResid + XtX[,SSet] %*% 
                      (Beta[SSet] - BetaNew);
			       Beta[SSet] = BetaNew;            
         } else {
             Resamp = sample(NetBetas[[jjGroup]], 
                              size= length(NetBetas[[jjGroup]]), replace=FALSE);
			       IDD = ceiling( length(Resamp) / MaxInv);
			       Ends = round((length(Resamp)/IDD) * (1:IDD))
		         for (jti in 1:length(Ends)) {
                 if (jti == 1) { SetI = 1:Ends[1] 
                 } else {SetI = (Ends[jti-1]+1):Ends[jti]}
			       SSet = Resamp[SetI];
			       QSmall = XtX[SSet,SSet] + Sigma * diag( MyWantDiag[SSet] );
			       SQSmall = try(solve(QSmall), silent=TRUE);
			       if (length(SQSmall) <= 4 || is.null(dim(SQSmall))) {
				       SQSmall = pseudoinverse(QSmall);	
			       }
			       SimMatSmall = try( sqrt(Sigma) * t(chol(SQSmall)) );
			       if (length(SimMatSmall) <= 4 || is.null(dim(SimMatSmall))) {
				 	     ##print(\"Went To diag Mistake\" );
				       SimMatSmall = diag(sqrt(Sigma *diag(SQSmall)));
			       }
			       BetaNew = SQSmall %*% (XtYResid[SSet] +
							 XtX[SSet,SSet] %*% Beta[SSet]) +
			                 SimMatSmall  %*% rnorm( length(SimMatSmall[,1]),0,1);
			       XtYResid = XtYResid + XtX[,SSet] %*%
                                      (Beta[SSet] - BetaNew);
			       Beta[SSet] = BetaNew;         
         }
}", sep=""), 
sep="\n"
);
} else {
InForLoop = paste(InForLoop,
"			 Q = XtX + oSigma *  diag( MyWantDiag );
			 SQ = try(solve(Q), silent=TRUE);
			 if (length(SQ) <= 4 || is.null(dim(SQ)) ) {
				 SQ <- try(pseudoinverse(Q));	
			 }
			
			 SimMat2 = try( sqrt(oSigma) * t(chol(SQ)),silent=TRUE );
			 if (length(SimMat2) <= 4 || is.null(dim(SimMat2))) {
			   if (dim(SQ) <= 2 || is.null(SQ)) {
           print(\"SQ cannot be diagonalized\"); flush.console();
         }
			 	 SimMat = diag( sqrt(oSigma) * sqrt(diag(SQ)) );	
			 } else {
				 SimMat = SimMat2;
			 }
			 Beta =  
           as.vector(crossprod(SQ, XtY) + crossprod(SimMat, rnorm( length(SimMat[,1]),0,1)));
", sep="\n");
}
InForLoop = paste(InForLoop,
"SumDeviation = as.numeric(sumYSq - 2 * sum(Beta * XtY) +
		         sum(Beta * crossprod(XtX, Beta)));
		oSigma = as.numeric(
        (mSigma + SumDeviation) /  
           rchisq(1,  dfSigma + nnn));
", sep="\n");

if (!is.null(this$dfTNoise) && this$dfTNoise > 0) {
InForLoop = paste(InForLoop,
paste( "VecOWeights = ((Y-X%*%Beta)^2/oSigma + ", dfTNoise, ") /
           rchisq(nnn, ", dfTNoise+1, ")", sep=""),
  sep="\n");
  if (!is.null(this$WeightsChains)) {
      InForLoop = paste(InForLoop,
     "FakeWeightsChains[ii,] = VecOWeights; ", sep="\n");
  }
}

if (!is.list(this$CodaChains)) {
InForLoop = paste(InForLoop, 
"   this$CodaChains[ii,] = c(Beta, otau, tauCrosses, oSigma); ", sep="\n");
} else {
InForLoop = paste(InForLoop, 
##paste("   FakeCodaChain[ii,] = 
##        c(Beta, otau, tauCrosses, oSigma); ", sep=""), sep="\n");
paste("   FakeChain[ii,] = 
        c(Beta, otau, tauCrosses, oSigma); ", sep=""), sep="\n");

} 

functiontext = paste(functiontext,
 preamble,
 TempData, 
 paste(" for( ii in 1:",ChainLength,") {", sep=""),
 InForLoop,
 "}",
 "this$Beta[1:length(Beta)] = Beta
  this$tau[1:length(otau)] = otau
  this$Sigma[1:length(this$Sigma)] = oSigma",
  paste("this$CodaChains[[", ChainIter, "]] = FakeChain", sep=""),
   sep="\n");
 if (is.null(this$WeigthsChains)) {
 functiontext = paste(functiontext,
   paste("this$WeightsChains[[", ChainIter, "]] = FakeWeightsChains;", sep=""), sep="\n");
 }
 if (!is.null(this$tauCrosses)) {
 functiontext =  paste(functiontext,
 "this$tauCrosses = tauCrosses", sep="\n");
 }
 functiontext=paste(functiontext,
  paste("this$T2[[ChainIter]] = proc.time();", sep=""),
  "}", sep="\n");
eval(parse(text=functiontext));

});
### 919-448-4262




################################################################################
###    Cross Impute Methods
###
###      -- Gibbs Sampler inputes "tau_j" and "tau_k" specific effects
###     for off diagonals.
###
setMethodS3("WriteCrossImpute", "DiallelOb", function(this, CO, ...) {
   .numj = this$.numj;
  Onumj = 0; 
  if (this$.BetaInbredLevel >= 2) { UseDiag = FALSE; } else { UseDiag = TRUE;}
              
 ImputeFuncs = list(WCross36Impute, WCross47Impute, WCross9Impute, WCross10Impute);
 if (this$.CrossModel %in% c(3,6)) { Group  = 1; 
 } else if (this$.CrossModel %in% c(4,7)) { Group  = 2; 
 } else if (this$.CrossModel %in% c(9)) { Group  = 3; 
 } else if (this$.CrossModel %in% c(10)) { Group  = 4; 
 } else { return; } 
              
 Func = ImputeFuncs[[Group]];

 CrossImputeText = ""
              
 for (ii in 1:length(this$tauCrossName)) {
CrossImputeText = paste(CrossImputeText,
   Func(this, EndRelBetas =this$.TDLenBeta[this$.TAUUseNames == this$tauCrossName[ii]],
        EndToggle=Onumj + .numj, UseDiag=UseDiag, CrossName=this$tauCrossName[ii], 
        intCross = ii, CO=CO), sep="\n");
        Onumj = Onumj + .numj;
 }
 return(CrossImputeText);
}); 
  
  
setMethodS3("WCross36Impute", "DiallelOb",  
              function(this, EndRelBetas, 
                       EndToggle, UseDiag = FALSE, 
                       CrossName = "SymCrossjk", 
                       intCross = 1, CO=NULL,...) {
TxT = paste("Fun1 = ", EndToggle-this$.numj +1, ":",
               EndToggle, sep="");
TxT = paste(TxT,
"    FunDiag1 = 1/tauCrosses[Fun1];", sep="\n");
TxT = paste(TxT,              
paste("ZCross3 = matrix( Beta[",
      EndRelBetas - (this$.numj * (this$.numj+1))/2,
      " + KDAlt], ", this$.numj, ", ", this$.numj, ");", sep=""),
     sep="\n");
if (UseDiag == TRUE && CrossName %in%c("SymCrossjk", "GendSymCrossjk")) {
TxT = paste(TxT, 
  paste("tauCrosses[Fun1] = (mCrosses[",intCross,"]
      + colSums(FunDiag1 * ZCrosse^2)/2) /
      rgamma(length(Fun1), dfCrosses[",intCross,"] + ", this$.numj/2,");",
        sep=""), sep="\n");
} else {
TxT = paste(TxT,
 paste("diag(ZCross3) = 0;
   tauCrosses[Fun1] = (mCrosses[",intCross,"] +
       colSums(FunDiag1 * ZCross3^2)/2) /
       rgamma(length(Fun1), dfCrosses[", intCross,"] + ",
       (this$.numj-1)/2, ");", sep=""), sep="\n");
}
return(TxT);
              });
  
setMethodS3("WCross10Impute", "DiallelOb", 
              function(tauCrosses, EndRelBetas, EndToggle, 
                       UseDiag = FALSE, CrossName="AllCrossjk", 
                       intCross = 1, CO = NULL,...) {
numj = this$.numj;
TxT = paste("Fun1 = ", EndToggle-this$.numj +1, ":",
        EndToggle, sep="");

TxT = paste(TxT,              
   paste("ZCross4a = matrix( Beta[",
      EndRelBetas - this$.numj^2,
      " + KDAll], ", this$.numj, ", ", this$.numj, ");", sep=""),
   sep="\n");
TxT = paste(TxT,              
    paste("ZCross4b = matrix( Beta[",
    EndRelBetas - this$.numj^2,
    " + t(KDAll)], ", this$.numj, ", ", 
    this$.numj, ");", sep=""),
    sep="\n");
TxT = paste(TxT,              
    paste("FMAT =  1 / matrix( rep(tauCrosses[Fun1], each=", this$.numj,")
    + rep(tauCrosses[Fun1], ", this$.numj,"), ", this$.numj, ", ", this$.numj,");",
     sep=""), sep="\n");

TxT = paste(TxT,
  paste("ZCross4a = tauCrosses[Fun1] * ZCross4a * FMAT +
   sqrt( (tauCrosses[Fun1] %*% t(tauCrosses[Fun1]) ) * FMAT) *
   matrix(rnorm(", this$.numj*this$.numj, "), ", numj, ", ", numj, ");",
    sep=""), sep="\n");
TxT = paste(TxT,
  paste("ZCross4b = tauCrosses[Fun1] * ZCross4b * FMAT +
   sqrt( (tauCrosses[Fun1] %*% t(tauCrosses[Fun1]) ) * FMAT) *
   matrix(rnorm(", this$.numj*this$.numj, "), ", numj, ", ", numj, ");",
    sep=""), sep="\n");
              
if (UseDiag == TRUE) {
TxT = paste(TxT,
  paste("diag(ZCross4a) = Beta[", EndRelBetas-(numj^2)," + diag(KDAll) ] / 2;
  diag(ZCross4b) = 0;
  tauCrosses[Fun1] = (mCrosses[intCross] + rowSums(ZCross4a^2) / 2 +
      rowSums(ZCross4b^2) /2 ) / 
      rgamma( length(Fun1), dfCrosses[intCross] + ",
      (numj + numj-1)/2, ");", sep=""), sep="\n");
} else {
TxT = paste(TxT,
  paste("diag(ZCross4a) = 0;
  diag(ZCross4b) = 0;
  tauCrosses[Fun1] = (mCrosses[intCross] + rowSums(ZCross4a^2) / 2 +
      rowSums(ZCross4b^2) /2 ) / 
      rgamma( length(Fun1), dfCrosses[intCross] + ",
      (numj -1 + numj-1)/2, ");", sep=""), sep="\n");
}
return(TxT);
});
setMethodS3("WCross47Impute", "DiallelOb", 
              function(tauCrosses, EndRelBetas, EndToggle, 
                       UseDiag = FALSE, CrossName="SymCrossjk", 
                       intCross = 1, CO = NULL,...) {
numj = this$.numj;
TxT = paste("Fun1 = ", EndToggle-this$.numj +1, ":",
        EndToggle, sep="");

TxT = paste(TxT,              
   paste("ZCross4 = matrix( Beta[",
      EndRelBetas - (this$.numj * (this$.numj+1))/2,
      " + KDAlt], ", this$.numj, ", ", this$.numj, ");", sep=""),
   sep="\n");
TxT = paste(TxT,              
    paste("FMAT =  1 / matrix( rep(tauCrosses[Fun1], each=", this$.numj,")
    + rep(tauCrosses[Fun1], ", this$.numj,", ", this$.numj, ", ", this$.numj,");",
     sep=""), sep="\n");

TxT = paste(TxT,
  paste("ZCross4 = tauCrosses[Fun1] * ZCross4 * FMAT +
   sqrt( (tauCrosses[Fun1] %*% t(tauCrosses[Fun1]) ) * FMAT) *
   matrix(rnorm(", this$.numj*this$.numj, "), ", numj, ", ", numj, ");",
    sep=""), sep="\n");
if (UseDiag == TRUE && CrossName %in% c("SymCrossjk", "GendSymCrossjk")) {
TxT = paste(TxT,
  paste("diag(ZCross4) = Beta[", EndRelBetas-(numj*(numj+1)/2)," + diag(KDAlt) ] / 2;
  tauCrosses[Fun1] = (mCrosses[intCross] + rowSums(ZCross4^2) / 2  ) / 
      rgamma( length(Fun1), dfCrosses[intCross] + ",
      (numj)/2, ");", sep=""), sep="\n");
} else {
TxT = paste(TxT,
  paste("diag(ZCross4) = 0;
  tauCrosses[Fun1] = (mCrosses[intCross] + rowSums(ZCross4^2) / 2 ) / 
      rgamma( length(Fun1), dfCrosses[intCross] + ",
      (numj -1)/2, ");", sep=""), sep="\n");
}
return(TxT);
});
setMethodS3("WCross9Impute", "DiallelOb", 
              function(tauCrosses, EndRelBetas, EndToggle, 
                       UseDiag = FALSE, CrossName="AllCrossjk", 
                       intCross = 1, CO = NULL,...) {
numj = this$.numj;
TxT = paste("Fun1 = ", EndToggle-this$.numj +1, ":",
        EndToggle, sep="");
TxT = paste(TxT,
"    FunDiag1 = 1/tauCrosses[Fun1];", sep="\n");
TxT = paste(TxT,              
   paste("ZCross3a = matrix( Beta[",
      EndRelBetas - this$.numj^2,
      " + KDAll], ", this$.numj, ", ", this$.numj, ");", sep=""),
   sep="\n");
TxT = paste(TxT,              
    paste("ZCross3b = matrix( Beta[",
    EndRelBetas - this$.numj^2,
    " + t(KDAll)], ", this$.numj, ", ", 
    this$.numj, ");", sep=""),
    sep="\n");
              
if (UseDiag == TRUE) {
TxT = paste(TxT,
  paste("diag(ZCross3b) = 0;
  tauCrosses[Fun1] = (mCrosses[intCross] + rowSums(ZCross3a^2) / 2 +
      rowSums(ZCross3b^2) /2 ) / 
      rgamma( length(Fun1), dfCrosses[intCross] + ",
      (numj + numj-1)/2, ");", sep=""), sep="\n");
} else {
TxT = paste(TxT,
  paste("diag(ZCross3a) = 0;
  diag(ZCross3b) = 0;
  tauCrosses[Fun1] = (mCrosses[intCross] + rowSums(ZCross3a^2) / 2 +
      rowSums(ZCross3b^2) /2 ) / 
      rgamma( length(Fun1), dfCrosses[intCross] + ",
      (numj -1 + numj-1)/2, ");", sep=""), sep="\n");
}
return(TxT);
});

################################################################################
###    WriteFillCrossWantDiag
###
###      -- Fills MyDiag at a certain point
###    
###
setMethodS3("WriteFillCrossWantDiag", "DiallelOb", function(this, CO, ...) {
  .numj = this$.numj;
	Onumj = 0; 
	if (this$.BetaInbredLevel >= 2) { UseDiag = FALSE; } else { UseDiag = TRUE;}
	
	FillFuncs = list(WFill36Diag, WFill47Diag, WFill9Diag, WFill10Diag);
	if (this$.CrossModel %in% c(3,6)) { Group  = 1; 
	} else if (this$.CrossModel %in% c(4,7)) { Group  = 2; 
	} else if (this$.CrossModel %in% c(9)) { Group  = 3; 
 	} else if (this$.CrossModel %in% c(10)) { Group  = 4; 
  } else { return(""); } 

  Func = FillFuncs[[Group]];
  FillText = "";

  for (ii in 1:length(this$tauCrossName)) {
   FillText = paste(FillText,
   Func(this, EndRelBetas =this$.TDLenBeta[this$.TAUUseNames == this$tauCrossName[ii]],
        EndToggle=Onumj + .numj, UseDiag=UseDiag, CrossName=this$tauCrossName[ii], 
        intCross = ii, CO=CO), sep="\n");
        Onumj = Onumj + .numj;  
  }
  return(FillText);
}); 



setMethodS3("WFill9Diag", "DiallelOb", function(
  this, EndRelBetas, EndToggle, UseDiag = FALSE, CrossName,
  intCross, CO, ...) {
  MyText = 
	   paste(" Fun1 = ", EndToggle - this$.numj + 1,":", EndToggle, sep="");
  MyText = paste(MyText,
" 
	tauUse = this$tauCrosses[Fun1];
	MtauUse = matrix(tauUse,length(tauUse),1) %*% 
              matrix(tauUse,1,length(tauUse));
", sep="\n");

	if (UseDiag == TRUE) {
MyText = paste(MyText,
   paste("MyWantDiag[", EndRelBetas-(this$.numj)^2+1,":", EndRelBetas,"] = ",
   " 1 / MtauUse[cbind(c(iCross, jCrossO),
                       c(jCross, iCrossO))];", sep=""), sep="\n");

	} else {
MyText = paste(MyText,
   paste("MyWantDiag[", EndRelBetas-(this$.numj)^2+this$.numj+ 1,":", EndRelBetas,"] = ",
   " 1 / MtauUse[cbind(c(iCross/o, jCrossO),
                       c(jCross/o, iCrossO))];", sep=""), sep="\n");  
   
	}	
  return(MyText);	
});


setMethodS3("WFill36Diag", "DiallelOb",
   function(this, EndRelBetas, EndToggle, 
   UseDiag = FALSE, 
   CrossName = "SymCrossjk", CO = NULL,...) {
MyText = 
	   paste(" Fun1 = ", EndToggle - this$.numj + 1,":", EndToggle, sep="");
  MyText = paste(MyText,
" 
	tauUse = this$tauCrosses[Fun1];
	MtauUse = matrix(tauUse,length(tauUse),1) %*% 
              matrix(tauUse,1,length(tauUse));
", sep="\n");
	if (UseDiag == TRUE && CrossName %in% 
                 c("SymCrossjk", "GendSymCrossjk") ) {
MyText = paste(MyText,
   paste("MyWantDiag[", EndRelBetas-(this$.numj)*(this$.numj+1)/2+1,":", EndRelBetas,"] = ",
   " 1 / MtauUse[idCross];", sep=""), sep="\n");

	} else {
MyText = paste(MyText,
   paste("MyWantDiag[", EndRelBetas-(this$.numj)*(this$.numj-1)/2+1,":", EndRelBetas,"] = ",
   " 1 / MtauUse[idCrossO];", sep=""), sep="\n");  
   
	}	   
		
}    );

setMethodS3("WFill47Diag", "DiallelOb",
   function(this, EndRelBetas, EndToggle, 
   UseDiag = FALSE, 
   CrossName = "SymCrossjk", CO = NULL,...) {
MyText = 
	   paste(" Fun1 = ", EndToggle - this$.numj + 1,":", EndToggle, sep="");
  MyText = paste(MyText,
" 
	tauUse = this$tauCrosses[Fun1];
	MtauUse =  matrix(rep(tauUse, length(tauUse)),
              length(tauUse),length(tauUse)) + 
	             t(matrix(rep(tauUse, length(tauUse)),
                   length(tauUse),length(tauUse)));	
", sep="\n");
	if (UseDiag == TRUE && CrossName %in% 
                 c("SymCrossjk", "GendSymCrossjk") ) {
MyText = paste(MyText,
   paste("MyWantDiag[", EndRelBetas-(this$.numj)*(this$.numj+1)/2+1,":", EndRelBetas,"] = ",
   " 1 / MtauUse[idCross];", sep=""), sep="\n");

	} else {
MyText = paste(MyText,
   paste("MyWantDiag[", EndRelBetas-(this$.numj)*(this$.numj-1)/2+1,":", EndRelBetas,"] = ",
   " 1 / MtauUse[idCrossO];", sep=""), sep="\n");  
   
	}	   
		
}    );
setMethodS3("WFill10Diag", "DiallelOb",
   function(this, EndRelBetas, EndToggle, 
   UseDiag = FALSE, 
   CrossName = "SymCrossjk", CO = NULL,...) {
MyText = 
	   paste(" Fun1 = ", EndToggle - this$.numj + 1,":", EndToggle, sep="");
  MyText = paste(MyText,
" 
	tauUse = this$tauCrosses[Fun1];
	MtauUse =  matrix(rep(tauUse, length(tauUse)),
              length(tauUse),length(tauUse)) + 
	             t(matrix(rep(tauUse, length(tauUse)),
                   length(tauUse),length(tauUse)));	
", sep="\n");
	if (UseDiag == TRUE) {
MyText = paste(MyText,
   paste("MyWantDiag[", EndRelBetas-(this$.numj)^2+1,":", EndRelBetas,"] = ",
   " 1 / MtauUse[cbind(c(iCross, jCrossO),
                       c(jCross, iCrossO))];", sep=""), sep="\n");

	} else {
MyText = paste(MyText,
   paste("MyWantDiag[", EndRelBetas-(this$.numj)^2+this$.numj+ 1,":", EndRelBetas,"] = ",
   " 1 / MtauUse[cbind(c(iCross/o, jCrossO),
                       c(jCross/o, iCrossO))];", sep=""), sep="\n");  
   
	}		   
		
}    );



