pop.back <- function(x)
# returns the last element of the array, removing it in place
{
    r <- x[length(x)]
    eval.parent(substitute(x<-x[-length(x)]))
    return (r)
}

pop.front <- function(x)
# returns the first element of the array, removing it in place
{
    r <- x[1]
    eval.parent(substitute(x<-x[-1]))
    return (r)
}


push.back <- function(x,y)
# pushes y onto the back of array x
{
    if (is.list(x))
    {
        eval.parent(substitute(
                x[[(length(x)+1)]]<-y
                ))
    }
    else
    {
        eval.parent(substitute(
                x[ (length(x)+1):(length(x)+length(y))]<-y
                ))
    }
}

push.front <- function(x,y)
# pushes y onto the front of array x
{
    if (is.list(x))
    {
        stop("push.front() for list not yet implemented\n")
    }
    eval.parent(substitute(x<-c(y,x)))
}
