
PutInVaritabilityText <- function() {
  "
  Varitability <- array(0, dim=c(NROW(BetaajVSireChain), NCOL(BetaajVSireChain),5),
    dimnames=c(\"Rows\", \"Crosses\", \"Heritance Group\"));

  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (2*BetaajVSireChain[,jj] * Wtsj[[1]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            ) * ( pMix^2*(1-pMix^2)) +
            ( pMix^2*(1-pMix^2)) *
            rowSums(4*taus[,1] * (Wtsj[[1]]-Wtsj[[1]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] +
          rowSums(
            (2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            ) * ( pMix^2*(1-pMix^2)) +
            ( pMix^2*(1-pMix^2)) *
            rowSums(4*taus[,3] * (Wtsj[[3]]-Wtsj[[3]]^2))
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (2*BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            ) * ( ((1-pMix)^2-(1-pMix)^4)) +
            ( ((1-pMix)^2-(1-pMix)^4)) *
            rowSums(4*taus[,1] * (WtsJ[[1]]-WtsJ[[1]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] +
          rowSums(
            (2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            ) * ( ((1-pMix)^2-(1-pMix)^4)) +
            ( ((1-pMix)^2-(1-pMix)^4)) *
            rowSums(4*taus[,3] * (WtsJ[[3]]-WtsJ[[3]]^2))
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            ) * ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) +
            ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) *
            rowSums(taus[,1] * (Wtsj[[1]]-Wtsj[[1]]^2+WtsJ[[1]]-WtsJ[[1]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] +
          rowSums(
            (BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            ) * ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) +
            ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) *
            rowSums(taus[,2] * (Wtsj[[2]]-Wtsj[[2]]^2+WtsJ[[2]]-WtsJ[[2]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] +
          rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            ) * ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) +
            ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) *
            rowSums(taus[,4] * (Wtsj[[4]]-Wtsj[[4]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] +
          rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            ) * ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) +
            ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) *
            rowSums(.25 *taus[,5] * (Wtsj[[5]]-Wtsj[[5]]^2))
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            ) * ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) +
            ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) *
            rowSums(taus[,1] * (Wtsj[[1]]-Wtsj[[1]]^2+WtsJ[[1]]-WtsJ[[1]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] +
          rowSums(
            (BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            ) * ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) +
            ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) *
            rowSums(taus[,2] * (Wtsj[[2]]-Wtsj[[2]]^2+WtsJ[[2]]-WtsJ[[2]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] +
          rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            ) * ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) +
            ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) *
            rowSums(taus[,4] * (Wtsj[[4]]-Wtsj[[4]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] +
          rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            ) * ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) +
            ( (pMix*(1-pMix)-pMix^2*(1-pMix)^2)) *
            rowSums(.25 *taus[,5] * (Wtsj[[5]]-Wtsj[[5]]^2))
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (2*BetaajVSireChain[,jj] * Wtsj[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            ) * ( pMix^3*(1-pMix)*-1) +
            ( pMix^3*(1-pMix)*-1) *
            rowSums(taus[,1]*(Wtsj[[1]]-Wtsj[[1]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] + rowSums(
            (2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            ) * ( pMix^3*(1-pMix)*-1 );
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (2*BetaajVSireChain[,jj] * Wtsj[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            ) * ( pMix^3*(1-pMix)*-1) +
            ( pMix^3*(1-pMix)*-1) *
            rowSums(taus[,1]*(Wtsj[[1]]-Wtsj[[1]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] + rowSums(
            (2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            ) * ( pMix^3*(1-pMix)*-1 );
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] + rowSums(
            (2*BetaajVSireChain[,jj] * Wtsj[[1]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            ) * ( pMix^2*(1-pMix)^2*-1 );
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] + rowSums(
            (2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            ) * ( pMix^2*(1-pMix)^2*-1 );
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] + rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            ) * ( pMix^2*(1-pMix)^2*-1 );
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] +
          rowSums(
            (BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            ) * ( pMix^2*(1-pMix)^2*-1) +
            ( pMix^2*(1-pMix)^2*-1) *
            rowSums(taus[,2] * (Wtsj[[2]]-Wtsj[[2]]^2+WtsJ[[2]]-WtsJ[[2]]^2)*-1)
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] +
          rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            ) * ( pMix^2*(1-pMix)^2*-1) +
            ( pMix^2*(1-pMix)^2*-1) *
            rowSums(taus[,4]*(Wtsj[[4]]-Wtsj[[4]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] +
          rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            ) * ( pMix^2*(1-pMix)^2*-1) +
            ( pMix^2*(1-pMix)^2*-1) *
            rowSums(taus[,5]*(Wtsj[[5]]-Wtsj[[5]]^2)*-.25)
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            ) * ( pMix*(1-pMix)^3*-1) +
            ( pMix*(1-pMix)^3*-1) *
            rowSums(taus[,1]*(WtsJ[[1]]-WtsJ[[1]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] + rowSums(
            (BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            ) * ( pMix*(1-pMix)^3*-1 );
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] + rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            ) * ( pMix*(1-pMix)^3*-1 );
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] + rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            ) * ( pMix*(1-pMix)^3*-1 );
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            ) * ( pMix*(1-pMix)^3*-1) +
            ( pMix*(1-pMix)^3*-1) *
            rowSums(taus[,1]*(WtsJ[[1]]-WtsJ[[1]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] + rowSums(
            (BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            ) * ( pMix*(1-pMix)^3*-1 );
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] + rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            ) * ( pMix*(1-pMix)^3*-1 );
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] + rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            ) * ( pMix*(1-pMix)^3*-1 );
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            ) * ( pMix^3*(1-pMix)*-1) +
            ( pMix^3*(1-pMix)*-1) *
            rowSums(taus[,1]*(Wtsj[[1]]-Wtsj[[1]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] + rowSums(
            (BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            ) * ( pMix^3*(1-pMix)*-1 );
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] + rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            ) * ( pMix^3*(1-pMix)*-1 );
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] + rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            ) * ( pMix^3*(1-pMix)*-1 );
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            ) * ( pMix^3*(1-pMix)*-1) +
            ( pMix^3*(1-pMix)*-1) *
            rowSums(taus[,1]*(Wtsj[[1]]-Wtsj[[1]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] + rowSums(
            (BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            ) * ( pMix^3*(1-pMix)*-1 );
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] + rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            ) * ( pMix^3*(1-pMix)*-1 );
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] + rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            ) * ( pMix^3*(1-pMix)*-1 );
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] + rowSums(
            (2*BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            ) * ( pMix^2*(1-pMix)^2*-1 );
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] + rowSums(
            (2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            ) * ( pMix^2*(1-pMix)^2*-1 );
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] + rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            ) * ( pMix^2*(1-pMix)^2*-1 );
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] +
          rowSums(
            (BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            ) * ( pMix^2*(1-pMix)^2*-1) +
            ( pMix^2*(1-pMix)^2*-1) *
            rowSums(taus[,2] * (Wtsj[[2]]-Wtsj[[2]]^2+WtsJ[[2]]-WtsJ[[2]]^2)*-1)
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] +
          rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            ) * ( pMix^2*(1-pMix)^2*-1) +
            ( pMix^2*(1-pMix)^2*-1) *
            rowSums(taus[,4]*(Wtsj[[4]]-Wtsj[[4]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] +
          rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            ) * ( pMix^2*(1-pMix)^2*-1) +
            ( pMix^2*(1-pMix)^2*-1) *
            rowSums(taus[,5]*(Wtsj[[5]]-Wtsj[[5]]^2)*-.25)
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (2*BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            ) * ( pMix*(1-pMix)^3*-1) +
            ( pMix*(1-pMix)^3*-1) *
            rowSums(taus[,1]*(WtsJ[[1]]-WtsJ[[1]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] + rowSums(
            (2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            ) * ( pMix*(1-pMix)^3*-1 );
        }
        
  
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (2*BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            ) * ( pMix*(1-pMix)^3*-1) +
            ( pMix*(1-pMix)^3*-1) *
            rowSums(taus[,1]*(WtsJ[[1]]-WtsJ[[1]]^2))
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] + rowSums(
            (2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            ) * ( pMix*(1-pMix)^3*-1 );
        }
        
  
      pModSigmakK <-  2 * pMix^3*(1-pMix) * SigmakK  + pMix^2*(1-pMix)^2 * SigmakK^2;
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (2*BetaajVSireChain[,jj] * Wtsj[[1]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            %*% ( 2 * pMix^3*(1-pMix) * SigmakK  + pMix^2*(1-pMix)^2 * SigmakK^2)) +
            -4* taus[,1]*
         (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
          rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] +
          rowSums(
            (2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            %*% ( 2 * pMix^3*(1-pMix) * SigmakK  + pMix^2*(1-pMix)^2 * SigmakK^2)) +
            -4* taus[,3]*
         (rowSums(WtsJ[[3]] * (WtsJ[[3]]%*% pModSigmakK))+
          rowSums(Wtsj[[3]] * (Wtsj[[3]]%*% pModSigmakK)))
          
        }
        
  
      pModSigmakK <-  2 * pMix*(1-pMix)^3 * SigmakK  + pMix^2*(1-pMix)^2 * SigmakK^2;
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (2*BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            %*% ( 2 * pMix*(1-pMix)^3 * SigmakK  + pMix^2*(1-pMix)^2 * SigmakK^2)) +
            -4* taus[,1]*
         (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
          rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] +
          rowSums(
            (2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            %*% ( 2 * pMix*(1-pMix)^3 * SigmakK  + pMix^2*(1-pMix)^2 * SigmakK^2)) +
            -4* taus[,3]*
         (rowSums(WtsJ[[3]] * (WtsJ[[3]]%*% pModSigmakK))+
          rowSums(Wtsj[[3]] * (Wtsj[[3]]%*% pModSigmakK)))
          
        }
        
  
      pModSigmakK <-  pMix*(1-pMix)^2*( SigmakK^2-2*SigmakK)+ pMix * (1-pMix) * SigmakK;
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            %*% ( pMix*(1-pMix)^2*( SigmakK^2-2*SigmakK)+ pMix * (1-pMix) * SigmakK)) +
            -2* taus[,1]*
         (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
          rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] +
          rowSums(
            (BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            %*% ( pMix*(1-pMix)^2*( SigmakK^2-2*SigmakK)+ pMix * (1-pMix) * SigmakK)) +
            -2* taus[,2]*
         (rowSums(WtsJ[[2]] * (WtsJ[[2]]%*% pModSigmakK))+
          rowSums(Wtsj[[2]] * (Wtsj[[2]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] +
          rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            %*% ( pMix*(1-pMix)^2*( SigmakK^2-2*SigmakK)+ pMix * (1-pMix) * SigmakK)) +
            -1* taus[,4]*
         (rowSums(WtsJ[[4]] * (WtsJ[[4]]%*% pModSigmakK))+
          rowSums(Wtsj[[4]] * (Wtsj[[4]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] +
          rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            %*% ( pMix*(1-pMix)^2*( SigmakK^2-2*SigmakK)+ pMix * (1-pMix) * SigmakK)) +
            -0.25* taus[,5]*
         (rowSums(WtsJ[[5]] * (WtsJ[[5]]%*% pModSigmakK))+
          rowSums(Wtsj[[5]] * (Wtsj[[5]]%*% pModSigmakK)))
          
        }
        
  
      pModSigmakK <-  pMix*(1-pMix)^2*( SigmakK^2-2*SigmakK)+ pMix * (1-pMix) * SigmakK;
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            %*% ( pMix*(1-pMix)^2*( SigmakK^2-2*SigmakK)+ pMix * (1-pMix) * SigmakK)) +
            -2* taus[,1]*
         (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
          rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] +
          rowSums(
            (BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            %*% ( pMix*(1-pMix)^2*( SigmakK^2-2*SigmakK)+ pMix * (1-pMix) * SigmakK)) +
            -2* taus[,2]*
         (rowSums(WtsJ[[2]] * (WtsJ[[2]]%*% pModSigmakK))+
          rowSums(Wtsj[[2]] * (Wtsj[[2]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] +
          rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            %*% ( pMix*(1-pMix)^2*( SigmakK^2-2*SigmakK)+ pMix * (1-pMix) * SigmakK)) +
            -1* taus[,4]*
         (rowSums(WtsJ[[4]] * (WtsJ[[4]]%*% pModSigmakK))+
          rowSums(Wtsj[[4]] * (Wtsj[[4]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] +
          rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            %*% ( pMix*(1-pMix)^2*( SigmakK^2-2*SigmakK)+ pMix * (1-pMix) * SigmakK)) +
            -0.25* taus[,5]*
         (rowSums(WtsJ[[5]] * (WtsJ[[5]]%*% pModSigmakK))+
          rowSums(Wtsj[[5]] * (Wtsj[[5]]%*% pModSigmakK)))
          
        }
        
  
      pModSigmakK <-  pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK);
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (2*BetaajVSireChain[,jj] * Wtsj[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK))) +
            -1* taus[,1]*
         (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
          rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] + rowSums(
            (2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
  
      pModSigmakK <-  pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK);
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (2*BetaajVSireChain[,jj] * Wtsj[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK))) +
            -1* taus[,1]*
         (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
          rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] + rowSums(
            (2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
  
      pModSigmakK <-  pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK);
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] + rowSums(
            (2*BetaajVSireChain[,jj] * Wtsj[[1]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            %*% ( pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK) ));
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] + rowSums(
            (2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            %*% ( pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK) ));
        }
        
  
      pModSigmakK <-  pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK);
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            %*% ( pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK))) +
            -2* taus[,1]*
         (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
          rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] +
          rowSums(
            (BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            %*% ( pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK))) +
            -2* taus[,2]*
         (rowSums(WtsJ[[2]] * (WtsJ[[2]]%*% pModSigmakK))+
          rowSums(Wtsj[[2]] * (Wtsj[[2]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] + rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            %*% ( pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK) ));
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] +
          rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            %*% ( pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK))) +
            -0.25* taus[,5]*
         (rowSums(WtsJ[[5]] * (WtsJ[[5]]%*% pModSigmakK))+
          rowSums(Wtsj[[5]] * (Wtsj[[5]]%*% pModSigmakK)))
          
        }
        
  
      pModSigmakK <-  pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK);
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK))) +
            -1* taus[,1]*
         (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
          rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] + rowSums(
            (BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] + rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] + rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
  
      pModSigmakK <-  pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK);
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK))) +
            -1* taus[,1]*
         (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
          rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] + rowSums(
            (BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] + rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] + rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) * (
            ( 2*BetaajVDamChain[,jj] * WtsJ[[1]] + 
    2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
  
      pModSigmakK <-  pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK);
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK))) +
            -1* taus[,1]*
         (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
          rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] + rowSums(
            (BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] + rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] + rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
  
      pModSigmakK <-  pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK);
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK))) +
            -1* taus[,1]*
         (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
          rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] + rowSums(
            (BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] + rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] + rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
  
      pModSigmakK <-  pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK);
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] + rowSums(
            (2*BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            %*% ( pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK) ));
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] + rowSums(
            (2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) * (
            ( 2*BetaajVSireChain[,jj] * Wtsj[[1]] + 
    2*BetadominancejVSireChain[,jj] * Wtsj[[3]]) )
            %*% ( pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK) ));
        }
        
  
      pModSigmakK <-  pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK);
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] + rowSums(
            (BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            %*% ( pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK) ));
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,2] <- 
          Varitability[,jj,2] +
          rowSums(
            (BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            %*% ( pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK))) +
            -2* taus[,2]*
         (rowSums(WtsJ[[2]] * (WtsJ[[2]]%*% pModSigmakK))+
          rowSums(Wtsj[[2]] * (Wtsj[[2]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,4] <- 
          Varitability[,jj,4] + rowSums(
            (BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            %*% ( pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK) ));
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,5] <- 
          Varitability[,jj,5] +
          rowSums(
            (BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            %*% ( pMix^2*(1-pMix)^2*( SigmakK^2-2*SigmakK))) +
            -0.25* taus[,5]*
         (rowSums(WtsJ[[5]] * (WtsJ[[5]]%*% pModSigmakK))+
          rowSums(Wtsj[[5]] * (Wtsj[[5]]%*% pModSigmakK)))
          
        }
        
  
      pModSigmakK <-  pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK);
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (2*BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK))) +
            -1* taus[,1]*
         (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
          rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] + rowSums(
            (2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVSireChain[,jj] * Wtsj[[2]]-BetamotherjVDamChain[,jj] * WtsJ[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] * .5) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
  
      pModSigmakK <-  pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK);
      if (length(pModSigmakK) == 1  && pModSigmakK == 1) {
        SigmakK <- matrix(0, KDim, KDim);
      }
      
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,1] <- 
          Varitability[,jj,1] +
          rowSums(
            (2*BetaajVDamChain[,jj] * WtsJ[[1]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK))) +
            -1* taus[,1]*
         (rowSums(WtsJ[[1]] * (WtsJ[[1]]%*% pModSigmakK))+
          rowSums(Wtsj[[1]] * (Wtsj[[1]]%*% pModSigmakK)))
          
        }
        
        for (jj in 1:NCOL(BetaajVSireChain)) {
          Varitability[,jj,3] <- 
          Varitability[,jj,3] + rowSums(
            (2*BetadominancejVDamChain[,jj] * WtsJ[[3]]) * (
            ( BetaajVSireChain[,jj] * Wtsj[[1]]+ BetaajVDamChain[,jj] * WtsJ[[1]] + 
    BetamotherjVDamChain[,jj] * WtsJ[[2]]-BetamotherjVSireChain[,jj] * Wtsj[[2]] + 
    BetaSymCrossjkVMeChain[,jj] * Wtsj[[4]] + 
    BetaASymCrossjkDkjVMeChain[,jj] * Wtsj[[5]] *- .5) )
            %*% ( pMix*(1-pMix)^2*  SigmakK * (2*pMix-1-pMix* SigmakK) ));
        }
        
   "; } 
   
