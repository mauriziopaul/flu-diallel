
if (FALSE){
DT1 = DT[SexVector == 1,];
phenotype1 = "phenotype";
main1 = "females (Observed means)";
strain.names = MyMap[,2];
DT2 = AFDLNoNoise[AFDLNoNoise$Female==1,];
main2="females (predicted means)";
data.range = c(DT1$phenotype, DT2$phenotype);
phenotype="phenotype"; cols = NULL; col.smoothness=100; npt = 6
phenotype2 = "Mean Posterior"
data.range=NULL; HeadTitle=NULL;
  }
setMethodS3("TwoDiallelPlot", "FullDiallelAnalyze", function(this,
  DoBS=FALSE,...) {
   this$AllDiallelObs[[this$OnObs]]$TwoDiallelPlot(DoBS=DoBS, ...);
});
setMethodS3("TwoDiallelPlot", "DiallelOb", function(this, AFD = NULL,
  FemalePlot = TRUE, MaleAgainstFemale = FALSE, PlotOnlyObserved = FALSE, 
  PlotObservedVersusExpectedAll=FALSE,
  main1 = NULL, main2=NULL, HeadTitle = NULL, data.range=NULL,
  npt = 6, roundDP = 2, cols = NULL, col.smoothness = 200, 
  DoMedian = FALSE,LabelLeft=FALSE, LabelTop = FALSE, new.strain.names="",
  show.strain.coords = TRUE, show.strain.names=TRUE, LeftLabel=NULL, 
  DoBS=FALSE, ...) {
  if (!exists("main1")) { main1 = NULL; }    
  if (!exists("main2")) { main2 = NULL; }
  if (!exists("AFD")) { AFD = this$.AFD; }
  if (!exists("FemalePlot")) { FemalePlot = TRUE; }
  if (!exists("MaleAgainstFemale")) { MaleAgainstFemale = FALSE; }
  if (!exists("PlotOnlyObserved")) { PlotOnlyObserved = FALSE; }
  if (!exists("npt")) { npt = 6; }
  if (!exists("roundDP")) { roundDP = 2; }
  if (!exists("col.smoothness")) { col.smoothness = 200; }
  if (!exists("DoMedian")) { DoMedian = FALSE; }
  if (!exists("cols")) { cols = NULL; }
  if (!exists("HeadTitle")) { HeadTitle = NULL; }  
  if (!exists("DoBS")) { DoBS = FALSE; }
  if (is.null(AFD)) { AFD = this$.AFD; }
  if (is.null(AFD)) { tryCatch("TwoDiallelPlot, cannot work without attached AFD"); } 
  if (!exists("LabelLeft")) { LabelLeft = FALSE;}
  if (!exists("LeftLabel") || is.null(LeftLabel)) { LeftLabel=LabelLeft; }
  if (is.logical(LeftLabel) && LabelLeft==FALSE) { LabelLeft = LeftLabel; }
  if (!exists("PlotObservedVersusExpectedAll")) {
    PlotObservedVersusExpectedAll = FALSE }
  if (!exists("show.strain.names")) { show.strain.names=TRUE; }
  if (!exists("show.strain.coords")) { show.strain.coords=TRUE; }
  if (!exists("PlotOnlyObserved")) {
    PlotOnlyObserved = FALSE }
  DT2 = this$getPosteriorPredictionsMeanSummary(DoBS = DoBS);
  DT1 = cbind(AFD$Listjk, AFD$Y, AFD$SexVector);
  if (length(AFD$SexVector) > 0) {
    colnames(DT1) = c("mother.strain", "father.strain", "phenotype", "is.female");
  } else {
     try(colnames(DT1) <- c("mother.strain", "father.strain", "phenotype"));
  }
  if (length(AFD$SexVector) < 0 || this$.SexModel <= 0) {
    PlotObservedVersusExpectedAll <- TRUE;
  }
  main1Back = main1;  main2Back = main2;  HeadTitleBack = HeadTitle;
  if (exists("new.strain.names") &&
    !is.null(new.strain.names) && length(new.strain.names) == AFD$.numj &&
    !(length(new.strain.names) == 1 && new.strain.names=="")) {
    strain.names = new.strain.names;
  } else if (!is.null(AFD$strain.map)) {
    strain.names = AFD$strain.map[,1];  
  } else {
    strain.names=NULL;  show.strain.names=FALSE;
  }
  if (PlotObservedVersusExpectedAll == TRUE) {
    DT1B = DT1[DT1[,colnames(DT1) == "is.female"] == 1  &
        !is.na(DT1[,colnames(DT1) == "is.female"]),]
    DT1A = DT1[DT1[,colnames(DT1) == "is.female"] == 0  &
        !is.na(DT1[,colnames(DT1) == "is.female"]),];
    if (length(DT1[,colnames(DT1) == "is.female"]) <= 0) {
      DT1B <- DT1;
    }
    UNF <- sort(unique(DT1[,colnames(DT1) == "mother.strain"]));
    UNM <- sort(unique(DT1[,colnames(DT1) == "father.strain"]));
    NewF <- rep(UNF, each=length(UNM));
    NewM <- rep(UNM, length(UNF));
    NewPhO <- rep(0, length(NewF));
    for (tt in 1:length(NewF)) {
      ADT1A <- DT1A[DT1A[,colnames(DT1A) == "mother.strain"] == 
        NewF[tt] & DT1A[,colnames(DT1A)=="father.strain"] == NewM[tt], 
        colnames(DT1A) == "phenotype"];
      ADT1B <- DT1B[DT1B[,colnames(DT1B) == "mother.strain"] == 
        NewF[tt] & DT1B[,colnames(DT1B)=="father.strain"] == NewM[tt], 
        colnames(DT1B) == "phenotype"];
      if (length(ADT1A) == 0 && length(ADT1B) == 0) {
        NewPhO[tt] = NA;
      } else if (length(ADT1A) == 0 && length(ADT1B) > 0) {
        NewPhO[tt] = mean(ADT1B);
      } else if (length(ADT1B) == 0 && length(ADT1A) > 0) {
        NewPhO[tt] = mean(ADT1A);
      } else {
        NewPhO[tt] = mean(c(ADT1B,ADT1A));
      }
    }   
    DT1 = cbind(NewF, NewM, NewPhO);
    try(colnames(DT1) <- c("mother.strain", "father.strain", "phenotype"));
    try(DT1 <- DT1[!is.na(DT1[,colnames(DT1) == "phenotype"]),])
     
    if (length(DT2[colnames(DT2) == "is.female"]) >= 1) {
      DT2B = DT2[DT2[,colnames(DT2) == "is.female"] == 1  &
        !is.na(DT2[,colnames(DT2) == "is.female"]),]
      DT2A = DT2[DT2[,colnames(DT2) == "is.female"] == 0  &
        !is.na(DT2[,colnames(DT2) == "is.female"]),];
    } else if (length(DT2[colnames(DT2) == "is.female"]) <= 0) {
       DT2B <- DT2;
       DT2A <- DT2;
    }
    UNF <- sort(unique(DT2[,colnames(DT2) == "mother.strain"]));
    UNM <- sort(unique(DT2[,colnames(DT2) == "father.strain"]));
    NewF <- rep(UNF, each=length(UNM));
    NewM <- rep(UNM, length(UNF));
    NewPhO <- rep(0, length(NewF));
    for (tt in 1:length(NewF)) {
      ADT2A <- DT2A[DT2A[,colnames(DT2A) == "mother.strain"] == 
        NewF[tt] & DT2A[,colnames(DT2A)=="father.strain"] == NewM[tt], 
        colnames(DT2A) %in% c("Mean Posterior", "phenotype")];
      ADT2B <- DT2B[DT2B[,colnames(DT2B) == "mother.strain"] == 
        NewF[tt] & DT2B[,colnames(DT2B)=="father.strain"] == NewM[tt], 
        colnames(DT2B) %in% c("Mean Posterior", "phenotype")];
      if (length(ADT2A) == 0 && length(ADT2B) == 0) {
        NewPhO[tt] = NA;
      } else if (length(ADT2A) == 0 && length(ADT2B) > 0) {
        NewPhO[tt] = mean(ADT2B);
      } else if (length(ADT2B) == 0 && length(ADT2A) > 0) {
        NewPhO[tt] = mean(ADT2A);
      } else {
        NewPhO[tt] = mean(c(ADT2B,ADT2A));
      }
    }   
    DT2 = cbind(NewF, NewM, NewPhO);
    try(colnames(DT2) <- c("mother.strain", "father.strain", "phenotype"));
    try(DT2 <- DT2[!is.na(DT2[,colnames(DT2) == "phenotype"]),]) 
    
    main1="observed"; main2="expected";
    HeadTitle="Observed Data versus Expected Data: Sexes combined";
    phenotype1 = "phenotype"; phenotype2 = "phenotype";
  } else if (PlotOnlyObserved == TRUE) {
    if (this$.SexModel <= 0) {
      tryCatch("TwoDiallelPlot: Cannot plot only observed because there is no sex in this model!");
      flush.console(); return(-1);
    }
    DT2 = DT1[DT1[,colnames(DT1) == "is.female"] == 1  &
        !is.na(DT1[,colnames(DT1) == "is.female"]),]
    DT1 = DT1[DT1[,colnames(DT1) == "is.female"] == 0  &
        !is.na(DT1[,colnames(DT1) == "is.female"]),];
    main1="male observed"; main2="female observed";
    HeadTitle="Observed Data, Male versus Female";
    phenotype1 = "phenotype"; phenotype2 = "phenotype";
  } else if (MaleAgainstFemale == TRUE) {
    if (this$.SexModel <= 0) {
      tryCatch("TwoDiallelPlot: Will not plot MaleAgainstFemale because there is no sex in this model!");
      flush.console(); return(-1);
    }
    DT1 = DT2[DT2[,colnames(DT2) == "is.female"] == 0  &
        !is.na(DT2[,colnames(DT2) == "is.female"]),];
    DT2 = DT2[DT2[,colnames(DT2) == "is.female"] == 1  &
        !is.na(DT2[,colnames(DT2) == "is.female"]),];
    main1 = "male predicted"; main2="female predicted";
    HeadTitle = "Predicted Difference, Male Versus Female"
    if (DoMedian == TRUE) {
      phenotype1 = "Median Posterior";  phenotype2 = phenotype1;
    } else {
      phenotype1 = "Mean Posterior";  phenotype2 = phenotype1;
    }
  } else if (this$.SexModel > 0) {
    if (FemalePlot == TRUE) {
      DT1 = DT1[DT1[,colnames(DT1) == "is.female"] == 1 &
        !is.na(DT1[,colnames(DT1) == "is.female"]),];
      DT2 = DT2[DT2[,colnames(DT2) == "is.female"] == 1  &
        !is.na(DT2[,colnames(DT2) == "is.female"]),];
      main1= "female observed";  main2 = "female predicted";
      HeadTitle = "Female Specimens, Observed versus Predicted";
      if (DoMedian == TRUE) {
        phenotype2 = "Median Posterior";
      } else {
        phenotype2 = "Mean Posterior"
      }
      phenotype1 = "phenotype";
    } else {
      DT1 = DT1[DT1[,colnames(DT1) == "is.female"] == 0 &
        !is.na(DT1[,colnames(DT1) == "is.female"]) ,];
      DT2 = DT2[DT2[,colnames(DT2) == "is.female"] == 0  &
        !is.na(DT2[,colnames(DT2) == "is.female"]),];
      main1= "male observed";  main2 = "male predicted";
      HeadTitle = "Male Specimens, Observed versus Predicted";    
    }
    if (DoMedian == TRUE) {
      phenotype2 = "Median Posterior";
    } else { 
      phenotype2 = "Mean Posterior"
    }
    phenotype1 = "phenotype";
  }
  if (!is.null(main1Back)) { main1 = main1Back; }
  if (!is.null(main2Back)) { main2 = main2Back; }
  if (!is.null(HeadTitleBack)) { HeadTitle = HeadTitleBack; }
  if (!exists("data.range")) { data.range = NULL; } 
  DT1 = as.data.frame(DT1, stringsAsFactors = FALSE);
  DT2 = as.data.frame(DT2, stringsAsFactors = FALSE);
  try(library(BayesDiallelGraphics), silent=TRUE);
  try(TwoDrawObject(DT1, DT2, data.range=data.range, phenotype="phentoype",
  phenotype1 = phenotype1, phenotype2 = phenotype2, strain.names=strain.names,
  main1 = main1, main2=main2, cols = cols, 
  col.smoothness = col.smoothness, npt = npt, roundDP = roundDP, HeadTitle = HeadTitle,
  LabelLeft=LabelLeft, LabelTop=LabelTop,show.strain.names=show.strain.names,
  show.strain.coords=show.strain.coords, ...)); 
  return(1);
});

TwoDrawObject <- function(DT1, DT2, data.range=NULL, phenotype="phentoype",
  phenotype1 = NULL, phenotype2 = NULL, strain.names=NULL,
  main1 = "(Observed means)", main2="(predicted means)", cols = NULL, 
  col.smoothness = 200, npt = 6, roundDP = 2, HeadTitle = NULL,
  LabelLeft=FALSE, LabelTop=FALSE,show.strain.names = TRUE,
  show.strain.coords = TRUE, LeftLabel = NULL, ...) {
  if (!exists("data.range")) { data.range = NULL; }
  if (!is.null(dim(strain.names)) && dim(strain.names)[2] == 2) {
    strain.names = strain.names[,1];
  }
  if (!exists("s") || is.null(LeftLabel)) { LeftLabel=LabelLeft; }
  if (is.logical(LeftLabel) && LabelLeft==FALSE) { LabelLeft = LeftLabel; }
  if ((is.character(DT1$mother.strain) || is.factor(DT1$mother.strain))
     && (is.character(DT1$father.strain)|| is.factor(DT1$father.strain) )) {
    if (!is.null(strain.names)) {
      DT1$mother.strain = match(as.character(DT1$mother.strain), strain.names)
      DT1$father.strain = match(as.character(DT1$father.strain), strain.names)
      if (any(is.na(DT1$mother.strain)) || any(is.na(DT1$father.strain))) {
        print("TwoPlot:  Warning, Doesn't seem like DT1 mothern.strain/father.strain match to strain.names")
      }
    } else {
      print("TwoPlot:  Warning, DT1 mother.strain, father.strain are characters but not mapped to integers")
    }
  }
  if ((is.character(DT2$mother.strain) || is.factor(DT2$mother.strain))
     && (is.character(DT2$father.strain)|| is.factor(DT2$father.strain) )) {
    if (!is.null(strain.names)) {
      DT2$mother.strain = match(DT2$mother.strain, strain.names)
      DT2$father.strain = match(DT2$father.strain, strain.names)
    if (any(is.na(DT2$mother.strain)) || any(is.na(DT2$father.strain))) {
        print("TwoPlot:  Warning, Doesn't seem like mothern.strain/father.strain match to strain.names")
      }
    } else {
      print("TwoPlot:  Warning, DT2 mother.strain, father.strain are characters but not mapped to integers")
    }
  }
  n = 0;
  if (!is.null(strain.names)) {
    if (!is.null(dim(strain.names)) && dim(strain.names)[2] == 2) {
      try(strain.names = strain.names[,1]);
    }
    if (length(strain.names) > 0) {
    n <- length(strain.names);     }
  }
  if (is.numeric(DT1$mother.strain) && is.numeric(DT1$father.strain)) {
     ab = 0; try(ab <- max(as.numeric(DT1$mother.strain), as.numeric(DT1$father.strain), na.rm=TRUE))
     if (ab > n) { n = ab; }
  } else {
    ab <- length(sort(unique(c(DT1$mother.strain, DT1$father.strain))));
    if (ab > n) { n = ab; }
  }
  if (is.numeric(DT2$mother.strain) && is.numeric(DT2$father.strain)) {
     ab = 0; try(ab <- max(as.numeric(DT2$mother.strain), as.numeric(DT2$father.strain), na.rm=TRUE))
     if (ab > n) { n = ab; }
  } else {
    ab <- length(sort(unique(c(DT2$mother.strain, DT2$father.strain))));
    if (ab > n) { n = ab; }
  } 
  try(d.range <- range(as.numeric(DT1[, phenotype1]), na.rm = TRUE));
  if (!exists("phenotype1") || is.null(phenotype1)) {
    phenotype1 = phenotype;
  }
  if (!exists("phenotype2") || is.null(phenotype2)) {
    phenotype2 = phenotype;
  }
  if (!exists("data.range") || is.null(data.range)) {
    try(data.range <- c(as.numeric(DT1[,phenotype1]), as.numeric(DT2[,phenotype2])));
    try(data.range <- sort(unique(data.range[!is.na(data.range)])));
  }
  if (is.null(HeadTitle)){
    layout(rbind(c(1,2),c(3,3)), widths=c(1,1), heights = c(1,.18));
  } else {
    layout(rbind(c(1,1),c(2,3),c(4,4)), widths=c(1,1), heights = c(.12,1,.18));
    par(plt=c(0,1,0,1));
    plot(c(0,1), c(0,1), axes=FALSE, main="", type="n", xlab="", ylab="");
    text(x=.5,y=0,label=HeadTitle, pos=3, cex=4)
  }
  par(plt=c(.12,.92,.15,.88))
  if (is.character(DT1[,colnames(DT1) == phenotype1])) {
    DT1[,colnames(DT1) == phenotype1] = as.numeric(DT1[,colnames(DT1) == phenotype1])
  }
  if (is.character(DT2[,colnames(DT2) == phenotype2])) {
    DT2[,colnames(DT2) == phenotype2] = as.numeric(DT2[,colnames(DT2) == phenotype2])
  }
   if (!exists("cols") || is.null(cols) || (is.logical(cols))) {
    if (!is.numeric(col.smoothness)) {
      print(paste("TwoPlot, some issue, col.smoothness = ", col.smoothness)); flush.console();
    }
    if (!is.numeric(n)) {
      print(paste("TwoPlot, some issue, n = ", n)); flush.console();
    }
    ncolors <- round(n^2 * as.numeric(col.smoothness)[1])
    if (is.null(ncolors) || is.na(ncolors) || ncolors <= 0) {
      ncolors = 200;
    }
    cols = gray(1 - (1:ncolors/ncolors))  
  } else {
    ncolors = length(cols);
  }
  oldmar <- par("mar")
	on.exit(par(mar=oldmar))
	onmar = oldmar+0.0;
	if (LabelLeft == TRUE && show.strain.names==TRUE && show.strain.coords == TRUE) {
    onmar[2] =onmar[2] + max(nchar(strain.names))/2;
  }
  onmar[4] = .5
  if (LabelTop == TRUE && show.strain.names==TRUE && show.strain.coords == TRUE) {
    onmar[3] = onmar[3] * 1.5;
  }
  par(mar=onmar);
  draw.diallel(DT1, phenotype=phenotype1, main=main1, strain.names=strain.names, col = cols, data.range=data.range,
    LabelLeft=LabelLeft, LabelTop=LabelTop, show.strain.names=show.strain.names, show.strain.coords=show.strain.coords)
	##if (LabelLeft == TRUE) {
  ##  onmar[2] =onmar[2] * ( 1 + max(nchar(strain.names))/2);
  ##}
  par(mar=onmar);
  draw.diallel(DT2, phenotype=phenotype2, main=main2, strain.names=strain.names, 
    col = cols, data.range=data.range, LabelLeft=LabelLeft, LabelTop=LabelTop,
    show.strain.names=show.strain.names, show.strain.coords=show.strain.coords)
  par(plt=c(.05,.95,.45,.9999))
  plot(c(0,1,1,0,0), c(0,0,1,1,0), axes=FALSE,main="", type="l", xlab="", ylab="",xlim=c(0,1), ylim=c(0,1));
 
                  
   Xs= cbind( ((1:ncolors)-.5)/ncolors, ((1:ncolors)-.5)/ncolors,
     rep(NA, ncolors))
   colB = cbind(cols, cols, cols);
   y2 = rep(c(0,1,NA),ncolors);
   for (ii in 1:length(cols)) {
     lines(y=c(0,1),x=Xs[ii,1:2], lwd=1, col=cols[ii])
   }
   lines=c(x=c(0,1,1,0,0), y=c(0,0,1,1,0), lwd=1, col="black");
    Mdata.range = max(data.range);
    mdata.range = min(data.range);
    DTT = round((0:npt) / npt * (Mdata.range - mdata.range) + mdata.range,roundDP);
    axis(1, (0:npt)/npt, labels=DTT)
}

DrawOneCSVTable <- function(DT, phenotype="phenotype", filename="", strain.names=NULL) {
  n = max(DT$mother.strain);
  RTName = paste(1:n, ":", strain.names, sep="");
  MyTable = matrix(NA,n,n);
  MyTable[ cbind(DT$mother.strain, DT$father.strain) ] = DT1[, phenotype];
  STR = n:1;
  MyTable = MyTable[n:1,];
  rownames(MyTable) = RTName[STR];
  colnames(MyTable) = RTName;
  if (filename != "") {
    write.table(MyTable, file=filename, sep=",", col.names = RTName,
    rownames = RTName[STR], quote=FALSE,
      eol="\n");
  }
  return(MyTable)
}

GiveMeMeanTable <- function(L1, L2, Ph1) {
  OurTable = matrix(NA, max(L1), max(L1));
  aL1 = sort(unique(L1));
  aL2 = sort(unique(L2));
  for (ii in aL1) {
    for (jj in aL2) {
      RTT = Ph1[ L1 == ii & L2 == jj];
      if (length(RTT) > 0) {
        OurTable[ii, jj] = mean(RTT[!is.na(RTT)]);
      }
    }
  }
  return(OurTable);
}
DrawTwoCSVTable <- function(DT1, DT2, data.range=NULL, phenotype="phentoype",
  phenotype1 = NULL, phenotype2 = NULL, strain.names=NULL,
  main1 = "(Observed means)", main2="(predicted means)", cols = NULL, 
  col.smoothness = 2, npt = 6, roundTable = 3, HeadTitle = NULL,
  filename = "") {
  n <- max(DT1$mother.strain, DT1$father.strain)
  if (!exists("phenotype1") || is.null(phenotype1)) {
    phenotype1 = phenotype;
  }
  if (!exists("phenotype2") || is.null(phenotype2)) {
    phenotype2 = phenotype;
  }
  RTName = paste(1:n, ":", strain.names, sep="");
  STR = n:1;
  MyTable1 = matrix(NA,n,n);
  FTTP = (1:length(colnames(DT1)))[ as.character(colnames(DT1)) ==
    as.character(phenotype1)];
  if (length(FTTP) == 0) {
    print(paste("Error: phenotype1 == ", phenotype1, " but colnames DT1 = ",
      paste(colnames(DT1), collapse=", ") , sep="")); flush.console();
  }
  if (length(as.vector(DT1[,FTTP]))  != length(DT1$mother.strain)) {
    print(paste("Error: Shape of DT1[,FTTP = ]", sep=""));
    print(DT1[,FTTP])
  }
  MyTable1 = GiveMeMeanTable( DT1$mother.strain, DT1$father.strain,
    as.vector(DT1[, FTTP] ));
    MyTable1 = MyTable1;  rownames(MyTable1) = RTName;
    colnames(MyTable1) = RTName;

  MyTable2 = matrix(NA,n,n);
    FTTP = (1:length(colnames(DT2)))[ as.character(colnames(DT2)) ==
      as.character(phenotype2)];
  MyTable2 = GiveMeMeanTable( DT2$mother.strain, DT2$father.strain,
    DT2[, FTTP]);
    MyTable2 = MyTable2;  rownames(MyTable2) = RTName;
    colnames(MyTable2) = RTName;
  if (filename=="") {
    return(list(HeadTitle=HeadTitle, MyTable1=MyTable1, MyTable2=MyTable2)) 
  }
  MyOP = file(filename, "wt")
  RTT = ( 1+ n ) * 2 + 2;
  MyTable1 = round(MyTable1, roundTable);
  MyTable2 = round(MyTable2, roundTable);
  if (!is.null(HeadTitle)) {
    writeLines(con=MyOP, text=paste(HeadTitle, paste(rep(",",RTT), collapse=""), sep=""));

  
  }
    writeLines(con=MyOP, text=paste(",", main1, paste(rep(",",n), collapse=""), ",,",
      main2, paste(rep(",",n), collapse=""), sep=""));
    writeLines(con=MyOP, text=paste(",", ",",
      paste(rownames(MyTable1), collapse=","), ",,",
      paste(rownames(MyTable2), collapse=","), sep=""));
    for (ii in 1:n) {
      writeLines(con=MyOP, text=paste(",", rownames(MyTable1)[ii], ",",
        paste(MyTable1[ii,], collapse=","), ",,", rownames(MyTable2)[ii], ",",
        paste(MyTable2[ii,], collapse=","), sep=""));
    }
     writeLines(con=MyOP, text=paste(",", ",",
      paste(rownames(MyTable1), collapse=","), ",,",
      paste(rownames(MyTable2), collapse=","), sep=""));
    close(MyOP);
     return(list(HeadTitle=HeadTitle, MyTable1=MyTable1, MyTable2=MyTable2));   
}   


setMethodS3("OneDiallelPlot", "DiallelOb", function(this, AFD = NULL,
  SexlessPlot = TRUE, FemalePlot = FALSE, PlotObserved = FALSE, 
  PlotExpected=TRUE,
  mainT = NULL,  HeadTitle = NULL, data.range=NULL,
  npt = 6, roundDP = 2, cols = NULL, col.smoothness = 200, 
  DoMedian = FALSE,LabelLeft=FALSE, LabelTop=FALSE,
  show.strain.names=TRUE, show.strain.coords=TRUE, new.strain.names="", ...) {
  if (!exists("main1")) { main1 = NULL; }    
  if (!exists("main2")) { main2 = NULL; }
  if (!exists("AFD")) { AFD = this$.AFD; }
  if (!exists("SexlessPlot")) { SexlessPlot = TRUE; }
  if (!exists("FemalePlot")) { FemalePlot = FALSE; }
  if (!exists("MaleAgainstFemale")) { MaleAgainstFemale = FALSE; }
  if (!exists("PlotExpected")) { PlotExpected = TRUE; }
  if (!exists("PlotObserved")) { PlotObserved = FALSE; }
  if (!exists("npt")) { npt = 6; }
  if (!exists("roundDP")) { roundDP = 2; }
  if (!exists("col.smoothness")) { col.smoothness = 200; }
  if (!exists("DoMedian")) { DoMedian = FALSE; }
  if (!exists("cols")) { cols = NULL; }
  if (!exists("HeadTitle")) { HeadTitle = NULL; }
  if (is.null(AFD)) { AFD = this$.AFD; }
  if (is.null(AFD)) { tryCatch("TwoDiallelPlot, cannot work without attached AFD"); } 
  DT2 = this$getPosteriorPredictionsMeanSummary();
  DT1 = cbind(AFD$Listjk, AFD$Y, AFD$SexVector);
  if (length(AFD$SexVector) > 0) {
    colnames(DT1) = c("mother.strain", "father.strain", "phenotype", "is.female");
  } else {
     try(colnames(DT1) <- c("mother.strain", "father.strain", "phenotype"));
  }
  main1Back = main1;  main2Back = main2;  HeadTitleBack = HeadTitle;
  if (!is.null(new.strain.names) && length(new.strain.names) == AFD$.numj &&
    !(length(new.strain.names) == 1 && new.strain.names=="")) {
    strain.names = new.strain.names;
  } else if (!is.null(AFD$strain.map)) {
    strain.names = AFD$strain.map[,1];  
  } else {
    strain.names=NULL;  show.strain.names=FALSE;
  }
  if (length(AFD$SexVector) > 0 &&
    SexlessPlot == FALSE && (PlotExpected ==TRUE || PlotObserved == FALSE) &&
    FemalePlot == TRUE) {
    DTT  = DT2[DT2[,colnames(DT2) == "is.female"] == 1  &
        !is.na(DT2[,colnames(DT2) == "is.female"]),1:3];
    if (length(as.vector(unlist(DTT))) <= 1) {
       print("Sorry, no Female items in Expected table cannot perform Oneplot!");
       return(-1);
    }
    try(colnames(DTT) <- c("mother.strain", "father.strain", "phenotype"));
    try(DTT <- DTT[!is.na(DTT[,colnames(DTT) == "phenotype"]),]);
    mainT="expected"; HeadTitle="Expected Data: Female Specimens";
    phenotypeT = "phenotype"; 
  } else if (length(AFD$SexVector) > 0 &&
    SexlessPlot == FALSE && (PlotExpected ==TRUE || PlotObserved == FALSE)) {
    DTT  = DT2[DT2[,colnames(DT2) == "is.female"] == 0  &
        !is.na(DT2[,colnames(DT2) == "is.female"]),1:3];
    if (length(as.vector(unlist(DTT))) <= 1) {
       print("Sorry, no male items in Expected table cannot perform Oneplot!");
       return(-1);
    }
    try(colnames(DTT) <- c("mother.strain", "father.strain", "phenotype"));
    try(DTT <- DTT[!is.na(DTT[,colnames(DTT) == "phenotype"]),]);
    mainT="expected"; HeadTitle="Expected Data: Male Specimens";
    phenotypeT = "phenotype"; 
  }  else if (length(AFD$SexVector) > 0 &&
    SexlessPlot == FALSE && (PlotExpected ==FALSE && PlotObserved == TRUE) &&
    FemalePlot == TRUE) {
    DTT  = DT1[DT1[,colnames(DT1) == "is.female"] == 1  &
        !is.na(DT1[,colnames(DT1) == "is.female"]),1:3];
    if (length(as.vector(unlist(DTT))) <= 1) {
       print("Sorry, no Female items in Expected table cannot perform Oneplot!");
       return(-1);
    }
    try(colnames(DTT) <- c("mother.strain", "father.strain", "phenotype"));
    try(DTT <- DTT[!is.na(DTT[,colnames(DTT) == "phenotype"]),]);
    try(colnames(DTT) <- c("mother.strain", "father.strain", "phenotype"));
    UNF <- sort(unique(DTT[,colnames(DTT) == "mother.strain"]));
    UNM <- sort(unique(DTT[,colnames(DTT) == "father.strain"]));
    NewF <- rep(UNF, each=length(UNM));
    NewM <- rep(UNM, length(UNF));
    NewPhO <- rep(0, length(NewF));
    for (tt in 1:length(NewF)) {
      ADTT <- DTT[DTT[,colnames(DTT) == "mother.strain"] == 
        NewF[tt] & DTT[,colnames(DTT)=="father.strain"] == NewM[tt], 
        colnames(DTT) == "phenotype"];
      if (length(ADTT) == 0) {
        NewPhO[tt] = NA;
      } else if (DoMedian == TRUE) {
        NewPhO[tt] = median(ADTT);
      } else {
        NewPhO[tt] = mean(ADTT);
      }
    } 
    DTT <- cbind(NewM, NewF, NewPhO);
    DTT = DTT[!is.na(DTT[,3]),];
    colnames(DTT) <- c("mother.strain", "father.strain", "phenotype");
    mainT="Observed"; HeadTitle="Observed Data: Female Specimens";
    phenotypeT = "phenotype"; 
  } else if (length(AFD$SexVector) > 0 &&
    SexlessPlot == FALSE && (PlotExpected ==FALSE && PlotObserved == TRUE)) {
    DTT  = DT1[DT1[,colnames(DT1) == "is.female"] == 0  &
        !is.na(DT1[,colnames(DT1) == "is.female"]),1:3];
    if (length(as.vector(unlist(DTT))) <= 1) {
       print("Sorry, no Female items in Expected table cannot perform Oneplot!");
       return(-1);
    }
    try(colnames(DTT) <- c("mother.strain", "father.strain", "phenotype"));
    try(DTT <- DTT[!is.na(DTT[,colnames(DTT) == "phenotype"]),]);
    try(colnames(DTT) <- c("mother.strain", "father.strain", "phenotype"));
    UNF <- sort(unique(DTT[,colnames(DTT) == "mother.strain"]));
    UNM <- sort(unique(DTT[,colnames(DTT) == "father.strain"]));
    NewF <- rep(UNF, each=length(UNM));
    NewM <- rep(UNM, length(UNF));
    NewPhO <- rep(0, length(NewF));
    for (tt in 1:length(NewF)) {
      ADTT <- DTT[DTT[,colnames(DTT) == "mother.strain"] == 
        NewF[tt] & DTT[,colnames(DTT)=="father.strain"] == NewM[tt], 
        colnames(DTT) == "phenotype"];
      if (length(ADTT) == 0) {
        NewPhO[tt] = NA;
      } else if (DoMedian == TRUE) {
        NewPhO[tt] = median(ADTT);
      } else {
        NewPhO[tt] = mean(ADTT);
      }
    } 
    DTT <- cbind(NewM, NewF, NewPhO);
    DTT = DTT[!is.na(DTT[,3]),];
    colnames(DTT) <- c("mother.strain", "father.strain", "phenotype");
    mainT="Observed"; HeadTitle="Observed Data: Male Specimens";
    phenotypeT = "phenotype"; 
  } else if (length(AFD$SexVector) <= 0 &&
    (PlotExpected ==TRUE || PlotObserved == FALSE)) {
    DTT  = DT2[,1:3];
    if (length(as.vector(unlist(DTT))) <= 1) {
       print("Sorry, no male items in Expected table cannot perform Oneplot!");
       return(-1);
    }
    try(colnames(DTT) <- c("mother.strain", "father.strain", "phenotype"));
    try(DTT <- DTT[!is.na(DTT[,colnames(DTT) == "phenotype"]),]);
    mainT="expected"; HeadTitle="Expected Data";
    phenotypeT = "phenotype"; 
  } else if (length(AFD$SexVector) <= 0 &&
    (PlotExpected ==FALSE && PlotObserved == TRUE)) {
    DTT  = DT1[,1:3];
    if (length(as.vector(unlist(DTT))) <= 1) {
       print("Sorry, no items in observed table cannot perform Oneplot!");
       return(-1);
    }
    try(DTT <- DTT[!is.na(DTT[,colnames(DTT) == "phenotype"]),]);
    try(colnames(DTT) <- c("mother.strain", "father.strain", "phenotype"));
    UNF <- sort(unique(DTT[,colnames(DTT) == "mother.strain"]));
    UNM <- sort(unique(DTT[,colnames(DTT) == "father.strain"]));
    NewF <- rep(UNF, each=length(UNM));
    NewM <- rep(UNM, length(UNF));
    NewPhO <- rep(0, length(NewF));
    for (tt in 1:length(NewF)) {
      ADTT <- DTT[DTT[,colnames(DTT) == "mother.strain"] == 
        NewF[tt] & DTT[,colnames(DTT)=="father.strain"] == NewM[tt], 
        colnames(DTT) == "phenotype"];
      if (length(ADTT) == 0) {
        NewPhO[tt] = NA;
      } else if (DoMedian == TRUE) {
        NewPhO[tt] = median(ADTT);
      } else {
        NewPhO[tt] = mean(ADTT);
      }
    } 
    DTT <- cbind(NewM, NewF, NewPhO);
    DTT = DTT[!is.na(DTT[,3]),];
    colnames(DTT) <- c("mother.strain", "father.strain", "phenotype");
 
    mainT="Observed"; HeadTitle="Observed Data";
    phenotypeT = "phenotype"; 
  } else if (PlotExpected == TRUE || PlotObserved == FALSE) {
    DT2B = DT2[DT2[,colnames(DT2) == "is.female"] == 1  &
        !is.na(DT2[,colnames(DT2) == "is.female"]),]
    DT2A = DT2[DT2[,colnames(DT2) == "is.female"] == 0  &
        !is.na(DT2[,colnames(DT2) == "is.female"]),];
    if (length(DT2[,colnames(DT2) == "is.female"]) <= 0) {
       DT2B <- DT2;
    }
    UNF <- sort(unique(DT2[,colnames(DT2) == "mother.strain"]));
    UNM <- sort(unique(DT2[,colnames(DT2) == "father.strain"]));
    NewF <- rep(UNF, each=length(UNM));
    NewM <- rep(UNM, length(UNF));
    NewPhO <- rep(0, length(NewF));
    for (tt in 1:length(NewF)) {
      ADT2A <- DT2A[DT2A[,colnames(DT2A) == "mother.strain"] == 
        NewF[tt] & DT2A[,colnames(DT2A)=="father.strain"] == NewM[tt], 
        colnames(DT2A) %in% c("Mean Posterior", "phenotype")];
      ADT2B <- DT2B[DT2B[,colnames(DT2B) == "mother.strain"] == 
        NewF[tt] & DT2B[,colnames(DT2B)=="father.strain"] == NewM[tt], 
        colnames(DT2B) %in% c("Mean Posterior", "phenotype")];
      if (length(ADT2A) == 0 && length(ADT2B) == 0) {
        NewPhO[tt] = NA;
      } else if (length(ADT2A) == 0 && length(ADT2B) > 0) {
        NewPhO[tt] = mean(ADT2B);
      } else if (length(ADT2B) == 0 && length(ADT2A) > 0) {
        NewPhO[tt] = mean(ADT2A);
      } else {
        NewPhO[tt] = mean(c(ADT2B,ADT2A));
      }
    }   
    DTT = cbind(NewF, NewM, NewPhO);
    try(colnames(DTT) <- c("mother.strain", "father.strain", "phenotype"));
    try(DTT <- DTT[!is.na(DTT[,colnames(DTT) == "phenotype"]),]) 

    mainT="expected"; 
    HeadTitle="Expected Data: Sexes combined";
    phenotypeT = "phenotype"; 
  } else {
    DT1B = DT1[DT1[,colnames(DT1) == "is.female"] == 1  &
        !is.na(DT1[,colnames(DT1) == "is.female"]),]
    DT1A = DT1[DT1[,colnames(DT1) == "is.female"] == 0  &
        !is.na(DT1[,colnames(DT1) == "is.female"]),];
    if (length(DT1[,colnames(DT1) == "is.female"]) <= 0) {
      DT1B <- DT1;
    }
    UNF <- sort(unique(DT1[,colnames(DT1) == "mother.strain"]));
    UNM <- sort(unique(DT1[,colnames(DT1) == "father.strain"]));
    NewF <- rep(UNF, each=length(UNM));
    NewM <- rep(UNM, length(UNF));
    NewPhO <- rep(0, length(NewF));
    for (tt in 1:length(NewF)) {
      ADT1A <- DT1A[DT1A[,colnames(DT1A) == "mother.strain"] == 
        NewF[tt] & DT1A[,colnames(DT1A)=="father.strain"] == NewM[tt], 
        colnames(DT1A) == "phenotype"];
      ADT1B <- DT1B[DT1B[,colnames(DT1B) == "mother.strain"] == 
        NewF[tt] & DT1B[,colnames(DT1B)=="father.strain"] == NewM[tt], 
        colnames(DT1B) == "phenotype"];
      if (length(ADT1A) == 0 && length(ADT1B) == 0) {
        NewPhO[tt] = NA;
      } else if (length(ADT1A) == 0 && length(ADT1B) > 0) {
        NewPhO[tt] = mean(ADT1B);
      } else if (length(ADT1B) == 0 && length(ADT1A) > 0) {
        NewPhO[tt] = mean(ADT1A);
      } else {
        NewPhO[tt] = mean(c(ADT1B,ADT1A));
      }
    }   
    DTT = cbind(NewF, NewM, NewPhO);
    try(colnames(DTT) <- c("mother.strain", "father.strain", "phenotype"));
    try(DTT <- DTT[!is.na(DTT[,colnames(DTT) == "phenotype"]),])
     

    mainT="observed"; 
    HeadTitle="Observed Data: Sexes combined";
    phenotypeT = "phenotype";
  }
  if (!is.null(main1Back)) { main1 = main1Back; }
  if (!is.null(main2Back)) { main2 = main2Back; }
  if (!is.null(HeadTitleBack)) { HeadTitle = HeadTitleBack; }
  if (!exists("data.range")) { data.range = NULL; } 
  DTT = as.data.frame(DTT, stringsAsFactors = FALSE);
  ##DT2 = as.data.frame(DT2, stringsAsFactors = FALSE);
  ##try(library(BayesDiallelGraphics), silent=TRUE);
  try(OneDrawObject(DTT, data.range=data.range, phenotype="phentoype",
  phenotypeT = phenotypeT, strain.names=strain.names,
  mainT = mainT, cols = cols, 
  col.smoothness = col.smoothness, npt = npt, roundDP = roundDP, HeadTitle = HeadTitle,
  LabelLeft=LabelLeft, LabelTop=LabelTop, show.strain.names=show.strain.names,
  show.strain.coords=show.strain.coords)); 
  return(1);
});

setMethodS3("OnePlot", "DiallelOb", function(this, AFD = NULL,
  SexlessPlot = TRUE, FemalePlot = FALSE, PlotObserved = FALSE, 
  PlotExpected=TRUE,
  mainT = NULL,  HeadTitle = NULL, data.range=NULL,
  npt = 6, roundDP = 2, cols = NULL, col.smoothness = 200, 
  DoMedian = FALSE,show.strain.names = TRUE,show.strain.coords=TRUE,
  LabelLeft=FALSE, LabelTop=FALSE, ...) {
  this$OneDiallelPlot(this, AFD = AFD,
  SexlessPlot = SexlessPlot, FemalePlot = FemalePlot, PlotObserved = PlotObserved, 
  PlotExpected=PlotExpected,
  mainT = mainT, HeadTitle = HeadTitle, data.range=data.range,
  npt = npt, roundDP = roundDP, cols = cols, col.smoothness = col.smoothness, 
  DoMedian = DoMedian,show.strain.names=TRUE, show.strain.coords=TRUE,
  LabelLeft=FALSE, LabelTop=LabelTop,
  ...);
  
});


OneDrawObject <- function(DTT, data.range=NULL, phenotype="phentoype",
  phenotypeT = NULL, strain.names=NULL,
  mainT = "(predicted means)", cols = NULL, 
  col.smoothness = 200, npt = 6, roundDP = 2, HeadTitle = NULL,
  LabelTop=FALSE, LabelLeft=FALSE, show.strain.coords=TRUE,
  show.strain.names=TRUE, ...) {
  if (!exists("phenotype")) { phenotype = "phenotype"; }
  if (!exists("data.range")) { data.range = NULL; }
  if (!is.null(dim(strain.names)) && dim(strain.names)[2] == 2) {
    strain.names = strain.names[,1];
  }
  if ((is.character(DTT$mother.strain) || is.factor(DTT$mother.strain))
     && (is.character(DTT$father.strain)|| is.factor(DTT$father.strain) )) {
    if (!is.null(strain.names)) {
      DTT$mother.strain = match(as.character(DTT$mother.strain), strain.names)
      DTT$father.strain = match(as.character(DTT$father.strain), strain.names)
      if (any(is.na(DTT$mother.strain)) || any(is.na(DTT$father.strain))) {
        print("OnePlot:  Warning, Doesn't seem like DTT mothern.strain/father.strain match to strain.names")
      }
    } else {
      print("OnePlot:  Warning, DTT mother.strain, father.strain are characters but not mapped to integers")
    }
  }

  n = 0;
  if (!is.null(strain.names)) {
    if (!is.null(dim(strain.names)) && dim(strain.names)[2] == 2) {
      try(strain.names = strain.names[,1]);
    }
    if (length(strain.names) > 0) {
    n <- length(strain.names);     }
  }
  if (is.numeric(DTT$mother.strain) && is.numeric(DTT$father.strain)) {
     ab = 0; try(ab <- max(as.numeric(DTT$mother.strain), as.numeric(DTT$father.strain), na.rm=TRUE))
     if (ab > n) { n = ab; }
  } else {
    ab <- length(sort(unique(c(DTT$mother.strain, DTT$father.strain))));
    if (ab > n) { n = ab; }
  }
  try(d.range <- range(as.numeric(DTT[, phenotypeT]), na.rm = TRUE));
  if (!exists("phenotypeT") || is.null(phenotypeT)) {
    phenotypeT = phenotype;
  }

  if (!exists("data.range") || is.null(data.range)) {
    try(data.range <- as.numeric(DTT[,phenotypeT]));
    try(data.range <- sort(unique(data.range[!is.na(data.range)])));
  }
  if (is.null(HeadTitle)){
    layout(rbind(c(1),c(2)), widths=c(1), heights = c(1,.18));
  } else {
    layout(matrix(1:3,3,1), widths=c(1,1), heights = c(.12,1,.18));
    par(plt=c(0,1,0,1));
    plot(c(0,1), c(0,1), axes=FALSE, main="", type="n", xlab="", ylab="");
    text(x=.5,y=0,label=HeadTitle, pos=3, cex=4)
  }
  oldmar <- par("mar")
	on.exit(par(mar=oldmar))
	PltM <- c(.12,.92,.15,.88);
	if (LabelLeft == TRUE && show.strain.names==TRUE && show.strain.coords == TRUE) {
    PltM[1] = .1424 * ( 4.1 + max(nchar(strain.names)) / 2) / 4.1;
  }
  if (LabelTop == TRUE && show.strain.names==TRUE && show.strain.coords == TRUE) {
    PltM[4] = 1.0 - (1.0-PltM[4]) * 1.5;
  }
  par(plt=c(.12,.92,.15,.88))
  if (is.character(DTT[,colnames(DTT) == phenotypeT])) {
    DTT[,colnames(DTT) == phenotypeT] = as.numeric(DTT[,colnames(DTT) == phenotypeT])
  }

   if (!exists("cols") || is.null(cols) || (is.logical(cols))) {
    if (!is.numeric(col.smoothness)) {
      print(paste("OnePlot, some issue, col.smoothness = ", col.smoothness)); flush.console();
    }
    if (!is.numeric(n)) {
      print(paste("OnePlot, some issue, n = ", n)); flush.console();
    }
    ncolors <- round(n^2 * as.numeric(col.smoothness)[1])
    if (is.null(ncolors) || is.na(ncolors) || ncolors <= 0) {
      ncolors = 200;
    }
    cols = gray(1 - (1:ncolors/ncolors))  
  } else {
    ncolors = length(cols);
  }
  draw.diallel(DTT, phenotype=phenotypeT, main=mainT, strain.names=strain.names, col = cols, data.range=data.range,
    LabelLeft=LabelLeft, LabelTop=LabelTop, show.strain.names=show.strain.names,
    show.strain.coords=show.strain.coords)
  ##draw.diallel(DT2, phenotype=phenotype2, main=main2, strain.names=strain.names, col = cols, data.range=data.range)
  par(plt=c(.05,.95,.45,.9999))
  plot(c(0,1,1,0,0), c(0,0,1,1,0), axes=FALSE,main="", type="l", xlab="", ylab="",xlim=c(0,1), ylim=c(0,1));
 
                  
   Xs= cbind( ((1:ncolors)-.5)/ncolors, ((1:ncolors)-.5)/ncolors,
     rep(NA, ncolors))
   colB = cbind(cols, cols, cols);
   y2 = rep(c(0,1,NA),ncolors);
   for (ii in 1:length(cols)) {
     lines(y=c(0,1),x=Xs[ii,1:2], lwd=1, col=cols[ii])
   }
   lines=c(x=c(0,1,1,0,0), y=c(0,0,1,1,0), lwd=1, col="black");
    Mdata.range = max(data.range);
    mdata.range = min(data.range);
    DTT = round((0:npt) / npt * (Mdata.range - mdata.range) + mdata.range,roundDP);
    axis(1, (0:npt)/npt, labels=DTT)
}