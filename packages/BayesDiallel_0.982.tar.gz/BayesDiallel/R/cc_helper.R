rgb256=function(...){rgb(...,maxColorValue=255)}
ccfounder.short2color=list(
        "A/J"=rgb256(240,240,0),
        "C57BL/6J"=rgb256(128,128,128),
        "129S1/SvImJ"=rgb256(240,128,128),
        "NOD/LtJ"=rgb256(16,16,240),
        "NZO/LtJ"=rgb256(0,160,240),
        "CAST/EiJ"=rgb256(0,160,0),
        "PWK/PhJ"=rgb256(240,0,0),
        "WSB/EiJ"=rgb256(144,0,224))
ccfounder.short2long=list(
        AJ="A/J",
        B6="C57BL/6J",
        "129s1"="129S1/SvImJ",
        NOD="NOD/LtJ", 
        NZO="NZO/LtJ",
        CAST="CAST/EiJ",
        PWK="PWK/PhJ",
        WSB="WSB/EiJ")
ccfounder.short.names=names(ccfounder.short2long)
ccfounder.long.names=as.character(unlist(ccfounder.short2long))
ccfounder.colors=as.character(unlist(ccfounder.short2color))
ccfounder.shortnames = ccfounder.short.names;
ccfounder.longnames  = ccfounder.long.names

