############################################################################
##  ProcessDiallelOutput.R
##
##
##
##
eval(parse(text=GetG0Text("roundShort", "globalenv()", S=1)));
roundShort = 1;
eval(parse(text=SetGText("roundShort", "globalenv()", S=1)));
eval(parse(text=GetG0Text("roundTo", "globalenv()", S=1)));
roundTo = 3
eval(parse(text=SetGText("roundTo", "globalenv()",S=1)));
WriteParamFightTable <- function(GriffingOAs, BayesDiallelOAs, FileName="",
  MedianSigLevel = .01, MIPSigLevel=.2,
  SubSetIters = NULL, TargetRDTable = NULL, TargetRDProb = NULL, HitSimPreds = NULL,
  GiveTargetGroups = 0, roundTo = 3, roundShort = 1, PredDiff = TRUE,
  KeepGAs = -1, KeepRDs = -1) {
    
  if (is.numeric(KeepGAs)) { 
    if (length(KeepGAs) == 1 && KeepGAs[1] == -1) {
      KeepGAs = 1:length(GriffingOAs); 
    } else {
      KeepGAs = KeepGAs[KeepGAs > 0 & KeepGAs <= length(GriffingOAs)];
    }
  } else {
    KeepGAs = NULL;
  }
  if (is.numeric(KeepRDs)) { 
    if (length(KeepRDs) == 1 && KeepRDs[1] == -1) {
      KeepRDs = 1:length(BayesDiallelOAs); 
    } else {
      KeepRDs = KeepRDs[KeepRDs > 0 & KeepRDs <= length(BayesDiallelOAs)];
    }
  } else {
    KeepRDs = NULL;
  }
  if (is.null(GiveTargetGroups)|| (is.numeric(GiveTargetGroups) &&
    GiveTargetGroups[1] == 0)) {
    eval(parse(text=GetG0Text("GiveTargetGroups")));
    if (is.null(GiveTargetGroups) || (is.numeric(GiveTargetGroups) &&
      GiveTargetGroups[1] == 0)) {
      GiveTargetGroups =c("aj", "motherj", "dominancej", "Gender:aj");
    }
  }
  
  ReadGIters = list();
    for (ii in 1:length(GriffingOAs)) {
      RTO = 1:dim(GriffingOAs[[ii]]$MeanVals$ReadTable)[1];
      if (exists("SubSetIters") && !is.null(SubSetIters)) {
        UseIters = RTO[RTO %in% SubSetIters];
      } else { UseIters = RTO; SubSetIters = NULL; }
      ReadGIters[[ii]] = UseIters;
    }
  ReadRDIters = list();
    for (ii in 1:length(BayesDiallelOAs)) {
      RTO = 1:dim(BayesDiallelOAs[[ii]]$MeanVals$ReadTable)[1];
      if (exists("SubSetIters") && !is.null(SubSetIters)) {
        UseIters = RTO[RTO %in% SubSetIters];
      } else {
        UseIters = RTO;  SubSetIters = NULL;
      }
      ReadRDIters[[ii]] = UseIters; 
    }
  GriffingOAs2 = list();  ReadGIters2 = c();
  if (length(KeepGAs) > 0) {
    for (ii in 1:length(KeepGAs)) {
      GriffingOAs2[[ii]] = GriffingOAs[[KeepGAs[ii]]];
      ReadGIters2 = c(ReadGIters2, ReadGIters[KeepGAs[ii]]);
    }
  }
  BayesDiallelOAs2 = list();  ReadRDIters2 = c();
  TargetRDTable2 = c();  TargetRDProb2 = c();
  if (length(KeepRDs) > 0) {
    for (ii in 1:length(KeepRDs)) {
      BayesDiallelOAs2[[ii]] = BayesDiallelOAs[[KeepRDs[ii]]];
      ReadRDIters2 = c(ReadRDIters2, ReadRDIters[KeepRDs[ii]]);
      TargetRDTable2 = c(TargetRDTable2, TargetRDTable[KeepRDs[ii]])
      TargetRDProb2 = c(TargetRDProb2, TargetRDProb[KeepRDs[ii]])
    }
  }
  
  if (length(KeepGAs) > 0 && length(KeepRDs) > 0) {
  FirstLine = paste("\\begin{tabular}{c|", 
    paste(rep("c", length(KeepGAs)), collapse=""),  "|",
    paste(rep("c", length(KeepRDs)), collapse=""), "} \\hline ", sep="");
  SecondLine = paste("\\multicolumn{1}{c|}{Simulated} & ",
    "\\multicolumn{", length(KeepGAs), "}{c|}{Griffing} & ",
    "\\multicolumn{", length(KeepRDs), "}{c}{BayesDiallel} \\\\ ", sep="");
  } else if (length(KeepGAs) > 0) {
 FirstLine = paste("\\begin{tabular}{c|", 
    paste(rep("c", length(KeepGAs)), collapse=""),  "|",
     sep="");
  SecondLine = paste("\\multicolumn{1}{c|}{Simulated} & ",
    "\\multicolumn{", length(KeepGAs), "}{c}{Griffing} & ",
    sep="");    
  } else if (length(KeepRDs) > 0) {
 FirstLine = paste("\\begin{tabular}{c|", 
    paste(rep("c", length(KeepRDs)), collapse=""), "} \\hline ", sep="");
  SecondLine = paste("\\multicolumn{1}{c|}{Simulated} & ",
    "\\multicolumn{", length(KeepRDs), "}{c}{BayesDiallel} \\\\ ", sep="");    
  }  else {
    print("Give Me Something"); return(NULL);
  }
  ThirdLine = paste("Parameter  ", sep="");
  if (length(KeepGAs) > 0) {
  for (ii in 1:length(KeepGAs)) { ThirdLine = paste( ThirdLine, " & "," ",
    GriffingOAs[[KeepGAs[ii]]]$ModelSubName,  sep=""); }
  }
  if (length(KeepRDs) > 0) {
  for (ii in 1:length(KeepRDs)) { ThirdLine = paste(ThirdLine, " & ", " ",
    BayesDiallelOAs[[KeepRDs[ii]]]$ModelSubName,  sep=""); }
  } 
  ThirdLine = paste(ThirdLine, " \\\\ ", sep="");  flush.console();
  FourthLine = paste("  ", sep="");
  if (length(KeepGAs) > 0) {
  for (tii in 1:length(KeepGAs)) {
     ii = KeepGAs[tii]
     CTN = colnames(GriffingOAs[[ii]]$MeanVals$ReadTable);
     TN1 = GriffingOAs[[ii]]$MeanVals$ReadTable[ReadGIters[[ii]],]
     TN1 = TN1[, CTN  != "SimID"]; CTN = CTN[CTN != "SimID"]
     TN = rep(0, length(CTN)); names(TN) = CTN;
     for (tt in 1:length(TN)) { TN[tt] = median(as.numeric(unlist(TN1[,tt])), na.rm=TRUE)}
     FourthLine = paste(FourthLine,
      " & ", "``", ModelToString(TN,
        MedianSigLevel),"''", sep="");   
  }} 
  if (length(KeepRDs) > 0) {
  for (tii in 1:length(KeepRDs)) {
    ii = KeepRDs[tii];
    if (exists("TargetRDTable") && !is.null(TargetRDTable) && TargetRDTable[ii] == "MedianVals") {
     CTN = colnames(BayesDiallelOAs[[ii]]$MedianVals$ReadTable);
     TN1 = BayesDiallelOAs[[ii]]$MedianVals$ReadTable[ReadRDIters[[ii]],]
     TN1 = TN1[ ,CTN != "SimID"]; CTN = CTN[CTN != "SimID"]
      TN = rep(0, length(CTN)); names(TN) = CTN;
     for (tt in 1:length(TN)) { TN[tt] = median(as.numeric(unlist(TN1[,tt])))}
    FourthLine = paste(FourthLine,
      " & ", "``", ModelToString(TN,
        MedianSigLevel),"''", sep="");
    } else {
     CTN = colnames(BayesDiallelOAs[[ii]]$MeanVals$ReadTable);
     TN1 = BayesDiallelOAs[[ii]]$MeanVals$ReadTable[ReadRDIters[[ii]],]
     TN1 = TN1[, CTN  != "SimID"]; CTN = CTN[CTN != "SimID"]
     TN = rep(0, length(CTN)); names(TN) = CTN;
     for (tt in 1:length(TN)) { TN[tt] = median(as.numeric(unlist(TN1[,tt])))}
     FourthLine = paste(FourthLine,
      " & ", "``", ModelToString(TN,
        MedianSigLevel),"''", sep="");   
    
    }
  }}
  FourthLine = paste(FourthLine, " \\\\ ", sep="");
  GroupLines = list();
  for (ii in 1:length(GiveTargetGroups)) {
    EHat = MakeEHat(GiveTargetGroups[ii])
      subHatEHat = paste("\\hat{", substr(EHat,1,1), "}", substr(EHat,2,nchar(EHat)), sep="")
    GroupLines[[ii]] = 
      paste("$\\mbox{\\small{$\\sum (", subHatEHat, " - ", EHat, ")^2$}}$ ", sep="");
    ListForGroup = list();
    if (length(KeepGAs) > 0) {
    for (tjj in 1:length(KeepGAs)) {
      jj = KeepGAs[tjj];
      ListForGroup[[tjj]] = ProcessAverageError(GriffingOAs[[jj]], L2OrL1 = "L2",
        MeanOrMedian="MEAN", ParamGroup = GiveTargetGroups[ii], 
        ParamVal = NULL, AllFixed = NULL,
        ITERS = NULL, NonNAIters = FALSE,
        Denominator = c("None","T1", "T2")[1], ShiftDiff = TRUE,
        quantiles=c(.025,.975)); 
    }}
    if (length(KeepRDs) > 0) {
    for (tjj in 1:length(KeepRDs)) {
      jj = KeepRDs[tjj];
      ListForGroup[[tjj+length(KeepGAs)]] = ProcessAverageError(
        BayesDiallelOAs[[jj]], L2OrL1 = "L2",
        MeanOrMedian=TargetRDTable[jj], ParamGroup = GiveTargetGroups[ii], 
        ParamVal = NULL, AllFixed = NULL,
        ITERS = NULL, NonNAIters = FALSE,
        Denominator = c("None","T1", "T2")[1], ShiftDiff = TRUE,
        quantiles=c(.025,.975)); 
    }}
    for (tt in 1:length(ListForGroup)) {
      GroupLines[[ii]] =paste(GroupLines[[ii]], " & ", round(ListForGroup[[tt]]$mean, roundTo), sep="");  
    }
    GroupLines[[ii]] = paste( GroupLines[[ii]], " ",  "  \\\\ 
       ", sep=""); 
    for (tt in 1:length(ListForGroup)) {
      if (ListForGroup[[tt]]$quantiles[1] == ListForGroup[[tt]]$quantiles[2]) {
        GroupLines[[ii]] = paste(GroupLines[[ii]], " &  - ", sep="")
      } else {
      GroupLines[[ii]] = paste(GroupLines[[ii]], "& ",
        "$\\mbox{\\footnotesize{(", round(ListForGroup[[tt]]$quantiles[1],roundShort), ", ",
        round(ListForGroup[[tt]]$quantiles[2],roundShort), ")}}$ ", sep="");  
      }
    }
    
  }
 PredMSE <- ProcessDiallelMSE(TrueParamVec, GriffingOAs2, ReadGIters2,
     BayesDiallelOAs2, ReadRDIters2, TargetRDTable = TargetRDTable2, 
     TargetRDProb = TargetRDProb2,PredDiff = PredDiff)
   FirstPredMSE = paste("Prediction ", sep="");
    SecondPredMSE = paste("MSE ", sep="");
   if (exists("HitSimPreds") && !is.null(HitSimPreds)) {
     FirstPredMSE = paste(FirstPredMSE, round(mean(sd(t(HitSimPreds))^2),2),
    "\\footnote{", PredMSEFootnote, "} & ", sep="");
    CHitPreds = sd(t(HitSimPreds))^2;
    SecondPredMSE = paste(SecondPredMSE, 
      "$\\mbox{\\footnotesize{(",
       round(quantile(CHitPreds,.025), roundShort), ", ", 
       round(quantile(CHitPreds, .975),roundShort), ")}}$  & ",
       sep="");
   } else {
      print("You Should probably supply HitSimPreds"); flush.console();
      FirstPredMSE = paste(FirstPredMSE, 
       "\\footnote{", PredMSEFootnote, "} & ",
        sep="");
      SecondPredMSE = paste(SecondPredMSE, " & ", sep="");flush.console();
   }
    FirstPredMSE = paste(FirstPredMSE,
      paste(paste(round(PredMSE$PredMSEM,2), collapse= " & "), sep=""),
      " \\\\ ", sep="");
    SecondPredMSE = paste(SecondPredMSE,
      paste( "$\\mbox{\\footnotesize{(", round(PredMSE$PredMSELowCI,roundShort), ", ",
      round(PredMSE$PredMSEUpCI,roundShort), ")}}$ ", collapse= " & ", sep=""), " \\\\ ", sep="");
  if (!exists("TrueParamVec")) {
    TrueParamVec = TrueParameterVec;
  }
  PDW <- ProcessDiallelWrong(TrueParamVec, GriffingOAs2, ReadGIters2,
     BayesDiallelOAs2, ReadRDIters2, TargetRDTable = TargetRDTable2,
      TargetRDProb = TargetRDProb2)  
  FixedErrorLine = paste("Untrue  ", " Fixed\\footnote{",
    DiallelFixedString, "}  & ",
      paste(PDW$PFixedWrong, collapse=" & "), "\\\\", sep="");
  RandomErrorLine = paste("Untrue ", " Random\\footnote{",
    DiallelRandomString, "}  & ",
      paste(PDW$PRandomWrong, collapse=" & ", sep=""), "\\\\", sep="");
  FinalLine = "\\hline \\end{tabular}"    
  AllTable = paste(FirstLine, SecondLine, ThirdLine, FourthLine, "\\hline",
    paste(GroupLines, collapse="  \\\\
 "), "\\\\ \\hline ",
    FirstPredMSE, SecondPredMSE, "\\hline",
    FixedErrorLine, RandomErrorLine, FinalLine, sep="
");
  if (FileName != "") {
    fcon = file(FileName, open = "wt");
    writeLines(text=AllTable, con=fcon);
    close(fcon);
  }
  return(AllTable)
}

WriteWillTable <- function(TrueParamVec, GriffingOAs=GriffingOAs,
  BayesDiallelOAs=BayesDiallelOAs, FileName ="", SigLevel = .2,
  ReadIter = 1, TargetRDTable = NULL, TargetRDProb = NULL, HitSimPreds=NULL,
  KeepGAs = -1, KeepRDs = -1) {
    
  if (is.numeric(KeepGAs)) { 
    if (length(KeepGAs) == 1 && KeepGAs[1] == -1) {
      KeepGAs = 1:length(GriffingOAs); 
    } else {
      KeepGAs = KeepGAs[KeepGAs > 0 & KeepGAs <= length(GriffingOAs)];
    }
  } else {
    KeepGAs = NULL;
  }
  if (is.numeric(KeepRDs)) { 
    if (length(KeepRDs) == 1 && KeepRDs[1] == -1) {
      KeepRDs = 1:length(BayesDiallelOAs); 
    } else {
      KeepRDs = KeepRDs[KeepRDs > 0 & KeepRDs <= length(BayesDiallelOAs)];
    }
  } else {
    KeepRDs = NULL;
  }

  if (!is.null(GriffingOAs) && length(GriffingOAs) > 0) {
  if (length(ReadIter) == 1) {
    if (ReadIter < 1) { ReadIter = 1;}
    ReadGIters = rep(ReadIter, length(GriffingOAs));
    for (ii in 1:length(GriffingOAs)) {
      if (dim(GriffingOAs[[ii]]$MeanVals$ReadTable)[1] < ReadGIters[ii]) {
        ReadGIters[ii] = dim(GriffingOAs[[ii]]$MeanVals$ReadTable)[1];
      }
    }
  } else {
    ReadGIters = list();
    for (ii in 1:length(GriffingOAs)) {
      RTO = 1:dim(GriffingOAs[[ii]]$MeanVals$ReadTable)[1];
      UseIters = RTO[RTO %in% ReadIter];
      ReadGIters[[ii]] = UseIters;
    }
  }}
  if (!is.null(BayesDiallelOAs) && length(BayesDiallelOAs) > 0) {
  if (length(ReadIter) == 1) {
    if (ReadIter < 1) { ReadIter = 1;}
    ReadRDIters = rep(ReadIter, length(BayesDiallelOAs));
    for (ii in 1:length(BayesDiallelOAs)) {
      if (dim(BayesDiallelOAs[[ii]]$MeanVals$ReadTable)[1] < ReadRDIters[ii]) {
        ReadRDIters[ii] = dim(BayesDiallelOAs[[ii]]$MeanVals$ReadTable)[1];
      }
    }
  } else {
    ReadRDIters = list();
    for (ii in 1:length(BayesDiallelOAs)) {
      RTO = 1:dim(BayesDiallelOAs[[ii]]$MeanVals$ReadTable)[1];
      UseIters = RTO[RTO %in% ReadIter];
      ReadGIters[[ii]] = UseIters; 
    }
  }
  }
  if (length(KeepGAs) > 0 && length(KeepRDs) > 0) {
  FirstLine = paste("\\begin{tabular}{cc|", 
    paste(rep("c", length(KeepGAs)), collapse=""),  "|",
    paste(rep("c", length(KeepRDs)), collapse=""), "} \\hline ", sep="");
  SecondLine = paste("\\multicolumn{2}{c|}{Simulated} & ",
    "\\multicolumn{", length(KeepGAs), "}{c}{Griffing} & ",
    "\\multicolumn{", length(KeepRDs), "}{c}{BayesDiallel} \\\\ ", sep="");
  } else if (length(KeepGAs) > 0) {
 FirstLine = paste("\\begin{tabular}{cc|", 
    paste(rep("c", length(KeepGAs)), collapse=""),  "|",
     sep="");
  SecondLine = paste("\\multicolumn{2}{c|}{Simulated} & ",
    "\\multicolumn{", length(KeepGAs), "}{c}{Griffing} & ",
    sep="");    
  } else if (length(KeepRDs) > 0) {
 FirstLine = paste("\\begin{tabular}{cc|", 
    paste(rep("c", length(KeepRDs)), collapse=""), "} \\hline ", sep="");
  SecondLine = paste("\\multicolumn{2}{c|}{Simulated} & ",
    "\\multicolumn{", length(KeepRDs), "}{c}{BayesDiallel} \\\\ ", sep="");    
  }  else {
    print("Give Me Something"); return(NULL);
  }

  ThirdLine = paste("Param & True  ", sep="");
  if (length(KeepGAs) > 0) {
  for (ii in 1:length(KeepGAs)) { ThirdLine = paste( ThirdLine, " & "," ",
    GriffingOAs[[KeepGAs[ii]]]$ModelSubName,  sep=""); }
  }
  if (length(KeepRDs) > 0 ) {
  for (ii in 1:length(KeepRDs)) { ThirdLine = paste(ThirdLine, " & ", " ",
    BayesDiallelOAs[[KeepRDs[ii]]]$ModelSubName,  sep=""); }
  } 
  ThirdLine = paste(ThirdLine, " \\\\ ", sep="");  flush.console();
  if (length(KeepGAs) > 0) {
  FourthLine = paste(" &  Value ", paste(
    rep( " & ", length(GriffingOAs)), collapse=""), sep="");
  } else {
  FourthLine = paste(" &  Value ",  sep="");    
  }
  if (length(KeepRDs) > 0) {
  for (tit in 1:length(KeepRDs)) {
    ii = KeepRDs[tit];
    if (!is.list(ReadRDIters)) {
    if (exists("TargetRDTable") && !is.null(TargetRDTable) && TargetRDTable[ii] == "MedianVals") {
     CTN = colnames(BayesDiallelOAs[[ii]]$MedianVals$ReadTable)
     TN = BayesDiallelOAs[[ii]]$MedianVals$ReadTable[ReadRDIters[ii],]
     TN = TN[CTN != "SimID"]; CTN = CTN[CTN != "SimID"]; names(TN) = CTN;
    FourthLine = paste(FourthLine,
      " & ", "``", ModelToString(TN,
        SigLevel),"''", sep="");
    } else {
     CTN = colnames(BayesDiallelOAs[[ii]]$MedianVals$ReadTable)
     TN = BayesDiallelOAs[[ii]]$MeanVals$ReadTable[ReadRDIters[ii],]
     TN = TN[CTN != "SimID"];  CTN=CTN[CTN!="SimID"];  names(CTN) = CTN;
     FourthLine = paste(FourthLine,
      " & ", "``", ModelToString(TN,
        SigLevel),"''", sep="");       
    }
    } else {
    if (exists("TargetRDTable") && !is.null(TargetRDTable) && TargetRDTable[ii] == "MedianVals") {
     CTN = colnames(BayesDiallelOAs[[ii]]$MedianVals$ReadTable)
     TN1 = BayesDiallelOAs[[ii]]$MedianVals$ReadTable[ReadRDIters[[ii]],]
     TN1 = TN1[,CTN != "SimID"]; CTN = CTN[CTN != "SimID"]
     TN = TN1[1,];
     for (tt in 1:length(TN1[1,])) {
       TN[tt] = median(TN1[,tt]);
     }
     names(TN) = CTN;
    FourthLine = paste(FourthLine,
      " & ", "``", ModelToString(TN,
        SigLevel),"''", sep="");
    } else {
     CTN = colnames(BayesDiallelOAs[[ii]]$MedianVals$ReadTable);
     TN1 = BayesDiallelOAs[[ii]]$MeanVals$ReadTable[ReadRDIters[[ii]],]
     TN1 = TN1[,CTN != "SimID"]; CTN=CTN[CTN != "SimID"]
     TN = TN1[1,];  names(TN) = CTN;
     for (tt in 1:length(TN1[1,])) {
       TN[tt] = median(TN1[,tt]);
     }
     FourthLine = paste(FourthLine,
      " & ", "``", ModelToString(TN,
        SigLevel),"''", sep="");   
    
    }    
    }
  } 
  }
  FourthLine = paste(FourthLine, " \\\\ \\hline", sep="");
  FifthLine = " \\hline "
  NextLines = list();
  GriffingOAs2 = list();  ReadGIters2 = c();
  if (length(KeepGAs) > 0) {
    for (ii in 1:length(KeepGAs)) {
      GriffingOAs2[[ii]] = GriffingOAs[[KeepGAs[ii]]];
      ReadGIters2 = c(ReadGIters2, ReadGIters[KeepGAs[ii]]);
    }
  }
  BayesDiallelOAs2 = list();  ReadRDIters2 = c();
  TargetRDTable2 = c();  TargetRDProb2 = c();
  if (length(KeepRDs) > 0) {
    for (ii in 1:length(KeepRDs)) {
      BayesDiallelOAs2[[ii]] = BayesDiallelOAs[[KeepRDs[ii]]];
      ReadRDIters2 = c(ReadRDIters2, ReadRDIters[KeepRDs[ii]]);
      TargetRDTable2 = c(TargetRDTable2, TargetRDTable[KeepRDs[ii]])
      TargetRDProb2 = c(TargetRDProb2, TargetRDProb[KeepRDs[ii]])
    }
  }
  if (length(ReadIter) == 1) {
    NowPDS <- ProcessDiallelStuff(TrueParamVec, GriffingOAs2, ReadGIters2, 
      BayesDiallelOAs2, ReadRDIters2, TargetRDTable=TargetRDTable);
  } else {
    NowPDS <- ProcessDiallelStuff(GriffingOAs[[1]]$TrueParamTable$ReadTable, GriffingOAs2, ReadGIters2, 
      BayesDiallelOAs2, ReadRDIters2, TargetRDTable=TargetRDTable2);  
  }
  TrueParamVec = TrueParamVec[names(TrueParamVec) != "SimID"];
  jti = 0;
  for (ii in 1:length(TrueParamVec)) {
    if (TrueParamVec[ii] != 0  &&
      substr(names(TrueParamVec)[ii],1, nchar("tau:")) != "tau:") {
    NextLine = paste( LatexVariable(names(TrueParamVec)[ii]), " & ",
      round(TrueParamVec[ii], 2), " & ",
      paste( round(NowPDS$MeanMatrix[ii,],2), collapse= " & "), "\\\\", "
", 
      " &  & ",
       paste( "(", round(NowPDS$LowCIM[ii,],2), ", ",
         round(NowPDS$UpCIM[ii,],2), ")", sep="", collapse= "  & "), "\\\\",
       sep="");
    jti= jti +1;
    NextLines[[jti]] = NextLine;
    } 
  }
  PredMSE <- ProcessDiallelMSE(TrueParamVec, GriffingOAs2, ReadGIters2,
     BayesDiallelOAs2, ReadRDIters2, TargetRDTable = TargetRDTable2, 
     TargetRDProb = TargetRDProb2)
  if (is.null(HitSimPreds)) {
  
  }
  FirstPredMSE = paste("Predict & ", round(mean(sd(t(HitSimPreds))^2),2),
    "\\footnote{", PredMSEFootnote, "} & ",
    paste(paste(round(PredMSE$PredMSEM,1), collapse= " & "), sep=""),
    " \\\\ ", sep="");
  CHitPreds = sd(t(HitSimPreds))^2
  SecondPredMSE = paste("MSE & ", "(",
    round(quantile(CHitPreds,.025), 2), ", ", 
    round(quantile(CHitPreds, .975),2), ") & ",
    paste( "(", round(PredMSE$PredMSELowCI,2), ", ",
      round(PredMSE$PredMSEUpCI,2), ") ", collapse= " & ", sep=""), " \\\\ ", sep="");
  PDW <- ProcessDiallelWrong(TrueParamVec, GriffingOAs2, ReadGIters2,
     BayesDiallelOAs2, ReadRDIters2, TargetRDTable = TargetRDTable2, TargetRDProb = TargetRDProb2)  
  FixedErrorLine = paste("Top false& ", " Fixed\\footnote{",
    DiallelFixedString, "}  & ",
      paste(PDW$PFixedWrong, collapse=" & "), "\\\\", sep="");
  RandomErrorLine = paste("compnts. & ", " Random\\footnote{",
    DiallelRandomString, "}  & ",
      paste(PDW$PRandomWrong, collapse=" & ", sep=""), "\\\\", sep="");
  FinalLine = "\\hline \\end{tabular}"    
  AllTable = paste(FirstLine, SecondLine, ThirdLine, FourthLine,
    paste(NextLines, collapse="
"), " \\hline ",
    FirstPredMSE, SecondPredMSE, "\\hline",
    FixedErrorLine, RandomErrorLine, FinalLine, sep="
");
  if (FileName != "") {
    fcon = file(FileName, open = "wt");
    writeLines(text=AllTable, con=fcon);
    close(fcon);
  }
  return(AllTable)
  
}
PredMSEFootnote = paste("For true values, we give mean and 95\\% confidence ",
  " interval for ", "$\\frac{1}{T}\\sum_{t=1}^{T}",
  " (Y_{i}^{(t)} - \\bar{Y}_{i}^{\\cdot})^2$", sep="");
DiallelFixedString=paste("Number in brackets is ",
  "$\\mbox{min}(p(\\beta > 0 | \\mbox{Data}), p(\\beta < 0 | \\mbox{Data})$",
  " for True, DICmin, and Full models, and $p(\\beta \\neq 0 | \\mbox{Data})$ ",
  " for BayesSpike. )", sep="");
DiallelRandomString=paste("Number in brackets is ",
  "magnitude of the falsely included random effects vector ",
  "$\\boldsymbol{\\theta}$ averaged over MCMC samples $T$ ",
  "(as $\\sqrt{(J-1)^{-1}\\sum_{j}(\\bar{\\theta}_{j} - \\bar{\\theta})^2}$ ",
  ") ", sep="");

##.DefaultAllFixedVariables; .DefaultAllRandomVariables;

ProcessDiallelWrong <- function(TrueParamVec, GriffingOAs, ReadGIters,
  BayesDiallelOAs, ReadRDIters, TargetRDProb = NULL, TargetRDTable = NULL) {
  FixedWrong <- rep("", length(GriffingOAs) + length(BayesDiallelOAs));
  RandomWrong <- rep("", length(GriffingOAs) + length(BayesDiallelOAs));

  PFixedWrong <- rep("", length(GriffingOAs) + length(BayesDiallelOAs));
  PRandomWrong <- rep("", length(GriffingOAs) + length(BayesDiallelOAs));
  TrueParamVec = TrueParamVec[names(TrueParamVec) != "SimID"];
  TrueGroups = GetTrueGroups(TrueParamVec);
  if (!is.null(GriffingOAs) && length(GriffingOAs) > 0) {
  for (ii in 1:length(GriffingOAs)) {
     CN = colnames(GriffingOAs[[ii]]$MeanVals$ReadTable);
 
     if (is.list(ReadGIters) && length(ReadGIters[[ii]]) > 1) {
      ICN = (1:length(CN))[CN != "SimID"];
       TGCol = c(-666, colMeans(GriffingOAs[[ii]]$MeanVals$ReadTable[ReadGIters[[ii]],ICN], na.rm=TRUE));
       names(TGCol)[1] = "SimID";
     } else {
       ICN = (1:length(CN))[CN != "SimID"];
       TGCol = GriffingOAs[[ii]]$MeanVals$ReadTable[ReadGIters[[ii]],ICN];
       TGCol = c(-666, TGCol);
       names(TGCol)[1] = "SimID"
     }
     if (is.list(ReadGIters)) {
       jjiters = ReadGIters[[ii]]
     } else {
       jjiters = ReadGIters[ii];
     }
     
     IterValidFixed = (1:length(CN))[CN %in% BayesDiallel:::.DefaultAllFixedVariables &
       !(CN %in% names(TrueParamVec)[TrueParamVec!= 0])];
     if(length(TGCol[IterValidFixed]) > 0) {
       if (length(TGCol[IterValidFixed]) == 1) {
         GuiltiestFixed = 1;
       } else {
         GuiltiestFixed = sort(
         TGCol[IterValidFixed], index=TRUE,
         decreasing=TRUE)$ix[1];
       }
     } else {GuiltiestFixed = NULL;}
     if (is.null(GuiltiestFixed) || length(GuiltiestFixed) == 0) {
       FixedWrong[ii] = "-";
     } else {
       FD = TGCol[IterValidFixed[GuiltiestFixed]];
       names(FD) = CN[IterValidFixed[GuiltiestFixed]];
       FixedWrong[ii] = paste(ModelToString(FD, .1), "(",
         round(as.numeric(FD), 3), ")", sep="");
       if (FixedWrong[ii] == "(0)") {FixedWrong[ii] = "-" }
     }
      BB = TGCol; BB = BB;
      CN = CN;
     names(BB) = CN;
     MyG = NULL;
     try(MyG <- GetTheWorstWrong(BB, TrueParamVec[TrueParamVec != 0], TrueGroups, CutOff = .01));
     if (is.null(MyG) || MyG[1] == "-") {
       RandomWrong[ii] = "-";
     } else {
       RandomWrong[ii] = MyG[1];
     }
     PZZ = GriffingOAs[[ii]]$SmPVal;
     if (is.list(ReadGIters) && length(ReadGIters[[ii]]) > 1) {
       IZN = (1:length(colnames(PZZ$ReadTable)))[ colnames(PZZ$ReadTable) != "SimID"];
       PZZS = colMeans(GriffingOAs[[ii]]$SmPVal$ReadTable[ReadGIters[[ii]],IZN], na.rm=TRUE);
       PZZS = c(-666, PZZS);
       names(PZZS)[1] = "SimID";
     } else {
       PZZS = GriffingOAs[[ii]]$SmPVal$ReadTable[ReadGIters[[ii]],];
     }
     CN = names(PZZ$ReadTable);
     IterValidFixed = (1:length(CN))[CN %in% BayesDiallel:::.DefaultAllFixedVariables &
       !(CN %in% names(TrueParamVec)[TrueParamVec != 0])];
     if (length(PZZS[IterValidFixed]) == 1) {
       GuiltiestFixed = 1;
     } else if (length(PZZS[IterValidFixed]) <= 0) {
       GuiltiestFixed = NULL;
     } else {
       GuiltiestFixed = sort(
         PZZS[IterValidFixed], index=TRUE,
         decreasing=TRUE)$ix[1];
     }
     if (is.null(GuiltiestFixed) || length(GuiltiestFixed) == 0) {
       FixedWrong[ii] = "-";
     } else {
       FD = PZZS[IterValidFixed[GuiltiestFixed]];
       names(FD) = CN[IterValidFixed[GuiltiestFixed]];
       PFixedWrong[ii] = paste(ModelToString(FD, .1), "(",
         round(as.numeric(FD), 3), ")", sep="");
       if (PFixedWrong[ii] == "(0)") {PFixedWrong[ii] = "-" }
     }

     BB = PZZS;
     names(BB) = CN;
     MyG = NULL;
     try(MyG <- GetTheWorstWrong(BB, TruePramVec, TrueGroups, CutOff = .001));
     if (is.null(MyG) || MyG[1] == "-") {
       PRandomWrong[ii] = "-";
     } else {
       PRandomWrong[ii] = MyG[1];
     }
  }}
  if (!is.null(BayesDiallelOAs) && length(BayesDiallelOAs) > 0) {
  for (ii in 1:length(BayesDiallelOAs)) { 
     ##jj = ReadRDIters[ii];
     if (exists("TargetRDTable") && !is.null(TargetRDTable) &&
       length(TargetRDTable) >= ii && TargetRDTable[ii] == "MeanVals") {
      MZZ = BayesDiallelOAs[[ii]]$MeanVals;
     } else if (exists("TargetRDTable") && !is.null(TargetRDTable) &&
       length(TargetRDTable) >= ii && TargetRDTable[ii] == "MedianVals") {
      MZZ = BayesDiallelOAs[[ii]]$MedianVals;     
     } else { MZZ = BayesDiallelOAs[[ii]]$MeanVals; }
     CN = colnames(BayesDiallelOAs[[ii]]$MeanVals$ReadTable);
     IterValidFixed = (1:length(CN))[CN %in% BayesDiallel:::.DefaultAllFixedVariables &
       !(CN %in% names(TrueParamVec)[TrueParamVec != 0])];
     if (exists("TargetRDTable") && !is.null(TargetRDTable) && TargetRDTable[[ii]] == "MedianVals") {
       MZZ = BayesDiallelOAs[[ii]]$MedianVals;
     } else {
       MZZ =  BayesDiallelOAs[[ii]]$MeanVals;
     }
     
     if (is.list(ReadRDIters) && length(ReadRDIters[[ii]]) > 1) {
       ITM = (1:length(colnames(MZZ$ReadTable)))[ colnames(MZZ$ReadTable) != "SimID"];
       MZZS = colMeans(MZZ$ReadTable[ReadRDIters[[ii]],ITM], na.rm=TRUE);
       MZZS = c(-666, MZZS);
       names(MZZS)[1] = "SimID";
     } else {
       MZZS = MZZ$ReadTable[ReadRDIters[[ii]],];
     }
     if (length(MZZS[IterValidFixed]) == 1) {
       GuiltiestFixed = 1;
     } else if (length(MZZS[IterValidFixed]) <= 0) {
       GuiltiestFixed = NULL;
     } else {
       GuiltiestFixed = sort(
         MZZS[IterValidFixed], index=TRUE,
         decreasing=TRUE)$ix;
     }
     if (is.null(GuiltiestFixed) || length(GuiltiestFixed) == 0) {
       FixedWrong[ii+ length(GriffingOAs)] = "-";
     } else {
       FD = MZZS[IterValidFixed[GuiltiestFixed]];
       names(FD) = CN[IterValidFixed[GuiltiestFixed]];
       FixedWrong[ii + length(GriffingOAs)] = paste(ModelToString(FD, -1), "(",
         round(as.numeric(FD), 3), ")", sep="");
      if (round(as.numeric(FD), 3) == 0) { 
         FixedWrong[ii+length(GriffingOAs)] = "-"
       }
     }
     
     
     BB = MZZS;
     names(BB) = CN;
     MyG = NULL;
     try(MyG <- GetTheWorstWrong(BB, TrueParamVec, TrueGroups));
     if (is.null(MyG) || MyG[1] == "-") {
       RandomWrong[ii+length(GriffingOAs)] = "-";
     } else {
       RandomWrong[ii+length(GriffingOAs)] = MyG[1];
     }         
     if (exists("TargetRDProb") && !is.null(TargetRDProb) &&
       length(TargetRDProb) >= ii && TargetRDProb[ii] == "MIPVal") {
       PZZ = BayesDiallelOAs[[ii]]$MIPVal;
       if (is.list(ReadRDIters) && length(ReadRDIters[[ii]]) > 1) {
         IZN = (1:length(colnames(PZZ$ReadTable)))[colnames(PZZ$ReadTable) != "SimID" &
           substr(colnames(PZZ$ReadTable), 1, nchar("a:")) == "a:"];
         PZZS = colMeans(PZZ$ReadTable[ReadRDIters[[ii]],IZN], na.rm = TRUE);
         names(PZZS) = substr(names(PZZS), nchar("a:")+1, nchar(names(PZZS)));
         PZZS = c(-666, PZZS);
         names(PZZS)[1] = "SimID"
       } else {
         IZN = (1:length(colnames(PZZ$ReadTable)))[colnames(PZZ$ReadTable) != "SimID" &
           substr(colnames(PZZ$ReadTable), 1, nchar("a:")) == "a:"];
         PZZS = PZZ$ReadTable[ReadRDIters[[ii]],IZN];
         names(PZZS) = substr(names(PZZS), nchar("a:")+1, nchar(names(PZZS)));
         PZZS = c(-666, PZZS);
         names(PZZS)[1] = "SimID"
         PZZS = unlist(PZZS);
       }
     } else {
       PZZ = BayesDiallelOAs[[ii]]$SmPVal;
       if (is.list(ReadRDIters) && length(ReadRDIters[[ii]]) > 1) {
         IZN = (1:length(colnames(PZZ$ReadTable)))[colnames(PZZ$ReadTable) != "SimID"];
         PZZS = colMeans(PZZ$ReadTable[ReadRDIters[[ii]],IZN], na.rm = TRUE);
         PZZS = c(-666, PZZS);
         names(PZZS)[1] = "SimID"
       } else {
         PZZS = PZZ$ReadTable[ReadRDIters[[ii]],];
       }
     }

     if (length(PZZS[IterValidFixed]) == 1) {
       GuiltiestFixed = 1;
     } else if (length(PZZS[IterValidFixed]) <= 0) {
      GuiltiestFixed = NULL;
     } else {
       GuiltiestFixed = sort(
         PZZS[IterValidFixed], index=TRUE,
         decreasing=TRUE)$ix[1];
     }
     if (is.null(GuiltiestFixed) || length(GuiltiestFixed) == 0) {
       PFixedWrong[ii+ length(GriffingOAs)] = "-";
     } else {
       FD = PZZS[IterValidFixed[GuiltiestFixed]];
       names(FD) = CN[IterValidFixed[GuiltiestFixed]];
       PFixedWrong[ii + length(GriffingOAs)] = paste(ModelToString(FD, .00001), "(",
         round(as.numeric(FD), 3), ")", sep="");
       if ( round(as.numeric(FD), 3) == 0 ) { 
         PFixedWrong[ii+length(GriffingOAs)] = "-"}
     }
     if (exists("TargetRDProb") && !is.null(TargetRDProb) &&
       length(TargetRDProb) >= ii && TargetRDProb[ii] == "MIPVal") {
      TTrueGroups = TrueGroups[TrueGroups %in% BayesDiallel:::.DefaultAllRandomVariables]
      PZZ = BayesDiallelOAs[[ii]]$MIPVal;

      if (is.list(ReadRDIters) && length(ReadRDIters[[ii]]) > 1) {
       ITN = (1:length(colnames(PZZ$ReadTable)))[ 
         colnames(PZZ$ReadTable) != "SimID"];
       APZ =  PZZ$ReadTable[ReadRDIters[[ii]],ITN] 
       MyA = APZ[substr(colnames(APZ),1,nchar("a:")) == "a:"];
       MyB = APZ[substr(colnames(APZ),1,nchar("b:")) == "b:"];
       colnames(MyA) = substr(colnames(MyA), nchar("a:")+1, nchar(colnames(MyA)));
      
       PZZS = colMeans(MyA, na.rm = TRUE);
       PZZS = c(-666, PZZS);
       names(PZZS)[1] = "SimID";
     } else {
       PZZS = PZZ$ReadTable[ReadRDIters[[ii]],];
       MyA = PZZS[substr(names(PZZS), 1, nchar("a:")) == "a:"];
       names(MyA) = substr(names(MyA), nchar("a:") + 1, nchar(names(MyA)));
       PZZS = c(-666, MyA);
       names(PZZS)[1] = "SimID"
       PZZS = unlist(PZZS);
     }
      COLS = PZZS[!(names(PZZS) %in% 
        paste("tau:", TTrueGroups, sep="")) & 
        names(PZZS) %in% 
        paste("tau:", BayesDiallel:::.DefaultAllRandomVariables, sep="")
        ]
      names(COLS) = substr(names(COLS), 1, nchar(names(COLS)));
      Stix = sort(unlist(COLS), index=TRUE, decreasing=TRUE)$ix[1]
      FDD = COLS[Stix]; names(FDD) = substr(names(FDD), 5, nchar(names(FDD)) );
      PRandomWrong[ii + length(GriffingOAs)] = paste(ModelToString(FDD, -.1), "(",
         round(as.numeric(COLS[Stix]), 3), ")", sep="");
          
     } else { PRandomWrong[ii+ length(GriffingOAs)] = 
       RandomWrong[ii+ length(GriffingOAs)] }
  } }
  return(list(FixedWrong=FixedWrong, RandomWrong=RandomWrong,
    PFixedWrong=PFixedWrong, PRandomWrong = PRandomWrong));
}

ProcessDiallelMSE <- function(TrueParamVec, GriffingOAs, ReadGIters,
     BayesDiallelOAs, ReadRDIters, TargetRDTable = TargetRDTable, TargetRDProb = TargetRDProb,
     MyLowCI = .025, MyUpCI = .975, PredDiff) {
  PredMSEM <- rep(0, length(GriffingOAs) + length(BayesDiallelOAs));
  PredMSEUpCI <- rep(0, length(GriffingOAs) + length(BayesDiallelOAs));
  PredMSELowCI <- rep(0, length(GriffingOAs) + length(BayesDiallelOAs));
  if (!exists("MyUpCI")) { MyUpCI = .975; }
  if (!exists("MyLowCI")) { MyLowCI = .025; }
  if (length(GriffingOAs) > 0) {
  ICols = 1:length(GriffingOAs[[1]]$PredSimsMeanTable$ReadTable[1,])
  IN  = colnames(GriffingOAs[[1]]$PredSimsMeanTable$ReadTable[1,])
  } else {
  ICols = 1:length(BayesDiallelOAs[[1]]$PredSimsMeanTable$ReadTable[1,])
  IN  = colnames(BayesDiallelOAs[[1]]$PredSimsMeanTable$ReadTable[1,])    
  }
  
  if (!exists("BayesDiallel:::.SHSExColumns")) {
    LNN = c("MeanOfMeansT", "SdOfMeansT", "SdOfMeansJ",
    "MeanOfSdT", "MeanOfSdJ", "LowCIOfSdT", "UpCIOfSdT",
      "LowCIOfSdj", "UpCIOfSdj");
  }  else {
    LNN =   BayesDiallel:::.SHSExColumns
  }
  INCols = ICols[IN != "SimID" & !(IN %in% LNN)]
  if (!is.null(GriffingOAs) && length(GriffingOAs) > 0) {
  for (ii in 1:length(ReadGIters)) {
    if (length(GriffingOAs[[ii]]$PredSimsMeanTable$ReadTable) <= 0 ||
      NROW(GriffingOAs[[ii]]$PredSimsMeanTable$ReadTable) <= 0) {
      print(paste("UhOh, trying to read GriffingOAs[[ii=",ii,"]] with ",
        GriffingOAs[[ii]]$ModelName, "/", GriffingOAs[[ii]]$ModelSubName,
        " is not good has no dimension for PredSimsMeanTable", sep=""))
      flush.console();
    } else if (is.list(ReadGIters) && length(ReadGIters[[ii]]) > 1) {
      OurC = as.character(GriffingOAs[[ii]]$MeanVals$ReadTable[,1]);
      if (!is.null(ReadGIters[[ii]])) {
        OurC = OurC[ReadGIters[[ii]][ReadGIters[[ii]] %in% (1:length(OurC))]];
      }
      OurD = as.character(GriffingOAs[[ii]]$PredSimsMeanTable$ReadTable[,1]);
       Keep = match(OurD,OurC);
      TNN = GriffingOAs[[ii]]$PredSimsMeanTable$ReadTable[(1:length(OurD))[!is.na(Keep)],INCols];
      ITN = matrix(0, dim(TNN)[1], dim(TNN)[2]);
      ITN[1:(dim(TNN)[1] * dim(TNN)[2])] = as.numeric(unlist(TNN));
      MZZ = colMeans(ITN)
      ##MZZ = unlist(colMeans(GriffingOAs[[ii]]$PredSimsMeanTable$ReadTable[ReadGIters[[ii]],INCols], na.rm = TRUE));
    } else {
      if (ReadGIters[[ii]] > NROW(GriffingOAs[[ii]]$PredSimsMeanTable$ReadTable)) {
        MZZ = as.numeric(unlist(GriffingOAs[[ii]]$PredSimsMeanTable$ReadTable[
          NROW(GriffingOAs[[ii]]$PredSimsMeanTable$ReadTable),INCols]));
      }
      MZZ = as.numeric(unlist(GriffingOAs[[ii]]$PredSimsMeanTable$ReadTable[ReadGIters[[ii]],INCols]));
      ##MZZ = unlist(GriffingOAs[[ii]]$PredSimsMeanTable$ReadTable[ReadGIters[[ii]],INCols]);
    }
    ##jj = ReadGIters[ii]
    
    PredMSEM[ii] = mean(MZZ, na.rm=TRUE);
    PredMSEUpCI[ii] = quantile(MZZ, MyUpCI, na.rm=TRUE);
    PredMSELowCI[ii] = quantile(MZZ, MyLowCI, na.rm=TRUE);  
  } }
  if (!is.null(BayesDiallelOAs) && length(BayesDiallelOAs) > 0) {
  for (ii in 1:length(ReadRDIters)) {
    if (exists("TargetRDTable") && !is.null(TargetRDTable) && TargetRDTable[[ii]] == "MedianVals") {
      AT = BayesDiallelOAs[[ii]]$PredSimsMedianTable 
    } else {
      AT= BayesDiallelOAs[[ii]]$PredSimsMeanTable;
    }
  
    if (length(AT$ReadTable) <= 0 || NROW(AT$ReadTable) <= 0) {
      print(paste("PredSimsMean Calculation error for BayesOAs[ii=]", ii,
        ",  for Model: ", BayesDiallelOAs[[ii]]$ModelName, "/",
        BayesDiallelOAs[[ii]]$ModelSubName, ", doh!", sep="")); flush.console();
    } else if (is.list(ReadRDIters) && length(ReadRDIters[[ii]]) > 1) {
      OurC = as.character(BayesDiallelOAs[[ii]]$MeanVals$ReadTable[,1]);
      if (!is.null(ReadRDIters[[ii]])) {
        OurC = OurC[ReadRDIters[[ii]][ReadRDIters[[ii]] %in% (1:length(OurC))]];
      }
      OurD = as.character(AT$ReadTable[,1]);
       Keep = match(OurD,OurC);
      
      
      ##ITN = matrix(0, dim(TNN)[1], dim(TNN)[2]);
      ##ITN[1:(dim(TNN)[1] * dim(TNN)[2])] = as.numeric(unlist(TNN));
      ##MZZ = colMeans(ITN)
      ATT = AT$ReadTable[!is.na(Keep),INCols];
      ATT = ATT[apply(ATT,1, function(X) {!any(is.na(X))}),]
      ATI = matrix(0, dim(ATT)[1], dim(ATT)[2]);
      ATI[1:(dim(ATT)[1] * dim(ATT)[2])] = as.numeric(unlist(ATT));
      MZZ = colMeans(ATI, na.rm=TRUE);
      ##MZZ = unlist(colMeans(ATT, na.rm=TRUE));
    } else {
      if (is.null(ReadRDIters[[ii]]) ||
        ReadRDIters[[ii]] > NROW(AT$ReadTable)) {
        MZZ =  as.numeric(unlist(AT$ReadTable[NROW(AT$ReadTable),INCols]));
      } else {
        MZZ = as.numeric(unlist(AT$ReadTable[ReadRDIters[[ii]],INCols]));
      }
      ##MZZ = unlist(AT$ReadTable[ReadRDIters[[ii]],INCols]);
    }

    PredMSEM[ii + length(GriffingOAs)] = mean(MZZ,na.rm=TRUE);
    PredMSEUpCI[ii+ length(GriffingOAs)] = quantile(MZZ, MyUpCI, na.rm=TRUE);
    PredMSELowCI[ii+ length(GriffingOAs)] = quantile(MZZ, MyLowCI, na.rm=TRUE);  
  } }
  return(list(PredMSEM=PredMSEM, PredMSEUpCI = PredMSEUpCI, PredMSELowCI = PredMSELowCI));   
  
}
     
GetTrueGroups <- function(TrueParamVec) {
  MyNamesMatch = c("Mu", "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av",
    "aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej", "Gender:dominancej",
    "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk")
  MyNTN = rep(0, length(TrueParamVec));
  for (ii in 1:length(MyNamesMatch)) {
    MyNTN[substr(names(TrueParamVec), 1, nchar(MyNamesMatch[ii])) ==
      MyNamesMatch[ii] & TrueParamVec > 0 ] =
      MyNamesMatch[ii];
    ##MyNTN[substr(names(TrueParamVec), 1 + nchar("tau:"), nchar(MyNamesMatch[ii])) ==
    ##  paste("tau:", MyNamesMatch[ii], sep="")] =
    ##  MyNamesMatch[ii];
  }
  UniqueNames = sort(unique(MyNTN));
  UniqueNames = UniqueNames[!(UniqueNames %in% c("Sigma", "tau", "", "SimID", "0"))]
  return(UniqueNames);
}
GetTheWorstWrong <- function(WrongBetas, TrueParamVec, TrueGroups, CutOff = .01) {
  WrongBetas = unlist(WrongBetas);
  WrongBetas = WrongBetas[ names(WrongBetas) != "SimID"]
  AllNamesStuff = strsplit(names(WrongBetas), ":");
  ATA = rep("", length(WrongBetas))
  for (ii in 1:length(AllNamesStuff)) {
    ATA[ii] = AllNamesStuff[[ii]][1];  
  }
  UniqueNames = sort(unique(ATA));
  UniqueNames = UniqueNames[!(UniqueNames %in% c("Sigma", "tau", "", "SimID"))]
  WrongNames = UniqueNames[UniqueNames %in% BayesDiallel:::.DefaultAllRandomVariables &
    !(UniqueNames %in% TrueGroups)]
  if (length(WrongNames) == 0) {
    return(NULL);
  }
  RankSubSet = rep(0, length(WrongNames));
  for (ii in 1:length(WrongNames)) {
    RankSubSet[ii] = sd( WrongBetas[substr(names(WrongBetas), 1, nchar(WrongNames)[ii])
      == WrongNames[ii]])
  }
  ABad = sort(RankSubSet, decreasing=TRUE, index=TRUE);
  MB = RankSubSet[ABad$ix]; names(MB) = WrongNames[ABad$ix];
  VV = rep("", length(MB));
  for (kk in 1:length(VV)) {
    VV[kk] = paste(ModelToString(MB[kk], CutOff), "(", round(as.numeric(MB[kk]),3), ")", sep="");
  }
  VV[MB == 0] = "-";
  return(VV);
}

RealGroupsFunction <- function(ATab, GoalGroups) {
  nATab = colnames(ATab);
  RTT = rep(0, length(GoalGroups));
  for (ii in 1:length(GoalGroups)) {
    if (any(substr(nATab, 1, nchar(GoalGroups)[ii]) == GoalGroups[ii])) {
       RTT[ii] = 1;
    }
  }
  RTT[GoalGroups == "Fixed"] = 1;
  return(GoalGroups[RTT == 1])
}
ProcessDiallelErrorCalc <- function(GoalGroups= c("aj", "motherj", "dominancj", "Genderj"), 
  GriffingOAs, ReadGIters,
  BayesDiallelOAs, ReadRDIters, TargetGTable =NULL, TargetRDTable=NULL, L2OrL1 = "L2",
  MeanOrMedian=NULL, ParamGroup = NULL, ParamVal = NULL, AllFixed = NULL,
  ITERS = NULL, NonNAIters = FALSE,
   Denominator = c("None","T1", "T2")[1], ShiftDiff = TRUE,
  quantiles=c(.025,.975)) {
  if (length(BayesDiallelOAs) > 0) {
  GoalGroups = RealGroupsFunction(BayesDiallelOAs[[1]]$TrueParamTable$ReadTable, GoalGroups);
  } else {
  GoalGroups = RealGroupsFunction(GriffingOAs[[1]]$TrueParamTable$ReadTable, GoalGroups);    
  }
  MeanMatrix = matrix(0, length(GoalGroups), length(GriffingOAs) + length(BayesDiallelOAs));
  LowCIM = matrix(0, length(GoalGroups), length(GriffingOAs) + length(BayesDiallelOAs));
  UpCIM = matrix(0, length(GoalGroups), length(GriffingOAs) + length(BayesDiallelOAs));
  if (!is.null(GriffingOAs) && length(GriffingOAs) > 0) {
  for (ii in 1:length(GriffingOAs)) {
    NNThis = names(GriffingOAs[[ii]]);
    if (exists("TargetGTable") && !is.null(TargetGTable) &&
      TargetGTable[[ii]] == "MedianVals") {
      TarNum = (1:length(NNThis))[NNThis == MedianVals];
      MZZ = GriffingOAs[[ii]]$MedianVals;
    } else {
      TarNum  = (1:length(NNThis))[NNThis == "MeanVals"];
       MZZ = GriffingOAs[[ii]]$MeanVals;
    }
    INNeed = (1:length(MZZ$ReadTable[1,]))[
      colnames(MZZ$ReadTable) %in% 
        nTrueParamVec ];
    MNNeed = (1:length(MZZ$ReadTable[1,]))[
      match(colnames(MZZ$ReadTable),
        nTrueParamVec) ];
    MNNeed = MNNeed[!is.na(MNNeed)];
    for (jj in 1:length(GoalGroups)) {
      ErrorOnNow = GriffinOAs[[ii]]$ProcessAverageError(L2OrL1=L2OrL1,
        MeanOrMedian=MeanOrMedian, ParamGroup=GoalGroups[jj], ParmVal = NULL,
        AllFixed=NULL, ITERS=NULL, NonNAIters = FALSE,)
    }
  } }
}

## In file "RTableProcessVals"
##setMethodS3("ProcessAverageError", "OutSimAnalyses", function(this, L2OrL1 = "L2",
##  MeanOrMedian=NULL, ParamGroup = NULL, ParamVal = NULL, AllFixed = NULL,
##  ITERS = NULL, NonNAIters = FALSE, Denominator = c("None","T1", "T2")[1],
##  ShiftDiff = TRUE,
##  quantiles=c(.025,.975),...) {
##})
ProcessDiallelStuff <- function(TrueParamVec, GriffingOAs, ReadGIters,
  BayesDiallelOAs, ReadRDIters, TargetGTable =NULL, TargetRDTable=NULL) {
 
  MeanMatrix = matrix(0, length(TrueParamVec), length(GriffingOAs) + length(BayesDiallelOAs));
  LowCIM = matrix(0, length(TrueParamVec), length(GriffingOAs) + length(BayesDiallelOAs));
  UpCIM = matrix(0, length(TrueParamVec), length(GriffingOAs) + length(BayesDiallelOAs));
  rownames(MeanMatrix) = names(TrueParamVec);
  rownames(LowCIM) = names(TrueParamVec);
  rownames(UpCIM) = names(TrueParamVec);
    
  if (!is.null(dim(TrueParamVec)) && length(TrueParamVec) == 2) {
    nTrueParamVec = colnames(TrueParamVec);
    nTrueParamVec = nTrueParamVec[nTrueParamVec != "SimID"]
  } else {
    nTrueParamVec = names(TrueParamVec);
  }
  nTrueParamVec = nTrueParamVec[nTrueParamVec != "SimID"];
  if (!is.null(GriffingOAs) && length(GriffingOAs) > 0) {
  for (ii in 1:length(GriffingOAs)) {
    NNThis = names(GriffingOAs[[ii]]);
    if (exists("TargetGTable") && !is.null(TargetGTable) &&
      TargetGTable[[ii]] == "MedianVals") {
      TarNum = (1:length(NNThis))[NNThis == MedianVals];
      MZZ = GriffingOAs[[ii]]$MedianVals;
    } else {
      TarNum  = (1:length(NNThis))[NNThis == "MeanVals"];
       MZZ = GriffingOAs[[ii]]$MeanVals;
    }
    INNeed = (1:length(MZZ$ReadTable[1,]))[
      colnames(MZZ$ReadTable) %in% 
        nTrueParamVec ];
    MNNeed = (1:length(MZZ$ReadTable[1,]))[
      match(colnames(MZZ$ReadTable),
        nTrueParamVec) ];
    MNNeed = MNNeed[!is.na(MNNeed)];
    if (is.list(ReadGIters) && length(ReadGIters[[ii]]) > 1) {
      FT1 = MZZ$ReadTable[ReadGIters[[ii]],INNeed];
    MeanMatrix[MNNeed, ii] = as.vector(as.numeric(unlist(colMeans(MZZ$ReadTable[ReadGIters[[ii]],INNeed], na.rm = TRUE))));
    LowCIM[MNNeed, ii] = as.vector(as.numeric(unlist(colMeans(GriffingOAs[[ii]]$LowCI$ReadTable[ReadGIters[[ii]],INNeed], na.rm = TRUE))));
    UpCIM[MNNeed, ii] = as.vector(as.numeric(unlist(colMeans(GriffingOAs[[ii]]$UpCI$ReadTable[ReadGIters[[ii]],INNeed], na.rm=TRUE))));    
    }  else {
    MeanMatrix[MNNeed, ii] = as.vector(as.numeric(unlist(MZZ$ReadTable[ReadGIters[[ii]],INNeed])));
    LowCIM[MNNeed, ii] = as.vector(as.numeric(unlist(GriffingOAs[[ii]]$LowCI$ReadTable[ReadGIters[[ii]],INNeed])));
    UpCIM[MNNeed, ii] = as.vector(as.numeric(unlist(GriffingOAs[[ii]]$UpCI$ReadTable[ReadGIters[[ii]],INNeed])));    
    }

  }}
  if (!is.null(BayesDiallelOAs) && length(BayesDiallelOAs) > 0) {
  for (ii in 1:length(BayesDiallelOAs)) {
      NNThis = names(BayesDiallelOAs[[ii]]);
    if (exists("TargetRDTable") && !is.null(TargetRDTable) &&
      TargetRDTable[[ii]] == "MedianVals") {
      TarNum = (1:length(NNThis))[NNThis == "MedianVals"];
      MZZ = BayesDiallelOAs[[ii]]$MedianVals;
    } else {
      TarNum  = (1:length(NNThis))[NNThis == "MeanVals"];
      MZZ = BayesDiallelOAs[[ii]]$MeanVals;
    }
  
    INNeed = (1:length(MZZ$ReadTable[1,]))[
      colnames(MZZ$ReadTable) %in% 
        nTrueParamVec ];
    MNNeed = (1:length(MZZ$ReadTable[1,]))[
      match(colnames(MZZ$ReadTable),
        nTrueParamVec) ];
    MNNeed = MNNeed[!is.na(MNNeed)];
    if (is.list(ReadRDIters) && length(ReadRDIters[[ii]]) > 1) {
    MeanMatrix[MNNeed, ii+length(GriffingOAs)] = 
      as.vector(as.numeric(unlist(colMeans(MZZ$ReadTable[ReadRDIters[[ii]],INNeed], na.rm=TRUE))));
    LowCIM[MNNeed, ii+length(GriffingOAs)] =
       as.vector(as.numeric(unlist(colMeans(BayesDiallelOAs[[ii]]$LowHPD$ReadTable[ReadRDIters[[ii]],INNeed], na.rm=TRUE))));
    UpCIM[MNNeed, ii+length(GriffingOAs)] = 
      as.vector(as.numeric(unlist(colMeans(BayesDiallelOAs[[ii]]$UpHPD$ReadTable[ReadRDIters[[ii]],INNeed], na.rm=TRUE))));
    }  else {
    MeanMatrix[MNNeed, ii+length(GriffingOAs)] = as.vector(as.numeric(unlist(MZZ$ReadTable[ReadRDIters[[ii]],INNeed])));
    LowCIM[MNNeed, ii+length(GriffingOAs)] = as.vector(as.numeric(unlist(BayesDiallelOAs[[ii]]$LowHPD$ReadTable[ReadRDIters[[ii]],INNeed])));
    UpCIM[MNNeed, ii+length(GriffingOAs)] = as.vector(as.numeric(unlist(BayesDiallelOAs[[ii]]$UpHPD$ReadTable[ReadRDIters[[ii]],INNeed])));   
    }
     }}
  dMM = dim(MeanMatrix)
  NewMeanMatrix = matrix(0, dMM[1], dMM[2]);
  NewMeanMatrix[1:(dMM[1]*dMM[2])] = as.numeric(unlist(MeanMatrix));
  rownames(NewMeanMatrix) = rownames(MeanMatrix);
  MeanMatrix = NewMeanMatrix;
  return(list(MeanMatrix=MeanMatrix, LowCIM = NumericMe(LowCIM), UpCIM = NumericMe(UpCIM)));  
}


LatexVariable <- function(StrN) {
  if (substr(StrN,1,3) == "aj:") {
    ATK = strsplit(StrN, "aj:"); ATK = unlist(ATK)[unlist(ATK)!= ""];
    return(paste("$a_{", as.numeric(ATK[1]), "}$", sep=""));
  }
  if (substr(StrN,1,2) == "Mu") {
    return(paste("$\\mu$", sep=""));
  }
  if (substr(StrN,1,5) == "Sigma") {
    return(paste("$\\sigma$", sep=""));
  }
}

ModelToString <- function(inBeta, SigLevel = .2) {
  Beta = inBeta;
  Beta = Beta[names(Beta) != "SimID" & names(Beta) != "SimId"];
  iDX = (1:length(Beta))[abs(as.numeric(Beta)) > SigLevel];
  SigBeta = Beta[iDX];
  names(SigBeta) = names(Beta)[iDX];
  nSigBeta = names(SigBeta);
  if (is.null(nSigBeta)) {
    print("ModelToString Error: Oh No, nSigBeta is NULL");
    print(" inBeta was: "); flush.console();
    print(inBeta);
  }
  MyString = "";
  if (any(nSigBeta == "BetaInbred:Gender:Av")) {
    MyString = paste(MyString, "$\\mbox{B}_{\\mbox{\\tiny{s}}}$", sep="")
  }
  if (any(nSigBeta == "BetaHybrid:Gender:Av")) {
    MyString = paste(MyString, "$\\mbox{B}_{\\mbox{\\tiny{s}}}$", sep="")
  }
  if (any(nSigBeta == "BetaInbred:Av")  && !any(nSigBeta == "BetaInbred:Gender:Av")) {
    MyString = paste(MyString, "$\\mbox{B}$", sep="")
  }
  if (any(nSigBeta == "BetaHybred:Av")  && !any(nSigBeta == "BetaInbred:Hybrid:Av")) {
    MyString = paste(MyString, "$\\mbox{B}$", sep="")
  }
  if (any(nSigBeta == "Gender:Av")) {
    MyString = paste(MyString, "$\\mbox{S}$", sep="")
  }
  if (any(substr(nSigBeta,1,2) == "aj") && !any(substr(nSigBeta,1,9) == "Gender:aj")) {
    MyString = paste(MyString, "$\\mbox{a}$", sep="")
  } else if (any(substr(nSigBeta,1,9) == "Gender:aj")) {
    MyString = paste(MyString, "$\\mbox{a}_{\\mbox{\\tiny{s}}}$", sep="")
  }
  if ( (any(substr(nSigBeta,1,10) == "dominancej"))  ||
    any(substr(nSigBeta,1,10) == "Dominancej" )
     && !any(substr(nSigBeta,1,17) == "Gender:dominancej")) {
    MyString = paste(MyString, "$\\mbox{b}$", sep="")
  } else if ( (any(substr(nSigBeta,1,17) == "Gender:dominancej")) ||
    any(substr(nSigBeta,1,17) == "Gender:Dominancej") ) {
    MyString = paste(MyString, "$\\mbox{b}_{\\mbox{\\tiny{s}}}$", sep="")
  }
  if (any(substr(nSigBeta,1,7) == "motherj") && !any(substr(nSigBeta,1,14) == "Gender:motherj")) {
    MyString = paste(MyString, "$\\mbox{m}$", sep="")
  } else if (any(substr(nSigBeta,1,14) == "Gender:motherj")) {
    MyString = paste(MyString, "$\\mbox{m}_{\\mbox{\\tiny{s}}}$", sep="")
  }

  if (any(substr(nSigBeta,1,8) == "SymCross") && !any(substr(nSigBeta,1,15) == "Gender:SymCross")) {
    MyString = paste(MyString, "$\\mbox{v}$", sep="")
  } else if (any(substr(nSigBeta,1,15) == "Gender:SymCross")) {
    MyString = paste(MyString, "$\\mbox{v}_{\\mbox{\\tiny{s}}}$", sep="")
  }
  if (any(substr(nSigBeta,1,9) == "ASymCross") && !any(substr(nSigBeta,1,16) == "Gender:ASymCross")) {
    MyString = paste(MyString, "$\\mbox{w}$", sep="")
  } else if (any(substr(nSigBeta,1,16) == "Gender:ASymCross")) {
    MyString = paste(MyString, "$\\mbox{w}_{\\mbox{\\tiny{s}}}$", sep="")
  }
  return(MyString);

}