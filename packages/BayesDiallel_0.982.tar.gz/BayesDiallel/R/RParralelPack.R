##############################################################################
##  RParrallel Pack
##
##  A R.oo based attempt to perform multi-core simulation databasing of common
##   metrics useful in MCMC analysis (specifically for the Diallel)
##
##  Some problems with data.frame converting numeric data to character/factor data
##   are an issue, which are caused by the "SimID" component which in retrospect is
##   not as useful as one had hoped
##
##  For large scale simulations an RParrallelPack table can unfortunately get large
##
##
##  Metrics like CI/HPD, coverage, posterior median, mean, and even metrics intended
##  to calculate future prediction MSE our stored in CSV tables.
##   ReadParrallelPack, and other functions are designed to process this data
##
##

library(R.oo, warn.conflicts=FALSE, verbose=FALSE);
tSeq = function(Number) {
CN <- sub("e", "e", as.character(Number));
CN <- sub("-", "n", as.character(CN));
CN <- sub("\\+", "f", as.character(CN));
CN <- sub("\\.", "p", as.character(CN));
CN <- sub("0p", "p", as.character(CN));
   return(CN);
}  

McMcStack <- function(codaList, killer = 50) {
  TL = 0;
  for (ii in 1:length(codaList)) {
    TL = TL + length(codaList[[ii]][,1]); 
  }    
  NewCoda = matrix(0, TL - killer * length(codaList), length(codaList[[1]][1,]));
  att = 0;
  for (ii in 1:length(codaList)) {
    NewCoda[(att+1):(att + length(codaList[[ii]][,1]) - killer), ] =
      codaList[[ii]][(killer+1):length(codaList[[ii]][,1]), ]
    att = att + length(codaList[[ii]][,1]) - killer;
  }
  colnames(NewCoda) = colnames(codaList[[ii]]);
  NewCoda = as.mcmc(NewCoda);
  return(NewCoda)
}

GetLowerTailProb <- function(meanVec, sdVec) {
  Col1 = pnorm(meanVec / sdVec);
  Col2 = pnorm(-meanVec / sdVec);
  MinCol = pmin(Col1,Col2);
  names(MinCol) = names(meanVec);
  return(MinCol);
}

GetLowPVals <- function(ACoda) {
  RL =0;
  if (is.null(dim(ACoda))) {
    LPct = rep(0, length(ACoda[[1]][1,]))
    RPct = rep(0, length(ACoda[[1]][1,]))
    for (ii in 1:length(ACoda)) {
      LPct <- LPct + colSums(ACoda[[ii]] < 0)
      RPct <- RPct + colSums(ACoda[[ii]] > 0)
    }
    RL = length(ACoda[[1]][,1]);
    RPct = RPct / (length(ACoda) * RL);
    LPct = LPct / (length(ACoda) * RL);
    FPT = pmin(RPct, LPct);
    names(FPT) = colnames(ACoda[[1]])
    return( FPT );
  }
  LPct = rep(0, length(ACoda[1,]))
  RPct = rep(0, length(ACoda[1,]))
    for (ii in 1:length(ACoda)) {
      LPct <- LPct + colSums(ACoda < 0)
      RPct <- RPct + colSums(ACoda > 0)
    }
    RL = length(ACoda[,1]);
    RPct = RPct / (RL);
    LPct = LPct / (RL);
  Rct = pmin(LPct, RPct);
  names(Rct) = colnames(ACoda);
  return( Rct );
}


GetMIPVals <- function(ACoda, TrueParametersList, AddMIPVals = NULL) {
  RL =0;
  UTrueParametersList = TrueParametersList[substr(names(TrueParametersList),1,nchar("Sigma")) != "Sigma"];
  if (!is.null(AddMIPVals)){
     ACoda = AddMIPVals
     MIPVecA = rep(0, length(UTrueParametersList)); MIPVecB = 0 * MIPVecA;
     names(MIPVecA) = names(UTrueParametersList);
     names(MIPVecB) = names(UTrueParametersList);
     SumACodaA = summary(as.mcmc.list(DeLogit(ACoda,1.0)))[[1]]
     SumACodaB = summary(as.mcmc.list(DeLogit(ACoda,-1.0)))[[1]]    
     NSA = colnames(ACoda[[1]]);
     MFixed = (1:length(NSA))[substr(NSA,1,nchar("ProbFixed")) == "ProbFixed"];
     MTau = (1:length(NSA))[substr(NSA,1,nchar("Prob:tau")) == "Prob:tau"];
     NMFixed = NSA[MFixed];
     NMFixedC = strsplit(NMFixed, "ProbFixed:\\d+:Beta:\\d+:", perl = TRUE)
     ##NMFixedC = strsplit(NMFixedC, ":");
     for (ii in 1:length(NMFixedC)) {
       NMFixedC[[ii]] = NMFixedC[[ii]][length(NMFixedC[[ii]])]
     }
     NMFixedC = unlist(NMFixedC);
     MyMatch = match(NMFixedC,names(MIPVecA));
       
     MIPVecA[MyMatch[!is.na(MyMatch)]] = SumACodaA[MFixed[!is.na(MyMatch)],1]
     MIPVecB[MyMatch[!is.na(MyMatch)]] = SumACodaB[MFixed[!is.na(MyMatch)],1]
     
     nMTau = substr(NSA[MTau], nchar("Prob:tau:")+1, nchar(NSA[MTau]))
     MIPVecA[match(paste("tau:",nMTau,sep=""), names(MIPVecA))] =
       SumACodaA[MTau,1]
     MIPVecB[match(paste("tau:",nMTau,sep=""), names(MIPVecB))] =
       SumACodaB[MTau,1]   
     NTO = rep(0, length(TrueParametersList));
     for (ii in 1:length(NTO)) {
       TRN = names(TrueParametersList)[ii];
       SubTRN = rep("", length(nMTau));
       for (jj in 1:length(nMTau)) {
         SubTRN[jj] = substr(TRN,1,nchar(nMTau[jj]));
       }
       if (any( SubTRN == 
          nMTau)) {
         NTO[ii] = (1:length(nMTau))[SubTRN == nMTau]   
       }
     }
     MIPVecA[(1:length(NTO))[NTO!=0]] = SumACodaA[NTO[NTO!=0],1]
     MIPVecB[(1:length(NTO))[NTO!=0]] = SumACodaB[NTO[NTO!=0],1]
      Returner = c(MIPVecA, MIPVecB);
     names(Returner) = c(paste("a:", names(MIPVecA),sep=""), paste("b:", names(MIPVecB), sep=""));
     return(Returner);
  }
  if (is.null(dim(ACoda))) {
    LPct = rep(0, length(ACoda[[1]][1,]))
    RPct = rep(0, length(ACoda[[1]][1,]))
    for (ii in 1:length(ACoda)) {
      LPct <- LPct + colSums(ACoda[[ii]] < 0)
      RPct <- RPct + colSums(ACoda[[ii]] > 0)
    }
    RL = length(ACoda[[1]][,1]);
    RPct = RPct / (length(ACoda) * RL);
    LPct = LPct / (length(ACoda) * RL);
    FPT = RPct + LPct;
    ReturnFPT = c(FPT, 1- FPT);
    names(ReturnFPT) = c(paste("a:", colnames(ACoda[[1]]), sep=""),
      paste("b:", colnames(ACoda[[1]]), sep="")
    );
    ReturnFPT = ReturnFPT[!(substr(names(ReturnFPT),1,nchar("a:Sigma"))  %in% c("a:Sigma", "b:Sigma"))]
    return(ReturnFPT);
  }
  LPct = rep(0, length(ACoda[1,]))
  RPct = rep(0, length(ACoda[1,]))
    for (ii in 1:length(ACoda)) {
      LPct <- LPct + colSums(ACoda < 0)
      RPct <- RPct + colSums(ACoda > 0)
    }
    RL = length(ACoda[,1]);
    RPct = RPct / (RL);
    LPct = LPct / (RL);
  Rct = LPct + RPct;
  names(Rct) = colnames(ACoda);
  
 ReturnFPT = c(Rct, 1- Rct);
 names(ReturnFPT) = c(paste("a:", names(Rct), sep=""),
   paste("b:", names(Rct), sep="")
 );
 ReturnFPT = ReturnFPT[!(substr(names(ReturnFPT),1,nchar("a:Sigma"))  %in% c("a:Sigma", "b:Sigma"))]
 return(ReturnFPT);
 return( Rct );
}

MakeHitSimPreds <- function(Target = 1000, X = NULL, SigmaSq = NULL,
  TrueParam = NULL,
  AFDS = NULL, numj = 8, NumRepetitions = 1)  {
  if (is.null(TrueParam) && is.null(AFDS)) {
    print("MakeHitSimPReds:  Error, you've got to supply TrueParam or AFDS");
    return(-1)
  }  
  if (!is.null(AFDS)) {
    X = AFDS$X;
    Beta = AFDS$ADiallelOb$Beta;
    XN = colnames(X);
    IDX = (1:length(XN))[XN %in% names(Beta)];
    PredMean = X[, IDX] %*% Beta;
    SigmaSq = AFDS$ADiallelOb$Sigma;
  } else if (!is.null(X) && !is.null(TrueParam)) {
    Beta = AFDS$ADiallelOb$Beta;
    XN = colnames(X);
    IDX = (1:length(XN))[XN %in% names(Beta)];
    PredMean = X[, IDX] %*% Beta;
  } else if (is.null(TrueParam)) {
    print("You're going to have to supply TrueParam! or AFDS"); flush.console();
    return(-1);
  } else {
    Listj = rep(1:numj, each=numj);
    Listk = rep(1:numj, numj);
    YesSex = FALSE;
    if (any(substr(names(TrueParam), 1,6) == "Gender")) {
      YesSex = TRUE
    }
  
    Listjk = cbind(Listj, Listk);
    AFDS = FullDiallelSimulate(numj = numj, YesSex = YesSex);
    SetupSimulateMethod(AFDS, ParamVec = TrueParam);
    Beta = AFDS$ADiallelOb$Beta;
    X = AFDS$X;
  }
  
  HitSimPreds = matrix(rep(PredMean, Target) +
    sqrt(SigmaSq) * 
    rnorm(length(PredMean) * length(Target)), length(PredMean), Target);
    colnames(HitSimPred) = paste(1:Target, sep=""); 
  
}

setMethodS3("ReadTableNamesColumns", "OutTable", function(this,...) {
  if (!is.null(this$ReadTable)) {
    colnames(this$ReadTable) = this$NamesColumns;
  }

});
setMethodS3("ReadTableNamesColumns", "OutSimAnalyses", function(this,...) {
  ReadTableNamesColumns(this$MeanVals);
  ReadTableNamesColumns(this$MedianVals);
  ReadTableNamesColumns(this$MIPVal);
  ReadTableNamesColumns(this$SmPVal);
      
});


.MatTables <- c("MeanDiff", "MedianDiff", "WidthCI", "CovCI", "MeanVals",
    "MedianVals", "LowCI", "UpCI", "SDVal", "SmPVal", "MIPVal", 
    "PredMeans", "PredMedians", "PredMeanDiffs", "PredMedianDiffs",
    "TrueParamTable", "PredSimsMeanTable", "PredSimsMedianTable","SummaryAll")

ThisIsNull <- function(A,BString) {
  AD = FALSE;
  MyS <- paste(" if (is.null( A$", BString, ")) { 
   AD = TRUE } else { AD = FALSE } ", sep ="");
  eval(parse(text=MyS));
  return(AD)
}
setMethodS3("LengthSimAnalyses", "OutSimAnalyses", function(this, Verbose=0,...) {
  if (Verbose > 0) {
    print("Starting Length Simanalyses"); flush.console();
  }
  MyTabs = BayesDiallel:::.MatTables;
  MyLengths = 1:length(MyTabs);
  for (ii in 1:length(MyTabs)) {
    AD = FALSE;
    BString = MyTabs[ii];
    MyS <- paste(" if (!is.null(this$", BString, ")) { 
    AD = TRUE } else { AD = FALSE } ", sep ="");
    eval(parse(text=MyS));    
    if (AD == TRUE) {
      RDD = NULL;
      MyT = paste(" RDD = this$", MyTabs[ii], sep="");
      eval(parse(text=MyT));
      if (is.null(dim(RDD$ReadTable))) {
        if (is.null(RDD$ReadTable)) {
          MyLengths[ii] = 0;
          if(Verbose > 1) {
            print(paste("LengthSimAnalyses: Table ", MyTabs[ii], " Has no readtable", sep=""));
            flush.console();
          }
        } else {
          MyLengths[ii] = 1;
          if(Verbose > 1) {
            print(paste("LengthSimAnalyses: Table ", MyTabs[ii], " only one line. ", sep=""));
            flush.console();
          }
        }
      } else {
        MyLengths[ii] = dim(RDD$ReadTable)[1];
        if (Verbose > 3) {
          print(paste("      Table ", MyTabs[ii], "  has ", MyLengths[ii], " lines. ", sep=""));
        }
      }
    } else {
      MyLengths[ii] = 0;
      if (Verbose > 2) {
        print(paste("LengthSimAnalyses:  Block for ", MyTabs[ii], " Does not exist.", sep=""));
        flush.console();
      }
    }
  }
  names(MyLengths) = MyTabs;
  return(MyLengths);
});                                


setConstructorS3("OutSimAnalyses", function(TargetLength = 1000,
  SampleBeta = NULL, FileDir=NULL, quantile = .95, INTIN=0,
  SimuName = NULL,IdentifierList = NULL, Verbose = TRUE,
  MethodName = NULL, PredMeanLength = NULL, PredMeanNames = NULL, 
  ModelName = "", ModelSubName = "", NumSimPred = 0,
  PredSimsMeanTable=NULL, PreferMeanMedian = "MEAN",
  PreferSmpValMIPVal = "SmpVal",  AModelObject = NULL, ADataObject=NULL,
  ...) {
  if (Verbose ==TRUE || Verbose > 0) {
    print("Starting OutSimAnalyses"); flush.console();
    if (is.null(SampleBeta)) {
      print("Start OutSimAnalyses with NULL SampleBeta "); flush.console();
    }
    if (is.null(FileDir)) {
      print("Start OutSimAnalyses with NULL FileDir"); flush.console();
    }
    if (is.null(SimuName)) {
      print("Start OutSimAnalyses SimuName is NULL"); flush.console();
    }
  }
  if (is.null(SampleBeta)) {
    SampleBeta = c(0,0,0); names(SampleBeta) = c("A", "B", "C")
    print("OutSimAnalyses: Can't work without SampleBeta");
    print(paste("  You failed with ModelName = ", ModelName, sep="")); flush.console();
    print(paste("  You failed with MethodName = ", MethodName, sep="")); flush.console();
    return(NULL);
  }
  if (is.null(FileDir)) {
    print("Cannot Do OutcodaAnalysis with out a printDirectory");
    ##return(NULL);
  }
  print(paste(" -- Prepping OutCodaAnalysis for Directory: ", FileDir, sep=""));

  if (Verbose ==TRUE || Verbose > 0) {
    print(paste("Creating OutTables of Length : ", TargetLength, sep="")); 
    flush.console();
  }

  MeanDiff = OutTable(TargetLength, 
    NamesColumns = c("SimID", names(SampleBeta)),
    FileName = "MeanDiff.csv", FileDir = FileDir);
  MeanDiffWrittenLength = 0;
  MedianDiff = OutTable(TargetLength, 
    NamesColumns = c("SimID", names(SampleBeta)),
    FileName = "MedianDiff.csv", FileDir = FileDir);
  WidthCI = OutTable(TargetLength, 
    NamesColumns = c("SimID", names(SampleBeta)),
    FileName = "WidthCI.csv", FileDir = FileDir);    
  CovCI = OutTable(TargetLength, 
    NamesColumns = c("SimID", names(SampleBeta)),
    FileName = "CovCI.csv", FileDir = FileDir);
  MeanVals = OutTable(TargetLength,
    NamesColumns= c("SimID", names(SampleBeta)),
     FileName = "MeanVal.csv", FileDir = FileDir);
  MedianVals = OutTable(TargetLength,
    NamesColumns= c("SimID", names(SampleBeta)),
     FileName = "MedianVal.csv", FileDir = FileDir);
  LowHPD = OutTable(TargetLength,
    NamesColumns= c("SimID", names(SampleBeta)),
     FileName = "LHPD.csv", FileDir = FileDir);
  UpHPD = OutTable(TargetLength,
    NamesColumns= c("SimID", names(SampleBeta)),
     FileName = "UHPD.csv", FileDir = FileDir);
  CovHPD = OutTable(TargetLength,
    NamesColumns= c("SimID", names(SampleBeta)),
     FileName = "CovHPD.csv", FileDir = FileDir);
  WidthHPD = OutTable(TargetLength,
    NamesColumns= c("SimID", names(SampleBeta)),
     FileName = "WidthHPD.csv", FileDir = FileDir);     
  LowCI = OutTable(TargetLength,
    NamesColumns= c("SimID", names(SampleBeta)),
     FileName = "LCI.csv", FileDir = FileDir);
  UpCI = OutTable(TargetLength,
    NamesColumns= c("SimID", names(SampleBeta)),
     FileName = "UCI.csv", FileDir = FileDir);
  SDVal = OutTable(TargetLength,
    NamesColumns= c("SimID", names(SampleBeta)),
     FileName = "SD.csv", FileDir = FileDir);    
  SmPVal = OutTable(TargetLength,
    NamesColumns= c("SimID", names(SampleBeta)),
     FileName = "SmP.csv", FileDir = FileDir);
  NamesMIPVal = c("SimID", paste("a:",names(SampleBeta), sep=""), paste("b:",names(SampleBeta), sep=""))
  NamesMIPVal = NamesMIPVal[!(substr(NamesMIPVal, 1, nchar("a:Sigma")) %in% c("a:Sigma", "b:Sigma"))];
  MIPVal = OutTable(TargetLength,
    NamesColumns= NamesMIPVal,
     FileName = "MIP.csv", FileDir = FileDir);    
  PredMeans = NULL; PredMedians = NULL; PredMeanDiffs = NULL; PredMedianDiffs = NULL;
  PredSimsMeanTable = NULL;  PredSimsMedianTable=NULL;
  if (Verbose == TRUE || Verbose > 0) {
    print("Checking Out new Objects");
  
  }
  if (!is.null(PredMeanLength) && !is.null(PredMeanNames) && PredMeanLength > 0) {
    PredMeans = OutTable(TargetLength,
      NamesColumns= c("SimID", PredMeanNames),
       FileName = "PredMean.csv", FileDir = FileDir);
    PredMedians = OutTable(TargetLength,
      NamesColumns= c("SimID", PredMeanNames),
       FileName = "PredMedian.csv", FileDir = FileDir);
    PredMeanDiffs = OutTable(TargetLength,
      NamesColumns= c("SimID", PredMeanNames),
       FileName = "PredMeanDiff.csv", FileDir = FileDir);      
    PredMedianDiffs = OutTable(TargetLength,
      NamesColumns= c("SimID", PredMeanNames),
       FileName = "PredMedianDiff.csv", FileDir = FileDir);
    if (NumSimPred > 0  && length(PredSimMeanNames) == NumSimPred) {
      ExColumns = c("MeanOfMeansT", "SdOfMeansT", "SdOfMeansJ",
        "MeanOfSdT", "MeanOfSdJ", "LowCIOfSdT", "UpCIOfSdT",
        "LowCIOfSdj", "UpCIOfSdj");
      PredSimsMeanTable = OutTable(TargetLength,
        NamesColumns= c("SimID", ExColumns, PredSimMeanNames),
        FileName = "PredSimsMean.csv", FileDir = FileDir);
      PredSimsMedianTable = OutTable(TargetLength,
        NamesColumns= c("SimID", ExColumns, PredSimMeanNames),
         FileName = "PredSimsMedian.csv", FileDir = FileDir);
    }
  }



  HSqTable = OutTable(TargetLength,    
      c("SimID", NamesHSqTable(SampleBeta)) ,
     FileName = "HSqTable.csv", FileDir=FileDir);
  BayesFactorTable = OutTable(TargetLength,
      c("SimID", NamesBayesFactorTable(SampleBeta)) ,
      FileName = "BFTable.csv", FileDir=FileDir);
  HSqWrittenLength = 0;  BayesFactorWrittenLength = 0;

  TrueParamTable = OutTable(TargetLength,
    NamesColumns = c("SimID", names(SampleBeta)),
    FileName = "TrueParamTable.csv", FileDir = FileDir);
  SummaryAll = OutTable(TargetLength, 
    NamesColumns = c("SimID", 
      "L2Tot", "L1Tot", "L0Tot", "Type1", "Type2", 
      paste("NumOutQuant", tSeq(quantile), sep=""),
      "time1", "time2", "time3"),
    FileName="SummaryAll.csv", FileDir=FileDir);  
 ##  extend(Object(), "OutCodaAnalyses",
 ##   TargetLength=TargetLength);  
  if (Verbose ==TRUE) {
    print(paste("OutCodaAnalyses: Got to Running Object Extend",  sep="")); 
    flush.console();
  }
  if (!is.null(MeanVals) && length(MeanVals) == 1 && is.numeric(MeanVals)) {
    print(paste("MeanVals is ", MeanVals, "  What Gives? ", sep=""));
  }
  if (!is.null(MedianVals) && length(MedianVals) == 1 && is.numeric(MedianVals)) {
    print(paste("MedianVals is ", MedianVals, "  What Gives? ", sep=""));
  }
  if (Verbose == TRUE || Verbose > 0) {
    print("AB1: We're about to Extend!");
  }
  AB1 = extend(Object(),"OutSimAnalyses",
    TargetLength=TargetLength, 
    NamesColumns = c("SimID", names(SampleBeta)),
    FileDir = FileDir,
    MeanDiff=MeanDiff, MedianDiff=MedianDiff,
    WidthCI=WidthCI, CovCI=CovCI, LowCI=LowCI, UpCI = UpCI,
    MeanVals = MeanVals, MedianVals=MedianVals, 
    SmPVal=SmPVal, MIPVal=MIPVal, SDVal = SDVal,
    PredMeans = PredMeans, PredMedians=PredMedians, PredMeanDiffs=PredMeanDiffs,
    PredMedianDiffs = PredMedianDiffs,
    TrueParamTable=TrueParamTable,
    SummaryAll=SummaryAll, 
    quantile=quantile, INTIN=INTIN,
    SimuName = SimuName, IdentifierList = IdentifierList,
    MethodName = MethodName,
    MeanDiffWrittenLength=MeanDiffWrittenLength,
    MedianDiffWrittenLength = 0,
    WidthCIWrittenLength = 0,
    CovCIWrittenLength = 0,
    LowHPD = LowHPD, UpHPD = UpHPD,
    CovHPD=CovHPD, WidthHPD=WidthHPD,
    SummaryAllWrittenLength = 0,
    TrueParamWrittenLength = 0, LowCIWrittenLength=0,UpCIWrittenLength=0,
    MeanValsWrittenLength=0, MedianValsWrittenLength=0, SmPValWrittenLength=0,
    MIPValWrittenLength=0,
    PredMeansWrittenLength = 0,
    PredMediansWrittenLength = 0,
    PredMeanDiffsWrittenLength = 0,
    PredMedianDiffsWrittenLength = 0,
    SDValWrittenLength = 0,
    PredMeanLength=PredMeanLength,PredMeanNames=PredMeanNames,
    ModelName=ModelName, ModelSubName=ModelSubName,
    PredSimsMeanTable=PredSimsMeanTable, PredSimsMedianTable=PredSimsMedianTable,
    PredSimsMeanTableWrittenLength=0, PredSimsMedianTableWrittenLength=0,
    PreferMeanMedian = PreferMeanMedian,
    PreferSmpValMIPVal = PreferSmpValMIPVal,
    HSqTable = HSqTable, BayesFactorTable=BayesFactorTable,
    HSqWrittenLength=HSqWrittenLength, 
    BayesFactorWrittenLength=BayesFactorWrittenLength);
  if (Verbose == TRUE || Verbose > 0) {
    print("OutSimAnalyses: AB1 finished, trying to return AB1"); flush.console();
  } 
  return(AB1); 
});



.SHSExColumns = c("MeanOfMeansT", "SdOfMeansT", "SdOfMeansJ",
    "MeanOfSdT", "MeanOfSdJ", "LowCIOfSdT", "UpCIOfSdT",
      "LowCIOfSdj", "UpCIOfSdj");
### HitSimsPred is collection of simulated values
###
SummarizeHitSimsPred <- function(HitSimsPred) {
   ## ExColumns = c("MeanOfMeansT", "SdOfMeansT", "SdOfMeansJ",
   ## "MeanOfSdT", "MeanOfSdJ", "LowCIOfSdT", "UpCIOfSdT",
   ##   "LowCIOfSdj", "UpCIOfSdj");
   MeanOfMeansT = mean(HitSimsPred);
   SdOfMeansT = sd(colMeans(HitSimsPred));
   SdOfMeansJ = sd(rowMeans(HitSimsPred));
   MeanOfSdT = mean(sd(HitSimsPred));
   MeanOfSdJ = mean(sd(t(HitSimsPred)));
   LowCIOfSdT = quantile(sd(HitSimsPred), .025);
   UpCIOfSdT = quantile(sd(HitSimsPred), .975);
   LowCIOfSdj = quantile(sd(t(HitSimsPred)), .025);
   UpCIOfSdj = quantile(sd(t(HitSimsPred)), .975);
   returner = c(MeanOfMeansT, SdOfMeansT, SdOfMeansJ,
     MeanOfSdT, MeanOfSdJ, LowCIOfSdT, UpCIOfSdT, LowCIOfSdj,
     UpCIOfSdj);
   names(returner) = BayesDiallel:::.SHSExColumns;
   return(returner)
}

setConstructorS3("OutCodaAnalyses", function(TargetLength = 1000,
  SampleBeta = NULL, FileDir=NULL, quantile = .95, INTIN=0,
  SimuName = NULL,IdentifierList = NULL, Verbose=FALSE,
  MethodName = NULL, start= 1, end =-1, thin = 1, PredMeanNames=NULL, PredMeanLength=NULL,
  ModelName="", ModelSubName="",NumSimPred = 0,
  PredSimMeanNames= NULL, PreferMeanMedian="MEAN",PreferSmpValMIPVal = "SmpVal",
  AModelObject=NULL, ADataObject=NULL,...) {
  if (is.null(SampleBeta)) {
    return(NULL);
  }
  if (is.null(FileDir)) {
     return(NULL);
  }
  if (is.null(SimuName)) {
    SimuName = "NONAME";
  }
  if (is.null(IdentifierList)) {
    IdentifierList = c(1,2,3)
  }
  if (!exists("AModelObject")) { AModelObject=NULL; }
  if (!exists("ADataObject")) { ADataObject=NULL; }
  AB1 = extend(OutSimAnalyses(TargetLength = 1000,
  SampleBeta = SampleBeta, FileDir=FileDir, quantile = .95, INTIN=0,
  SimuName = SimuName, IdentifierList = IdentifierList, Verbose=Verbose,
    MethodName = MethodName, PredMeanNames=PredMeanNames, PredMeanLength=PredMeanLength,
    ModelName=ModelName,ModelSubName=ModelSubName, NumSimPred = NumSimPred,
  PredSimMeanNames= PredSimMeanNames, PreferMeanMedian=PreferMeanMedian,
  PreferSmpValMIPVal=PreferSmpValMIPVal,
  AModelObject=AModelObject,ADataObject=ADataObject), "OutCodaAnalyses",
    OutType = "OutCodaAnalyses", start=start,end=end,thin=thin
    )  
  SummaryAll = OutTable(TargetLength, 
    NamesColumns = c("SimID", 
      "L2Tot", "L1Tot", "L0Tot", "Type1", "Type2", 
      paste("NumOutQuant", tSeq(quantile), sep=""),
      "time1", "time2", "time3", "DIC", "PID", "BarD", "DofMean"),
    FileName="SummaryAll.csv", FileDir=FileDir);  
  AB1$SummaryAll = SummaryAll;
  if (Verbose == TRUE) {
    print("OutCodaAnalyses: AB1 finished"); flush.console();
  }
  return(AB1);
});

setConstructorS3("OutLMAnalyses", function(TargetLength = 1000,
  SampleBeta = NULL, FileDir=NULL, quantile = .95, INTIN=0,
  SimuName = NULL,IdentifierList = NULL, Verbose = FALSE,
  MethodName = NULL, PredMeanNames=NULL, PredMeanLength=NULL,
  ModelName="", ModelSubName="", NumSimPred = 0,
  PredSimMeanNames= NULL,PreferMeanMedian = "MEAN",
  PreferSmpValMIPVal = "SmpVal",
  AModelObject=NULL, ADataObject=NULL,...) {
  if (is.null(SampleBeta)) {
    return(NULL);
  }
  if (is.null(FileDir)) {
     return(NULL);
  }
  if (is.null(SimuName)) {
    SimuName = "NONAME";
  }
  if (is.null(IdentifierList)) {
    IdentifierList = c(1,2,3)
  }
  if (!exists("AModelObject")) { AModelObject=NULL; }
  if (!exists("ADataObject")) { ADataObject=NULL; }
    
  extend(OutSimAnalyses(TargetLength = 1000,
  SampleBeta = SampleBeta, FileDir=FileDir, quantile = .95, INTIN=0,
  SimuName = SimuName,IdentifierList = IdentifierList, Verbose=Verbose,
  MethodName=MethodName, PredMeanNames=PredMeanNames, PredMeanLength=PredMeanLength,
  ModelName=ModelName,ModelSubName=ModelSubName, NumSimPred = NumSimPred,
  PredSimMeanNames= PredSimMeanNames, PreferMeanMedian = PreferMeanMedian,
  PreferSmpValMIPVal = PreferSmpValMIPVal, AModelObject=AModelObject,
  ADataObject=ADataObject), "OutLMAnalyses",
    OutType = "OutLMAnalyses"
  )  
});
setMethodS3("SetMethodName", "OutSimAnalyses", function(this, MethodName = NULL,...){
  this$MethodName = MethodName;
});

setMethodS3("UpdateTables", "OutCodaAnalyses", function(this, OutCoda=NULL,
  TrueParam=NULL, Times=NULL, DICFeed = c(0,0,0,0), start=1,end=-1,thin=1,
  GX = NULL, TruePredMeans=NULL,GX2 = NULL, HitSimPreds = NULL, verbose=FALSE, 
  AddMIPVals = NULL, AModelObject=NULL, ADataObject=NULL, RealX = NULL,
  RealY = NULL, PCodaList = NULL, PriorProb = NULL, StartOnSimID = "",
  ...) {
  
  if (!exists("AModelObject")) { AModelObject=NULL; }
  if (!exists("ADataObject")) {ADataObject=NULL;}
  if (!is.null(this$verbose) && this$verbose == TRUE) {verbose=TRUE;}
  if (is.numeric(thin) && length(thin) == 1 && thin > 1) {this$thin = thin;}
  if (is.null(this$thin)) { this$thin = 1; }
  if (length(start) != 1) {
    print(paste("UpdateTables: weird, start has length ", length(start),
      " and it seems to be ", paste( start, collapse=", "), sep=""));
   flush.console();
   if (length(start) <= 0) {
     start = 1;
   } else {
     start = start[1];
   }
  }
  
  if (is.null(OutCoda) || is.null(dim(OutCoda[[1]])) ||
    length(dim(OutCoda[[1]])) <= 1) {
    print("Error in OutCodaAnalyses: Update Table OutCoda is just a null matrix!");
    flush.console();
    return(-1);
  }
  
  if (!is.null(start) && start > 1) { this$start = start; }
  if (!is.null(end) && end > 0 ) { this$end = end; } else {
    if (!is.null(this$end)) { end = this$end; } else {
       end = length(OutCoda[[1]][,1]);
    }
  }
  if (end <= 0 || end < start) { end = length(OutCoda[[1]][,1]); }
  
  if (is.null(OutCoda) || is.null(TrueParam)) {
    print("Cannot UpdateTables, NULL input"); flush.console();
  }
  
  if (this$start == this$end) {
    print("Error in OutCodaAnalyses: UpdateTable: this$start = this$end");
    flush.console();
  }
  if (this$start > 1 || this$end > 0 || this$thin > 1) {

    OutCoda = mcmc.subset(OutCoda, burnin=this$start, thin=this$thin)
  }
  if (!exists("DICFeed") || is.null(DICFeed)) {
    print("DICFeed is null, maybe you should supply it ! "); flush.console();
  } else if (length(DICFeed) > 4) {
    DICFeed = DICFeed[1:4];
  } else if (length(DICFeed) < 4) {
    DICFeed = c( DICFeed, rep(0, 4-length(DICFeed)))
  }
  ##start(OutCoda) = .2 * end(OutCoda);
  if (!exists("StartOnSimID") || is.null(StartOnSimID) ||
    (is.character(StartOnSimID) && StartOnSimID == "") ||
    (is.numeric(StartOnSimID))) {
    eval(parse(text=GetG0Text("StartOnSimID", S=1)));
    if (is.null(StartOnSimID) || is.numeric(StartOnSimID)) {
      StartOnSimID = "";
    }
  }
  MyNameID = paste(tSeq(this$SimuName),tSeq(StartOnSimID),tSeq(this$INTIN), paste(tSeq(proc.time()[1:3]), collapse=""),
    sep="");
  MySummary = NULL;
  try(MySummary <- summary(OutCoda), silent=TRUE);
  if (is.null(MySummary)) {
    print("MySummary: We could not create summary "); flush.console();
  }
  LowPVals = GetLowPVals(OutCoda);
  MIPVals = GetMIPVals(OutCoda, TrueParametersList = TrueParam, AddMIPVals = AddMIPVals);
  
  VN = rownames(MySummary$statistics);
  if (any(VN == "Sigma")) { VN[VN=="Sigma"] = "Sigma:1";}
   AllMeansColumns = this$MeanVals$NamesColumns
  AllMeansColumns = AllMeansColumns[
    substr(AllMeansColumns, 1, nchar("Sim")) != "Sim"]
  AllLen = length(AllMeansColumns);

  
  if (any(VN == "Sigma")) { VN[VN == "Sigma"] = "Sigma:1"; }
  AllMeansColumns = this$MeanVals$NamesColumns
  AllMeansColumns = AllMeansColumns[
    substr(AllMeansColumns, 1, nchar("Sim")) != "Sim"]
  AllLen = length(AllMeansColumns);
  TBVN = function(vec) {    ANT = -1;
    MYF = rep(0,AllLen);
    if (!is.null(names(vec))) {
      VN = names(vec);
    }
    if (any(VN == "Sigma")) {
      VN[VN == "Sigma"] = "Sigma:1";
    }
    MyTBVNTry =  "MYF[match( VN, AllMeansColumns) ] <- vec; ANT <- 1";
    try(eval(parse(text=MyTBVNTry)));
    if (ANT == -1) {
      print(paste("UpdateTables:OutLMAnalyses: We have an error for : ",
        this$MethodName, sep="")); flush.console();
      print("TrueParam is :")
      print(TrueParam);
      print("  But VN = ");
      print(VN)
      tryCatch("Go Catch this Error!");
    }
    return(MYF);
  }
  this$MeanDiff$currentIDs = c(this$MeanDiff$currentIDs, MyNameID);
  this$MeanDiff$currentTable = as.data.frame(rbind(this$MeanDiff$currentTable,
    TBVN(as.vector(MySummary$statistics[,1]))- TrueParam  ) );
  colnames(this$MeanDiff$currentTable) = 
    this$MeanDiff$NamesColumns[2:length(this$MeanDiff$NamesColumns)];
    
  this$MeanVals$currentIDs = c(this$MeanVals$currentIDs, MyNameID);
  this$MeanVals$currentTable = as.data.frame(rbind(this$MeanVals$currentTable,
    TBVN(as.vector(MySummary$statistics[,1])) ) );
  colnames(this$MeanVals$currentTable) = 
    this$MeanVals$NamesColumns[2:length(this$MeanVals$NamesColumns)];

  this$MedianVals$currentIDs = c(this$MedianVals$currentIDs, MyNameID);
  this$MedianVals$currentTable = as.data.frame(rbind(this$MedianVals$currentTable,
    TBVN(as.vector(MySummary$quantiles[,3])) ) );
  colnames(this$MedianVals$currentTable) = 
    this$MedianVals$NamesColumns[2:length(this$MedianVals$NamesColumns)];
 
  if (!is.null(GX) && !is.null(this$PredMeans)) {
    if (is.null(dim(GX)) || dim(GX)[1] != length(this$PredMeans$NamesColumns)-1) {
      print(paste("GX Error: Note dim(GX) input = (", paste(dim(GX), collapse=", "),
        ")", " but length(PredMeans) previous = ",
      length(this$PredMeans$NamesColumns)-1, sep="")); flush.console();  
    }
    MeanV = as.vector(MySummary$statistics[,1])
    names(MeanV) = colnames(OutCoda[[1]])
    if (is.null(colnames(OutCoda[[1]]))) {
      print(paste("UpdateTables:  Up oh, Out Coda had no colnames ", sep=""));
      flush.console();
    }
    NGC = match(names(MeanV), colnames(GX))
    VMV = (1:length(NGC))[!is.na(NGC)]
    NGG = NGC[!is.na(NGC)]
    if (length(dim(GX)) != 2) {
      print("Error, GX doesn't havegood dims"); flush.console();
    }
    if (length(NGG) <= 0) {
      print("UpdateTable: Error: My NGG doesn't have good length"); flush.console();
    }
    if (min(NGG) < 1 || max(NGG) > dim(XP)[2]) {
      print(paste("UpdateTable: Uh Oh, min(NGG) = ", min(NGG),
        " but max(NGG) = ", max(NGG), " and dim(GX) = (",
        paste(dim(GX), collapse=", "), ")", sep="")); flush.console();
    }
    PredMean = GX[,NGG]%*%MeanV[VMV]
    PredMean = as.vector(PredMean); names(PredMean) = rownames(GX);
    MedianV = as.vector(MySummary$quantiles[,3])
    names(MedianV) = colnames(OutCoda[[1]])
    NGC = match(names(MeanV), colnames(GX))
    VMV = (1:length(NGC))[!is.na(NGC)]
    NGG = NGC[!is.na(NGC)]
    PredMedian = GX[,NGG]%*%MedianV[VMV]
    PredMedian = as.vector(PredMedian); names(PredMedian) = rownames(GX);
    
    TBPVM = function(vec) {
      MYF = rep(0, length(this$PredMeanNames));
      MYF[match( names(vec), this$PredMeanNames) ] = vec;
      return(MYF);           
    }  
    this$PredMeans$currentIDs = c(this$PredMeans$currentIDs, MyNameID);
    this$PredMeans$currentTable = as.data.frame(rbind(this$PredMeans$currentTable,
      TBPVM(PredMean)
     ) );
    colnames(this$PredMeans$currentTable) = 
      this$PredMeans$NamesColumns[2:length(this$PredMeans$NamesColumns)];  
    this$PredMedians$currentIDs = c(this$PredMedians$currentIDs, MyNameID);
    this$PredMedians$currentTable = as.data.frame(rbind(this$PredMedians$currentTable,
      TBPVM(PredMedian)
     ) );
    colnames(this$PredMeans$currentTable) = 
      this$PredMeans$NamesColumns[2:length(this$PredMeans$NamesColumns)];
    
    if (!is.null(TruePredMeans)) {  
    this$PredMeanDiffs$currentIDs = c(this$PredMeanDiffs$currentIDs, MyNameID);
    this$PredMeanDiffs$currentTable = as.data.frame(rbind(this$PredMeanDiffs$currentTable,
      TBPVM(PredMean - TruePredMeans)
     ) );
    colnames(this$PredMeanDiffs$currentTable) = 
      this$PredMeanDiffs$NamesColumns[2:length(this$PredMeanDiffs$NamesColumns)];   

    this$PredMedianDiffs$currentIDs = c(this$PredMedianDiffs$currentIDs, MyNameID);
    this$PredMedianDiffs$currentTable = as.data.frame(rbind(this$PredMedianDiffs$currentTable,
      TBPVM(PredMedian - TruePredMeans)
     ) );
    colnames(this$PredMedianDiffs$currentTable) = 
      this$PredMedianDiffs$NamesColumns[2:length(this$PredMedianDiffs$NamesColumns)];   
    }
    if (!is.null(HitSimPreds) && !is.null(GX2)) {
      MeanV = as.vector(MySummary$statistics[,1])
      names(MeanV) = rownames(MySummary$statistics);
      NGC = match(names(MeanV), colnames(GX2))
      VMV = (1:length(NGC))[!is.na(NGC)]
      NGG = NGC[!is.na(NGC)]
      PredMean = GX2[,NGG]%*%MeanV[VMV]
      MedianV = as.vector(MySummary$quantiles[,3])
      names(MedianV) = rownames(MySummary$statistics)
      NGC = match(names(MedianV), colnames(GX2))
      VMV = (1:length(NGC))[!is.na(NGC)]
      NGG = NGC[!is.na(NGC)]
      PredMedian = GX2[,NGG]%*%MedianV[VMV]
      SHSP = SummarizeHitSimsPred(HitSimPreds);
     AVec = colMeans((HitSimPreds - matrix(rep(PredMean, length(HitSimPreds[1,])), length(PredMean), length(HitSimPreds[1,])))^2);
     this$PredSimsMeanTable$currentIDs = c(this$PredSimsMeanTable$currentIDs, MyNameID);
     this$PredSimsMeanTable$currentTable = as.data.frame(rbind(this$PredSimsMeanTable$currentTable,
       c(SHSP, AVec)
     ) );
     colnames(this$PredSimsMeanTable$currentTable) = 
      this$PredSimsMeanTable$NamesColumns[2:length(this$PredSimsMeanTable$NamesColumns)];   
     AVec = colMeans((HitSimPreds -  matrix(rep(PredMedian, length(HitSimPreds[1,])), length(PredMedian), length(HitSimPreds[1,])))^2);
     this$PredSimsMedianTable$currentIDs = c(this$PredSimsMedianTable$currentIDs, MyNameID);
     this$PredSimsMedianTable$currentTable = as.data.frame(rbind(this$PredSimsMedianTable$currentTable,
       c(SHSP, AVec)
     ) );
     colnames(this$PredSimsMedianTable$currentTable) = 
      this$PredSimsMedianTable$NamesColumns[2:length(this$PredSimsMedianTable$NamesColumns)];   
    }   
    
  }
  
  MyDo = NULL;
  try(MyDo <- HPDinterval(as.mcmc(McMcStack(OutCoda,200))));
  if (is.null(MyDo)) {
    try(MyDo <- HPDinterval(as.matrix(McMcStack(OutCoda,200))));  
  }
  if (!is.null(MyDo)) {
    MyDo1 = MyDo[,1];  names(MyDo1) = colnames(OutCoda[[1]]);
    names(MyDo1)[names(MyDo1) == "Sigma"] = "Sigma:1";
  this$LowHPD$currentIDs = c(this$LowHPD$currentIDs, MyNameID);
  this$LowHPD$currentTable = as.data.frame(rbind(this$LowHPD$currentTable,
    TBVN(MyDo1) ) );
  colnames(this$LowHPD$currentTable) = 
    this$LowHPD$NamesColumns[2:length(this$LowHPD$NamesColumns)];

    MyDo2 = MyDo[,2];  names(MyDo2) = colnames(OutCoda[[1]]);
    names(MyDo2)[names(MyDo2) == "Sigma"] = "Sigma:1";
  this$UpHPD$currentIDs = c(this$UpHPD$currentIDs, MyNameID);
  this$UpHPD$currentTable = as.data.frame(rbind(this$UpHPD$currentTable,
    TBVN(MyDo2) ) );
  colnames(this$UpHPD$currentTable) = 
    this$UpHPD$NamesColumns[2:length(this$UpHPD$NamesColumns)];
    
    if (!is.null(this$CovHPD)) {
      BD =  rep(0, AllLen)
  BD[ TBVN( MyDo1 ) <= TrueParam &
      TBVN( MyDo2 ) >= TrueParam] = 1;
  this$CovHPD$currentIDs = c(this$CovHPD$currentIDs, MyNameID);
  this$CovHPD$currentTable = rbind(this$CovHPD$currentTable, BD);  
  colnames(this$CovHPD$currentTable) = 
    this$CovHPD$NamesColumns[2:length(this$CovHPD$NamesColumns)];
   }
   if (!is.null(this$WidthHPD)) {
      BD =  abs(TBVN(MyDo2) - TBVN(MyDo1))

  this$WidthHPD$currentIDs = c(this$CovHPD$currentIDs, MyNameID);
  this$WidthHPD$currentTable = rbind(this$WidthHPD$currentTable, BD);  
  colnames(this$WidthHPD$currentTable) = 
    this$WidthHPD$NamesColumns[2:length(this$WidthHPD$NamesColumns)];
   } 
  }
  
  this$SDVal$currentIDs = c(this$SDVal$currentIDs, MyNameID);
  this$SDVal$currentTable = as.data.frame(rbind(this$SDVal$currentTable,
    TBVN(as.vector(MySummary$statistics[,2])) ) );
  colnames(this$SDVal$currentTable) = 
    this$SDVal$NamesColumns[2:length(this$SDVal$NamesColumns)];
    
  this$SmPVal$currentIDs = c(this$SmPVal$currentIDs, MyNameID);
  this$SmPVal$currentTable = as.data.frame(rbind(this$SmPVal$currentTable,
    TBVN(as.vector(LowPVals)) ) );
  colnames(this$SmPVal$currentTable) = 
    this$SmPVal$NamesColumns[2:length(this$SmPVal$NamesColumns)];
  
  if (!is.null(MIPVals)) {
  if (verbose >= 2) {
    print("Recording MIPVal"); flush.console();
  }
  ##this$MIPVal$currentIDs = c(this$MIPVal$currentIDs);
  MyEval = NULL;
  UpdateType = "MIPVals";
  EvalCode = "UpdateCurrentTable(this$MIPVal, NewVector = MIPVals, MyNameID = MyNameID, UpdateType = UpdateType); MyEval <- 1";
  try(eval(parse(text=EvalCode)));
  if (is.null(MyEval)) {
    print("Attempt to write table failed for MIPVals insert"); flush.console();
    print("  MIPVals = "); print(MIPVals); flush.console();
    print("  this$MIPVal$NamesColumns = "); flush.console();
    print(paste(this$MIPVal$NamesColumns, collapse=", ")); flush.console();
  }
  }
        
  this$MedianDiff$currentIDs = c(this$MedianDiff$currentIDs, MyNameID);  
  this$MedianDiff$currentTable = rbind(this$MedianDiff$currentTable,
    TBVN(as.vector(MySummary$quantiles[,3]))- TrueParam );
  colnames(this$MedianDiff$currentTable) = 
    this$MedianDiff$NamesColumns[2:length(this$MedianDiff$NamesColumns)];
   
   
  AddWidthCI = as.vector(MySummary$quantiles[,5])- as.vector(MySummary$quantiles[,1]);
  names(AddWidthCI) = rownames(MySummary$quantiles);
  names(AddWidthCI)[names(AddWidthCI) == "Sigma"] = "Sigma:1"
  MyEval = "UpdateCurrentTable(this$WidthCI, NewVector = AddWidthCI, MyNameID = MyNameID, UpdateType = \"WidthCI\" ); MyNull <- 1";
    try(eval(parse(text=MyEval))) 


  AddLowCI = as.vector(MySummary$quantiles[,1]);
  names(AddLowCI) = rownames(MySummary$quantiles);
  names(AddLowCI)[names(AddLowCI) == "Sigma"] = "Sigma:1"
  MyEval = "UpdateCurrentTable(this$LowCI, NewVector = AddLowCI, MyNameID = MyNameID, UpdateType = \"LowCI\" ); MyNull <- 1";
    try(eval(parse(text=MyEval))) 

  AddUpCI = as.vector(MySummary$quantiles[,5]);
  names(AddUpCI) = rownames(MySummary$quantiles);
  names(AddUpCI)[names(AddUpCI) == "Sigma"] = "Sigma:1"
  MyEval = "UpdateCurrentTable(this$UpCI, NewVector = AddUpCI, MyNameID = MyNameID, UpdateType = \"UpCI\" ); MyNull <- 1";
    try(eval(parse(text=MyEval)))         
 
 
  MyEval = "UpdateCurrentTable(this$TrueParamTable, NewVector = TrueParam, MyNameID = MyNameID, UpdateType = \"TrueParam\" ); MyNull <- 1";
    try(eval(parse(text=MyEval)))
      
      
  BD1 =  rep(0, AllLen);  BD2 = rep(0, AllLen); BD3 = rep(0, AllLen);
  BD = rep(0, AllLen);
  nQ = rownames(MySummary$quantiles);
  try(nQ[nQ == "Sigma"] <- "Sigma:1");
    AFT = match(nQ, AllMeansColumns);
  BD1[ AFT[!is.na(AFT)] ] = MySummary$quantiles[!is.na(AFT),1];
  BD2[ AFT[!is.na(AFT)] ] = MySummary$quantiles[!is.na(AFT),5]; 
    AFT2 = match(TrueParam, AllMeansColumns)
  BD3[ AFT2[!is.na(AFT2)] ] = TrueParam[!is.na(AFT2)]; 
  BD[ BD1 <= BD3 &
      BD2 >= BD3] = 1;
  try(names(BD) <- AllMeansColumns);
  MyEval = "UpdateCurrentTable(this$CovCI, NewVector = BD, MyNameID = MyNameID, UpdateType = \"CovCI\" ); MyNull <- 1";
    try(eval(parse(text=MyEval)))     

         
  try(AddHSqTable <- MakeHSqTable(CodaChains = OutCoda, AllX = RealX,
    CurrentHSqTableNames = this$HSqTable$NamesColumns,
    startiter=start, thin=thin, enditer=end, AY = RealY, TrueVector = TrueParam));
  if (!exists("AddHSqTable") || is.null(AddHSqTable)) {
    print("Oh boy, error: AddHSq table did not create! "); flush.console();
    AddHSqTable = rep(0, length(this$HSq$NamesColumns));
    names(AddSqTable) = this$HSq$NamesColumns;
    eval(parse(text=SetGText("AddSqTable")));
  } else {
    MyNull = NULL;
    UpdateType = "HSqTable";
    MyEval = "UpdateCurrentTable(this$HSqTable, NewVector = AddHSqTable, MyNameID = MyNameID, UpdateType = UpdateType ); MyNull <- 1";
    try(eval(parse(text=MyEval)));
    if (is.null(MyNull)) {
      print("UpdatecurrentTable Fails for HSqTable, AddHSqTable = "); flush.console();
      print(AddHSqTable); flush.console();

      print("  The column names for HSq Table are:");  print(this$HSqTable$NamesColumns)
      print(this$HSqTable$NamesColumns); flush.console();
      print(paste("  Length of AddHSq Table is ", length(AddHSqTable), 
        "But ", length(this$HSqTable$currentTable), 
        "dim this$HSqTable$currentTable is (", 
          paste(dim(this$HSqTable$currentTable), collapse=", "), ")", sep=""));
      flush.console();
    }
  }
  
  if (!exists("PCodaList")) { PCodaList = NULL; }
  if (!exists("PriorProb")) { PriorProb = NULL; }
  if (!is.null(AddMIPVals) && !is.null(PriorProb) &&
    !is.null(this$BayesFactorTable)) {
    AddBayesFactorTable <- BayesFactor(AddMIPVals, PriorProb,
      this$BayesFactorTable$NamesColumns);
    MyNull = NULL;
    UpdateType = "BayesFactorTable"
    AText = "UpdateCurrentTable(this$BayesFactorTable, NewVector = 
      AddBayesFactorTable, MyNameID = MyNameID, UpdateType = UpdateType); MyNull <- 1";
    try(eval(parse(text=AText)));
     if (is.null(MyNull)) {
      print("UpdatecurrentTable Fails for AddBayesFactorTable = "); flush.console();
      print(AddBayesFactorTable); flush.console();
      print("  The column names for BayesFactorTable are:");
      print(this$BayesFactorTable$NamesColumns); flush.console();
      print(paste("  Length of AddBayesFactorTable Table is ", length(AddBayesFactorTable), 
        "But ", length(this$BayesFactorTable$currentTable), 
        "dim this$BayesFactorTable$currentTable is (", 
          paste(dim(this$BayesFactorTable$currentTable), collapse=", "), ")", sep=""));
      flush.console();
    }
  }
      

  
  L2Tot = sum(( TBVN( MySummary$statistics[,1] )- TrueParam)^2) / sum(TrueParam^2);
  L1Tot = sum(abs( TBVN( MySummary$quantiles[,3] ) - TrueParam)) / sum(abs(TrueParam));
   FT = TBVN( MySummary$quantiles[,3] );  FT[FT != 0] = 1;
   AT = TrueParam;  AT[AT != 0] = 1;
  L0Tot = sum(abs(FT-AT)) / sum(abs(AT));
  Type1 = sum(FT[AT==0]);
  Type2 = length(FT[AT==1])- sum(FT[AT==1]);
  if (is.null(Times) || length(Times) < 3) {
    Times=c(0,0,0);
  } else {
    Times=Times[1:3];
  }
  NumOutQuant = length(BD)-sum(BD);
  this$SummaryAll$currentIDs = c(this$SummaryAll$currentIDs, MyNameID);
  this$SummaryAll$currentTable = rbind(this$SummaryAll$currentTable,
   c( L2Tot, L1Tot, L0Tot, Type1, Type2, NumOutQuant, Times, DICFeed)); 
  colnames(this$SummaryAll$currentTable) = 
    this$SummaryAll$NamesColumns[2:length(this$SummaryAll$NamesColumns)];  
});


setMethodS3("UpdateTables", "OutLMAnalyses", function(this, 
  meanVector=NULL, sdVector = NULL, lmOb = NULL, hglmOb = NULL,
  TrueParam=NULL, Times=NULL, dtD = 1.96, verbose = FALSE, GX = NULL, TruePredMeans = NULL,
  HitSimPreds = NULL, GX2 = NULL, StartOnSimID = "", ...) {  
  if (verbose == TRUE) {
    print(paste("Starting OutLMAnalyses load in meanVector: ",
      paste(meanVector, collapse=", "), sep="")); flush.console();
  }         
  if ( is.null(meanVector) ||  is.null(sdVector)) {
    if (is.null(lmOb) && is.null(hglmOb)) {
      print("Cannot UpdateTables, NULL input!");
    } else if (!is.null(lmOb)) {
      meanVector = summary(coefficients(lmOb))[,1];
      sdVector = summary(coefficients(lmOb))[,2];
    } else if (!is.null(hglmOb)) {
      meanVector = hglmOb$sum.table[,1]
      sdVector = hglmOb$sum.table[,2];
    }
  }
  if (is.null(TrueParam)) {
    print("Cannot UpdateTables, NULL input");
  }
  ##start(OutCoda) = .2 * end(OutCoda);
  if (!exists("StartOnSimID") || is.null(StartOnSimID) ||
    (is.character(StartOnSimID) && StartOnSimID == "") ||
    (is.numeric(StartOnSimID))) {
    eval(parse(text=GetG0Text("StartOnSimID",S=1)));
    if (is.null(StartOnSimID) || is.numeric(StartOnSimID)) {
      StartOnSimID = "";
    }
  }
  MyNameID = paste(tSeq(this$SimuName),tSeq(StartOnSimID),tSeq(this$INTIN), paste(tSeq(proc.time()[1:3]), collapse=""),
    sep="");
  if (!is.null(lmOb)) {
    MySummary = coefficients(summary(lmOb));
  } else if (!is.null(hglmOb)) {
    MySummary = hglmOb$sum.table;
  }
  
  VN = names(meanVector);
  AllMeansColumns = this$MeanVals$NamesColumns
  AllMeansColumns = AllMeansColumns[
    substr(AllMeansColumns, 1, nchar("Sim")) != "Sim"]
  AllLen = length(AllMeansColumns);

  
  if (any(VN == "Sigma")) { VN[VN == "Sigma"] = "Sigma:1"; }
  AllMeansColumns = this$MeanVals$NamesColumns
  AllMeansColumns = AllMeansColumns[
    substr(AllMeansColumns, 1, nchar("Sim")) != "Sim"]
  AllLen = length(AllMeansColumns);
  TBVN = function(vec) {    ANT = -1;
    MYF = rep(0,AllLen);
    if (!is.null(names(vec))) {
      VN = names(vec);
    }
    if (any(VN == "Sigma")) {
      VN[VN == "Sigma"] = "Sigma:1";
    }
    MyTBVNTry =  "MYF[match( VN, AllMeansColumns) ] <- vec; ANT <- 1";
    try(eval(parse(text=MyTBVNTry)));
    if (ANT == -1) {
      print(paste("UpdateTables:OutLMAnalyses: We have an error for : ",
        this$MethodName, sep="")); flush.console();
      print("TrueParam is :")
      print(TrueParam);
      print("  But VN = ");
      print(VN)
      tryCatch("Go Catch this Error!");
    }
    return(MYF);
  }
  
  
  this$MeanDiff$currentIDs = c(this$MeanDiff$currentIDs, MyNameID);
  if (!is.null(this$MeanDiff$currentTable) ) {
    this$MeanDiff$currentTable = as.data.frame(rbind(this$MeanDiff$currentTable,
      TBVN(as.vector(meanVector))- TrueParam  ) );
  } else {
    this$MeanDiff$currentTable = as.data.frame(matrix(
      TBVN(as.vector(meanVector))- TrueParam ,
      1, length(TrueParam) ) );  
  }
  colnames(this$MeanDiff$currentTable) = 
    this$MeanDiff$NamesColumns[2:length(this$MeanDiff$NamesColumns)];

  this$MeanVals$currentIDs = c(this$MeanVals$currentIDs, MyNameID);
  if (!is.null(this$MeanVals$currentTable) ) {
    this$MeanVals$currentTable = as.data.frame(rbind(this$MeanVals$currentTable,
      TBVN(as.vector(meanVector)) ) );
  } else {
    this$MeanVals$currentTable = as.data.frame(matrix(
      TBVN(as.vector(meanVector)),
      1, length(TrueParam) ) );  
  }
  colnames(this$MeanVals$currentTable) = 
    this$MeanVals$NamesColumns[2:length(this$MeanVals$NamesColumns)];

  if (!is.null(GX) && !is.null(this$PredMeans)) {
    if (verbose == TRUE) {
      print("Creating GX Means "); flush.console();
    }
    
   if (is.null(dim(GX)) || dim(GX)[1] != length(this$PredMeans$NamesColumns)-1) {
      print(paste("GX Error: Note dim(GX) input = (", paste(dim(GX), collapse=", "),
        ")", " but length(PredMeans) previous = ",
      length(this$PredMeans$NamesColumns)-1, sep="")); flush.console();  
    }
    MeanV = meanVector;
    NGC = match(names(MeanV), colnames(GX))
    VMV = (1:length(NGC))[!is.na(NGC)]
    NGG = NGC[!is.na(NGC)]
    PredMean = GX[,NGG]%*%MeanV[VMV];
    PredMean = as.vector(PredMean); names(PredMean) = rownames(GX);
    MedianV = meanVector;
    NGC = match(names(MeanV), colnames(GX))
    VMV = (1:length(NGC))[!is.na(NGC)]
    NGG = NGC[!is.na(NGC)]
    PredMedian = GX[,NGG]%*%MedianV[VMV]
    PredMedian = as.vector(PredMedian); names(PredMedian) = rownames(GX);
    
    TBPVM = function(vec) {
      MYF = rep(0, length(this$PredMeanNames));
      MYF[match( names(vec), this$PredMeanNames) ] = vec;
      return(MYF);           
    }  
    this$PredMeans$currentIDs = c(this$PredMeans$currentIDs, MyNameID);
    this$PredMeans$currentTable = as.data.frame(rbind(this$PredMeans$currentTable,
      TBPVM(PredMean)
     ) );
    colnames(this$PredMeans$currentTable) = 
      this$PredMeans$NamesColumns[2:length(this$PredMeans$NamesColumns)];  
    this$PredMedians$currentIDs = c(this$PredMedians$currentIDs, MyNameID);
    this$PredMedians$currentTable = as.data.frame(rbind(this$PredMedians$currentTable,
      TBPVM(PredMedian)
     ) );
    colnames(this$PredMeans$currentTable) = 
      this$PredMeans$NamesColumns[2:length(this$PredMeans$NamesColumns)];
    
    if (!is.null(TruePredMeans)) {
      MeanDiffVector = PredMean - TruePredMeans;
      this$PredMeanDiffs$currentIDs = c(this$PredMeanDiffs$currentIDs, MyNameID);
      this$PredMeanDiffs$currentTable = as.data.frame(rbind(this$PredMeanDiffs$currentTable,
      TBPVM(MeanDiffVector)
     ) );
    colnames(this$PredMeanDiffs$currentTable) = 
      this$PredMeanDiffs$NamesColumns[2:length(this$PredMeanDiffs$NamesColumns)];   

    this$PredMedianDiffs$currentIDs = c(this$PredMedianDiffs$currentIDs, MyNameID);
    this$PredMedianDiffs$currentTable = as.data.frame(rbind(this$PredMedianDiffs$currentTable,
      TBPVM(PredMedian - TruePredMeans)
     ) );
    colnames(this$PredMedianDiffs$currentTable) = 
      this$PredMedianDiffs$NamesColumns[2:length(this$PredMedianDiffs$NamesColumns)];   
    }
    if (!is.null(HitSimPreds)  && !is.null(GX2) ) {
      MeanV = meanVector;
      NGC = match(names(MeanV), colnames(GX2))
      VMV = (1:length(NGC))[!is.na(NGC)]
      NGG = NGC[!is.na(NGC)]
      PredMean = GX2[,NGG]%*%MeanV[VMV]
      MedianV = meanVector;
      NGC = match(names(MeanV), colnames(GX2))
      VMV = (1:length(NGC))[!is.na(NGC)]
      NGG = NGC[!is.na(NGC)]
      PredMedian = GX2[,NGG]%*%MedianV[VMV]
      SHSP = SummarizeHitSimsPred(HitSimPreds);
       AVec = colMeans((HitSimPreds -  matrix(rep(PredMean, length(HitSimPreds[1,])), length(PredMean), length(HitSimPreds[1,])))^2);
     this$PredSimsMeanTable$currentIDs = c(this$PredSimsMeanTable$currentIDs, MyNameID);
     this$PredSimsMeanTable$currentTable = as.data.frame(rbind(this$PredSimsMeanTable$currentTable,
       c(SHSP, AVec)
     ) );
     colnames(this$PredSimsMeanTable$currentTable) = 
      this$PredSimsMeanTable$NamesColumns[2:length(this$PredSimsMeanTable$NamesColumns)];   
     AVec = colMeans((HitSimPreds -  matrix(rep(PredMedian, length(HitSimPreds[1,])), length(PredMedian), length(HitSimPreds[1,])))^2);
     this$PredSimsMedianTable$currentIDs = c(this$PredSimsMedianTable$currentIDs, MyNameID);
     this$PredSimsMedianTable$currentTable = as.data.frame(rbind(this$PredSimsMedianTable$currentTable,
       c(SHSP, AVec)
     ) );
     colnames(this$PredSimsMedianTable$currentTable) = 
      this$PredSimsMedianTable$NamesColumns[2:length(this$PredSimsMedianTable$NamesColumns)];   
    }   
  }
  
  this$MedianVals$currentIDs = c(this$MedianVals$currentIDs, MyNameID);
  if (!is.null(this$MedianVals$currentTable) ) {
    this$MedianVals$currentTable = as.data.frame(rbind(this$MedianVals$currentTable,
      TBVN(as.vector(meanVector)) ) );
  } else {
    this$MedianVals$currentTable = as.data.frame(matrix(
      TBVN(as.vector(meanVector)),
      1, length(TrueParam) ) );  
  }
  colnames(this$MedianVals$currentTable) = 
    this$MedianVals$NamesColumns[2:length(this$MedianVals$NamesColumns)];

  this$MedianDiff$currentIDs = c(this$MedianDiff$currentIDs, MyNameID);
  if (!is.null(this$MedianDiff$currentTable) ) {
    this$MedianDiff$currentTable = as.data.frame(rbind(this$MedianDiff$currentTable,
      TBVN(as.vector(meanVector))- TrueParam ) );
  } else {
    this$MedianDiff$currentTable = as.data.frame(matrix(
      TBVN(as.vector(meanVector))- TrueParam ,
      1, length(TrueParam) ) );  
  }    

  colnames(this$MedianDiff$currentTable) = 
    this$MedianDiff$NamesColumns[2:length(this$MedianDiff$NamesColumns)];
  this$WidthCI$currentIDs = c(this$WidthCI$currentIDs, MyNameID);  
  ##print("Griff WidthCI Trying to Save TBVN!!"); flush.console();  
  
  if (is.null(this$WidthCI$currentTable)) {
    this$WidthCI$currentTable = matrix(
      TBVN( dtD * 2 * sdVector ), 1,
      length(TrueParam ) );  
  } else {
    this$WidthCI$currentTable = rbind(this$WidthCI$currentTable,
      TBVN( dtD * 2 * sdVector ) );  
  }
  ##print("Griff WidthCI Saved TBVN!!"); flush.console();  
  colnames(this$WidthCI$currentTable) = 
    this$WidthCI$NamesColumns[2:length(this$WidthCI$NamesColumns)];
  this$TrueParamTable$currentIDs = c(this$TrueParamTable$currentIDs, MyNameID);
  this$TrueParamTable$currentTable = rbind(this$TrueParamTable$currentTable,
    TrueParam);
  colnames(this$TrueParamTable$currentTable) = this$TrueParamTable$NamesColumns[
      2:length(this$TrueParamTable$NamesColumns)];
  
  
  BD1 =  rep(0, AllLen);  BD2 = rep(0, AllLen); BD3 = rep(0, AllLen);
  BD = rep(0, AllLen);
  nQ = names(meanVector);
  try(nQ[nQ == "Sigma"] <- "Sigma:1");
    AFT = match(nQ, AllMeansColumns);
  BD1[ AFT[!is.na(AFT)] ] = meanVector - dtD * sdVector;
  BD2[ AFT[!is.na(AFT)] ] = meanVector + dtD * sdVector; 
    AFT2 = match(TrueParam, AllMeansColumns)
  BD3[ AFT2[!is.na(AFT2)] ] = TrueParam[!is.na(AFT2)]; 
  BD[ BD1 <= BD3 &
      BD2 >= BD3] = 1;
  try(names(BD) <- AllMeansColumns);
  MyEval = "UpdateCurrentTable(this$CovCI, NewVector = BD, MyNameID = MyNameID, UpdateType = \"CovCI\" ); MyNull <- 1";
    try(eval(parse(text=MyEval)))     

this$LowCI$currentIDs = c(this$LowCI$currentIDs, MyNameID);
  if (!is.null(this$LowCI$currentTable) ) {
    this$LowCI$currentTable = as.data.frame(rbind(this$LowCI$currentTable,
      TBVN(as.vector(meanVector) - dtD * as.vector(sdVector))  ) );
  } else {
    this$LowCI$currentTable = as.data.frame(matrix(
      TBVN(as.vector(meanVector) - dtD * as.vector(sdVector) ),
      1, length(TrueParam) ) );  
  }
  colnames(this$LowCI$currentTable) = 
    this$LowCI$NamesColumns[2:length(this$LowCI$NamesColumns)];

this$UpCI$currentIDs = c(this$UpCI$currentIDs, MyNameID);
  if (!is.null(this$UpCI$currentTable) ) {
    this$UpCI$currentTable = as.data.frame(rbind(this$UpCI$currentTable,
      TBVN(as.vector(meanVector) - dtD * as.vector(sdVector) ) ) );
  } else {
    this$UpCI$currentTable = as.data.frame(matrix(
      TBVN(as.vector(meanVector) + dtD * as.vector(sdVector) ),
      1, length(TrueParam) ) );  
  }
  colnames(this$UpCI$currentTable) = 
    this$UpCI$NamesColumns[2:length(this$UpCI$NamesColumns)];

this$SmPVal$currentIDs = c(this$SmPVal$currentIDs, MyNameID);
  if (!is.null(this$SmPVal$currentTable) ) {
    this$SmPVal$currentTable = as.data.frame(rbind(this$SmPVal$currentTable,
      TBVN(GetLowerTailProb(as.vector(meanVector), as.vector(sdVector))  )) );
  } else {
    this$SmPVal$currentTable = as.data.frame(matrix(
      TBVN(GetLowerTailProb(as.vector(meanVector), as.vector(sdVector))),
      1, length(TrueParam) ) );  
  }
  colnames(this$SmPVal$currentTable) = 
    this$SmPVal$NamesColumns[2:length(this$SmPVal$NamesColumns)];
    
  this$SDVal$currentIDs = c(this$SDVal$currentIDs, MyNameID);
  if (!is.null(this$SDVal$currentTable) ) {
    this$SDVal$currentTable = as.data.frame(rbind(this$SDVal$currentTable,
      TBVN(as.vector(sdVector))) );
  } else {
    this$SDVal$currentTable = as.data.frame(matrix(
      TBVN(as.vector(sdVector)),1, length(TBVN(as.vector(sdVector)))));  
  }
  colnames(this$SDVal$currentTable) = 
    this$SDVal$NamesColumns[2:length(this$SDVal$NamesColumns)];   
 
      
  L2Tot = sum(( TBVN( meanVector )- TrueParam)^2) / sum(TrueParam^2);
  L1Tot = sum(abs( TBVN( meanVector ) - TrueParam)) / sum(abs(TrueParam));
   FT = TBVN( meanVector  );  FT[FT != 0] = 1;
   AT = TrueParam;  AT[AT != 0] = 1;
  L0Tot = sum(abs(FT-AT)) / sum(abs(AT));
  Type1 = sum(FT[AT==0]);
  Type2 = length(FT[AT==1])- sum(FT[AT==1]);
  if (is.null(Times) || length(Times) < 3) {
    Times=c(0,0,0);
  } else {
    Times=Times[1:3];
  }
  NumOutQuant = length(BD)-sum(BD);
  this$SummaryAll$currentIDs = c(this$SummaryAll$currentIDs, MyNameID);
  this$SummaryAll$currentTable = rbind(this$SummaryAll$currentTable,
   c( L2Tot, L1Tot, L0Tot, Type1, Type2, NumOutQuant, Times)); 
  colnames(this$SummaryAll$currentTable) = 
    this$SummaryAll$NamesColumns[2:length(this$SummaryAll$NamesColumns)];  
});


if (FALSE) {
setMethodS3("UpdateTables", "OutNoAnalyses", function(this, OutCoda=NULL,
  TrueParam=NULL, Times=NULL, StartOnSimID = "",...) {
  if (is.null(OutCoda) || is.null(TrueParam)) {
    print("Cannot UpdateTables, NULL input");
  }
  ##start(OutCoda) = .2 * end(OutCoda);
  if (!exists("StartOnSimID") || is.null(StartOnSimID) ||
    (is.character(StartOnSimID) && StartOnSimID == "") ||
    (is.numeric(StartOnSimID))) {
    eval(parse(text=GetG0Text("StartOnSimID", S=1)));
    if (is.null(StartOnSimID) || is.numeric(StartOnSimID)) {
      StartOnSimID = "";
    }
  }
  
  MyNameID = paste(tSeq(this$SimuName),tSeq(this$INTIN), paste(tSeq(proc.time()[1:3]), collapse=""),
    sep="");
  MySummary = summary(OutCoda);
  
  VN = rownames(MySummary$statistics);
  if (any(VN == "Sigma")) { VN[VN == "Sigma"] = "Sigma:1"; }
  AllMeansColumns = this$MeanVals$NamesColumns
  AllMeansColumns = AllMeansColumns[
    substr(AllMeansColumns, 1, nchar("Sim")) != "Sim"]
  AllLen = length(AllMeansColumns);
  TBVN = function(vec) {    ANT = -1;
    MYF = rep(0,AllLen);
    if (!is.null(names(vec))) {
      VN = names(vec);
    }
    if (any(VN == "Sigma")) {
      VN[VN == "Sigma"] = "Sigma:1";
    }
    MyTBVNTry =  "MYF[match( VN, AllMeansColumns) ] <- vec; ANT <- 1";
    try(eval(parse(text=MyTBVNTry)));
    if (ANT == -1) {
      print(paste("UpdateTables:OutLMAnalyses: We have an error for : ",
        this$MethodName, sep="")); flush.console();
      print("TrueParam is :")
      print(TrueParam);
      print("  But VN = ");
      print(VN)
      tryCatch("Go Catch this Error!");
    }
    return(MYF);
  }
  
  this$MeanDiff$currentIDs = c(this$MeanDiff$currentIDs, MyNameID);
  this$MeanDiff$currentTable = as.data.frame(rbind(this$MeanDiff$currentTable,
    TBVN(as.vector(MySummary$statistics[,1]))- TrueParam  ) );
  colnames(this$MeanDiff$currentTable) = 
    this$MeanDiff$NamesColumns[2:length(this$MeanDiff$NamesColumns)];
  this$MedianDiff$currentIDs = c(this$MedianDiff$currentIDs, MyNameID);  
  this$MedianDiff$currentTable = rbind(this$MedianDiff$currentTable,
    TBVN(as.vector(MySummary$quantiles[,3]))- TrueParam );
  colnames(this$MedianDiff$currentTable) = 
    this$MedianDiff$NamesColumns[2:length(this$MedianDiff$NamesColumns)];
  this$WidthCI$currentIDs = c(this$WidthCI$currentIDs, MyNameID);    
  this$WidthCI$currentTable = rbind(this$WidthCI$currentTable,
    TBVN( as.vector(MySummary$quantiles[,5])- 
         as.vector(MySummary$quantiles[,1]) ) );
  colnames(this$WidthCI$currentTable) = 
    this$WidthCI$NamesColumns[2:length(this$WidthCI$NamesColumns)];
  
  BD =  rep(0, AllLen)
  BD[ TBVN( MySummary$quantiles[,1] ) <= TrueParam &
      TBVN( MySummary$quantiles[,5] ) >= TrueParam] = 1;
  this$CovCI$currentIDs = c(this$CovCI$currentIDs, MyNameID);
  this$CovCI$currentTable = rbind(this$CovCI$currentTable, BD);  
  colnames(this$CovCI$currentTable) = 
    this$CovCI$NamesColumns[2:length(this$CovCI$NamesColumns)]; 
  this$TrueParamTable$currentIDs = c(this$TrueParamTable$currentIDs, MyNameID);
  this$TrueParamTable$currentTable = rbind(this$TrueParamTable$currentTable,
    TrueParam);
  colnames(this$TrueParamTable$currentTable) = this$TrueParamTable$NamesColumns[
      2:length(this$TrueParamTable$NamesColumns)];
        
  L2Tot = sum(( TBVN( MySummary$statistics[,1] )- TrueParam)^2) / sum(TrueParam^2);
  L1Tot = sum(abs( TBVN( MySummary$quantiles[,3] ) - TrueParam)) / sum(abs(TrueParam));
   FT = TBVN( MySummary$quantiles[,3] );  FT[FT != 0] = 1;
   AT = TrueParam;  AT[AT != 0] = 1;
  L0Tot = sum(abs(FT-AT)) / sum(abs(AT));
  Type1 = sum(FT[AT==0]);
  Type2 = length(FT[AT==1])- sum(FT[AT==1]);
  if (is.null(Times) || length(Times) < 3) {
    Times=c(0,0,0);
  } else {
    Times=Times[1:3];
  }
  NumOutQuant = length(BD)-sum(BD);
  this$SummaryAll$currentIDs = c(this$SummaryAll$currentIDs, MyNameID);
  this$SummaryAll$currentTable = rbind(this$SummaryAll$currentTable,
   c( L2Tot, L1Tot, L0Tot, Type1, Type2, NumOutQuant, Times)); 
  colnames(this$SummaryAll$currentTable) = 
    this$SummaryAll$NamesColumns[2:length(this$SummaryAll$NamesColumns)];  
});
}

setMethodS3("ReadMinorLength", "OutSimAnalyses", function(this, MaxReadLength = 50, verbose=0,
  OnlyNeedTablesList = NULL,  KillLockFiles = FALSE,...)  {
  if ((!is.null(this$verbose) && this$verbose > 0) && this$verbose > verbose) {
     verbose = this$verbose;
  }
  if ((!is.null(this$verbose) && this$verbose > 0) || verbose > 0) {
    print("OutSimAnalysis, starting ReadMinorLength"); flush.console();   
  }
  for (ii in 1:length(names(this))) {
    if (is.null(OnlyNeedTablesList) || names(this)[ii] %in% OnlyNeedTablesList) {
    MyText = paste("try( this$", names(this)[ii], "$ReadAMaxValue(MaxValue = ", 
      MaxReadLength,", KillLockFiles = KillLockFiles), silent=TRUE)", sep="");
    if (verbose > 1) {
       print(paste(" We eval: ", MyText, sep="")); flush.console();
    }
     eval(parse(text=MyText));
   }
  }
  return(1);  
});




setMethodS3("WriteAndClear", "OutSimAnalyses", function(this, certainNoPrint = 0,
  verbose = 0, SumNeed = NULL, ...) {
   TargetTableNames = c("MeanVals", "MedianVals", "MeanDiff", "MedianDiff",
    "LowCI", "UpCI", "WidthCI", "CovCI", "PredMeans", "PredMedians", "PredMeanDiffs", "PredMedianDiffs",
      "PredSimsMeanTable", "PredSimsMedianTable", "TrueParamTable","SummaryAll",
      "SmPVal", "SDVal", "BayesFactorTable", "MIPVal", "HSqTable",
      "LowHPD", "UpHPD", "CovHPD", "WidthHPD")
  DefaultSumNeed = c("MeanVals", "MedianVals", "MeanDiff", "MedianDiff",
    "LowCI", "UpCI", "WidthCI", "CovCI", "PredMeans", "PredMedians", "PredMeanDiffs", "PredMeanDiffs",
      "PredSimsMeanTable", "PredSimsMedianTable", "TrueParamTable","SummaryAll",
      "SDVal")
  if (!exists("SumNeed") || (is.null(SumNeed) && is.null(this$SumNeed))) {
    SumNeed = DefaultSumNeed;
  }
  WriteIdentifierList(this);
  ASummersList = rep(0, length(TargetTableNames));
  if (!exists("certainNoPrint")) {certainNoPrint = 0;}
  if (is.null(certainNoPrint)) { certainNoPrint = 0; }
  for (ii in 1:length(TargetTableNames)) {
    OnNeed = TargetTableNames[ii];
  FailFlag = NULL;
  IDCurrentTable = 0;
  MyText = paste("if (is.null(this$", TargetTableNames[ii], "$currentTable)) {
    IDCurrentTable = 1;
  }", sep="");
  try(eval(parse(text=MyText)));
   if (IDCurrentTable == 1) {
     print(paste(this$SimuName, "|", this$MethodName, ": Null currentTable on write: TargetTableNames[", ii, "] = ", TargetTableNames[ii], ", FailFile: ",
       this$FileDir, sep="")); flush.console();
   }  
  TryWrite = paste(
   "  FailFlag = NULL;
      if (!is.null(this$", TargetTableNames[ii], ") &&
       length(this$", TargetTableNames[ii], "$currentTable) > 0) {
       certainNoPrint = 0;  
     }
   ABA = 0;
   ABA = WriteToTable(this$", TargetTableNames[ii], ", certainNoPrint=certainNoPrint);
   if (ABA > 0) {
     this$", TargetTableNames[ii], "$currentTable = NULL;
     this$", TargetTableNames[ii], "$currentIDs = NULL;
     this$", TargetTableNames[ii], "WrittenLength = ABA;
     ASummersList[ii] = ABA;
   }
   FailFlag = 1;", sep="");
   try(eval(parse(text=TryWrite)));
   if (is.null(FailFlag)) {
     print(paste(this$SimuName, "|", this$MethodName, ": WriteToTableError on write: TargetTableNames[", ii, "] = ", TargetTableNames[ii], ", FailFile: ",
       this$FileDir, sep="")); flush.console();
   }  
  }
  MinTLen = -1;
  try(MinTLen <- min(ASummersList[TargetTableNames %in% SumNeed]));
  if (MinTLen < 0) {
    print(paste("MinTLen Problem, ASummerList = ", paste(ASummersList, collapse=","), sep=""));
    flush.console();
  }
  
  
  if (MinTLen >= this$TargetLength) {
    return(this$TargetLength);
  }  else {
    return(MinTLen);
  }
});
setMethodS3("WriteIdentifierList", "OutSimAnalyses", function(this, ...) {
  ##print("Write Identifier List Now");
  ##print(paste(" Write To directory: ", this$FileDir)
  if (is.null(this$IdentifierList)) { 
    ##print("IdentifierList is Null, cannot write"); flush.console();
    return(FALSE);}
  ##print("Identifier List is Not NULL!")
  FilesInDir = unlist(list.files(this$FileDir));
  FileNameAll = paste(this$FileDir, "//", "IdentifierList.R", sep="")
  if (FilesInDir == 0 || !any(FilesInDir == "IdentifierList.R")) {
     Onfile = file(FileNameAll, "wt");
     writeLines(
       "###### IdentifierList.R  ## ParametersUsed For These Simulations",
        Onfile);
     writeLines(paste("No Files Found: TargetLength = ", this$TargetLength, ";  FileDir = ", this$FileDir, sep=""));
     for (ii in 1:length(IdentifierList)) {
       writeLines(paste(names(IdentifierList)[ii], " = ",
         IdentifierList[ii], ";", sep=""), Onfile);
     } 
     close(Onfile); 
  }
});

setConstructorS3("OutTable", function(TargetLength = 0,
 NamesColumns = NULL, FileName = NULL, FileDir = NULL, ...) {
 if (is.null(FileDir)) {
 }   else {
   dir.create(FileDir, showWarnings = FALSE)
 }
 extend(Object(), "OutTable", TargetLength=TargetLength, 
   NamesColumns=NamesColumns, FileDir = FileDir,  FileName = FileName,
   currentTable = NULL, currentIDs = NULL,
   ReadTable = NULL, ReadLength = NULL);
});
 
setMethodS3("ReadAMaxValue", "OutTable", function(this, MaxValue = 0,Verbose = 3,
  KillLockFiles = FALSE, ...) {
 if (MaxValue <= 0) {
   MaxValue = this$TargetLength;
 }
 if (!is.null(this$Verbose) && this$Verbose > 0) {
    if (this$Verbose > Verbose) { Verbose = this$Verbose;}   
 } else if (!is.null(this$verbose) && this$verbose > 0) {
    if (this$verbose > Verbose) { Verbose = this$verbose;}    
 }
 if (Verbose > 1) {
    print(paste("ReadMaxValue on an OutTable:  Reading:",
      this$FileName, sep="")); flush.console();
    
 }
 if (KillLockFiles == TRUE) {
   if (Verbose > 1) {
     print("KillLockFiles == TRUE, trying to unlink this LockFile ");
   }
   MyListFiles = unlist(list.files(this$FileDir));
   LockFileName = paste("LockFile", this$FileName, sep="");
   if (any(MyListFiles == LockFileName)) {
      LockFileAll = paste(this$FileDir, "//", LockFileName, sep="");
      if (Verbose > 1) {
        print("KillLockFiles: lockFile = ");
        MyT = NULL;
        try(MyT = read.table(LockFile, sep=",", header=FALSE));
        if (!is.null(MyT)) {
          print(MyT);
        }
      }

      unlink(LockFileAll);
   }
 }
 IIT = 0;
 while(this$LockMeIn(IntNTries = IIT)  == FALSE) {
   if (IIT > 0 && IIT %% 100 == 0) {
     print(paste("ReadMaxValue, problem we've worked on Lock Table ", IIT, " times.",
       sep="")); flush.console();
       LockFileName = paste("LockFile", this$FileName, sep="");
       LockFileAll = paste(this$FileDir, "//", LockFileName, sep="");
       RD = NULL;
       try(RD <- read.table(LockFileAll, header=FALSE, sep=","), silent=TRUE);
       if (is.null(RD)) {
         print("  Yet Read Lock File is NULL!" ); flush.console();
       } else {
         print("  LockFile Reads as: ");
         print(RD); flush.console();
         print(paste("proc.time() = ", paste(proc.time()[1:3], collapse=", ")), sep="");
         try(print(paste(" diff = ", sum(abs(proc.time()[1:3] - RD[1,1:3])), sep="")));
       }
   }
   IIT = IIT +1;
 }
  FileAll = paste(this$FileDir, "//", this$FileName, sep="");
  FilesInDir = unlist(list.files(this$FileDir));   
  MyReadTable = NULL;
  try(MyReadTable <- read.table(FileAll, header=TRUE, sep=","));
   this$UnLockMe();
  if (is.null(MyReadTable)) {
    try(MyReadTable <- read.csv(FileAll, header=TRUE, col.names=this$NamesColumns));
  }
  if (is.null(MyReadTable)) {
    lenReadTable = 0;
    lenWidthTable = 0;
      
 } else {
    lenReadTable = dim(MyReadTable)[1];
    lenWidthTable = dim(MyReadTable)[2];
    colnames(MyReadTable) = this$NamesColumns;
    if (MaxValue > lenReadTable) {
      MyReadTable = MyReadTable[1:MaxValue,];
      lenReadTable = MaxValue;      
    }
    
    Keep = (1:lenReadTable)[
      0 == apply(MyReadTable, 1, function(X) { 
      if (length(X[is.na(X)]) > 5) { return(1) } else {return(0)}})  ]    
    this$ReadTable = MyReadTable[Keep,];  this$ReadLength = length(Keep);
    colnames(this$ReadTable) = this$NamesColumns;  
 }
 
 if (!is.null(colnames(this$ReadTable)) &&
   is.character(colnames(this$ReadTable)) &&
   any(colnames(this$ReadTable) == "SimID")) {
   ATA = NumericMe(this$ReadTable[, colnames(this$ReadTable) != "SimID"]);
   ARD = as.character(this$ReadTable[, colnames(this$ReadTable) == "SimID"]);
   ATR = as.data.frame(cbind(as.data.frame(ARD, stringAsFactors=FALSE), as.data.frame(ATA, stringsAsFactors = FALSE)), stringsAsFactors = FALSE)
   colnames(ATR) = this$NamesColumns;
   this$ReadTable = ATR;
 } else {
   this$ReadTable = NumericMe(this$ReadTable);
 }

});
setMethodS3("WriteToTable", "OutTable", function(this, certainNoPrint = 1, 
  verbose = FALSE, ...) { 
  if (length(this$ReadTable) > 0 && !is.null(this$ReadTable)) {
    if (length(this$ReadTable)  == 1  && (!is.list(this$ReadTable) ||
      length(unlist(this$ReadTable))==1)   ) {
      this$ReadTable = NULL;
      unlink(paste(this$FileDir, "//", this$FileName, sep=""));
    } else if (length(unlist(this$ReadTable)) == 1) {
      this$ReadTable = NULL;
      unlink(paste(this$FileDir, "//", this$FileName, sep=""));    
    } else if (is.null(dim(this$ReadTable))) {
    
    } else if (!is.null(dim(this$ReadTable)) && 
      dim(this$ReadTable)[2] == length(this$NamesColumns) ){
      colnames(this$ReadTable) = this$NamesColumns;
    }
  }
  if (!is.data.frame(this$currentTable) && !is.matrix(this$currentTable)  
    && is.vector(this$currentTable)) {
    if (!is.null(names(this$currentTable)) &&
      (any(names(this$currentTable) %in% c("SimIDNo", "SimID")))) {
      this$currentTable = this$currentTable[!( names(this$currentTable) %in%
        c("SimIDNo", "SimID")) ];  
    } else if (any(this$NamesColumns %in% c("SimIDNo", "SimID")) &&
      length(this$NamesColumns) == length(this$currentTable)) {
      this$currentTable = this$currentTable[!( (this$NamesColumns) %in%
        c("SimIDNo", "SimID")) ];          
    }  
    
  }
  if (!is.data.frame(this$currentTable) && is.list(this$currentTable)) {    
    this$currentTable = unlist(this$currentTable);
  }
  if (is.matrix(this$currentTable)) {
  if (!is.null(colnames(this$currentTable)) && any(colnames(this$currentTable) == "SimID")) {
    this$currentTable = this$currentTable[, colnames(this$currentTable) != "SimID"];
  } else if (!is.null(colnames(this$currentTable)) && any(colnames(this$currentTable) == "SimIDNo")) {
    this$currentTable = this$currentTable[, colnames(this$currentTable) != "SimIDNo"];
  } else if (is.null(colnames(this$currentTable)) && length(this$currentTable[1,]) ==
    length(this$NamesColumns)) {
    this$currentTable = this$currentTable[, !(this$NamesColumns %in% c("SimID", "SimIDNo"))]
  }
  if (is.null(this$currentIDs)) {
    this$currentIDs = (1:length(this$currentTable[,1]));
  }
  } else if (is.vector(this$currentTable)) { 
    if (!is.null(names(this$currentTable)) && any(names(this$currentTable) == "SimID")) {
      this$currentTable = this$currentTable[colnames(this$currentTable) != "SimID"];
    } else if (!is.null(names(this$currentTable)) && any(names(this$currentTable) == "SimIDNo")) {
      this$currentTable = this$currentTable[names(this$currentTable) != "SimIDNo"];
    } else if (is.null(names(this$currentTable)) && length(this$currentTable) ==
      length(this$NamesColumns)) {
      this$currentTable = this$currentTable[!(this$NamesColumns %in% c("SimID", "SimIDNo"))];
    }
    this$currentTable = matrix(this$currentTable, 1, length(this$currentTable));
    if (is.null(this$currentIDs)) {
      this$currentIDs = 1;
    }
  }
  
  if (!is.null(rownames(OutTable)) && length(rownames(OutTable)) !=
    length(this$currentIDs)) {
    this$currentIDs = rownames(OutTable);
  }
  IIT = 0;
  while(this$LockMeIn(IntNTries = IIT) == FALSE) {
    if (IIT > 0 && IIT %% 100 == 0) {
      print(paste("ReadMaxValue, problem we've worked on Lock Table ", IIT, " times.",
       sep="")); flush.console();
       LockFileName = paste("LockFile", this$FileName, sep="");
       LockFileAll = paste(this$FileDir, "//", LockFileName, sep="");
       RD = NULL;
       try(RD <- read.table(LockFileAll, header=FALSE, sep=","), silent=TRUE);
       if (is.null(RD)) {
         print("  Yet Read Lock File is NULL!" ); flush.console();
       } else {
         print("  LockFile Reads as: ");
         print(RD); flush.console();
         print(paste("proc.time() = ", paste(proc.time()[1:3], collapse=", ")), sep="");
         try(print(paste(" diff = ", sum(abs(proc.time()[1:3] - RD[1,1:3])), sep="")));
       }
   }
   IIT = IIT +1;
  }
  FileAll = paste(this$FileDir, "//", this$FileName, sep="");
  FilesInDir = unlist(list.files(this$FileDir));
  if (!is.null(this$currentTable)) {
    if (is.null(this$ReadTable) || length(this$ReadTable) == 0) {
      if(length(dim(this$currentTable)) == 2) {
        this$ReadTable = cbind(as.data.frame(this$currentIDs, stringsAsFactors = FALSE),
          as.data.frame(this$currentTable));
        colnames(this$ReadTable) = this$NamesColumns;
      } else {
        this$ReadTable = matrix(c(this$currentIDs, this$currentTable),1,
          1 + length(this$currentTable));
             colnames(this$ReadTable) = this$NamesColumns;
      }
    }
  }
  
  if (certainNoPrint == 1) { 
    print(paste("WriteToTable: Will not print to ", this$FileName, sep=""));
  }
  if (is.null(dim(this$currentTable))) {
    thisLen = 0;
    if (certainNoPrint == 1) { 
      print("this Current Table has zero length, nothing to not print");
    }
  } else {
    thisLen = dim(this$currentTable)[1];
  }
  MyReadTable = NULL;
  lenReadTable = 0; lenWidthTable = 0;
  if (verbose == TRUE) {
    print(paste( "Writing this OutTable, dim of this$currentTable (", 
      paste(dim(this$currentTable), collapse=", "), ")", sep=""));
  }
  if (length(FilesInDir)== 0 || !any(FilesInDir == this$FileName)) {
    if (thisLen > 0) {
      ##colnames(this$currentTable) = this$NamesColumns;
      if (certainNoPrint == 1) {
        print("certainNoPrint = 1, but no file in directory!");
      }
      try(write.table( cbind(this$currentIDs, this$currentTable), FileAll, sep=", ", eol="\n",
        quote=FALSE, na="NA", append=FALSE,
        col.names=this$NamesColumns, row.names=FALSE));
      this$UnLockMe();
      if (verbose == TRUE) {
        print(paste( "We tried to write first time (no table in directory) to ", FileAll, sep=""));
      }
      return(thisLen);
    } else {
      this$UnLockMe();
      return(thisLen);
    }
  }  else {
    if (any(FilesInDir == this$FileName)) {
      MyReadTable = NULL;
      try(MyReadTable <- read.table(FileAll, header=TRUE, sep=","));
      if (is.null(MyReadTable)) {
        lenReadTable = 0;
        lenWidthTable = 0;
      } else {
        lenReadTable = dim(MyReadTable)[1];
        lenWidthTable = dim(MyReadTable)[2];
        if (lenWidthTable == length(this$NamesColumns)) {
          colnames(MyReadTable) = this$NamesColumns;
        } else {
          print(paste("File in Dir, but Width of Table", lenWidthTable, " and lenNamesColumns = ",
            length(this$NamesColumns), sep="")); flush.console();
        }
        this$ReadTable = MyReadTable;  this$ReadLength = lenReadTable;
        colnames(this$ReadTable) = this$NamesColumns;
        ATA = NumericMe(this$ReadTable[, colnames(this$ReadTable) != "SimID"]);
        ARD = as.character(this$ReadTable[, colnames(this$ReadTable) == "SimID"]);
        ATR = as.data.frame(cbind(as.data.frame(ARD, stringAsFactors=FALSE), as.data.frame(ATA)), stringsAsFactors = FALSE)
        colnames(ATR) = this$NamesColumns;
        this$ReadTable = ATR;
      }
      ##print(paste("lenReadTable = ", lenReadTable, sep=""));
    } else {
      print("Why Can't I find the File!!")
      unlink(FileAll);
      MyReadTable = NULL;
      lenReadTable = 0; lenWidthTable = 0;
    }
    if (lenReadTable >= this$TargetLength) {
      if (!is.null(this$ReadTable)) {
        colnames(this$ReadTable) = this$NamesColumns;
      }
      ##print("Max Out This Table");
      this$UnLockMe();
      return(this$TargetLength);
    } else if (certainNoPrint == 1) {
       if (!is.null(this$ReadTable)) {
        colnames(this$ReadTable) = this$NamesColumns;
        ATA = NumericMe(this$ReadTable[, colnames(this$ReadTable) != "SimID"]);
        ARD = as.character(this$ReadTable[, colnames(this$ReadTable) == "SimID"]);
        ATR = as.data.frame(cbind(as.data.frame(ARD, stringAsFactors=FALSE), as.data.frame(ATA)), stringsAsFactors = FALSE)
        colnames(ATR) = this$NamesColumns;
        this$ReadTable = ATR;
      }
      print("Not Going to print to this table");
      this$UnLockMe();
      return(this$TargetLength);    
    } else {
      if (thisLen!= 0 && lenWidthTable != dim(this$currentTable)[2] + 1) {
          print("We've Got a bad MyReadTable!!!");
         ErrorFile = NULL;
         if (length(FilesInDir) == 0 ||  !any(FilesInDir == 
            paste("ErrorFile", this$FileName, sep="")) ) {
           try(ErrorFile <- file( paste(this$FileDir, "//", "ErrorFile", this$FileName, sep=""),
           open="wt"));            
         } else {
           try(ErrorFile <- file( paste(this$FileDir, "//", "ErrorFile", this$FileName, sep=""),
           open="at"));
         }
         if (!is.null(ErrorFile)) {
           try(writeLines(
            paste("Failed Because Dims Are Wrong, dim(MyReadTable) = c(",
             paste(dim(MyReadTable), collapse=", "), "), dim(currentTable) = c(",
             paste(dim(this$currentTable), collapse=", "), ")", 
             " and so lenWidthTable - 1 = ", lenWidthTable -1, sep=""),
             ErrorFile));
          close(ErrorFile);
        }   else {
          print("Doh, I totally wanted to save to Error file but something stupid happened!!")
          ##error("Doh, I totally wanted to save to Error file but something stupid happened!!")
        }
        if (thisLen > 0) {
          colnames(this$currentTable) = this$NamesColumns;
          try(write.table(cbind(this$currentIDs, this$currentTable), FileAll, sep=", ", eol="\n",
              quote=FALSE, na="NA", append=FALSE,
              col.names=this$NamesColumns, row.names=FALSE));
          this$ReadTable = as.data.frame(cbind(this$currentIDs, this$currentTable));
          colnames(this$ReadTable) = this$NamesColumns;
          ATA = NumericMe(this$ReadTable[, colnames(this$ReadTable) != "SimID"]);
          ARD = as.character(this$ReadTable[, colnames(this$ReadTable) == "SimID"]);
          ATR = as.data.frame(cbind(as.data.frame(ARD, stringAsFactors=FALSE), as.data.frame(ATA)), stringsAsFactors = FALSE)
          colnames(ATR) = this$NamesColumns;
          this$ReadTable = ATR;   
          this$ReadLength = length(thisLen);
        }    
         this$UnLockMe();
         if (verbose == TRUE) {
          print(paste( "We tried to write over a bad file this time to ", FileAll, sep=""));
         }    
         return(thisLen);           
         return(0);
      } else {
        if (!is.null(this$currentTable) && !is.null(MyReadTable)) { 
          if (thisLen > 0) {
            ##print("Appending")
            try(write.table(cbind(this$currentIDs,this$currentTable), FileAll, append=TRUE, quote=FALSE,
              sep=", ", eol="\n", na = "NA", dec=".", row.names=FALSE,
              col.names=FALSE));
          AddTable = cbind(this$currentIDs, this$currentTable);
          colnames(AddTable) = this$NamesColumns;
          colnames(this$ReadTable) = this$NamesColumns
          this$ReadTable = as.data.frame(
          rbind(this$ReadTable,AddTable ));
          colnames(this$ReadTable) = this$NamesColumns;
          ATA = NumericMe(this$ReadTable[, colnames(this$ReadTable) != "SimID"]);
          ARD = as.character(this$ReadTable[, colnames(this$ReadTable) == "SimID"]);
          ATR = as.data.frame(cbind(as.data.frame(ARD, stringAsFactors=FALSE), as.data.frame(ATA)), stringsAsFactors = FALSE)
          colnames(ATR) = this$NamesColumns;
          this$ReadTable = ATR;
          }
          if (verbose == TRUE) {
            print(paste( "We tried to write apend last time to ", FileAll, sep=""));
          } 
          this$UnLockMe(); 
          return(thisLen + lenReadTable);
        } else {
           if (!is.null(this$ReadTable)) {
             colnames(this$ReadTable) = this$NamesColumns;
           }
           this$UnLockMe();
           return(lenReadTable);        
        }
      }
    }
  }
  if (!is.null(this$ReadTable)) {
    NN = this$NamesColumns;
    colnames(this$ReadTable) = this$NamesColumns;
    if (!is.null(colnames(this$ReadTable)) && is.character(colnames(this$ReadTable)) &&
      any(colnames(this$ReadTable) == "SimID")) {
     ATA = NumericMe(this$ReadTable[, colnames(this$ReadTable) != "SimID"]);
     ARD = as.character(this$ReadTable[, colnames(this$ReadTable) == "SimID"]);
     ATR = as.data.frame(cbind(as.data.frame(ARD, stringAsFactors=FALSE), as.data.frame(ATA)), stringsAsFactors = FALSE)
     colnames(ATR) = this$NamesColumns;
     this$ReadTable = ATR;
    } else {
      this$ReadTable = NumericMe(this$ReadTable);
    }
  }
  this$UnLockMe();
  return(lenReadTable);
}
);

setMethodS3("UpdateCurrentTable", "OutTable", function(this, NewVector, MyNameID = NULL,UpdateType = "", verbose = 0,...) {
   if (verbose > 0) {
   } else if (!is.null(this$verbose) && this$verbose > 0) {
     verbose = this$verbose;
   }
   if (verbose > 0) {
     print(paste("UpdateCurrentTable: starting for ", UpdateType, sep="")); flush.console();
   }
   if (any(names(NewVector) == "SimID")) {
      if (is.null(MyNameID)) {
        MyNameID = NewVector[names(NewVector) == "SimID"];
      }
      NewVector = NewVector[names(NewVector) != "SimID"];
   }
   NewVector = NewVector[names(NewVector) != "SimIDNo"];
   if (is.null(NewVector)) {
     print(paste("UpdateCurrentTable: New Vector is NULL, not useful, UpdateType = ", UpdateType, sep="")); flush.console();
   }
   NamesColumns = this$NamesColumns[this$NamesColumns != "SimID"];
   if (verbose > 0) {
     print(paste("UpdateCurrentTable: collected NamesColumns", sep="")); flush.console();
   }
   if (is.null(names(NewVector)) && length(NewVector) != length(NamesColumns)) {
     print(paste("Update Current Table: Sorry, you supplied bad knowledge to ",
       this$FileName, sep=""));
     print(paste(" Names NewVector = ", paste(names(NewVector), collapse=", "),
       " and length is ", length(NewVector), " but length NamesColumns is ",
       length(NamesColumns), sep="")); flush.console();
     tryCatch("Better Luck Next time");
   } else if (is.null(names(NewVector))) {
     names(NewVector) = NamesColumns;
     NewNewVector = NewVector;
   } else {
     MyMatch = NULL;
     if (any(names(NewVector) == "Sigma")) {
       try(names(NewVector)[names(NewVector) == "Sigma"] <- "Sigma:1");
     }
     try(MyMatch <- match(names(NewVector), NamesColumns));
     if (is.null(MyMatch)) {
       print(paste("UpdateCurrentTable: Tried to match NewVector with NNamesColumns but failed!: UpdateType = ", UpdateType, sep=""));
       flush.console();
       plot(paste("NamesColumns = ", paste(NamesColumns, collapse=","))); flush.console();
       plot(paste("  Newvector = ")); print(NewVector); flush.console();
     }
     NewNewVector = as.data.frame(
        matrix(0, 1,length(NamesColumns)), stringsAsFactors = FALSE);
     NewVectorKeepId = (1:length(NewVector))[!is.na(MyMatch)];
     NewNewVector[1,MyMatch[!is.na(MyMatch)]] = NewVector[NewVectorKeepId];
     names(NewNewVector) = NamesColumns;
   }
   if (!is.null(dim(this$currentTable)) && dim(this$currentTable)[2] != length(this$NamesColumns)) {
     print("I don't know why but CurrentTable has terrible Dimensions!"); flush.console();
     print(paste("     Note we are doing table ", UpdateType, sep=""));
     print(paste("dim(this$currentTable) == (", paste(dim(this$currentTable), collapse=", "),
        ") but length(NamesColumns) = ", length(this$NamesColumns), sep="")); flush.console();
     this$currentTable = NULL;
     this$currentIDs = NULL;
   }

   NewNoID = 0;
   if (is.null(this$currentTable)) {
     NewNoID = 1;
   } else if (is.null(dim(this$currentTable))) {
     NewNoID = this$currentTable[1] +1;  
   } else {
     NewNoID = max(this$currentTable[,1]) +1;
   }
   
   NV = as.vector(unlist(c(NewNoID, NewNewVector)));
   NewMatrix = .Call("CreateNewVector", this$currentTable, NV);
   if (is.null(NewMatrix)) {
     print(paste("CreateNewVector NewMatrix did not return other than NULL, UpdateType = ", UpdateType)); flush.console();
     return(-1);
   }
   MyNN = NULL;  MyColNames = this$NamesColumns;  SimIDNoN = "SimIDNo";
   try(this$currentIDs <- c(this$currentIDs, MyNameID));
   MyTryText = "if (is.matrix(NewMatrix)) {
     MyColNames[1] = SimIDNoN; colnames(NewMatrix) = MyColNames;  rownames(NewMatrix) = this$currentIDs;
     } else if (is.vector(NewMatrix)) {
       names(NewMatrix) = MyColNames
     } 
     MyNN = 1;"
   try(eval(parse(text=MyTryText)), silent=TRUE);
   if (is.null(MyNN)) {
     print(paste("CreateNewVector: NewMatrix did not input Colnames/RowNames ", UpdateType));  
   }
   try( this$currentTable <- NewMatrix);
   return(1);
   
   if (is.null(this$currentTable)) {
   
    if (verbose > 1) {
      print(paste("UpdateCurrentTable: Adding in currentTable for First Time, ", UpdateType, sep=""));
       flush.console();
    }
    this$currentIDs = MyNameID;
    this$currentTable = NULL
     if (verbose > 1) {
      print(paste("UpdateCurrentTable: right now inserting first NewNewVector, ", UpdateType, sep=""));
       flush.console();
    }   
    try(this$currentTable <- matrix(c(1, NewNewVector), 1, length(NewNewVector)+1 ));
     if (!is.null(dim(this$currentTable)) && dim(this$currentTable)[1] == 
        length(this$NamesColumns)) {
        this$currentTable = t(this$currentTable);     
      }
    MyTryer=NULL;
    MyText = "colnames(this$currentTable) = this$NamesColumns; MyTryer = 1;"
    try(eval(parse(text=MyText)));
    SimIDNoName = "SimIDNo"
      MyText = "colnames(this$currentTable) = this$NamesColumns;
        colnames(this$currentTable)[1] = SimIDNoName;
        rownames(this$currentTable) = MyNameID; MyTryer = 1;"
      try(eval(parse(text=MyText)));

    if (is.null(MyTryer)) {
      MyText = "names(this$currentTable) = this$NamesColumns;
        names(this$currentTable)[1] = SimIDNoName; MyTryer = NULL; "
      try(eval(parse(text=MyText)));   
    }
    if (is.null(MyTryer)) {
      print("UpdateCurrentTable: Tried to add row to NULL");
      tryCatch("Better Luck Next Time");
    }
  } else if (is.null(dim(this$currentTable))) {
    this$currentIDs = c(this$currentIDs[1], MyNameID);
    NewNumID = max(this$currentTable[1]) + 1;
    if (length(this$currentTable) != length(NewNewVector)+1) {
       print(paste("Copy error, Null Dim, length this$currentTable = ", length(this$currentTable), sep=""));
       print(paste("  But length NewNewVector = ", length(NewNewVector), sep=""));
       print(paste("  We fail with ", this$FileName, sep="")); flush.console();
       tryCatch("  Better Luck next time");
    }
    NewTable = as.matrix(rbind(as.numeric(unlist(this$currentTable)),
      c(NewNumID, NewNewVector)));
     if (!is.null(dim(this$currentTable)) && dim(this$currentTable)[1] == 
        length(this$NamesColumns)) {
        NewTable = t(NewTable);     
      }
      SimIDNoName = "SimIDNo";
      MyTryer=NULL;
      MyText = "colnames(NewTable) = this$NamesColumns;
        colnames(NewTable)[1] = SimIDNoName;
        rownames(NewTable) = this$currentIDs[round(as.numeric(unlist(NewTable[,1])))]; 
        this$currentTable = NewTable; MyTryer = 1;"
      try(eval(parse(text=MyText)));
      if (is.null(MyTryer)) {
        print("Well, tried to add row to row and got hurt");
        tryCatch("Better Luck Next Time");
      }
  } else {
    this$currentIDs = c(this$currentIDs, MyNameID);
    NewNoID = max(as.numeric(unlist(this$currentTable[,1]))) +1;
    AddVector = c(NewNoID, NewNewVector);
    try(colnames(this$currentTable)[1] <- "SimIDNo");
    names(AddVector) = c("SimIDNo", names(NewNewVector));
    names(AddVector) = NULL;
    CNcurrentTable = colnames(this$currentTable);
    colnames(this$currentTable) = NULL;
    dimT = dim(this$currentTable);
    NewTable = matrix(0, dimT[1]+1, dimT[2]);
    if (verbose > 1) {
      print(paste("UpdateCurrentTable: Now copying into region, ", UpdateType, sep=""));
       flush.console();
    }
    try(NewTable[1:dimT[1],1:dimT[2]] <- as.numeric(this$currentTable[,1:dimT[2]]));
      if (verbose > 1) {
      print(paste("UpdateCurrentTable: Adding in NewNewVector, ", UpdateType, sep=""));
       flush.console();
    }
    try(NewTable[dimT[1]+1,2:dimT[2]] <- as.numeric(NewNewVector));
    try(NewTable[dimT[1]+1,1] <- NewNoID);
    try(colnames(NewTable) <- CNcurrentTable);
    
    try(rownames(NewTable) <-this$currentIDs[round(as.numeric(NewTable[,1]))]);
    if (verbose > 1) {
      print(paste("UpdateCurrentTable: Moment Of truth, inserting NewTable: ", UpdateType, sep=""));
      flush.console();
    }
    this$currentTable <- NewTable;
    return;
    this$currentTable = as.data.frame(rbind(
        as.data.frame(this$currentTable),
        matrix(AddVector,1,length(AddVector))   ),stringsAsFactors = FALSE);
    MyTryer=NULL;
    MyText = "colnames(this$currentTable) = this$NamesColumns; MyTryer = 1;"
    try(eval(parse(text=MyText)));
    if (is.null(MyTryer)) {
      print(paste("  I don't know why we cant fix column names, dim originally (",
        paste(dim(this$currentTable), collapse=", "), "), filename = ",
        this$FileName, sep="")); flush.console();
      tryCatch("  Better Luck Next Time");
      MyText = "names(this$currentTable) = this$NamesColumns; MyTryer = 1;"
      try(eval(parse(text=MyText)));
    }
  }
  return(1);
    
});

setMethodS3("UnLockMe", "OutTable", function(this, ...) {
   LockFileName = paste("LockFile", this$FileName, sep="");
   LockFileAll = paste(this$FileDir, "//", LockFileName, sep="");
   FilesInDir = unlist(list.files(this$FileDir));
  ##print(paste("Unlock: ", LockFileAll, sep=""))
  if (length(FilesInDir) > 0 && any(FilesInDir == LockFileName)) {
    try(unlink(LockFileAll), silent=TRUE);
  }
  return(TRUE);
});
setMethodS3("LockMeIn", "OutTable", function(this, DefaultTime = 10, IntNTries = 0,
  IntPrintEvery = 100, ...) {
   LockFileName = paste("LockFile", this$FileName, sep="");
   LockFileAll = paste(this$FileDir, "//", LockFileName, sep="");
   FilesInDir = unlist(list.files(this$FileDir));
   if (length(FilesInDir) > 0 && any(FilesInDir == LockFileName)) {
      RD <- NULL;
      try(RD <- read.table(LockFileAll, header=FALSE, sep=","), silent=TRUE);
      MyTime <- proc.time();  MyTime = MyTime[1:3];
      if (!is.null(RD) && (is.null(length(dim(RD))) ||
        length(dim(RD)) == 1 || length(RD) == 3)) {
         lRD = length(RD); if (lRD > 3) { lRD = 3;}
         if (lRD == 0) {
           unlink(LockFileAll);
           MyLockTable = rbind(as.numeric(MyTime), as.numeric(MyTime)); 
           try(write.table(MyLockTable, LockFileAll, append=FALSE, col.names=FALSE,
            row.names=FALSE, sep=", "), silent=TRUE);   
           return(TRUE);
         }
         TT = sum( (MyTime[1:lRD] - RD[1:lRD])^2 );
         if ( TT  < DefaultTime) {
           if (IntNTries > 0 && IntNTries %% IntPrintEvery == 0) {
             print(paste("LockMeIn: Tries = ", IntNTries,
              ": We've got MyTime[1:3] = ", paste(MyTime[1:3], collapse=", "),
              " and RD[1:3] = ", paste(RD[1:3], collapse=", "),
              " but diff = ", sum( abs(MyTime[1:3] - RD[1,1:3])),
              " DefaultTime = ", DefaultTime,sep=""));
             flush.console();
           }
           return(FALSE);
         } else {
           MyLockTable = rbind(as.numeric(MyTime), as.numeric(MyTime));
           try(write.table(MyLockTable, LockFileAll, append=FALSE, col.names=FALSE,
            row.names=FALSE, sep=", "), silent=TRUE);
            return(TRUE);          
         }
      } else if (!is.null(RD) && sum( abs(MyTime[1:3] - RD[1,1:3])) < DefaultTime) {
          if (IntNTries > 0 && IntNTries %% IntPrintEvery == 0) {
            print(paste("LockMeIn: Tries = ", IntNTries,
             ": We've got MyTime[1:3] = ", paste(MyTime[1:3], collapse=", "),
             " and RD[1:3] = ", paste(RD[1:3], collapse=", "),
             " but diff = ", sum( abs(MyTime[1:3] - RD[1,1:3])),
              " DefaultTime = ", DefaultTime,sep="") );
            flush.console();
          }
          return(FALSE);
      }
      MyLockTable = rbind(as.numeric(MyTime), as.numeric(MyTime));
      try(write.table(MyLockTable, LockFileAll, append=FALSE, col.names=FALSE,
        row.names=FALSE, sep=", "), silent=TRUE);
      return(TRUE); 
   }
   MyTime = proc.time();
   MyLockTable = rbind(as.numeric(MyTime), as.numeric(MyTime));
   try(write.table(MyLockTable, LockFileAll, append=FALSE, col.names=FALSE,
     row.names=FALSE, sep=", "), silent=TRUE);
   return(TRUE); 
}
);



setMethodS3("OutMapper", "OutSimAnalyses", function(this, 
  NameOfError,TrueParams = 0, WidthCover = 0,
  TargetColErrorNames = NULL, ...) {
  FakeLength = this$SummaryAll$ReadLength;
  if (is.null(FakeLength)) {
    throw("OutMapper Error: ReadLength is NULL!");
    flush.console();
  }
  if (FakeLength < this$TargetLength) {
    print(paste("Warning, OutMapper: FakeLength is only ", FakeLength, sep=""));
    flush.console();
  } else {
    FakeLength = this$TargetLength;
  }
  if (is.null(this$SummaryAll$ReadTable)) {
    throw("OutMapper Error: SummaryAll for this is NULL!");
  }
  ColNames = this$NamesColumns;

  if (NameOfError == "L2") {
   
    if (is.null(TargetColErrorNames)) {
      NeedCols = (1:length(ColNames))[substr(ColNames,1,3) != "tau" &
        ColNames != "SimID"];
    } else {
      NeedCols = (1:length(ColNames))[ColNames %in% TargetColErrorNames] 
    }
    ##print("L2 Colnames are :");
    ##print(ColNames, collapse=", ");  flush.console();
    print(paste("L2 NeedCols are :"));    flush.console();
    print(paste(NeedCols, collapse=", "));  flush.console();
    if (length(NeedCols) == 0) {
      print("L2 Error, NeedCols has zero length");      flush.console();
      print(paste("length of ColNames is ", length(ColNames), sep=""));
      print("FirstLine of ReadTable is:");    flush.console();
    }
    if (length(NeedCols) > 1) {
      Summers = rowSums( this$MeanDiff$ReadTable[,NeedCols]^2);
    } else {
      Summers = this$MeanDiff$ReadTable[,NeedCols]^2;
    }
    if (!is.null(this$TrueParamTable)) {
      print("L2 Error Using TrueParamTable");
      MatchedSum = match(this$TrueParamTable$ReadTable[,1], 
        this$MeanDiff$ReadTable[,1]);
      if (length(NeedCols) > 1) {
        TrueParamM2AtMatch =  rowSums(
          this$TrueParamTable$ReadTable[ !is.na(MatchedSum), NeedCols ]^2);
      } else {
        TrueParamM2AtMatch =
          this$TrueParamTable$ReadTable[ !is.na(MatchedSum), NeedCols ]^2;      
      }
      Summers = Summers[MatchedSum[!is.na(MatchedSum)]] /
        TrueParamM2AtMatch;
      return(Summers);   
    } else if (length(TrueParams) > 0) {
      print("L2 Error using Supplied TrueParams")
      Summers = Summers / sum(TrueParams[NeedCols-1]^2);
    }
    return(Summers);
  } else if (NameOfError == "L1") {
    if (is.null(TargetColErrorNames)) {
      NeedCols = (1:length(ColNames))[substr(ColNames,1,3) != "tau" &
        ColNames != "SimID"];
    } else {
      NeedCols = (1:length(ColNames))[ColNames %in% TargetColErrorNames] 
    }
    ##print("L1 Colnames are :");
    ##print(paste(ColNames, collapse=", "));  flush.console();
    print("L1 NeedCols are :");
    print(paste(NeedCols, collapse=", "));  flush.console();
    if (length(NeedCols) == 0) {
      print("L1 Error, NeedCols has zero length");
    }
    if (length(NeedCols) > 1) {
      Summers = rowSums( abs(this$MedianDiff$ReadTable[,NeedCols] ) );
    } else {
      Summers =  abs(this$MedianDiff$ReadTable[,NeedCols] );    
    }
    if (!is.null(this$TrueParamTable)) {
      print("L1 Error Useing TrueParamTable ")
      MatchedSum = match(this$TrueParamTable$ReadTable[,1], 
        this$MedianDiff$ReadTable[,1]);
      if (length(NeedCols) > 1) {
        TrueParamM2AtMatch =  rowSums( abs(
          this$TrueParamTable$ReadTable[ !is.na(MatchedSum), NeedCols ] ) );
      } else {
        TrueParamM2AtMatch =  abs(
          this$TrueParamTable$ReadTable[ !is.na(MatchedSum), NeedCols ] );      
      }
      Summers = Summers[MatchedSum[!is.na(MatchedSum)]] /
        TrueParamM2AtMatch;
      return(Summers);   
    } else if (length(TrueParams) > 0) {
      print("L1 Error Using Supplied TrueParams");
      Summers = Summers / sum(abs(TrueParams[NeedCols-1]));
    }
    return(Summers);  
    return(Summers);
  } else if (NameOfError == "L0") {
    if ((is.null(TrueParams) || length(TrueParams) <= 1) &&
       is.null(this$TrueParamTable) ) {
      print("Error: L0 Error hard with no TrueParams");   flush.console();
      return(this$SummaryAll$ReadTable[1:FakeLength,names(this$SummaryAll$ReadTable) == "L0Tot"]);
    } 
    ColNames = colnames(this$MeanDiff$ReadTable);
    NeedCols = (1:length(ColNames))[substr(ColNames,1,3) != "tau" &
      ColNames != "SimID"];
    if (length(NeedCols) == 0) {
      print("L0 Error, NeedCols has zero length");
    }
    if (WidthCover == 1) {
      ColMat = ColMat * 0;
      ColMat[abs(this$MeanDiff$ReadTable[,NeedCols]) > .5 * 
        abs(this$WidthCI$ReadTable[,NeedCols]) ] <- 1;
      if (length(NeedCols) > 1) {
        L0Error = colSums( abs(t(ColMat) - TrueParams[NeedCols]) );
      } else {
        L0Error = abs(ColMat - TrueParams[NeedCols]);
      }
    } else {
      ColMat = this$MeanDiff$ReadTable[,NeedCols];
      ColMat[ColMat != 0] = 1;
      if (length(NeedCols) > 1) {
        L0Error = colSums( abs(t(ColMat) - TrueParams[NeedCols]) );
      } else {
        L0Error = abs(ColMat - TrueParams[NeedCols]);      
      }
    }
    if (!is.null(this$TrueParamTable)) {
      print("L0 Error, using TrueParamTable")
      MatchedSum = match(this$TrueParamTable$ReadTable[,1], 
        this$MeanDiff$ReadTable[,1]);
      TrueParamM2AtMatchT =  
        this$TrueParamTable$ReadTable[ !is.na(MatchedSum), NeedCols ]
      TrueParamM2AtMatchT[TrueParamM2AtMatchT != 0] = 1;
      if (length(NeedCols) > 1) {
        Summers = rowSums(abs(ColMat[MatchedSum[!is.na(MatchedSum)],NeedCols] 
          - TrueParamM2AtMatchT));
      } else {
        Summers = abs(ColMat[MatchedSum[!is.na(MatchedSum)],NeedCols] 
          - TrueParamM2AtMatchT);      
      }
      Summers = Summers[MatchedSum[!is.na(MatchedSum)]] /
        TrueParamM2AtMatch;
      return(Summers);   
    } else if (length(TrueParams) > 0) {
      Summers = Summers / sum(abs(TrueParams[NeedCols-1]));
    }
    return(L0Error);  

  }  else if (NameOfError == "Type1") {
    if ((is.null(TrueParams) || length(TrueParams) <= 1) &&
      is.null(this$TrueParamTable)) {
      print("Error: Type 1 Error hard with no TrueParams")
      return(this$SummaryAll$ReadTable[1:FakeLength,names(this$SummaryAll$ReadTable) == "Type1"]);
    } 
    ColNames = colnames(this$MeanDiff$ReadTable);
    NeedCols = (1:length(ColNames))[substr(ColNames,1,3) != "tau" &
      ColNames != "SimID"];
    ColMat = this$MeanDiff$ReadTable[,NeedCols];
    if (WidthCover == 1) {
      ColMat = ColMat * 0;
      ColMat[abs(this$MeanDiff$ReadTable[,NeedCols]) > .5 * 
        abs(this$WidthCI$ReadTable[,NeedCols]) ] <- 1;
    } else {
      ColMat[ColMat != 0] = 1;
    }
    if (!is.null(this$TrueParamTable) && !is.null(this$TrueParamTable$ReadTable)) {
      print("Type 1 Error, using TrueParamTable")
      MatchedSum = match(this$TrueParamTable$ReadTable[,1], 
        this$MeanDiff$ReadTable[,1]);
      TrueParamM2AtMatchT =  
        this$TrueParamTable$ReadTable[ !is.na(MatchedSum), NeedCols ]
      TrueParamM2AtMatchT[TrueParamM2AtMatchT != 0] = 1;
      MatchCol = ColMat[MatchedSum[!is.na(MatchedSum)],]
      SubTractCol =  MatchCol - TrueParamM2AtMatchT;
      SubTractCol[SubTractCol  <=  0] = 0;
      if (length(NeedCols) > 1) {
        Summers=rowSums(SubTractCol) /
          rowSums(TrueParamM2AtMatchT);
      } else {
        Summers=(SubTractCol) /
          (TrueParamM2AtMatchT);     
      }
      return(Summers);
    }   
    Type1Error = rowSums(ColMat[,TrueParam == 0]) /
       length(TrueParam[TrueParam==0]);
    return(Type1Error); 
  } else if (NameOfError == "Type2") {
    if (is.null(TrueParams) || length(TrueParams) <= 1 &&
      is.null(this$TrueParamTable)) {
      print("Error: Type 2 Error hard with no TrueParams")
      return(this$SummaryAll$ReadTable[1:FakeLength,names(this$SummaryAll$ReadTable) == "Type1"]);
    } 
    ColNames = colnames(this$MeanDiff$ReadTable);
    NeedCols = (1:length(ColNames))[substr(ColNames,1,3) != "tau" &
      ColNames != "SimID"];
    ColMat = this$MeanDiff$ReadTable[,NeedCols];
    if (WidthCover == 1) {
      ColMat = ColMat * 0;
      ColMat[abs(this$MeanDiff$ReadTable[,NeedCols]) > .5 * 
        abs(this$WidthCI$ReadTable[,NeedCols]) ] <- 1;
    } else {
      ColMat[ColMat != 0] = 1;
    }
    if (!is.null(this$TrueParamTable)) {
      print("Type 2 Error, using TrueParamTable")
      MatchedSum = match(this$TrueParamTable$ReadTable[,1], 
        this$MeanDiff$ReadTable[,1]);
      TrueParamM2AtMatchT =  
        this$TrueParamTable$ReadTable[ !is.na(MatchedSum), NeedCols ]
      TrueParamM2AtMatchT[TrueParamM2AtMatchT != 0] = 1;
      MatchCol = ColMat[MatchedSum[!is.na(MatchedSum)],]
      SubtractCol = TrueParamM2AtMatchT - MatchCol;
      SubtractCol[SubtractCol <= 0] = 0;
      if (length(NeedCols) >1) {
        Summers=rowSums(SubtractCol) /
          rowSums(TrueParamM2AtMatchT);
      } else {
        Summers = SubtractCol/ TrueParamM2AtMatchT;s
      }
      return(Summers);
    }   
    ColMat = 1-ColMat;
    Type2Error = rowSums(ColMat[,TrueParam == 1]) / 
      length(TrueParam[TrueParam == 1]);
    return(Type2Error); 
  } else if (NameOfError == "OutQuant") {
    return(
    this$SummaryAll$ReadTable[1:FakeLength,
      substr(names(this$SummaryAll$ReadTable), 1, nchar("NumOutQuant")) == "NumOutQuant"]);
  } else if (NameOfError == "time") {
    return(
    colSums(this$SummaryAll$ReadTable[1:FakeLength,
      substr(names(this$SummaryAll$ReadTable), 1, nchar("time")) == "time"]));
  } else if (NameOfError == "DIC") {
    return(
    this$SummaryAll$ReadTable[1:FakeLength,
      substr(names(this$SummaryAll$ReadTable), 1, nchar("DIC")) == "DIC"]);
  } else if (NameOfError == "PID") {
    return(
    this$SummaryAll$ReadTable[1:FakeLength,
      names(this$SummaryAll$ReadTable) == "PID"]);
  } else if (NameOfError == "BarD") {
    return(
    this$SummaryAll$ReadTable[1:FakeLength,
      names(this$SummaryAll$ReadTable) == "BarD"]);
  } else if (NameOfError == "DofMean") {
    return(
    this$SummaryAll$ReadTable[1:FakeLength,
      names(this$SummaryAll$ReadTable) == "DofMean"]);
  }             
  return(NULL);
});


setMethodS3("BoxedOneLine", "OutSimAnalyses", function(
  this, ListRFlags = NULL, ListsdRFlags = NULL,na.rm=TRUE, TrueParams = 0,
  TargetColErrorNames = NULL, 
  ...) {
  if (is.null(ListRFlags) || length(ListRFlags) == 0) {
    return(NULL);
  }
  RetString = paste(this$MethodName, sep="");
  for (ii in 1:length(ListRFlags)) {
    MyCol = OutMapper(this, ListRFlags[ii], TrueParams = TrueParams,
      TargetColErrorNames = TargetColErrorNames);  giveSD = FALSE;
    if (ListRFlags[ii] %in% ListsdRFlags) { giveSD = TRUE; }
    RetString = paste(RetString, " & ", SummarizeString(column=MyCol,
      na.rm=na.rm, giveSD = giveSD), sep="");
  }
  RetString = paste(RetString, " \\\\ \n", sep="");
  return(RetString);
});


