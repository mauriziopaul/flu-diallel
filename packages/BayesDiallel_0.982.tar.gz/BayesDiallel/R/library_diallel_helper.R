#library(rjags)



reformat.data.for.aduse <- function(data,
		components=c("a", "d", "u", "s", "e", "sex"))
{
	required.cols <- c(
			"phenotype",
			"is.female",
			"mother.strain.name",
			"father.strain.name")
	if (!all(required.cols %in% colnames(data)))
	{
		stop("Missing columns ", paste(collapse=", ", setdiff(required.cols, colnames(data))))
	}
	
	strain.name   <- sort(unique(c(as.character(data$mother.strain.name), as.character(data$father.strain.name))))
	mother.strain <- as.integer(factor(data$mother.strain.name, levels=strain.name))
	father.strain <- as.integer(factor(data$father.strain.name, levels=strain.name))

	parentpair.name  <- paste(data$mother.strain.name, sep="_x_", data$father.strain.name)
	parentpair.id    <- as.integer(as.factor(parentpair.name))

	strainpair.name <- ifelse(mother.strain < father.strain,
				paste(data$mother.strain.name, sep="_x_", data$father.strain.name),
				paste(data$father.strain.name, sep="_x_", data$mother.strain.name))
	strainpair.id <- as.integer(as.factor(strainpair.name))
	
	parentpair.to.strainpair <- integer(unique(parentpair.id))
	parentpair.to.strainpair[parentpair.id] <- strainpair.id
	
	augmented.data <- cbind(data, data.frame(
			mother.strain=mother.strain,
			father.strain=father.strain,
			parentpair.name=parentpair.name,
			parentpair.id=parentpair.id,
			strainpair.name=strainpair.name,
			strainpair.id=strainpair.id))
			
	jags.data <- list(
			n = nrow(data),
			phenotype = data$phenotype)
			
	if (any(components %in% c("sex")))
	{
		jags.data$is.female <- as.integer(data$is.female)
	}
	if (any(components %in% c("a", "d", "u", "s")))
	{
		jags.data$num.strains   <- length(strain.name)
		jags.data$mother.strain <- mother.strain
		jags.data$father.strain <- father.strain
	}
	if (any(components %in% c("e")))
	{		
		jags.data$num.strainpairs           <- length(unique(strainpair.id))
		jags.data$parentpair.to.strainpair  <- parentpair.to.strainpair
					
		jags.data$num.parentpairs <- length(unique(parentpair.id))
		jags.data$parentpair.id             <- parentpair.id
	}
	list( data = augmented.data, jags.data = jags.data )
}

gelman.converged <- function(x, min.psrfq=1.1)
{
	max(gelman.diag(x)$psrf[,2]) < min.psrfq
}


make.diallel.skeleton <- function(num.strains, num.replicates)
{
	num.data <- num.replicates*num.strains^2

	# set up strain combinations
	mother.strain <- integer(num.data)
	father.strain <- integer(num.data)
	is.female <- integer(num.data)
	i <- 1
	for (m in 1:num.strains)
	{
		for (f in 1:num.strains)
		{
			for (r in 1:num.replicates)
			{
				mother.strain[i] <- m
				father.strain[i] <- f
				if (r/num.replicates > 0.5)
				{
					is.female[i] <- 1
				}			
				i <- i + 1
			}
		}
	}
	data <- data.frame(
			phenotype = rep(NA, num.data),
			father.strain.name=father.strain,
			mother.strain.name=mother.strain,
			is.female=is.female)
	data
}

expand.diallel.skeleton <- function(data,
		fill.missing=0,
		make.missing=0,
		phenotype="phenotype")
{
	required.cols <- c(phenotype, "is.female", "mother.strain.name", "father.strain.name")
	if (!all(required.cols %in% colnames(data)))
	{
		stop("Missing columns ", paste(collapse=", ", setdiff(required.cols, colnames(data))))
	}
	
	strain.name   <- sort(unique(c(as.character(data$mother.strain.name), as.character(data$father.strain.name))))
	data$mother.strain <- as.integer(factor(data$mother.strain.name, levels=strain.name))
	data$father.strain <- as.integer(factor(data$father.strain.name, levels=strain.name))
    
  data$original <- 1
	orig.mothers <- data$mother.strain
	orig.fathers <- data$father.strain
	orig.female  <- data$is.female
	if (0 < make.missing + fill.missing)
	{
		for (j in 1:length(strain.name))
		{
			for (k in 1:length(strain.name))
			{
				for (f in 0:1)
				{
					num.wanted <- make.missing
					if (0<fill.missing)
					{
						num.present <- sum(orig.mothers==j & orig.fathers==k & orig.female==f)
						num.wanted <- max(0, fill.missing-num.present)+num.wanted
					}
					if (0==num.wanted) next
					new.i <- (nrow(data)+1:num.wanted)
					data[new.i,] <- NA
					for (i in new.i)
					{
						data[i,c("mother.strain", "father.strain", "is.female", "original")] <- c(j,k,f,0)
					} 					
				}
			}
		}
		data$mother.strain.name <- strain.name[data$mother.strain]
		data$father.strain.name <- strain.name[data$father.strain]
	}
	data$diallel.id <- 1:nrow(data)


	parentpair.name  <- paste(data$mother.strain.name, sep="_x_", data$father.strain.name)
	parentpair.id    <- as.integer(as.factor(parentpair.name))

	strainpair.name <- ifelse(data$mother.strain < data$father.strain,
				paste(data$mother.strain.name, sep="_x_", data$father.strain.name),
				paste(data$father.strain.name, sep="_x_", data$mother.strain.name))
	strainpair.id <- as.integer(as.factor(strainpair.name))
	
	parentpair.to.strainpair <- integer(unique(parentpair.id))
	parentpair.to.strainpair[parentpair.id] <- strainpair.id
	
	augmented.data <- cbind(data, data.frame(
			parentpair.name=parentpair.name,
			parentpair.id=parentpair.id,
			strainpair.name=strainpair.name,
			strainpair.id=strainpair.id,
			is.hybrid=ifelse(data$mother.strain==data$father.strain, 0, 1)))
	list(
			data=augmented.data,
			strain.name=strain.name,
			parentpair.to.strainpair=parentpair.to.strainpair,
			num.obs=nrow(data),
			num.strains=length(strain.name),
			num.parentpairs=length(parentpair.to.strainpair),
			num.strainpairs=length(unique(parentpair.to.strainpair))
			)
}

sample.until.converged <- function(jo, min.psrfq=1.1, max.rounds=10, burnin=1e3, ...)
{
	if (0<burnin)
	{
		update(jo, n.iter=burnin)
	}
	
	string.time <- function(a,b, divisor=1)
	{
		d <- difftime(b,a)
		paste(round(d/divisor,3), attr(d, "units"))
	}
		
    count     <- 0
	timer     <- list(Sys.time())
	mcmc      <- NULL
	converged <- FALSE
   	while (!converged & count < max.rounds)
	{
		count <- count + 1
		cat("Sampling until converged: round ", count, "[", date(), "]:\n")
		mcmc <- coda.samples(jo, ...)
		timer[[count+1]] <- Sys.time()
		stat <- max(gelman.diag(mcmc)$psrf[,2])
		if (stat<min.psrfq)
		{
			cat("Converged to ", stat, "[")
			converged <- TRUE
		}
		else
		{
			cat("Unconverged to ", stat, "[")
		}
		cat("", string.time(timer[[count]],timer[[count+1]]), "]\n")
	}
	cat("Total time until convergence",
			string.time(timer[[1]], timer[[count+1]]),
			"[ average time of (", count, ") rounds =", string.time(timer[[1]], timer[[count+1]], count), "]\n")
	invisible(mcmc)
}

sim.diallel.effects <- function(data.list,
		var=list(a=0,d=0,m=0,
				strainpair=0, parentpair=0, 
				delta.a=0, delta.d=0, delta.m=0,
				delta.strainpair=0, delta.parentpair=0,
				ind=1),
		beta=list(mu=0, hybrid=0, female=0, female.hybrid=0)
		)
{
	data <- data.list$data
	num.strains <- data.list$num.strains
	num.strainpairs <- data.list$num.strainpairs
	num.parentpairs <- data.list$num.parentpairs
	parentpair.to.strainpair <- data.list$parentpair.to.strainpair
	num.obs <- nrow(data.list$data)
	
	#----------------------------------------
	# specific combining ability effects
	# epistatic and ss-epistatic
	delta.strainpair <- rnorm(num.strainpairs, sd=sqrt(var$delta.strainpair))
	strainpair       <- rnorm(num.strainpairs, sd=sqrt(var$strainpair))

	# reciprocal epistatic and ss-reciprocal epistatic
	delta.parentpair <- rnorm(num.parentpairs,
			mean=delta.strainpair[parentpair.to.strainpair],
			sd=sqrt(var$delta.parentpair))
	parentpair <- rnorm(num.parentpairs,
			mean=strainpair[parentpair.to.strainpair],
			sd=sqrt(var$parentpair))
		
	#----------------------------------------
	# general combining ability effects
	
	delta.d <- rnorm(num.strains, mean=beta$female.hybrid, sd=sqrt(var$delta.d))
	d <- rnorm(num.strains, mean=beta$hybrid, sd=sqrt(var$d))
	
	delta.a <- rnorm(num.strains, sd=sqrt(var$delta.a))
	a <- rnorm(num.strains, sd=sqrt(var$a))
	
	delta.m <- rnorm(num.strains, sd=sqrt(var$delta.m))
	m <- rnorm(num.strains, sd=sqrt(var$m))
	
	ind <- rnorm(num.obs, sd=sqrt(var$ind))
	
	# record effects
	data.list$true.effects <- list(
		a=a, delta.a=delta.a,
		d=d, delta.d=delta.d,
		m=m, delta.m=delta.m,
		strainpair=strainpair, delta.strainpair=delta.strainpair,
		parentpair=parentpair, delta.parentpair=delta.parentpair)
	data.list$true.var     <- var
	data.list$true.beta	   <- beta
	
	
	data <- data.list$data
	y.expect <- rep(NA, num.obs)
	for (i in 1:num.obs)
	{	
		f <- ifelse(data$is.female[i], 0.5, -0.5)
		
		j <- data$mother.strain[i]
		aj.sex <- a[j] + f*delta.a[j]
		dj.sex <- d[j] + f*delta.d[j]
		mj.sex <- m[j] + f*delta.m[j]
		
		k <- data$father.strain[i]
		ak.sex <- a[k] + f*delta.a[k]
		dk.sex <- d[k] + f*delta.d[k]
		mk.sex <- m[k] + f*delta.m[k]
		
		mother.sex <- aj.sex + data$is.hybrid[i]*dj.sex + mj.sex
		father.sex <- ak.sex + data$is.hybrid[i]*dk.sex - mk.sex
		
		epi.jk.sex <- parentpair[data$parentpair.id[i]] + f*delta.parentpair[data$parentpair.id[i]]
		
		y.expect[i] <- beta$mu + mother.sex + father.sex + f*beta$female + epi.jk.sex
	}
	data$y.expect <- y.expect
	data$phenotype <- y.expect + ind
	
	data.list$data <- data
	data.list
}

timethis <- function(...)
{
	string.time <- function(a,b, divisor=1)
	{
		d <- difftime(b,a)
		paste(round(d/divisor,3), attr(d, "units"))
	}
	before <- Sys.time()
	out <- eval(...)
	after <- Sys.time()
	cat(string.time(before,after), "\n")
	out
}


draw.diallel.old <- function(data, phenotype="phenotype",
		main=paste("diallel", nrow(data), "obs"),
		show.text=FALSE,
		text.white.at=0.7,
		text.col=NA,
		text.fun=length
		)
{
	n <- max(data$mother.strain, data$father.strain)
	d.range <- range(data[,phenotype])
	
	strain.names <- 1:n
	if (!is.null(data$mother.strain.name))
	{
		nd <- unique(data[,c("mother.strain.name","mother.strain")])
		strain.names[nd$mother.strain] <- as.character(nd$mother.strain.name)
	}
	if (!is.null(data$father.strain.name))
	{
		nd <- unique(data[,c("father.strain.name","father.strain")])
		strain.names[nd$father.strain] <- as.character(nd$father.strain.name)
	}
	
	plot(c(0,n), c(0,n), axes=FALSE, type="n", ylab="", xlab="", main=main)
	title(ylab="father strain", line=1)
	title(xlab="mother strain", line=1)
	axis(1, at=(1:n)-0.5, labels=strain.names, lty=0, line=-1)
	if (!all(1:n==strain.names))
	{
		axis(1, at=(1:n)-0.5, labels=1:n, lty=0, line=-2)
	}
	axis(2, at=(1:n)-0.5, labels=rev(1:n), lty=0, las=1, line=-1)
	axis(3, at=(1:n)-0.5, labels=1:n, lty=0, line=-1)
	for (j in 1:n)
	{
		for (k in 1:n)
		{
			i <- data$mother.strain==k & data$father.strain==j
			d.cell <- data[i,phenotype]
			if (0==length(d.cell)) next
			d <- (mean(d.cell)-d.range[1])/diff(d.range)
			col <- gray(1-d)
			
			x.start <- j-1
			x.end   <- j
			y.start <- n-k
			y.end   <- n-k+1
			polygon(c(x.start,x.end,x.end,x.start), c(y.end, y.end, y.start, y.start), col=col, border=1, density=NA)
			
			if (show.text)
			{    
				text.color <- text.col
				if (is.na(text.col)) 
				{
					text.color <- gray(1-ifelse(d>text.white.at,0,1))
				}
				text(0.5*(x.start+x.end), 0.5*(y.start+y.end), labels=text.fun(d.cell), col=text.color)
			}
		}
	}
}

draw.diallel <- function(data, phenotype="phenotype",
		main=paste("diallel", nrow(data), "obs"),
		cex.strain.names=1,
		col=NULL,
		col.grid="black",
		col.smoothness=2,
		data.matrix=NULL,
		data.range=range(na.rm=TRUE, data[,phenotype]),
		lwd.grid=1,
		mothers.across=FALSE,
		na.action="na.exclude",
		na.symbol="cross",
		strain.names=NULL,
		strain.coords=NULL,	
		show.strain.coords=TRUE,
		show.strain.names=TRUE,
		show.gridlines=TRUE,
		xlab=ifelse(mothers.across, "mother strain", "father strain"),
		ylab=ifelse(mothers.across, "father strain", "mother.strain"),
		LabelLeft=FALSE, LabelTop=FALSE,...
		)
{
  if (!all(c("mother.strain", "father.strain") %in% colnames(data)))
  {
    msg="Need integer columns \"mother.strain\" and \"father.strain\" or factor columns \"mother.strain.name\" and \"father.strain.name\""
    if (!all(c("mother.strain.name", "father.strain.name") %in% colnames(data)))
    {
      stop(msg)
    }
    parents=c(as.character(data$mother.strain.name), as.character(data$father.strain.name))
    parents.int=as.integer(as.factor(parents))
    data$mother.strain=parents.int[1:nrow(data)]
    data$father.strain=parents.int[ (nrow(data)+1):(2*nrow(data)) ]
  }

	n <- max(data$mother.strain, data$father.strain)
	d.range <- range(data[,phenotype], na.rm=TRUE)
	if (!is.null(data.matrix))
	{
		stopifnot(identical(dim(data.matrix),c(n,n)))
	}
	else
	{
		data.matrix=matrix(nrow=n, ncol=n)
		for (j in 1:n)
		{
			for (k in 1:n)
			{
			  #browser()
				i <- data$mother.strain==k & data$father.strain==j
				d.cell <- data[i,phenotype]
				if (0==length(d.cell))
				{
				  d <- NA
				}
				else if (all(is.na(d.cell)))
				{
					d <- NA
				}
				else if (any(is.na(d.cell)) & "na.exclude"==na.action)
				{
					d <- NA
				}
				else
				{
					d <- mean(d.cell, na.rm=TRUE)
				}
				data.matrix[j,k] <- d
			}
		}
	}
	
	if (!mothers.across)
	{
	  data.matrix=t(data.matrix)
	}
	
	if (is.null(col))
	{
		ncolors <- n^2*col.smoothness
		col=gray(1-(1:ncolors/ncolors))
	}
	if (show.strain.names)
	{
		if (is.null(strain.names))
		{
			strain.names <- 1:n
			if (!is.null(data$mother.strain.name))
			{
				nd <- unique(data[,c("mother.strain.name","mother.strain")])
				strain.names[nd$mother.strain] <- as.character(nd$mother.strain.name)
			}
			if (!is.null(data$father.strain.name))
			{
				nd <- unique(data[,c("father.strain.name","father.strain")])
				strain.names[nd$father.strain] <- as.character(nd$father.strain.name)
			}
		}
	}

  if (LabelLeft == FALSE || show.strain.coords==FALSE) {	
	image(0:n, 0:n, t(data.matrix[n:1,]), col=col, axes=FALSE, ylab="", xlab="", main=main,
	    zlim=range(data.range, na.rm=TRUE))
	title(ylab=ylab, line=.9+max(nchar(strain.names))/2)
  } else {
	image(0:n, 0:n, t(data.matrix[n:1,]), col=col, axes=FALSE, ylab="", xlab="", main=main,
	    zlim=range(data.range, na.rm=TRUE))
	title(ylab=ylab, line=1.7+max(nchar(strain.names))/2);  
  }
	title(xlab=xlab, line=2)
	
	if (show.strain.coords)
	{
		if (is.null(strain.coords))
		{
			strain.coords <- 1:n
		}
		axis(1, at=(1:n)-0.5, labels=strain.coords, lty=0, line=-1)
		axis(2, at=(1:n)-0.5, labels=rev(strain.coords), lty=0, las=1, line=-0.5)
		axis(3, at=(1:n)-0.5, labels=strain.coords, lty=0, line=-0.5)
	}

	if (show.strain.names)
	{
		if (is.null(strain.names))
		{
			strain.names <- 1:n
			if (!is.null(data$mother.strain.name))
			{
				nd <- unique(data[,c("mother.strain.name","mother.strain")])
				strain.names[nd$mother.strain] <- as.character(nd$mother.strain.name)
			}
			if (!is.null(data$father.strain.name))
			{
				nd <- unique(data[,c("father.strain.name","father.strain")])
				strain.names[nd$father.strain] <- as.character(nd$father.strain.name)
			}
		}
		if (show.strain.coords == TRUE) {
		axis(1, at=(1:n)-0.5, labels=strain.names, lty=0, line=0, cex.axis=cex.strain.names)
		if (LabelLeft == TRUE) {
	  	axis(2, at=(1:n)-0.5, labels=rev(strain.names), lty=0, las=1, line=.2);   
    }
    if (LabelTop == TRUE) {
      axis(3, at=(1:n)- 0.5, labels=strain.coords, lty=0, line=-.5)      
    }
    } else {
		axis(1, at=(1:n)-0.5, labels=strain.names, lty=0, line=-1, cex.axis=cex.strain.names)
		if (LabelLeft == TRUE) {
	  	axis(2, at=(1:n)-0.5, labels=rev(strain.names), lty=0, las=1, line=-.5);   
    }
    if (LabelTop == TRUE) {
      axis(3, at=(1:n)-0.5, labels=strain.names, lty=0, line=0)      
    }    
    }
	}

	
	for (j in 1:n)
	{
		for (k in 1:n)
		{
			if (!is.na(data.matrix[j,k])) next
			if ("cross"==na.symbol)
			{
				segments(x0=rep(k-1,2), y0=(n-j)+c(0,1), x1=rep(k,2), y1=(n-j)+c(1,0))
			}
		}
	}

	if (show.gridlines)
	{
	  abline(h=0:n, lwd=lwd.grid, col=col.grid)
	  abline(v=0:n, lwd=lwd.grid, col=col.grid)
	}
	
	invisible(data.matrix)
}


order.ccfounders=function(x)
{
  x=sub("^129$", "129s1", x)
  match(x, ccfounder.short.names)
}

plot.straws.cc=function(data,
		strain.names=ccfounder.short.names,
		strain.cols=ccfounder.colors,
		...)
{
  correct.order=c("AJ", "B6", "129","NOD","NZO","CAST","PWK","WSB")
  if (!all(sub("additive:", "", rownames(data))==correct.order))
  {
    stop("strain names out of order")
  }
  
  plot.straws(data, col=ccfounder.colors, ...)
}

plot.straws=function(data,
    col=rainbow(nrow(data)),
    axes=sides(default=FALSE, bottom=TRUE, left=TRUE),
    axes.update=sides(),
    axes.lty=1,
    mar=sides(bottom=5,left=7,top=4,right=2),
    mar.update=sides(),
    name.line=0,
		lwd=3,
		type="l", xlim=NULL, GiveHeadings = TRUE,
		ylab = "", strain.names=NULL,
		...)
{
	oldmar <- par("mar")
	on.exit(par(mar=oldmar))
	
	num.stats <- ncol(data)
	num.straws <- nrow(data)
	if (GiveHeadings==TRUE) {
	   mar[2] = max(nchar(colnames(data))) * 9 / 20
	} else {
           mar[2] = 1;   mar[4] = 1;
	}

	par(mar=update.sides(mar, mar.update))
	axes=update.sides(axes, axes.update)
	if (is.null(xlim)) {
	plot(range(data), c(1,num.stats), type="n", axes=FALSE, ylab="",  xlab="", ...)
	} else {
	plot(range(data), c(1,num.stats), type="n", axes=FALSE, ylab="", xlab="", xlim=xlim, ...)	
	}
	if (((!is.logical(GiveHeadings) && is.numeric(GiveHeadings) && GiveHeadings > 0)
	  || GiveHeadings == TRUE) && axes["left"])
	{
	  axis(2, at=1:num.stats, labels=rev(colnames(data)), las=1, lty=axes.lty, line=name.line)
	}
	if (axes["bottom"])
	{
	  axis(1)
	}
	if ("l"==type)
	{
	  for (i in 1:num.straws)
  	{
  		lines(data[i,], num.stats:1, col=col[i], lwd=lwd)
  	}
  }
}


draw.diallel.sexed <- function(data, phenotype="phenotype", main=paste("diallel", nrow(data), "obs"))
{
	n <- max(data$mother.strain, data$father.strain)
	y.range <- range(data[,phenotype])

	strain.names <- 1:n
	if (!is.null(data$mother.strain.name))
	{
		nd <- unique(data[,c("mother.strain.name","mother.strain")])
		strain.names[nd$mother.strain] <- as.character(nd$mother.strain.name)
	}
	if (!is.null(data$father.strain.name))
	{
		nd <- unique(data[,c("father.strain.name","father.strain")])
		strain.names[nd$father.strain] <- as.character(nd$father.strain.name)
	}
	
	plot(c(0,n), c(0,2*n+1), axes=FALSE, type="n", ylab="", xlab="", main=main)
	title(ylab="father strain", line=1)
	title(xlab="mother strain", line=1)
	axis(1, at=(1:n)-0.5, labels=strain.names, lty=0, line=-1)
	axis(1, at=(1:n)-0.5, labels=1:n, lty=0, line=-2)
	axis(2, at=c((1:n)-0.5, (n+2):(2*n+1)-0.5), labels=rep(rev(1:n),2), lty=0, las=1, line=-1)
	text((1:n)-0.5, rep(n+0.5, n), labels=1:n)
	mtext("[females]", side=2, at=1.5*n, line=1)
	mtext("[males]", side=2, at=0.5*n, line=1)
	for (j in 1:n)
	{
		for (k in 1:n)
		{
			i <- data$mother.strain==k & data$father.strain==j
			for (is.female in 0:1)
			{
				si <- i & data$is.female==is.female
				y.cell <- data[si,phenotype]
				if (0==length(y.cell)) next
				x <- (mean(y.cell)-y.range[1])/diff(y.range)
				polygon(c(j-1,j,j,j-1), c(n-k+1, n-k+1, n-k, n-k)+is.female*(n+1), col=gray(1-x))
			}
		}
	}
}

prepare.jags.data <- function(data.list, model="sadme")
{
	components <- unlist(strsplit(model, ""))
	jags.data <- list(
			n = data.list$num.obs,
			phenotype = data.list$data$phenotype)
			
	if (any(components %in% c("s")))
	{
		jags.data$is.female <- as.integer(data.list$data$is.female)
	}
	if (any(components %in% c("d")))
	{
		jags.data$is.hybrid     <- data.list$data$is.hybrid
	}
	if (any(components %in% c("a", "d", "m")))
	{
		jags.data$num.strains   <- data.list$num.strains
		jags.data$mother.strain <- data.list$data$mother.strain
		jags.data$father.strain <- data.list$data$father.strain
	}
	if (any(components %in% c("e")))
	{		
		jags.data$num.strainpairs           <- data.list$num.strainpairs
		jags.data$parentpair.to.strainpair  <- data.list$parentpair.to.strainpair
					
		jags.data$num.parentpairs 			<- data.list$num.parentpairs
		jags.data$parentpair.id             <- data.list$parentpair.id
	}
	jags.data
}

read.sim.spec <- function(file)
{
	d <- read.table(file, header=FALSE)
	spec <- list(var=list(), beta=list())
	for (i in grep("^beta.*", d[,2]))
	{
		spec$beta[[sub("^beta.", "", d[i,2])]] <- as.numeric(d[i,1])
	}
	for (i in grep("^var.*", d[,2]))
	{
		spec$var[[sub("^var.", "", d[i,2])]] <- as.numeric(d[i,1])
	}
	spec	
}	
	
# GENERAL FUNCTIONS
vload=function(file, read.only=FALSE, as.list=FALSE, env=parent.frame())
{
  load(file)
  object.names=setdiff(ls(), c("file", "read.only", "as.list"))
  if (read.only)
  {
    return (object.names)
  }
  cat("Objects:-\n")
  print(object.names)
  if (as.list)
  {
    retval=list()
    for (object.name in object.names)
    {
      retval=c(retval, eval(parse(text=object.name)))
    }
    return (retval)
  }
  for (object.name in object.names)
  {
    assign(object.name, eval(parse(text=object.name)), env=env)
  }
}

# CC/Alan-specific

rename4hpd=function(x)
{
  x=sub("Gender", "female", x)
  x=sub("BetaHybrid:female:Av", "female.inbreed.overall", x)
  x=sub("BetaHybrid:Av", "inbreed.overall", x)
  x=sub("female:Av", "female.overall", x)
  x=sub("ASymCrossjkDkj", "w:", x)
  x=sub("SymCrossjk", "v", x)
  x=sub("dominancej", "inbreed", x)
  x=sub("motherj", "maternal", x)
  x=sub("aj", "additive", x)
  x=sub(":j", ":", x)
  x=sub(";k:", ":", x)
  x=sub("::", ":", x)
  x=sub("Mu", "mu", x)
  x=sub("B6AJ9", "129", x)
  x=sub("Sigma:1", "sigma", x)
  x
}

component.indices=function(x)
{
  key=list()
  key$B=which(x=="inbreed.overall")
  key$S=which(x=="female.overall")
  key$Bs=which(x=="female.inbreed.overall")
  key$a=grep("^additive", perl=TRUE, x)
  key$b=grep("^inbreed:", perl=TRUE, x)
  key$m=grep("^maternal:", perl=TRUE, x)
  key$v=grep("^v",perl=TRUE, x)
  key$w=grep("^w",perl=TRUE, x)
  key$as=grep("^female:additive", x)
  key$bs=grep("^female:inbreed:", x)
  key$ms=grep("^female:maternal", x)
  key$vs=grep("^female:v",perl=TRUE, x)
  key$ws=grep("^female:w",perl=TRUE, x)
  key
}

make.point.est=function(mcmc, FUN=mean)
{
  J=8
  mcmat=as.matrix(mcmc.stack(mcmc))
  mcpoint=apply(mcmat, 2, FUN)
  vars=names(mcpoint)
  
  lp=list()

  # female
  i=which("female.overall"==vars)
  lp[["female.overall"]] = rep(mcpoint[i], J)
  
  # inbreed penalty
  i=which("inbreed.overall"==vars)
  lp[["inbreed.overall"]] = rep(mcpoint[i], J)
  if (length(lp[["inbreed.overall"]]) == 0) {
    lp[["inbreed.overall"]] = rep(0, J);
    names(lp[["inbreed.overall"]]) = rep("inbreed.overall", J);
  }

  # female inbreed penalty
  i=which("female.inbreed.overall"==vars)
  lp[["female.inbreed.overall"]] = rep(mcpoint[i], J)
  if (length(lp[["female.inbreed.overall"]]) == 0) {
    lp[["female.inbreed.overall"]] = rep(0, J);
    names(lp[["female.inbreed.overall"]]) = rep("female.inbreed.overall", J);
  }
  
  # additive
  i=grep("^additive:\\w+$", vars, perl=TRUE)
  lp[["additive"]] = mcpoint[i]
  
  # inbreed
  i=grep("^inbreed:\\w+$", vars, perl=TRUE)
  lp[["inbreed"]] = mcpoint[i]
  if (length(lp[["inbreed"]]) == 0) {
    lp[["inbreed"]] = rep(0, J);
    names(lp[["inbreed"]]) = rep("inbreed", J);
  }
  
  # maternal
  i=grep("^maternal:\\w+$", vars, perl=TRUE)
  lp[["maternal"]] = mcpoint[i]
  
  # female additive
  i=grep("^female:additive:\\w+$", vars, perl=TRUE)
  lp[["female.additive"]] = mcpoint[i]

  # female inbreed
  i=grep("^female:inbreed:\\w+$", vars, perl=TRUE)
  lp[["female.inbreed"]] = mcpoint[i]
  if (length(lp[["female.inbreed"]]) == 0) {
    lp[["female.inbreed"]] = rep(0, J);
    names(lp[["female.inbreed"]]) = rep("female.inbreed", J);
  }
  
  # female maternal
  i=grep("^female:maternal:\\w+$", vars, perl=TRUE)
  lp[["female.maternal"]] = mcpoint[i]
  
  if (FALSE) {
  lp2 = list();
  it = 0;
  for (ii in 1:length(lp)) {
    if (length(lp[[ii]]) > 0) {
      it = it+1; lp2[[it]] = lp[[ii]]
    } else {
      it = it +1;  lp2[[it]] = rep(0, J);
    }
  }
  }
  for (ii in 1:length(lp)) {
    if (length(lp[[ii]]) != J) {
      lp[[ii]] = rep(0,J);
    }
  }
  dp=as.data.frame(lp)
  rownames(dp)=sub("additive:", "", rownames(dp))
  dp
}
  
draw.fourhpd=function(mcmc, file=NULL, height=5, width=8, preview=FALSE, xlim=NULL)
{
  varnames(mcmc)=rename4hpd(varnames(mcmc))
  k=component.indices(varnames(mcmc))

  wanted1=c(
      k$B, 
      k$a, k$b, k$m)
  wanted2=c(k$v, k$w)
  wanted3=c(
      k$S, k$Bs, 
      k$as, k$bs, k$ms)
  wanted4=c(
      k$vs, k$ws)
#browser()
  if (!is.null(file))
  {
    pdf(file, height=height, width=width)
  }

  cex=0.5
  par(mfrow=c(1,4))
  plot.hpd(mcmc, wanted=wanted1,
      cex=cex, 
      ylim=c(3,length(wanted1)),
      mar.update=sides(right=0, left=3),
      main="General effects",
      name.line=0,
      before.data=function(){abline(v=0, lwd=3, col="gray")},
      xlim=xlim)
  plot.hpd(mcmc, wanted=wanted2,
      cex=cex,
      ylim=c(2,length(wanted2)),
      name.line=0,
      mar.update=sides(right=0, left=1), 
      main="Strainpair-specific",
      before.data=function(){abline(v=0, lwd=3, col="gray")},
      xlim=xlim)
  plot.hpd(mcmc, wanted=wanted3,
      cex=cex, 
      ylim=c(4,length(wanted3)),
      mar.update=sides(right=0, left=1),
      main="Sex-specific",
      name.line=0,
      names=sub("female:","",varnames(mcmc)[wanted3]),
      before.data=function(){abline(v=0, lwd=3, col="gray")},
      xlim=xlim)
  plot.hpd(mcmc, wanted=wanted4,
      cex=cex,
      ylim=c(2,length(wanted4)),
      name.line=0,
      mar.update=sides(right=0, left=1), 
      main="Sex/strainpair-specific",
      names=sub("female:","",varnames(mcmc)[wanted4]),
      before.data=function(){abline(v=0, lwd=3, col="gray")},
      xlim=xlim)
  
  if (!is.null(file))
  {
    dev.off()
    if (preview)
    {
      preview(file)
    }
  }
}

  
  
  
  
  
  
  
  

