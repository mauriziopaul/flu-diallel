
if (FALSE) {
  library(R.oo);  library(BayesDiallel);
  load("SaveAFDBackUpPiximusDataTotalTissue.RData");
  AFD1 <- AFD;
  load("SaveAFDBackUpPiximusDataLeanTissue.RData");
  AFD2 <- AFD;
  AFDTreat <- AFD1;  AFDControl <- AFD2;

}

ProductAFD <- function (AFDTreat, AFDControl, SaveFileName = "") {

   if (!exists("AFDTreat") || is.null(AFDTreat) ||
    !exists("AFDControl") || is.null(AFDControl)) {
    print("ProductAFD: no dice, give me FD!"); flush.console();                                                       r
    return(-1);  
  }
  if ((is.logical(AFDTreat$Verbose) && AFDTreat$Verbose==TRUE) ||
    (is.numeric(AFDTreat$Verbose) && AFDTreat$Verbose > 0)) {
    print("ProductAFD: Starting. "); flush.console();  
  }
  if (!exists("Verbose") || is.null(Verbose)) {
    try(Verbose <- AFDTreat$Verbose);
  }
  FixedIndices <- (1:NCOL(AFDTreat$X))[
    colnames(AFDTreat$X) %in% AFDTreat$.AllFixedVariables];
  RandomIndiceList <- list();
  CountRandom <- 0;
  RandomNamesList <- list();
  RandomCNames <- c();
  AP <- 1;
  for (ii in 1:length(AFDTreat$.AllRandomVariables)) {
    if (length((1:NCOL(AFDTreat$X))[
      substr(colnames(AFDTreat$X), 1, nchar(AFDTreat$.AllRandomVariables[ii])) ==
      AFDTreat$.AllRandomVariables[ii]]) > 0) {
    RandomIndiceList[[AP]] <- (1:NCOL(AFDTreat$X))[
      substr(colnames(AFDTreat$X), 1, nchar(AFDTreat$.AllRandomVariables[ii])) ==
      AFDTreat$.AllRandomVariables[ii]];
    if (length(RandomIndiceList[[AP]]) > 0) {
      CountRandom <- CountRandom+1;
      RandomCNames <- c(RandomCNames, AFDTreat$.AllRandomVariables[ii]);
    }
    RandomNamesList[[AP]] <- paste("Treat:", colnames(AFDTreat$X)[RandomIndiceList[[AP]]], sep="");
    AP <- AP + 1;
    }
  }
  names(RandomIndiceList) <- paste("Treat:", RandomCNames, sep="");
  TotalFixedEffects <- matrix(0, length(AFDTreat$Y)+length(AFDControl$Y),
    length(FixedIndices));
  TotalFixedEffects[1:length(AFDTreat$Y),] <- AFDTreat$X[1:length(AFDTreat$Y), FixedIndices];
  colnames(TotalFixedEffects) <- paste("Treat:", colnames(AFDTreat$X)[FixedIndices], sep="");
  
  TotalRandomEffects <- matrix(0, length(AFDTreat$Y)+length(AFDControl$Y), 
    length(unlist(RandomIndiceList)) );
  colnames(TotalRandomEffects) <- unlist(RandomNamesList);
  TotalRandomEffectsGroups <- rep(0, length(RandomCNames));
  AK <- 0;
  for (ii in 1:length(RandomIndiceList)) {
    TotalRandomEffects[1:length(AFDTreat$Y),AK + 
      1:length(RandomIndiceList[[ii]])] <- AFDTreat$X[, RandomIndiceList[[ii]] ];  
    TotalRandomEffectsGroups[ii] = length(RandomIndiceList[[ii]]) 
    AK <- AK + length(RandomIndiceList[[ii]]) 
  }
  names(TotalRandomEffectsGroups) <- paste("Treat:", RandomCNames, sep="");
  TotalY <- c(AFDTreat$Y, AFDControl$Y);                                                
  TotalListjk <- rbind(AFDTreat$Listjk, AFDControl$Listjk);
  TotalSexVector <- c(AFDTreat$SexVector, AFDControl$SexVector);
  
  AFDAll <- FullDiallelAnalyze(Y = TotalY, SexVector = TotalSexVector, 
   Listjk = TotalListjk, InFixedEffects = TotalFixedEffects, InRandomEffects = TotalRandomEffects, 
   InRandomEffectsGroups = TotalRandomEffectsGroups,
   nameFixedEffects=NULL, nameRandomEffects=NULL,
   WeightsKeep = 0, dfStart=.01, mStart=.01,
   tauFixedEffects = 1000, dfRandomEffects = .5, mRandomEffects = .5,
   dfTNoise = AFDTreat$dfTNoise, Verbose = AFDTreat$Verbose, MyFullDiallelName = "Combined Treat Control Dialel",
   PriorGender = AFDTreat$PriorGender, strain.map = AFDTreat$strain.map, 
   ListUnknownGender= NULL,
   ProbUnknownGender = NULL, NoChainsUnknownGender = FALSE, 
   burnin = 100, thin = 1, 
   LogTransformedFlag = FALSE, SqrtTransformedFlag = FALSE,
   ProbFemaleUnknownSex = NULL, NoChainsUnknownSex=NULL, ListUnknownSex=NULL,
   MissingYIndices = NULL,
   LowCensorBound=NULL, UpCensorBound=NULL, NoChainsImputeY=FALSE, phenotype.name = "", 
   DoGelman = TRUE, DoFirstCenter = AFDTreat$DoFirstCenter);
   if (AFDTreat$DoFirstCenter == TRUE) {
     AFDAll$DoFirstCenter <- TRUE;
     AFDAll$AllCenteredRandomVariables <- c(
       paste("Treat:", BayesDiallel:::.DefaultAllRandomVariables, sep=""),
       paste(BayesDiallel:::.DefaultAllRandomVariables, sep=""));
  }
## Setup Analysis Methods for AFD, including allocating for MCMC chains
## "Sigma" is starting Sigma anticipated noise value
SetupAnalysisMethods(AFDAll, ModelsList = AFDTreat$ModelsList, Sigma = AFDTreat$AllDiallelObs[[1]]$Sigma,
  numChains = length(AFDTreat$AllDiallelObs[[1]]$CodaChains), 
  lengthChains = NROW(AFDTreat$AllDiallelObs[[1]]$CodaChains[[1]]), 
  dfTNoise = AFDTreat$dfTNoise);
   

if (!is.null(Verbose) && Verbose == TRUE) {
  print("**********************************************************");
  print("DiallelAnalyze:  About to run all Chains");
  flush.console();
}
#######################################################
## This will run the MCMC sampler on Model of choice
AOut = NULL;
t1 = proc.time();
try(AOut <- RunChains(AFDAll));
t2 = proc.time();

if (!is.null(AFDTreat$Verbose) && AFDTreat$Verbose >= 1) {
  print("DiallelAnalyze all done we've run a massive include treat model.");
  flush.console();
}
   if (AFDTreat$DoFirstCenter == TRUE) {
     AFDAll$AllCenteredRandomVariables <- c(
       paste("Treat:", BayesDiallel:::.DefaultAllRandomVariables, sep=""),
       paste(BayesDiallel:::.DefaultAllRandomVariables, sep=""));
  }
##SaveAFDFile <-  "SaveAFDBackUpCombined.RData"
AFD = AFDAll;
save(AFD = AFD, this = AFD, file=SaveFileName);
## load("SaveAFDBackUpCombined.RData");
eval(parse(text=GetG0Text("MapChainNamesHPD", "BayesDiallel:::RSIMNAMESPACE", S=1)));
if (substr(MapChainNamesHPD[NROW(MapChainNamesHPD),1], 1, nchar("Treat")) != "Treat") {
MapChainNamesTreatHPD = rbind(MapChainNamesHPD,
  cbind(paste("Treat:", MapChainNamesHPD[,1], sep=""),
    paste(MapChainNamesHPD[,2], sep="")),
    c("FixedEffect:1:Treat:Mu", "mean"),
    c("FixedEffect:2:Treat:Gender:Av", "female.overall"),
    c("FixedEffect:3:Treat:BetaInbred:Av", "inbreed.overall"), 
    c("FixedEffect:3:Treat:BetaHybrid:Av", "inbreed.overall"), 
    c("FixedEffect:4:Treat:BetaInbred:Gender:Av", "female.inbreed.overall"),
    c("FixedEffect:4:Treat:BetaHybrid:Gender:Av", "female.inbreed.overall"),
    c("FixedEffect:4:Treat:Gender:BetaInbred:Av", "female.inbreed.overall"),
    c("FixedEffect:4:Treat:Gender:BetaHybrid:Av", "female.inbreed.overall"));
try(eval(parse(text=SetGText("MapChainNamesTreatHPD", "globalenv()", S=1))), silent=TRUE);
try(eval(parse(text=SetGText("MapChainNamesTreatHPD", "BayesDiallel:::RSIMNAMESPACE", S=1))), silent=TRUE);
}
return(AFDAll);
##.AllFixedVariables
##.DefaultAllRandomVariables =
  MyX <- 
  MyText = "
     if (!exists(\"stauInbredNoise\") && exists(\"stauHybridNoise\")) {
        stauInbredNoise <- stauHybridNoise;
     }
     if (!exists(\"stoggleInbred\") && exists(\"stoggleHybrid\")) {
        stoggleInbred <- stoggleHybrid;
     }
     if (!exists(\"MyBetaInbredLevel\") && exists(\"MyBetaHybridLevel\")) {
        MyBetaInbredLevel <- MyBetaHybridLevel;
     }
     MyCall = .Call(\"RunDiallelAlgorithmNoNet\",
       AFD$.numj, MyX, MyY, MyXtX, MyXtY,
       MySumYSq, MyBeta, Mytau, MySigmaSq, MyLikelihood,
       MyCodaChain,
       MyLikelihoodChain,
       MyQ, MyInvQ, MyInvSqQ,
       MyDpBeta, MyTauFixed, Mydftau, Mymtau,
       mSigma, dfSigma,
       MyWantDiag,
       MyCrossModel, MyBetaInbredLevel,
       MytauCrosses,ASymNotASym = 0,
       jCross, kCross, jCrossO, kCrossO,
       VecOWeights, fW, dfTNoise,                   
       stauInbredNoise, stoggleInbred, sSigmaDeltaInbred,
       Verbose, MeanWeights, AllWeights, CheckNaFlag,
       StartIter, c(InformEvery, ChainIteri),
       CListUnknowns, this$GXX,
       this$ImputedGender, this$ProbUnknownGender,
       this$ImputeGenderChains[[ChainIteri]], 
       KeeperList, Extractor,
       State, globalenv(), OldBeta, NULL, 
       CMissingYIndices, AFD$LowCensorBound,  AFD$UpCensorBound,
       ImputeYChain,
       NULL, NULL
       );
       FF = TRUE ";
       try(eval(parse(text=MyText)));
       FailError = 0;
       
}
  

if (FALSE) {

OneProductDiallel = setRefClass("OneProductDiallel",
  fields = list(.X = "matrix", X=function(){ if (length(.X) == 0) {
    return(NULL);
   }
     return(.self$.X);}, 
  .Y = "vector",
  Y=function() {
    if (is.null(.Y) || length(.Y) == 0) { return(NULL); }
    return(.self$.Y);
  }
  
  ),
  methods=list(
   initialize = function(X = NULL, tauIndexList = NULL) {
     if (is.null(X)) {
       print("Cannot Allocate One Product Diallel!"); flush.console();
     }
   
   }
  )
);
}