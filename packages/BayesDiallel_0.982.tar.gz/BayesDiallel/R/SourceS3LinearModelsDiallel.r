##
## SourceS3LinearModelsDiallel.R
##
##
## Created by Alan Lenarcic on 9/3/10.
## Copyright 2010 UNC Genetics. All rights reserved.
##
##

###  Note there are 6 diagonals to deal with.

## ajLevel:
##  0 if no Aj terms, 1 if
## MotherModel: MotherModel = 0 if no mother effect to study,
##     0 if no Mother Effect
##     1 if j dependent
##     2 if so complicated as to make Thetaij discrete from Thetaji;

## Cross Epistatsis Models  
##   0 For No Cross Terms
##   1 For dominance BetaInbred:Av model
##   2 For all pooled
##   3 for pool Theta_ij sim N(0, taui^2i * tauj^2)
##   4 for pool Theta_ij sim N(0, taui^2 + tauj^2);
##   5 for All Pooled with Counter Cross terms
##   6 for pool Theta_ij sim N(0, taui^2i * tauj^2), counter cross
##   7 for pool Theta_ij sim N(0, taui^2i + tauj^2), counter cross
##   8 for All Pooled, ij and ji all separate
##   9 for separate ij and ji both N(0, taui^2i * tauj^2)
##   10 for separate ij and ji both N(0, taui^2i + tauj^2)

## Beta Inbred Level
## 0 No Beta Hybrid
## 1 BetaInbred ~ N(0, tauD);
## 2 BetaInbredj ~ N(0, tauDj);  tauDj ~ InvGamma
## 3 BetaInbredj ~ N(BetaInbred, tauDj), tauDj ~InvGamma, BetaInbred ~ tauD; 

## Sex Models
##  0 for No Sex
##  1 for Additive Only Sex
##  2 for Cross Sex aj
##  3 for Cross Sex aj Cross Sex mj
##  4 for Cross Sex aj Cross Sex dj
##  5 for Cross Sex aj Cross Sex mj, Cross taui tauj

## BetaInbred * Sex 
##  0 No BetaInbred * Sex
##  1 Else 
##BetaInbredTimesSex = 1;

## RandomEffects
## FixedEffects


###################################
## required libraries for
require(corpcor, warn.conflicts=FALSE, quietly=TRUE);  ## pseudoinverse here
require(R.oo, warn.conflicts=FALSE, quietly=TRUE);     ## Object Oriented Code
require(coda, warn.conflicts=FALSE, quietly=TRUE);
require(session, warn.conflicts=FALSE, quietly=TRUE);  ## Gain speed by compiling a function inline

###############################################################333
## defaultConstants:
defaultIItersSample = 1000; 
defaultNumRepetitions = 200;## For Simulation, default 
                            ## number of repetitions of each 
                            ## point in diallel
defaultSigma =1; names(defaultSigma) = "SigmaAll"

defaultnumj = 8;
defaultnumChains = 1;
defaultlengthChains = defaultIItersSample;

MaxInvert = 600;

####### Max dimension of Matrix to invert before throwing into pieces.
MaxInv = 200;


.DiallelNameSpace <- environment()

Copy <- function(Ob) {
  if (is.null(Ob)) { return(NULL);}
  if (is.vector(Ob)) {
    No = rep(0, length(Ob));  No[1:length(No)] = Ob[1:length(Ob)];
    names(No) = names(Ob);
    return(No);
  }
  if (is.matrix(Ob)) {
    No = matrix(as.vector(Ob), dim(Ob)[1], dim(Ob)[2]);
    rownames(No) = rownames(Ob); colnames(No) = colnames(Ob); return(No);
  }
  if (is.list(Ob)) {
    No = list();
    for (ii in 1:length(Ob)) {
      No[[ii]] = Copy(Ob);
    }
    return(No);
  }
  print(paste("Copy Failed to copy this Ob: ", names(Ob), sep=""));
  return(NULL);
}

.DiallelNameSpace <- environment()
.onLoad <- function(libname, pkgname) {
## load the module and store it in our namespace
  ##BAYESSPIKENAMESPACE <- environment()
  TryO = NULL;
  try( TryO <- bindingIsActive("Copy", .DiallelNameSpace), silent = TRUE);
  if (!is.null(TryO) && (TryO == TRUE || TryO == FALSE)) {
   unlockBinding( "Copy" , .DiallelNameSpace )
  }
  assign( "Copy", Copy, .DiallelNameSpace )
  lockBinding( "Copy", .DiallelNameSpace )

}


##############################################################################
##  DiallelModel is a Linear model
##
##     Y_t = Mu + .5 s_i + (BetaInbred) + (BetaInbred)_s + A_j + A_k+ .5 M_[j(i)] + Dominance_j&k
##               + V_jk (Symmetric) + .5 W_kj  (AntiSymmetric) + Error
##
##  Values:  Mu, s_i, BetaInbred, and BetaInbred_s are the "Fixed" Betas
##        These are not given a prior structure other than flat priors
##        They do not care about strain  (mother) or strain k (father)
##
##    A_j, M(other)_j, Dominance_j&k effects are added for strain effect
##
##    V_jk, W_jk are combination of strain effects, particular to pairing of j,k
##
###############################################################################
##  Apologies, to create better modularity and pass by reference I have 
##   written this in S3 Objects, using R.oo Object Oriented Code
##    
##  Unfortunately, this creates rather unreadable R code
##    Some quick R.oo defitions:
##       setConstructorS3() : declares a new Class object, including constructor
##           extend() :  function extends a Class from what it inherits 
##                 (default Object() is the overall parent class
##       setMethodS3() : declares a method that operates on the object
##                Note that "this" pointer points to object
##
##    Defining my objects:
##
##      RConstantsList : is a list of constants relating to 
##                       Random parameters in Diallel Model
##                       these are scale and shape parameters for inverse Gamma
##                       distriubution.  
##                       "df" refers to the shape parameter (as in df of chi-squared)
##                       "m" refers to scale parameter
##      FConstantsList : a list of "tau" variance constants relating to prior
##                        to fixed paramters (Mu, s_i, BetaInbred...)   
## 
##      FullDiallel : A parent object which has two types:
##       FullDiallelAnalyze : A parent object for analyzing a diallel
##       FullDiallelSimulate : A parent object for simulating a diallel
##
##      
##
##
##############################################################################
##   RConstantsList
##
##     This is a list that can represent shape or scale parameters relevant
##      to all of the possible hyperparameters to random effects of the Model
library(R.oo, verbose=FALSE, warn.conflicts=FALSE);
library(coda, verbose=FALSE, warn.conflicts=FALSE);
setConstructorS3("RConstantsList", function(StartF = .01, 
  StartRandomEffects = NULL,...) {
  if (is.null(StartF) || StartF < 0  || length(StartF) > 1) {
    StartF = .01;
  }
  extend(Object(), "RConstantsList", 
    aj = StartF, motherj = StartF, Genderaj = StartF,
    motherj = StartF, Gendermotherj = StartF,
    dominancej = StartF, Genderdominancej = StartF,
    cross = StartF, SymCrossjk = StartF,
    GenderSymCrossjk = StartF, SymCrossajk = StartF,
    GenderSymCrossajk = StartF, ASymCrossjkDkj = StartF,
    GenderASymCrossjkDkj = StartF,
    AllCrossajk = StartF, 
    GenderAllCrossajk=StartF,
    GenderSymCrossajk = StartF,
    AllCrossjk = StartF,
    GenderAllCrossjk   = StartF,
    RandomEffects = StartF,
    hybridj = StartF,
    Sigma = StartF,
    RandomEffects = StartRandomEffects, .StartF = StartF);
})



setMethodS3("Copy", "RConstantsList", function(this,...) {
  NR = RConstantsList(this$.StartF);
  NN = names(this);
  ## NR$aj = this$aj; NR;motherj = this$motherj;  NR$Gendmotherj = this$Gendmotherj;
  for (ii in 1:length(NN)) {
    NT = paste("NR$", NN[ii], " <- Copy(this$", NN[ii], ")", sep="");
    eval(parse(text=NT));    
  }
  return(NR);
});
##  Method to give the list hyper Parameters
setMethodS3("ListRList", "RConstantsList", function(this, ...) {
   returnVector  = c(this$RandomEffects, this$aj, this$Genderaj, this$motherj,
       this$Gendermotherj, this$dominancej, this$Genderdominancej,
       this$SymCrossjk, this$GenderSymCrossjk, this$ASymCrossjkDkj,
       this$GenderASymCrossjkDkj,
       this$AllCrossjk, this$GenderAllCrossjk);
   RNDNames = NULL;
   if (!is.null(this$RandomEffects) && length(this$RandomEffects)> 0) {
    RNDNames =  paste("RandomEffect:", 1:length(this$RandomEffects),
                           sep="");
   }
   names(returnVector) = c(RNDNames,
                            "aj", "Gender:aj", "motherj", "Gender:motherj",
                           "dominancej", "Gender:dominancej", "SymCrossjk",
                           "Gender:SymCrossjk", "ASymCrossjkDkj",
                           "Gender:ASymCrossjkDkj",
                           "AllCrossjk", "Gender:AllCrossjk" 
                           );
  return(returnVector); 
});



##############################################################################
##   FConstantsList
##
##     This is a list that represents variance parameters for the
##       fixed parameters in the Model
setConstructorS3("FConstantsList", function(StartF = 1000, StartFixedEffects = 1000,...) {
  extend(Object(), "FConstantsList", 
    tauMu = StartF, tauGender = StartF,  
    tauBetaInbred = StartF,
	  tauBetaInbredTimesSex = StartF,
    tauFixedEffects = StartFixedEffects,
	  dfTNoise = 0, .StartF = StartF, .StartFixedEffects = StartFixedEffects
	)
});

setMethodS3("Copy", "FConstantsList", function(this,...) {
 NR = FConstantsList(StartF = this$.StartF, StartFixedEffects = this$.StartFixedEffects);   
  ## NR$aj = this$aj; NR;motherj = this$motherj;  NR$Gendermotherj = this$Gendermotherj;
  NN = names(this);
  for (ii in 1:length(NN)) {
    NT = paste("NR$", NN[ii], " <- Copy(this$", NN[ii], ")", sep="");
    eval(parse(text=NT));    
  }
  return(NR);
});

setMethodS3("GettauFixedAll", "FConstantsList", function(this,...) {
  retty =  c(this$tauMu, this$tauGender, this$tauBetaInbred, this$tauBetaInbredTimesSex); 
  names(retty)[1:4] = c("Mu", "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av");
  if (length(this$tauFixedEffects) == 0) {
   this$tauFixedEffects = NULL;
  }
  if (!is.null(this$tauFixedEffects) && length(this$tauFixedEffects) > 0) {
     if (is.null(names(this$tauFixedEffects))) {
        names(this$tauFixedEffects) = paste("FixedEffect:", 
          1:length(this$tauFixedEffects), sep=""); flush.console();
     }
     retty = c(retty, this$tauFixedEffects)

  }
     return(retty);
});


###############################################################################
##    FullDiallel Storage Object
##
##      This Object should store R data from both a model that simulates
##         diallels ("FullDiallelSimulate"), as also  one that analyzes
##         diallels ("FullDiallelAnalyze")
##
##   On Output: the "CodaChains" of this object are most essential
##
##   The "X" matrix designed by function ConstructXJK()
##          [in "SourceS3LinearModelsHelperFunctions.R" file]
##    is specific to this model
##
##   .numj = number of strains
##   .ajModel, .MotherMode, .CrossModel, .SexModel, .BetaInbredLevel
##     and .BetaInbredTimesSex all encode levels of the model size
##
setConstructorS3("FullDiallel", function(numj=defaultnumj,Indf = NULL, Inm = NULL,
                                         IntauFixed=NULL, InSexVector=NULL,
                                         InListjk = NULL, Indftau = NULL,
                                         Inmtau = NULL,
                                         InFixedEffects = NULL,
                                         InRandomEffects = NULL, 
                                         InRandomEffectsGroups = NULL,
                                         nameFixedEffects = NULL,
                                         nameRandomEffects = NULL,
                                         InRandomPrintEffects=NULL,
                                         dfTNoise = NULL,
                                         Verbose = -1,
                                         YesSex = NULL, MyFullDiallelName = "Default Full Diallel",
                                         strain.map = NULL,
       ListAddFunctions = NULL, ListAddElements = NULL,
       LogTransformedFlag = FALSE, SqrtTransformedFlag = FALSE,
       phenotype.name = "", DoFirstCenter = FALSE, 
                                         ...) {
  if (!exists("nameFixedEffects")) { nameFixedEffects=NULL;}
  if (!exists("nameRandomEffects")) { nameRandomEffects=NULL; }
  if (is.character(InFixedEffects)  &&  (!is.null(InListjk) && NROW(InListjk) != 
    max(NROW(InFixedEffects), NCOL(InFixedEffects))  )) {
    nameFixedEffects = InFixedEffects;
  } else if (is.character(InFixedEffects) && (!is.null(InListjk) && NROW(InListjk) == 
    max(NROW(InFixedEffects), NCOL(InFixedEffects))  )) {
    if (!is.null(colnames(InFixedEffects))) { nameFixedEffects = colnames(InFixedEffects); }  
  }

  ##print(paste("FullDiallel Way Beginning length(InRandomEffects) == ", length(InRandomEffects), sep=""));
  ##  print(paste("FullDiallel Way Beginning dim(InListjk) == ", paste(dim(InListjk), collapse=", "), sep=""));      
  RandomEffects=NULL; RandomEffectsGroups=NULL;
  if (is.numeric(numj) && numj == defaultnumj && is.null(Indf) &&
    is.null(Inm) && is.null(IntauFixed) && is.null(InSexVector) &&
    (is.null(InListjk) || is.matrix(InListjk) && length(InListjk) == 4 &&
      sum(abs(InListjk)) == 0) && is.null(Indftau) && is.null(Inmtau) &&
    is.null(InFixedEffects) && is.null(InRandomEffects) &&
    is.null(nameFixedEffects) && is.null(nameRandomEffects)) {
    return(extend(Object(), "FullDiallel", .numj=numj)); 
  }    
                               
  if (is.null(InListjk)) {
    RandomEffects=NULL; RandomEffectsGroups=NULL;
  } else if (!is.null(InRandomEffectsGroups) && !is.null(InRandomEffects)) {
    if (sum(InRandomEffectsGroups) != NCOL(InRandomEffects)) {
      print("BayesDiallel: Error Sorry, if you input random effects as a matrix with random effects groups.")
      print(" it must be that the InRandomEffectsGroups encodes Group IDs along with the group names ");
      flush.console();
      tryCatch("Sorry, go back to reinstall.");
    }
    if (NROW(InRandomEffects) != NROW(InListjk)) {
      print(paste("BayesDiallel: Error, sorry, you gave Random rows ",
        NROW(InRandomEffects), " but NROW(InListjk) = ", NROW(InListjk), sep=""));
      flush.console();
      tryCatch("Sorry, go back to reinstall.");
    }
    RandomEffectsGroups = InRandomEffectsGroups;
    nRandomEffectsGroups = names(RandomEffectsGroups);
    RandomEffects = InRandomEffects;
  } else if (is.null(InRandomEffects)) {
    RandomEffectsGroups = NULL;
  } else if (all(is.na(unlist(InRandomEffects))) ||
             all(is.nan(unlist(InRandomEffects)))) {
    InRandomEffects = NULL;
  } else if (!is.null(InRandomEffects) && is.numeric(InRandomEffects) && 
    length(InRandomEffects[!is.na(as.vector(unlist(InRandomEffects)))]) > 0 &&
    length(InRandomEffects[!is.nan(as.vector(unlist(InRandomEffects)))]) > 0 && 
    min(InRandomEffects, na.rm = TRUE) == 0 && 
    max(InRandomEffects, na.rm = TRUE) == 1) {
    RandomEffects = InRandomEffects;  
    RandomEffectsGroups = 1:length(InRandomEffects[1,]);
    if (is.null(InSexVector)) {
      YesSex = FALSE;
    }
    if ((!exists("nameRandomEffects") || is.null(nameRandomEffects)) &&
      !is.null(colnames(InRandomEffects))) {
      nameRandomEffects = colnames(InRandomEffects);  
    } 
  } else if (!is.null(dim(InRandomEffects)) && 
    length(InRandomEffects[,1]) == length(InListjk[,1])) {
    MyLevels = sort(unique(as.factor(InRandomEffects[,1])))
    RandomEffects = matrix(0, length(InRandomEffects[,1]), length(MyLevels));
    for (jj in 1:length(MyLevels)) {
      RandomEffects[as.factor(InRandomEffects[,1]) == MyLevels[jj],jj] = 1;
    }
    RandomEffectsGroups = length(MyLevels);    
    if (!is.null(colnames(InRandomEffects))) {
      colnames(RandomEffects) = 
      paste("RandomEffect:1:", colnames(InRandomEffects)[1],":", 
        MyLevels, sep="");    
      names(RandomEffectsGroups) = c(
        paste("RandomEffect:1:", colnames(InRandomEffects)[1], sep=""));
    } else {
      colnames(RandomEffects) = paste("RandomEffect:1:", MyLevels, sep="");    
      names(RandomEffectsGroups) = c(
        paste("RandomEffect:1", sep=""));    
    }
    if (dim(InRandomEffects)[2] > 1) {
      for (kk in 2:length(InRandomEffects[1,])) {
        MyLevels = sort(unique(as.factor(InRandomEffects[,kk])));
        nOn = length(RandomEffects[1,]);
        namesRandomEffects = colnames(RandomEffects);
        RandomEffects = cbind(RandomEffects, 
          matrix(0, length(InRandomEffects[,1]), length(MyLevels)));
        for (jj in 1:length(MyLevels)) {
          RandomEffects[as.factor(InRandomEffects[,kk]) ==
            MyLevels[jj],jj+nOn] = 1;
        }
        nRandomEffectsGroups = names(RandomEffectsGroups)
        RandomEffectsGroups = c(RandomEffectsGroups,length(MyLevels) );
        if (!is.null(colnames(InRandomEffects))) {
          names(RandomEffectsGroups) = c(nRandomEffectsGroups, 
            paste("RandomEffect:",kk,":", 
            colnames(InRandomEffects)[kk], sep=""));
          colnames(RandomEffects) =c(namesRandomEffects,
            paste("RandomEffect:", kk,":", 
            colnames(InRandomEffects)[kk],":", MyLevels, sep=""));     
        } else {
          names(RandomEffectsGroups) = c(nRandomEffectsGroups, 
            paste("RandomEffect:",kk, sep=""));
          colnames(RandomEffects) =c(namesRandomEffects,
            paste("RandomEffect:", kk,":", MyLevels, sep=""));         
        }
      }
      if (is.null(InSexVector)) {
        YesSex = FALSE;
      }
    }
  } else if (length(InRandomEffects) == length(InListjk[,1]))  {
    ##print("Here is where we should, want to be"); flush.console();
    MyLevels = sort(unique(as.factor(InRandomEffects)))
    DMatrix = length(MyLevels);
    RandomEffects = matrix(0, length(InRandomEffects), DMatrix);
    ##print(paste("length(InRandomEffects) == ", length(InRandomEffects), sep=""));
    ##print(paste("dim(InListjk) == ", paste(dim(InListjk), collapse=", "), sep=""));
    ##print(paste("DMatrix = ", DMatrix, " and dim(RandomEffects) == ",
    ##  paste("c(", dim(RandomEffects),")", collapse=", "), " ", sep=""));
    ##flush.console();
    for (jj in 1:DMatrix) {
      RandomEffects[as.factor(InRandomEffects) == MyLevels[jj],jj] = 1;
    }
    if (length(names(InRandomEffects)) >= 1) {
      RandomEffectsGroups = length(MyLevels);
      names(RandomEffectsGroups) = 
        paste("RandomEffect:1:", names(InRandomEffects)[1], sep="");
    } else {
      RandomEffectsGroups = c(1);
      names(RandomEffectsGroups) = "RandomEffect";
    }
    colnames(RandomEffects) = paste("RandomEffect:1:", MyLevels, sep="");
    if (is.null(InSexVector)) {
      YesSex = FALSE;
    }
  } else {
    RandomEffects=NULL;
    RandomEffectsGroups = NULL;

  } 
  if (DimObject(InFixedEffects) == 1) {
    InFixedEffects = matrix(InFixedEffects, length(InFixedEffects),1);
    colnames(InFixedEffects) = "FixedEffect:1"
    if (is.null(InSexVector)) {
      YesSex = FALSE;
    }   
  } else if (DimObject(InFixedEffects) >= 1) {
    if (is.null(colnames(InFixedEffects))) {
      colnames(InFixedEffects) = paste("FixedEffect:", 
        1:DimObject(InFixedEffects),sep="");
    } else {
      colnames(InFixedEffects) = paste("FixedEffect:",
        1:DimObject(InFixedEffects),":",
        colnames(InFixedEffects), sep="");
    }
    if (is.null(InSexVector)) {
      YesSex = FALSE;
    }   
  }
  AllFixedVariables = .DefaultAllFixedVariables;
  if (!is.null(InFixedEffects)) { 
    AllFixedVariables = c(AllFixedVariables, colnames(InFixedEffects))
  }
  AllRandomVariables = .DefaultAllRandomVariables;
  if (!is.null(RandomEffectsGroups)) { 
    AllRandomVariables = c(names(RandomEffectsGroups), AllRandomVariables)
  }
  idAllVariables = 1:(length(AllFixedVariables) + length(AllRandomVariables));
  AllVariables = c(AllFixedVariables, AllRandomVariables);
  
  if (is.null(RandomEffects)) {
    if (!is.null(Inm)) { Inm$RandomEffects = NULL; }
    if (!is.null(Indf)) { Indf$RandomEffects = NULL; }
  }
  if(exists("InSexVector") && 
    !is.null(InSexVector) && length(InListjk[,1]) == length(InSexVector)) {
    YesSex = TRUE;
  }  
  if (!is.null(InListjk) && length(InListjk) > 2) {
    numj = length(unique(as.numeric(as.vector(InListjk))));
  }                                                                                                                               
  ##if (numj == defaultnumj) {
  ##  numj = length(unique(as.numeric(as.vector(InListjk))));
  ##} 
  if (numj <= 2 || round(numj) != numj ) {
    numj =  length(unique(as.numeric(as.vector(InListjk))));
    if (numj <= 2 ) {
      print("----------------------------------------------------------------");
      print(paste("--  Construct Diallel Error, we have that numj  = ", numj, 
        ", Sorry, this only works for 3+ strains", sep="")); flush.console();
      print(paste("-- Unique List for InListjk = (", 
        paste(unique(as.vector(InListjk)), collapse=", "), ")", sep=""));
      tryCatch("  FullDiallel Construction Error");
    }
  } 
  if (is.null(Verbose)) { Verbose = -1; }                          
  ACrossLocations = CrossLocations(numj);
  ListFunctions = c("Copy", "finalize");
  ListElements = c("numj", "df", "m", "tauFixed", "SexVector", "Listjk",
    "FixedEffects", "RandomEffects", "nameFixedEffects", "nameRandomEffects",
    "RandomEffectsGroups", "ACrossLocations", "dfTNoise", 
    ".AllFixedVariables", ".AllRandomVariables", ".idAllVariables", 
    ".AllVariables", "Verbose", "YesSex", ".BeingDestroyed",
    "nameFixedEffects", "nameRandomEffects",
    "MyFullDiallelName", "deleting", "strain.map", "phenotype.name", "phenotype");
  if (!is.null(ListAddElements)) {
    ListElements = c(ListAddElements, ListElements);
  }
  if (!is.null(ListAddFunctions)) {
    ListFunctions = c(ListAddFunctions, ListFunctions);
  }
  if (is.null(InListjk) &&  !is.null(nameFixedEffects) && 
    length(nameFixedEffects) != 1 && !is.null(InFixedEffects) && length(InFixedEffects) == NROW(InListjk)) {
    print(paste("Oops, nameFixedEffects = (", paste(nameFixedEffects, collapse=", "),
      ") is inappropriate given InFixedEffects.", sep=""));  flush.console();
    nameFixedEffects = NULL;  
  }
   extend(Object(), "FullDiallel",
     ListElements = ListElements,
     ListFunctions = ListFunctions, 
     .numj = numj,
     df = Indf,
     m = Inm,
     tauFixed = IntauFixed,
     SexVector= InSexVector,
     Listjk = InListjk, 
     FixedEffects = InFixedEffects, 
     RandomEffects = RandomEffects,
     nameFixedEffects = nameFixedEffects,
     nameRandomEffects = nameRandomEffects,
     RandomEffectsGroups = RandomEffectsGroups,
     ACrossLocations = ACrossLocations,
     dfTNoise = dfTNoise,
     .AllFixedVariables = AllFixedVariables,
     .AllRandomVariables = AllRandomVariables,
     .idAllVariables = idAllVariables,
     .AllVariables = AllVariables, 
     .MySummary = NULL,
     Verbose = Verbose,
     YesSex = YesSex, .BeingDestroyed = 0,  MyFullDiallelName =  MyFullDiallelName,
     deleting = 0, strain.map = strain.map,
     LogTransformedFlag = LogTransformedFlag, SqrtTransformedFlag = SqrtTransformedFlag,
     phenotype.name = phenotype.name, .phenotype = NULL, DoFirstCenter = DoFirstCenter)
} );

setMethodS3("finalize", "FullDiallel", function(this,...) {
  if (!is.null(this$deleting) && this$deleting[1] == 1) {
    return;
  }
  this$deleting = 1;
  print(paste("a FullDiallel: Named = [", this$MyFullDiallelName,
    "] is about to be removed from memory", sep="")); flush.console();
  MyText = "if (!is.null(this$AllDiallelObs)) {
  for (ii in length(this$AllDiallelObs):1) {
     if (!is.null(this$AllDiallelObs[[ii]])) {
     try(finalize(this$AllDiallelObs[[ii]]), silent = TRUE);
     try(this$AllDiallelObs[[ii]] <- NULL);
     }
  }
  this$AllDiallelObs = NULL;
  }";
  try(eval(parse(text=MyText)), silent=TRUE);
  MyText = "if (!is.null(this$ADiallelOb)) { this$ADiallelOb == NULL; }";
  try(eval(parse(text=MyText)), silent=TRUE);
  this$X = NULL;  this$Y = NULL;
  print(paste(" Finished removing info from ", this$MyFullDiallelName, sep=""));
  this$Verbose = -1;
  flush.console();
  flush.console();
});

setMethodS3("Copy", "FullDiallel", function(this,  MyFullDiallelName = NULL, ...) {
 if (is.null(MyFullDiallelName)) {
   MyFullDiallelName = this$MyFullDiallelName;
 }
 NR = FullDiallel(numj = this$.numj, Indf = Copy(this$df), Inm = Copy(this$m),
    IntauFixed = Copy(this$tauFixed), InSexVector = Copy(this$SexVector),
    InListjk = Copy(this$Listjk), Indftau = Copy(this$AllDiallelObs[[1]]$dftau),
    Inmtau = Copy(this$AllDiallelObs[[1]]$mtau),
    InFixedEffects = Copy(this$FixedEffects), InRandomEffects = Copy(this$RandomEffects),
    nameFixedEffects = NULL, nameRandomEffects=NULL, 
    InRandomPrintEffects = Copy(this$InRandomPrintEffects),
    dfTNoise = this$dfTNoise, Verbose = this$Verbose, YesSex = this$YesSex,
    MyFullDiallelName =  MyFullDiallelName);
  NN = names(this);
  ## NR$aj = this$aj; NR;motherj = this$motherj;  NR$Gendermotherj = this$Gendermotherj;
  for (ii in 1:length(NN)) {
    NT = paste("NR$", NN[ii], " <- Copy(this$", NN[ii], ")", sep="");
    eval(parse(text=NT));    
  }
  return(NR);
});




############################################################################
## DiallelOb
##
##   Each DiallelOb contains parameter Models
##    The chain is  stored in mcmc object CodaChain
setConstructorS3("DiallelOb", function(numj = defaultnumj, 
  ajModel = 1, MotherModel = 0, 
         CrossModel = 1, SexModel = 0, BetaInbredLevel = 0, 
         BetaInbredTimesSex = 0, dfTNoise = NULL, Extractor = NULL, 
         Wanted = NULL, 
         AFD=NULL, iOb=NULL, DoFirstCenter = FALSE, ...) {
   if (!exists("numj") || length(numj) <= 0) {
     throw("numj is a failure");
   }
   ListFunctions = c("SetupUnknownGender", "RunChainsCC", "SetupDpBeta",
     "LenBetaUse", "CreateGotList", "MakeDp", "AFDhglm", "RenameChains", "SetupWeights", 
    "ReplaceAndRerunUpdatedChains", "SetupChains", "RecalculateLikelihood", "SetupInbredNoise", 
    "RunChain", "CreateNetBetas", "PrintItersSamples", "CalcDIC", "RunEMcc", 
    "RunEM", "CalcDICC",  "summary.table", "PosteriorPredictionSummary",
    "StrawPlot","PlotStrawPlot", "TwoDiallelPlots",
    "Copy", "finalize");
   ListElements = c("XSubSetList", "GotList", "tauCrosses", "tauCrossName",
     "DpBeta", "tauFixed", "Beta", "tau", "Sigma", "MyWantDiag", "CodaChains",
     "T1", "T2", "NetBetas", "dfTNoise", "PostKeeper", "GXX", 
     "UnknownSexCoda", "ListUnknownSex", "ImputeSexChains", "ImputedSex",
     "ListUnknownGender", "ImputedGender", 
     "ImputedGenderChains", "cListUnknownGender", 
     "UnknownGenderCoda", "UnknownGenderX", "LPRSq", "Extractor", "Wanted",
     "State", "KeeperList", "LengthChainsMatrix", "namesChainsMatrix",
     "AFD", "iOb", "chains", "Model", "raw.chains", "cent.chains",
     "XTX", "X", "PosteriorPredictionsMeanSummary", "PosteriorPredictionsErrorSummary",
     "PosteriorPredictionsMeanChains", "PosteriorPredictionsErrorChains", 
     ".numj", ".ajModel", ".MotherModel", ".BetaInbredLevel",
     ".CrossModel", ".SexModel", ".BetaInbredTimesSex",
     "MyRaw.Summary", "MyCent.Summary", 
     "PosteriorHSqChains", "PosteriorHSqTable", "PosteriorHSqAll",
     "PosteriorHSqPoint",
     "PosteriorHSqChainsWithFixed", "PosteriorHSqTableWithFixed",
     "PosteriorHSqAllWithFixed",  "PosteriorHSqPointWithFixed",
     "PosteriorHSqChainsImproper", "PosteriorHSqTableImproper",
     "PosteriorHSqAllImproper",  "PosteriorHSqPointImproper",
     "PosteriorRSqChains", "PosteriorRSqTable",
     "PosteriorRSqAll", "PosteriorRSqAllImproper",
     "PosteriorRSqAllWithFixed", "PosteriorRSqPoint", 
     "PosteriorRSqPointImproper",
     "PosteriorRSqPointWithFixed",
     "PosteriorRSqChainsImproper", "PosteriorRSqTableImproper",
     "PosteriorRSqChainsWithFixed", "PosteriorRSqTableWithFixed",
     "PosteriorDSqChains", "PosteriorDSqTable",
     "PosteriorDSqAll", "PosteriorDSqAllImproper",
     "PosteriorDSqAllWithFixed", "PosteriorDSqPoint", 
     "PosteriorDSqPointImproper",
     "PosteriorDSqPointWithFixed",
     "PosteriorDSqChainsImproper", "PosteriorDSqTableImproper",
     "PosteriorDSqChainsWithFixed", "PosteriorDSqTableWithFixed",
     "PosteriorPSqChains", "PosteriorPSqTable",
     "PosteriorPSqAll", "PosteriorPSqAllImproper",
     "PosteriorPSqAllWithFixed", "PosteriorPSqPoint", 
     "PosteriorPSqPointImproper",
     "PosteriorPSqPointWithFixed",
     "PosteriorPSqChainsImproper", "PosteriorPSqTableImproper",
     "PosteriorPSqChainsWithFixed", "PosteriorPSqTableWithFixed",
     "TauChains", "SigmaChains", "FixedChains",
     "cent.DiallelChains", "cent.RandomEffectChains",
     "raw.DiallelChains", "raw.RandomEffectChains", "ImputedYChains", "DoFirstCenter",
     "Residuals", "HPDTable")
   extend(Object(), "DiallelOb", ListElements = ListElements,
     ListFunctions = ListFunctions,
     .numj = numj, .ajModel = ajModel,
     .MotherModel = MotherModel,
     .BetaInbredLevel = BetaInbredLevel,
     .CrossModel  = CrossModel,
     .SexModel = SexModel,
     .BetaInbredTimesSex = BetaInbredTimesSex,
     XSubSetList = NULL,
     GotList = NULL, 
     tauCrosses = NULL, 
     tauCrossName = NULL,
     DpBeta = NULL,
     tauFixed = NULL,
     Beta = NULL,
     tau = NULL,
     Sigma = NULL,
     MyWantDiag = NULL,
     CodaChains = NULL,
     T1 = NULL, T2 = NULL, NetBetas = NULL,
     dfTNoise = dfTNoise,
     PostKeeper = NULL, GXX = NULL, ListUnknownGender = NULL, .FakeGenderChain=NULL,
     cListUnknownGender = NULL, .UnknownGenderCoda = NULL, UnknownGenderX = 0,
     LPRSq = NULL, Extractor = Extractor, Wanted = Wanted,
     .State = NULL, KeeperList = NULL,
     LengthChainsMatrix = -1, namesChainsMatrix = NULL,
     .ListUnknownSex=NULL, .cListUnknownSex=NULL, .UnknownSexCoda=NULL,
     .AFD = AFD, .iOb = iOb, .chains = NULL, .Model = NULL,
     .ImputedSex=NULL, .ImputeSexChains=NULL,
     .cent.chains = NULL, .centered.chains =NULL,.raw.chains=NULL,
     .Remapped.cent.chains=NULL, .Remapped.raw.chains=NULL, XtX = NULL, .X = NULL,
     .PosteriorPredictionsMeanSummary =  NULL, .PosteriorPredictionsSummary = NULL,
     .PosteriorPredictionsMeanChains =  NULL, .PosteriorPredictionsChains = NULL,
     .MyRaw.Summary = NULL, .MyCent.Summary = NULL,
     .PosteriorHSqChains = NULL, .PosteriorHSqTable = NULL, .PosteriorHSqAll = NULL,
     .PosteriorHSqPoint = NULL,
     .PosteriorHSqChainsWithFixed = NULL, .PosteriorHSqTableWithFixed = NULL,
     .PosteriorHSqAllWithFixed = NULL,  .PosteriorHSqPointWithFixed = NULL,
     .PosteriorHSqChainsImproper=NULL, .PosteriorHSqTableImproper=NULL,
     .PosteriorHSqAllImproper=NULL,  .PosteriorHSqPointImproper=NULL,
     .PosteriorRSqChains = NULL, .PosteriorRSqTable = NULL,
     .PosteriorRSqAll = NULL, .PosteriorRSqAllImproper = NULL,
     .PosteriorRSqAllWithFixed=NULL, .PosteriorRSqPoint=NULL, 
     .PosteriorRSqPointImproper=NULL,
     .PosteriorRSqPointWithFixed=NULL,
     .PosteriorRSqChainsImproper=NULL, .PosteriorRSqTableImproper=NULL,
     .PosteriorRSqChainsWithFixed = NULL, .PosteriorRSqTableWithFixed = NULL,
     .PosteriorDSqChains = NULL, .PosteriorDSqTable = NULL,
     .PosteriorDSqSubTable = NULL, .PosteriorDSqSumTable = NULL,
     .PosteriorDSqAll = NULL, .PosteriorDSqAllImproper = NULL,
     .PosteriorDSqAllWithFixed=NULL, .PosteriorDSqPoint=NULL, 
     .PosteriorDSqPointImproper=NULL,
     .PosteriorDSqPointWithFixed=NULL,
     .PosteriorDSqChainsImproper=NULL, .PosteriorDSqTableImproper=NULL,
     .PosteriorDSqChainsWithFixed = NULL, .PosteriorDSqTableWithFixed = NULL,
     .PosteriorPSqChains = NULL, .PosteriorPSqTable = NULL,
     .PosteriorPSqSubTable = NULL, .PosteriorPSqSumTable = NULL,
     .PosteriorPSqAll = NULL, .PosteriorPSqAllImproper = NULL,
     .PosteriorPSqAllWithFixed=NULL, .PosteriorPSqPoint=NULL, 
     .PosteriorPSqPointImproper=NULL,
     .PosteriorPSqPointWithFixed=NULL,
     .PosteriorPSqChainsImproper=NULL, .PosteriorPSqTableImproper=NULL,
     .PosteriorPSqChainsWithFixed = NULL, .PosteriorPSqTableWithFixed = NULL,
     .PosteriorRSqHPDTable = NULL,  .PosteriorRSqHPDSubTable = NULL,
     .PosteriorDSqHPDTable = NULL,  .PosteriorDSqHPDSubTable = NULL,
     .PosteriorHSqHPDTable = NULL,  .PosteriorHSqHPDSubTable = NULL,
     .PosteriorPSqHPDTable = NULL,  .PosteriorPSqHPDSubTable = NULL,         
     .TauChains = NULL, .SigmaChains = NULL, .FixedChains=NULL,
     .cent.DiallelChains=NULL, .cent.RandomEffectChains = NULL,
     .raw.DiallelChains=NULL, .raw.RandomEffectChains = NULL, ImputedYChains=NULL,
     MyQ = NULL, MyInvQ = NULL, MyInvSqQ = NULL, MyWantDiag = NULL, 
     MyTauFixed = NULL, DoFirstCenter = DoFirstCenter,
     PriorProbFixed=NULL, PriorProbRandom=NULL, .Residuals = NULL,
     .HPDTable=NULL
         
   );
} );

setMethodS3("getMyRaw.Summary", "DiallelOb", function(this,...) {
  if (is.null(this$.MyRaw.Summary) || !is.list(this$.MyRaw.Summary)) {
    this$.MyRaw.Summary = summary(this$raw.chains);
  }
  if (all(names(this$.MyRaw.Summary) == c("Length", "Class",  "Mode" )) ) {
    this$.MyRaw.Summary = summary(this$raw.chains);
  }
  return(this$.MyRaw.Summary);
} );
setMethodS3("getMyCent.Summary", "DiallelOb", function(this,...) {
  if (is.null(this$.MyCent.Summary) || !is.list(this$.MyCent.Summary) ) {
    this$.MyCent.Summary = summary(this$cent.chains);
  }
  if (all(names(this$.MyCent.Summary) == c("Length", "Class",  "Mode" )) ) {
    this$.MyCent.Summary = summary(this$cent.chains);
  }
  return(this$.MyCent.Summary);
} );

setMethodS3("getBS", "FullDiallelAnalyze", function(this,...) {
  return(this$.BS); });
##setMethodS3("getBSAFD", "FullDiallelAnalyze", function(this,...) {
##  return(this$.BSAFD); });
    
setMethodS3("getListUnknownSex", "FullDiallelAnalyze", function(this,...) {
  return(this$ListUnknownGender); });
setMethodS3("getListUnknownSex", "DiallelOb", function(this,...) {
  return(this$ListUnknownGender); });
setMethodS3("getCListUnknownSex", "DiallelOb", function(this,...) {
  return(this$cListUnknownGender); });
setMethodS3("getUnknownSexCoda", "DiallelOb", function(this,...) {
  return(this$ImputeGenderChains); });  

setMethodS3("getImputeSexChains", "DiallelOb", function(this,...) {
  return(this$ImputeGenderChains); }); 
setMethodS3("getImputedSex", "DiallelOb", function(this,...) {
  return(this$ImputedGender); });     
  
setMethodS3("getCentered.chains","DiallelOb", function(this,...) {
  return(this$getCent.chains());
});
setMethodS3("getState", "DiallelOb", function(this, ...) {
 if (is.null(this$Beta)) {
   print("Sorry: get State does not work without Beta"); flush.console();
 }
 if (is.null(this$Sigma)) {
   print("Sorry: Sigma is NULL"); flush.console();
 }
 if (!is.null(this$VecOWeights) && length(this$VecOWeights) > 0) {
   AB <- c(this$Beta, this$tau, this$Sigma, this$VecOWeights);
  namesAB = c(names(this$Beta), paste("tau:", names(this$tau), sep=""),
   "Sigma:1", paste("Weight:", 1:length(this$VecOWeights), sep=""));
  if (length(namesAB) != length(AB)) {
    print("Uh Oh: length of namesAB does not equal length AB"); flush.console();
    print(paste("Length Beta = ", length(this$Beta), ", and tau = ",
      length(this$tau), " amd length Sigma = ", length(this$Sigma),
      "  and length VecOWeights = ", length(this$VecOWeights), sep=""));
    flush.console();
  }
  try(names(AB) <- namesAB);
   return(AB);
 }
 AB <- c(this$Beta, this$tau, this$Sigma);
  namesAB = c(names(this$Beta), paste("tau:", names(this$tau), sep=""),
   "Sigma:1");
  if (length(namesAB) != length(AB)) {
    print("Uh Oh: length of namesAB does not equal length AB"); flush.console();
    print(paste("Length Beta = ", length(this$Beta), ", and tau = ",
      length(this$tau), " amd length Sigma = ", length(this$Sigma),
      sep=""));
    flush.console();
  }
  try(names(AB) <- namesAB);
   return(AB); 
});

setMethodS3("SetupUnknownSex", "DiallelOb", function(this, AFD=NULL, NoGenderUnknownChains,
  Verbose=NULL,...) {
  this$SetupUnknownGender(AFD=AFD, NoGenderUnknownChains=NoGenderUnknownChains,
    Verbose=Verbose,...);
})
############################################################################
##  Setup Diallel Object to deal with NA values for Gender
##
##   during computation, computer will used informed update imputation of Gender
##   of mouse to make decision.
##
setMethodS3("SetupUnknownGender", "DiallelOb", function(this, AFD=NULL,
  NoGenderUnknownChains = NULL, Verbose = NULL, ...) {
  if (is.null(AFD)) {
    AFD = this$.AFD;
  }
  if (is.null(AFD)) {
    tryCatch("DiallelOb:SetupUnknownGender can't work without AFD supplied!");
  }
  if (is.null(Verbose) || (!is.numeric(Verbose) && !is.logical(Verbose))) {
    try(Verbose <- AFD$Verbose);
    if (is.null(Verbose) || (!is.numeric(Verbose) && !is.logical(Verbose))) {
      print("SetupUnknownGender:DiallelOb, you should set verbose on something!");
      flush.console(); Verbose = 3;
    }
  }
  if (is.logical(Verbose) && Verbose == FALSE) {
    Verbose = -1;
  } else if (is.logical(Verbose) && Verbose == TRUE) {
    Verbose = 2;
  } else if (!is.numeric(Verbose)) {
     print("SetupUnknownGender:DiallelOb, verbose is not a numeric or logical!");
     Verbose = 2;
     try(AFD$Verbose <- Verbose);
     flush.console();
  }
  if (Verbose > 0) {
    print(paste("SetupUnknownGender: DiallelOb, Start, iOb = ", this$.iOn, sep="")); flush.console();
  }
  if (this$.SexModel <= 0) {
    return(1);
  }

  if (is.null(NoGenderUnknownChains)) {
    NoGenderUnknownChains = AFD$NoGenderUnknownChains;
  }
  if (is.null(this$CodaChains)) {
    print("SetupUnknownGender: setup CodaChainsFirst "); flush.console();
    tryCatch("SetupUnknownGender: DialllelOb, CodaChains Not Set");
  } 
  nChains = length(this$CodaChains);
  LengthChains = length(this$CodaChains[[1]]);

  if (is.null(AFD)) {
    print("SetupUnknownGender: setup AFD is NULL can't do "); flush.console();
    tryCatch("SetupUnknownGender: No AFD");
  }
  ##if (is.null(AFD$GGX)) {
  ##  print("SetupUnknownGender: setup AFD$GGX is NULL can't do "); flush.console();
  ##  tryCatch("SetupUnknownGender: No AFD$GGX");
  ##}
  if (is.null(AFD$ListUnknownGender)) {
    print("SetupUnknownGender: setup AFD$ListUnknownGender is NULL can't do "); flush.console();
    tryCatch("SetupUnknownGender: No AFD$ListUnknownGender");
  }
  this$ListUnknownGender = AFD$ListUnknownGender;
  this$cListUnknownGender = this$ListUnknownGender -1;
  this$UnknownGenderX = 0 * this$ListUnknownGender;
  UnknownGenderCoda = NULL;
  if (length(this$CodaChains) >= 1) {
  for (ii in 1:length(this$CodaChains)) {
    if (Verbose > 1) {
      print(paste("SetupUnknwonGender, DiallelOb[", 
        this$.iOb, "] well, making CodaChain[", ii, "]", sep="")); 
        flush.console();
    }
    kTU = matrix(0, length(this$CodaChains[[ii]][,1]), length(this$ListUnknownGender));
    colnames(kTU) = paste("j:", this$ListUnknownGender, sep="");
    kTU = as.mcmc(kTU);
    UnknownGenderCoda[[ii]] = kTU;
  }
  }
  UnknownGenderCoda = as.mcmc(UnknownGenderCoda);
  if (Verbose > 1) {
      print(paste("SetupUnknownGender, DiallelOb[", 
        this$.iOb, "] fill Unknown Gender Coda. ", sep="")); 
        flush.console();
  }
  this$UnknownGenderCoda = UnknownGenderCoda;
  

  if (max(abs(AFD$X[,colnames(AFD$X) == "Gender:Av"]+.5-AFD$SexVector), na.rm=TRUE) > .1) {
    print("Issue, AFD$X[Gender] and AFD$SexVector Differ at:");
    KTT = (1:length(AFD$X[,1]))[ abs(2*AFD$X[,colnames(AFD$X) == "Gender:Av"] -1-AFD$SexVector) > .1]
    print(cbind(KTT, AFD$X[KTT, colnames(AFD$X) == "Gender:Av"], SexVector[KTT]));
    tryCatch("Fix it?");
  }
  if (min(AFD$X[is.na(AFD$SexVector),colnames(AFD$X)=="Gender:Av"]) < .45) {
    print("Issue, AFD$X[Gender] for the NA terms is not default 1!");
    KTT = (1:length(AFD$X[,1]))[ is.na(AFD$SexVector) &
      AFD$X[is.na(AFD$SexVector),colnames(AFD$X)=="Gender:Av"] < .45 ]
    print(cbind(KTT, AFD$X[KTT, colnames(AFD$X) == "Gender:Av"], SexVector[KTT]));
    tryCatch("Fix it?");    
  }
  GXX = AFD$X[this$ListUnknownGender,this$XSubSetList];
  iX = (1:length(this$XSubSetList));
  ngiX = iX[substr(names(this$XSubSetList),1,nchar("Gender")) != "Gender" &
    substr(names(this$XSubSetList),1,nchar("BetaInbred:Gender:Av")) 
    != "BetaInbred:Gender:Av"];
  GXX[,ngiX] = 0.0;
  AT2 = (1:NCOL(AFD$X))[colnames(AFD$X) == "Gender:Av"]
  GXX = GXX * (2*AFD$X[this$ListUnknownGender, AT2]);
  this$GXX = GXX;

  if (Verbose > 1) {
      print(paste("SetupUnknownGender, DiallelOb[", 
        this$.iOb, "] Setup ProbUnknownGender ", sep="")); 
        flush.console();
  }
    
  this$ProbUnknownGender = AFD$ProbUnknownGender;
  if (length(this$ProbUnknownGender) >= 1 &&
    length(this$ListUnknownGender) !=  length(this$ProbUnknownGender)) {
    this$ProbUnknownGender = rep(this$ProbUnknownGender[1],
      length(this$ListUnknownGender));  
  } else if (length(this$ProbUnknownGender) <= 0) {
    this$ProbUnknownGender = rep(.5, length(this$ListUnknownGender));
  }
  
  if (Verbose > 1) {
    print("SetupUnknownGender: DiallelOb, about to Impute gender and create chains");
    flush.console();
  }
  
  if (Verbose > 1) {
      print(paste("SetupUnknownGender, DiallelOb[", 
        this$.iOb, "] , setting up Imputed Gender", sep="")); 
        flush.console();
  }
  
  this$ImputedGender = round(AFD$X[this$ListUnknownGender,colnames(AFD$X) == "Gender:Av"]+.5);
  ##this$ImputedGender = rbinom(length(this$ListUnknownGender), 
  ##  1, this$ProbUnknownGender);
  if (!(is.logical(NoGenderUnknownChains) && NoGenderUnknownChains == TRUE)) {
    if (Verbose > 1) {
      print(paste("SetupUnknownGender, DiallelOb[", 
        this$.iOb, "] Start setting ImputeGenderChains ", sep="")); 
        flush.console();
   }
    this$ImputeGenderChains = list();
    for (ii in 1:length(this$CodaChains)) {
      AChain = matrix(0,NROW(this$CodaChains[[ii]]),
        length(this$ListUnknownGender));
      colnames(AChain) = paste("UnknownGender:", this$ListUnknownGender, sep="");
      this$ImputeGenderChains[[ii]] = as.mcmc(AChain);
      if (Verbose > 1) {
        print(paste("SetupUnknownGender, DiallelOb[", 
          this$.iOb, "], On Setup ImputeGenderChains = ", ii, 
          " dimension is (", paste(dim(AChain), collapse =", "),
          ")", sep="")); 
          flush.console();
      }
    }
    if (Verbose > 1) {
      print(paste("SetupUnknownGender, DiallelOb[", 
        this$.iOb, "], now fill ImputeGenderChains  by creating CodaChain", sep="")); 
        flush.console();
    }
    ATry = FALSE;
    AText = "this$ImputeGenderChains <- as.mcmc.list(this$ImputeGenderChains);
      ATry = TRUE;"
    try(eval(parse(text=AText)), silent=TRUE);
    if (!is.null(ATry) || ATry == FALSE) {
      try(this$ImputeGenderChains <- as.mcmc(this$ImputeGenderChains),
        silent=TRUE);    
    }
  }
  if (Verbose > 1) {
    print("SetupUnknownGender: DiallelOb, All Finished");
    flush.console();
  }
});

setMethodS3("getModel", "DiallelOb", function(this,...) {
	RT = c(this$.ajModel, this$.MotherModel, this$.CrossModel, 
	    this$.SexModel,
	  this$.BetaInbredLevel, this$.BetaInbredTimesSex);
  names(RT) = c("ajModel", "MotherModel", "CrossModel",
                "SexModel", "BetaInbredLevel", "BetaInbredTimesSex");
  return(RT);
} );
setMethodS3("GetModel", "DiallelOb", function(this,...) {
  return(getModel(this));
});


Diff2AFD <- function(AFD1 = NULL, AFD2 = NULL, ...) {
  if (!exists("AFD1") || is.null(AFD1) ||
    !exists("AFD2") || is.null(AFD2)) {
    print("Diff2AFD: no dice, give me FD!"); flush.console();
    return(-1);  
  }
  if ((is.logical(AFD1$Verbose) && AFD1$Verbose==TRUE) ||
    (is.numeric(AFD1$Verbose) && AFD1$Verbose > 0)) {
    print("Diff2AFD: Starting. "); flush.console();  
  }
  AFDD = AFD1$DiffAFD(AFD2);
  if ((is.logical(AFD1$Verbose) && AFD1$Verbose==TRUE) ||
    (is.numeric(AFD1$Verbose) && AFD1$Verbose > 0)) {
    print("Diff2AFD: GotAFDD, returning. "); flush.console();  
  }
  return(AFDD);
}

DiffADO <- function(AFD1, AFD2, ii = 1, ...) {

FixedEffects = c("Mu", "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av");
RandomEffects = c("aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej", "Gender:dominancej",
    "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk" );
  if (length(AFD1$AllDiallelObs) < ii) {
    print(paste("Error: DiffADO, AFD1 has length ", length(AFD1$AllDiallelObs),
      " < ", ii, sep=""));
    flush.console(); return(NULL);
  }
  if (length(AFD2$AllDiallelObs) < ii) {
    print(paste("Error: DiffADO, AFD1 has length ", length(AFD1$AllDiallelObs),
      " < ", ii, sep=""));
    flush.console(); return(NULL);
  }
  ChainNames1 <- colnames(AFD1$AllDiallelObs[[ii]]$CodaChains[[1]]);
  ChainNames2 <- colnames(AFD2$AllDiallelObs[[ii]]$CodaChains[[2]]);
  if (is.null(ChainNames1) || is.null(ChainNames2)) {
    print("Error: ChainNames1, ChainNames2, no names!"); flush.console();
    return(NULL);
  }
  NewFixedEffects <- c();
  if (any(substr(ChainNames1,1,nchar("Fixed")) == "Fixed")) {
    NewFixedEffects <-  ChainNames1[substr(ChainNames1,1,nchar("Fixed"))
       == "Fixed"];
    NewFixedEffects <- NewFixedEffects[!is.na(NewFixedEffects)];
  }
  if (any(substr(ChainNames2,1,nchar("Fixed")) == "Fixed")) {
    NewFixedEffects <-  c(NewFixedEffects, 
      ChainNames2[substr(ChainNames2,1,nchar("Fixed")) 
      == "Fixed"]);
    NewFixedEffects <- NewFixedEffects[!is.na(NewFixedEffects)];
  }
  if (length(NewFixedEffects) > 0) {
    FixedEffects <- c(FixedEffects, NewFixedEffects);
  }
  SigLoc1 <- (1:length(ChainNames1))[ChainNames1 %in%
    c("Sigma", "Sigma:1", "sigma", "sigma:1", "sigma[1]", "Sigma[1]",
    "SIGMA", "SIGMA:1")];
  SigLoc2 <- (1:length(ChainNames2))[ChainNames2 %in%
    c("Sigma", "Sigma:1", "sigma", "sigma:1", "sigma[1]", "Sigma[1]",
    "SIGMA", "SIGMA:1")];
  tauLoc1 <-  (1:length(ChainNames1))[
    substr(ChainNames1,1, nchar("tau")) == "tau"];
  tauLoc2 <-  (1:length(ChainNames2))[
    substr(ChainNames2,1, nchar("tau")) == "tau"];
    
  AFD1Ob <- AFD1$AllDiallelObs[[ii]];
  NewADO <- DiallelOb(numj = AFD1$.numj, ajModel = AFD1Ob$.ajModel, 
    MotherModel=AFD1Ob$.MotherModel, 
    CrossModel=AFD1Ob$.CrossModel, SexModel=AFD1Ob$.SexModel, 
    BetaInbredLevel=AFD1Ob$.BetaInbredLevel, 
    BetaInbredTimesSex=AFD1Ob$.BetaInbredTimesSex, 
    dfTNoise=AFD1Ob$dfTNoise, iOb = ii, DoFirstCenter = AFD1$DoFirstCenter);
  NN = names(AFD1$AllDiallelObs[[ii]]);


  for (tt in 1:length(NN)) {
    if (NN[tt] == "CodaChains") {
    } else if (NN[tt] %in% c("Beta", "tau", "Sigma")) {
    } else if (NN[tt] == "ImputedYChains") {
    } else if (NN[tt] == "ImputeGenderChains") {
    } else if (NN[tt] == "UnknownGenderCoda") {
    } else if (!(NN[tt] %in% c(".AFD", ".iOb"))) {
      NT = paste("NewADO$", NN[tt], 
        " <- Copy(AFD1$AllDiallelObs[[ii]]$", NN[tt], ")", sep="");
      try(eval(parse(text=NT)), silent=TRUE);
    }
  }
  try(NewADO$Beta <- rep(0, length(AFD1$AllDiallelObs[[ii]]$Beta)), silent=TRUE);
  try(names(NewADO$Beta) <- names(AFD1$AllDiallelObs[[ii]]$Beta), silent=TRUE);
  try(NewADO$tau <- rep(0, length(AFD1$AllDiallelObs[[ii]]$tau)), silent=TRUE);
  try(names(NewADO$tau) <- names(AFD1$AllDiallelObs[[ii]]$tau), silent=TRUE);  
  try(NewADO$Sigma <- 1.0, silent=TRUE);
  try(names(NewADO$Sigma) <- "Sigma", silent=TRUE);  
  
  NewADO$CodaChains <- NULL;
  if (!is.null(AFD1$DoFirstCenter) && 
    ( (is.logical(AFD1$DoFirstCenter) &&
       AFD1$DoFirstCenter == TRUE) ||
      (is.numeric(AFD1$DoFirstCenter) && AFD1$DoFirstCenter >= .5))) {
   NewADO$DoFirstCenter = TRUE;
   NewC <- list();
   ChainNames2[ChainNames2 %in% c("Sigma", "Sigma:1", "sigma", "sigma:1")] <- "Sigma";
   ChainNames1[ChainNames1 %in% c("Sigma", "Sigma:1", "sigma", "sigma:1")] <- "Sigma";
   MCChainNames2 <- match(ChainNames2, ChainNames1);
   KeepChainNames2 <- (1:length(ChainNames2))[!is.na(MCChainNames2)];
   MMCChainNames2 <- MCChainNames2[!is.na(MCChainNames2)];
   Iters1 <- 1:NROW(AFD1$AllDiallelObs[[ii]]$CodaChains[[1]]);
   Iters2 <- 1:NROW(AFD2$AllDiallelObs[[ii]]$CodaChains[[1]]);
   MIters <- match(Iters2, Iters1);
   MMIters <- MIters[!is.na(MIters)];
   M2Iters <-  Iters2[!is.na(MIters)];
   for (tt in 1:length(AFD1$AllDiallelObs[[ii]]$CodaChains)) {
     NewC[[tt]] <- matrix(0, 
       length(MMIters),
       length(ChainNames1)
       );
     NewC[[tt]][, MMCChainNames2] <- AFD1$AllDiallelObs[[ii]]$CodaChains[[tt]][MMIters,MMCChainNames2] -
       AFD2$AllDiallelObs[[ii]]$CodaChains[[tt]][M2Iters,KeepChainNames2];
     colnames(NewC[[tt]]) <- ChainNames1;
     try(NewC[[tt]] <- as.mcmc(NewC[[tt]]));
   }
   Logic2 <- substr(ChainNames2, 1, nchar("tau")) == "tau" |
     substr(ChainNames2, 1, nchar("Sigma")) %in% c("Sigma", "sigma", "Sigma:1", "sigma:1");
   for (tt in 1:length(AFD1$AllDiallelObs[[ii]]$CodaChains)) {
     NewC[[tt]][, MMCChainNames2[Logic2]] <- AFD1$AllDiallelObs[[ii]]$CodaChains[[tt]][MMIters,MMCChainNames2[Logic2]] +
       AFD2$AllDiallelObs[[ii]]$CodaChains[[tt]][M2Iters,KeepChainNames2[Logic2]];
     try(NewC[[tt]] <- as.mcmc(NewC[[tt]]));
   }
   try(NewC <- as.mcmc.list(NewC));
   try(NewADO$CodaChains <- NewC)
  } else {
    NewC <- list();
   Iters1 <- 1:NROW(AFD1$AllDiallelObs[[ii]]$CodaChains[[1]]);
   Iters2 <- 1:NROW(AFD2$AllDiallelObs[[ii]]$CodaChains[[1]]);
   MIters <- match(Iters2, Iters1);
   MMIters <- MIters[!is.na(MIters)];
   M2Iters <-  Iters2[!is.na(MIters)];    
    for (tt in 1:length(AFD1$AllDiallelObs[[ii]]$cent.chains)) {
      NewC[[tt]] <- matrix(0, length(MMIters),
        length(ChainNames1));
      colnames(NewC[[tt]]) <- ChainNames1;
    }
  ##try(NewC <- as.mcmc.list(NewC));
  ##NewC;
  FixedNN <- c("aj", "Gender:aj", "dominancej", "Gender:dominancej")
  for (jj in 1:length(FixedEffects)) {
    A1Loc <- (1:length(ChainNames1))[ChainNames1 %in%
      FixedEffects[jj]];
    A2Loc <- (1:length(ChainNames2))[ChainNames2 %in%
      FixedEffects[jj]];
    if (jj <= length(FixedNN)) {
    A1LocKill <- (1:length(ChainNames1))[substr(ChainNames1,1, nchar(FixedNN[jj])) == 
      FixedNN[jj]];
    A2LocKill <- (1:length(ChainNames1))[substr(ChainNames2,1, nchar(FixedNN[jj])) == 
      FixedNN[jj]];
    A1LocKill <- A1LocKill[!is.na(A1LocKill)];
    A2LocKill <- A2LocKill[!is.na(A2LocKill)];
    } else {
      A1LocKill <- NULL; A2LocKill <- NULL;
    }
    if (length(A1Loc) == 1 && length(A2Loc) == 1  && length(A1LocKill) >= 1 && length(A2LocKill) >= 1) {
      for (tt in 1:length(NewC)) {
        NewC[[tt]][,A1Loc] <- (
          AFD1$AllDiallelObs[[ii]]$CodaChains[[tt]][MMIters,A1Loc] +
          rowMeans(AFD1$AllDiallelObs[[ii]]$CodaChains[[tt]][MMIters,A1LocKill])/2-
          ( AFD2$AllDiallelObs[[ii]]$CodaChains[[tt]][M2Iters,A2Loc] + 
            rowMeans(AFD2$AllDiallelObs[[ii]]$CodaChains[[tt]][M2Iters,A2LocKill])/2
          ));
      }
    } else if (length(A1Loc) == 1 && length(A2Loc) == 1  && length(A1LocKill) >= 1 ) {
      for (tt in 1:length(NewC)) {
        NewC[[tt]][,A1Loc] <- (
          AFD1$AllDiallelObs[[ii]]$CodaChains[[tt]][MMIters,A1Loc] +
          rowMeans(AFD1$AllDiallelObs[[ii]]$CodaChains[[tt]][MMIters,A1LocKill])-
          ( AFD2$AllDiallelObs[[ii]]$CodaChains[[tt]][M2Iters,A2Loc]) 
          );
      }   
    } else if (length(A1Loc) == 1 && length(A2Loc) == 1  && length(A2LocKill) >= 1) {
      for (tt in 1:length(NewC)) {
        NewC[[tt]][,A1Loc] <- (
          AFD1$AllDiallelObs[[ii]]$CodaChains[[tt]][MMIters,A1Loc] -
          ( AFD2$AllDiallelObs[[ii]]$CodaChains[[tt]][M2Iters,A2Loc] + 
            rowMeans(AFD2$AllDiallelObs[[ii]]$CodaChains[[tt]][M2Iters,A2LocKill])/2)
          );
      }    
    } else if (length(A1Loc) == 1 && length(A2Loc) == 1) {
      for (tt in 1:length(NewC)) {
        NewC[[tt]][,A1Loc] <- (
          AFD1$AllDiallelObs[[ii]]$CodaChains[[tt]][MMIters,A1Loc] -
          ( AFD2$AllDiallelObs[[ii]]$CodaChains[[tt]][M2Iters,A2Loc])
          );
       }  
    }
  }
  tauNames1 <- ChainNames1[tauLoc1]; tauNames2 <- ChainNames2[tauLoc2];
  mtauN1 <- match(tauNames1, tauNames2);
  tauKeep <- tauNames1[!is.na(mtauN1)];
  for (jj in 1:length(tauKeep)) {
    for (tt in 1:length(NewC)) {
      NewC[[tt]][,SigLoc1] <- 
       (AFD1$AllDiallelObs[[ii]]$CodaChains[[tt]][MMIters,SigLoc1]+
        AFD2$AllDiallelObs[[ii]]$CodaChains[[tt]][M2Iters,SigLoc2]);
    }
  }
  for (jj in 1:length(tauKeep)) {
    tauSt <- substr(tauKeep[jj], nchar("tau:")+1, nchar(tauKeep[jj]));
    KC1 <- (1:length(ChainNames1))[substr(ChainNames1, 1, nchar(tauSt)) == tauSt];
    KC2 <- (1:length(ChainNames2))[substr(ChainNames2, 1, nchar(tauSt)) == tauSt];  
    tC1 <- (1:length(ChainNames1))[ChainNames1 == tauKeep[jj]];
    tC2 <- (1:length(ChainNames2))[ChainNames2 == tauKeep[jj]];
    if (length(KC1) > 0  && length(KC2) == length(KC1)) {
      for (tt in 1:length(NewC)) {
        NewC[[tt]][,KC1] <- 
          AFD1$AllDiallelObs[[ii]]$cent.chains[[tt]][MMIters,KC1] -
          AFD2$AllDiallelObs[[ii]]$cent.chains[[tt]][M2Iters,KC2];
        NewC[[tt]][,tC1] <- (rowSums(NewC[[tt]][,KC1]^2)-
          (rowSums(NewC[[tt]][,KC1]))^2/length(KC1))/(length(KC1)-1);
      }
    } 
  }
  for (tt in 1:length(NewC)) {
    try(NewC[[tt]] <- as.mcmc(NewC[[tt]]));
  }
  try(NewC <- as.mcmc.list(NewC));
  }
  NewADO$CodaChains <- NewC;
  if (!is.null(AFD1$DoFirstCenter) && is.logical(AFD1$DoFirstCenter) && AFD1$DoFirstCenter == TRUE) {
    NewADO$DoFirstCenter = TRUE;
    NewADO$.cent.chains <- NULL;
  } else {
    NewADO$.cent.chains = NULL;
  }
  NewADO$.PosteriorPredictionsMeanSummary=NULL;
  NewADO$.PosteriorPredictionsErrorSummary=NULL;
  NewADO$.PosteriorPredictionsMeanChains=NULL;
  NewADO$.PosteriorPredictionsErrorChains=NULL;
  NewADO$.ImputeGenderChains=NULL;
  NewADO$.ImputedGender=NULL;
  NewADO$.PosteriorHSqChains=NULL;
  NewADO$.MyRaw.Summary=NULL;
  NewADO$.MyCent.Summary =NULL;
  NewADO$PostKeeper = NULL;
  NewADO$.PosteriorHSqTable=NULL;
  NewADO$.PosteriorHSqAll=NULL;
  NewADO$.PosteriorHSqPoint=NULL;
  NewADO$.PosteriorHSqChains=NULL;
  NewADO$.PosteriorHSqChainsWithFixed=NULL;                        
  NewADO$.PosteriorRSqChains=NULL;
  NewADO$.PosteriorRSqAllImproper=NULL;
  NewADO$.PosteriorRSqPoint=NULL;
  NewADO$.PosteriorRSqPointImproper=NULL;   
  NewADO$.FixedChains=NULL;
  NewADO$.TauChains=NULL;   
  NewADO$.SigmaChains=NULL;
  if (is.null(AFD1$DoFirstCenter) || 
    !((is.logical(AFD1$DoFirstCenter) &&
      AFD1$DoFirstCenter == TRUE) ||
     (is.numeric(AFD1$DoFirstCenter) && AFD1$DoFirstCenter >= .5))) {
    NewL <- list();
    for (jj in 1:length(NewADO$CodaChains)) {
      ABT <- matrix(0, NROW(NewADO$CodaChains[[jj]]), 
        NCOL(NewADO$CodaChains[[jj]]));
      ABT[1:NROW(NewADO$CodaChains[[jj]]), 1:NCOL(NewADO$CodaChains[[jj]])] <-
        as.numeric(
          NewADO$CodaChains[[jj]][
          1:NROW(NewADO$CodaChains[[jj]]), 1:NCOL(NewADO$CodaChains[[jj]])]);
      colnames(ABT) <- colnames(NewADO$CodaChains[[jj]]);
      NewL[[jj]] <- as.mcmc(ABT);
    }
    try(NewL <- as.mcmc.list(NewL));
    NewADO$.cent.chains <- NewL;
  }
  NewADO$.cent.DiallelChains=NULL;
  NewADO$.cent.OtherRandomEffectChains=NULL;   
  NewADO$.raw.DiallelChains=NULL;
  NewADO$.raw.OtherRandomEffectChains=NULL;   
  return(NewADO);
}

setMethodS3("DiffAFD", "FullDiallelAnalyze", function(this, AFD2 = NULL, ...) {
  if (!exists("AFD2") || is.null(AFD2)) {
    print("DiffAFD: no dice, give me AFD2!"); flush.console();
    return(-1);
  }
  if ((is.logical(this$Verbose) && this$Verbose==TRUE) ||
    (is.numeric(this$Verboe) && this$Verbose > 0)) {
    print("Diff2AFD: Starting. "); flush.console(); 
    Verbose=this$Verbose; 
    if (is.logical(Verbose)  && Verbose == TRUE) {
      Verbose = 1;
    }
  } else {
    Verbose = 0;
  }
  if (!is.null(this$BS)) {
     print("Copy FullDiallelAnalyze, we don't copy BayesSpike Attachment");
     flush.console();
  }
   if (length(this$SexVector) == 0) {
     CSexVector = NULL;
   } else {
     CSexVector = Copy(this$SexVector);
   }
 NewY <- NULL;  NewListjk=-1; NewSex = -1; 
 ALT1 <- sort(unique(as.vector(this$Listjk)));
 ALT2 <- sort(unique(as.vector(AFD2$Listjk)));
 ASO <- sort(unique(c(ALT1,ALT2)));
 AllSex <- sort(unique(CSexVector));
 for (ss in AllSex) {
 for (ii in ASO) {
   for (jj in ASO) {
     if (length(this$Listjk[this$SexVector == ss & this$Listjk[,1] == ii & this$Listjk[,2] == jj]) > 0
       && length(AFD2$Listjk[AFD2$SexVector == ss &  AFD2$Listjk[,1] == ii & AFD2$Listjk[,2] == jj]) > 0) {
      AT1 <- (1:NROW(this$Listjk))[
        this$SexVector == ss & this$Listjk[,1] == ii & this$Listjk[,2] == jj]
      AT2 <-(1:NROW(AFD2$Listjk))[
        AFD2$SexVector == ss & AFD2$Listjk[,1] == ii & AFD2$Listjk[,2] == jj];
      if (is.null(NewY)) { 
        NewY <- mean(this$Y[AT1]) - mean(AFD2$Y[AT2]);
        NewListjk <- c(ii,jj);  NewSex = ss;
      } else {
        NewY <- c(NewY, mean(this$Y[AT1]) - mean(AFD2$Y[AT2]));
        NewListjk <- rbind(NewListjk, c(ii,jj));
        NewSex = c(NewSex,ss);
      }
    }
   }
 }
 }
 AFDD = FullDiallelAnalyze(Y = NewY, SexVector = NewSex,
   Listjk = NewListjk, 
   InFixedEffects = NULL, 
   InRandomEffects = NULL,
    nameFixedEffects = NULL, nameRandomEffects=NULL, 
   WeightsKeep = NULL, dfStart = this$dfSTart, mStart = this$mStart,
   tauFixedEffects = this$tauFixedEffects,  
   dfRandomEffects = this$.dfRandomEffects, mRandomEffects= this$.mRandomEffects,
   Verbose = this$Verbose, BS = NULL, strain.map = this$strain.map,
   LogTransformedFlag = this$LogTransformedFlag, SqrtTransformedFlag = this$SqrtTransformedFlag);
  AFDD$DDO1 <- Copy(this$AllDiallelObs);
  AFDD$DDO2 <- Copy(AFD2$AllDiallelObs);
  try(AFDD$.AllFixedVariables <- this$.AllFixedVariables);
  try(AFDD$.AllRandomVariables <- this$.AllRandomVariables);  
  if (is.null(AFDD$Verbose)) { AFDD$Verbose <- 0; }
  NN = names(this);
  NN = NN[!(NN %in% c("AllDiallelObs", "Y", "SexVector", "Listjk",
    "InFixedEffects", "InRandomEffects", "FixedEffects", "RandomEffects",
    "WeightsKeep", "nameRandomEffects", "dfStart", "mStart", "Verbose",
    "BS", "strain.map", "LogTransformedFlag", "SqrtTransformedFlag"))];
  for (ii in 1:length(NN)) {
    NT = paste("AFDD$", NN[ii], " <- Copy(this$", NN[ii], ")", sep="");
    try(eval(parse(text=NT)), silent=TRUE);    
  }
  AFDD$AllDiallelObs <- list();
  for (ii in 1:length(this$AllDiallelObs)) {  
    if (Verbose > 1) {
      print(paste("DiffAFD: on DiallelObs ", ii, sep="")); flush.console();
    }
    try(AFDD$AllDiallelObs[[ii]] <- DiffADO(this, AFD2, ii)); 
    try(AFDD$AllDiallelObs[[ii]]$.AFD <- AFDD, silent=TRUE); 
    if (Verbose > 1) {
      print(paste("DiffAFD: on DiallelObs ", ii, sep="")); flush.console();
    }
  }
  
  AFDD$.chains = NULL; AFDD$.model = NULL;
  AFDD$.raw.chains=NULL; AFDD$.cent.chains = NULL; 
  AFDD$.centered.chains = NULL; 
  AFDD$ListUnknownGender = this$ListUnknownGender;
  AFDD$ProbUnknownGender=this$ProbUnknownGender;
  AFDD$NoChainsUnknownGender = this$NoChainsUnknownGender;
  AFDD$.ListUnknownSex = NULL;
  AFDD$.ProbFemaleUnknownSex=NULL;
  AFDD$.NoChainsUnknownSex=NULL;
  AFDD$.PosteriorPredictionsMeanSummary=NULL; 
  AFDD$.PosteriorPredictionsErrorSummary=NULL;
  AFDD$OnObs = 1;  AFDD$.OnObs = 1;

  return(AFDD);
});
## Make copy "FullDiallelAnalyze" object
setMethodS3("Copy", "FullDiallelAnalyze", function(this,...) {
   if (!is.null(this$BS)) {
     print("Copy FullDiallelAnalyze, we don't copy BayesSpike Attachment");
     flush.console();
   }
   if (length(this$SexVector) == 0) {
     CSexVector = NULL;
   } else {
     CSexVector = Copy(this$SexVector);
   }
 NR = FullDiallelAnalyze(Y = this$Y, SexVector = CSexVector,
   Listjk = Copy(this$Listjk), 
   InFixedEffects = Copy(this$FixedEffects), 
   InRandomEffects = Copy(this$RandomEffects),
    nameFixedEffects = NULL, nameRandomEffects=NULL, 
   WeightsKeep = this$WeightsKeep, dfStart = this$dfSTart, mStart = this$mStart,
   tauFixedEffects = this$tauFixedEffects,  
   dfRandomEffects = this$.dfRandomEffects, mRandomEffects= this$.mRandomEffects,
   Verbose = this$Verbose, BS = NULL, strain.map = this$strain.map,
   LogTransformedFlag = this$LogTransformedFlag, SqrtTransformedFlag = this$SqrtTransformedFlag);

  if (is.null(this$Verbose)) {  try(NR$Verbose <- 0); } else {
    try(NR$Verbose <- this$Verbose);
  }
  ## NR$aj = this$aj; NR;motherj = this$motherj;  NR$Gendmotherj = this$Gendmotherj;
  NN = names(this);
  NN = NN[NN != "AllDiallelObs"];
  for (ii in 1:length(NN)) {
    NT = paste("NR$", NN[ii], " <- Copy(this$", NN[ii], ")", sep="");
    eval(parse(text=NT));    
  }
  try(NR$.AllFixedVariables <- this$.AllFixedVariables);
  try(NR$.AllRandomVariables <- this$.AllRandomVariables);
  NR$AllDiallelObs = list();
  if (length(this$AllDiallelObs) >= 1) {
  for (ii in 1:length(this$AllDiallelObs)) {
    try(NR$AllDiallelObs[[ii]] <- Copy(this$AllDiallelObs[[ii]], AFD = NR, iOb = ii));
    if (length(NR$AllDiallelObs) < ii || is.null(NR$AllDiallelObs[[ii]])) {
      print(paste("FullDiallelAnalyze Copy error, ii ", ii, " is NULL!", sep=""));
      flush.console();
      tryCatch("NR$AllDiallelObs Copying error"); 
    }
    if (length(this$AllDiallelObs) < ii || is.null(this$AllDiallelObs[[ii]])) {
      print(paste("FullDiallelAnalyze Copy error, ii ", ii, " is NULL!", sep=""));
      flush.console();
      tryCatch("this$AllDiallelObs Copying error"); 
    }  
    try(NR$AllDiallelObs[[ii]]$.AFD <- NR);  
  }
  } else {
    print("Why are we copying Full Diallel Object with AllDiallelObs Not setup?");  flush.console();
  }
  return(NR);
});
if (!exists("throw")) {
  throw < function(...) { tryCatch(...); }
}

#######################################################################
## "FullDiallelAnalyze"
##
##  This is the key structure in doing Diallel Analysis
##
##   Y is phenotype input
##   SexVector is Vector of genders of animals
##   Listjk is 2 column matrix, 1st col strain of mother, 2nd col of father
##
##   InFixedEffects:  Extra Fixed effects (environmental variables)
##   InRandomEffects: Extra Random batch effects (like cage identifier)
##
##   WeightsKeep:  Flag to keep weights
##   dfStart: df degrees of freedom for inv-Gamma priors to apply to all factors
##   mStart:  "m" mean for Gamma priors to apply to all factors
##   tauFixedEffects:  Default prior variance for fixed effects
##   dfRandomEffects:  df for Random effects (like dfStart)
##
##   MyFullDiallelName:  Unique name for this object (useful for printing)
##   PriorGender:  A prior probability of gender for unknown sex values
##
setConstructorS3("FullDiallelAnalyze", function(Y = c(0,0), SexVector = NULL, 
   Listjk = matrix(0,2,2), InFixedEffects = NULL, InRandomEffects = NULL, 
   InRandomEffectsGroups = NULL,
   nameFixedEffects=NULL, nameRandomEffects=NULL,
   WeightsKeep = 0, dfStart=.01, mStart=.01,
   tauFixedEffects = 1000, dfRandomEffects = 1, mRandomEffects = 1,
   dfTNoise = NULL, Verbose = -1, MyFullDiallelName = "My Default Full Analyze Diallel",
   PriorGender = .5, strain.map = NULL, ListUnknownGender= NULL,
   ProbUnknownGender = NULL, NoChainsUnknownGender = FALSE, 
   burnin = 100, thin = 1, 
   LogTransformedFlag = FALSE, SqrtTransformedFlag = FALSE,
   ProbFemaleUnknownSex = NULL, NoChainsUnknownSex=NULL, ListUnknownSex=NULL,
   MissingYIndices = NULL,
   LowCensorBound=NULL, UpCensorBound=NULL, NoChainsImputeY=FALSE, phenotype.name = "", 
   DoGelman = TRUE, DoFirstCenter = FALSE, ...) {
  if (!exists("Listjk")) { print("Listjk Does Not Exist") }
  if (!exists("Verbose")) { Verbose = 2; }
  if (is.null(Verbose)) { Verbose = 0; }
  if (!is.null(Verbose) && is.logical(Verbose) && Verbose == TRUE) { Verbose = 1; }
  if (!is.null(Verbose) && is.logical(Verbose) && Verbose == FALSE) { Verbose = 0; }
  if (!exists("nameFixedEffects") || is.null(nameFixedEffects)) {
    if (!is.null(InFixedEffects) && !is.null(colnames(InFixedEffects))) {
      nameFixedEffects = colnames(InFixedEffects);
    } else { nameFixedEffects = NULL; }
  }
  if ((!exists("nameRandomEffects") || is.null(nameRandomEffects)) &&
    !is.null(InRandomEffectsGroups) && !is.null(names(InRandomEffectsGroups)) ) {
    nameRandomEffects <- names(InRandomEffectsGroups);
  } else if (!exists("nameRandomEffects") || is.null(nameRandomEffects)) {
    if (!is.null(InRandomEffects) && !is.null(colnames(InRandomEffects))) {
      nameRandomEffects = colnames(InRandomEffects);
    } else { nameRandomEffects = NULL; }
  }

     
  if ((!is.null(Y) && is.numeric(Y) && length(Y) == 2 & sum(abs(Y)) == 0) &&
    is.null(SexVector) &&
   (!is.null(Listjk) && is.matrix(Listjk) && length(Listjk) == 4 &&
     sum(abs(Listjk)) == 0) && is.null(InFixedEffects) &&
    is.null(InRandomEffects)) {
    return(extend(FullDiallel(),"FullDiallelAnalyze",
      Verbose = -1));  
  }
  if (Verbose > 0) {
    print("**************************************************************")
    print("**   Full Diallel Analyze:  Starting entry.  "); flush.console();
  }
  if (is.null(Y)) 
      tryCatch("FullDiallelAnalyze: Y is null");
  
  if (is.null(Listjk)) {
      tryCatch("FullDiallelAnalyze: Listjk is null, cannot use data");
  }    

  if (length(Listjk) <= 0) { tryCatch("Listjk Has no length"); }
  if (is.null(dim(Listjk)) || length(dim(Listjk)) != 2) 
    tryCatch("FullDiallelAnalyze: Input Listjk is invalid in dimension")
  if (length(SexVector) <= 1)  {
  } else if (length(SexVector) < length(Listjk[,1])) {
    print(paste("length SexVector = ", length(SexVector), sep=""))  ;
    print(paste("length(Listjk[,1]) == ", length(Listjk[,1]), sep=""));
    tryCatch("Input SexVector is False");
  }
  if (length(Y) != NROW(Listjk))  {
   print(paste("Y[", length(Y),"] not long enough to Listjk[", 
     paste(dim(Listjk), collapse=", "), "]!!", sep=""));
   tryCatch("FullDiallelanalyze: bad Listjk");
  }
  
  if (!is.null(strain.map)) {
    if ((is.data.frame(strain.map) ||is.matrix(strain.map)) 
      && !is.null(strain.map) && dim(strain.map)[2] == 2) {   
      Listjjkk = Listjk;  numj = NROW(strain.map);
      if (Verbose > 1) {
        print("** FullDiallelAnalyze, Setup we believe strain.map to be valid. "); flush.console();
      }
      if (Verbose > 4) {
        print("** FullDiallelanalyze, strain.map = ");
        print(t(strain.map)); flush.console();
      }
    } else {
      strain.map = cbind(as.vector(strain.map), 1:length(strain.map));
      Listjjkk = Listjk;  numj = NROW(strain.map);
      if (Verbose > 1) {
        print("** FullDiallelAnalyze, Setup was given vector strain.map. "); flush.console();
      }
      if (Verbose > 4) {
        print("** FullDiallelanalyze, After conversion strain.map = ");
        print(t(strain.map)); flush.console();
      }
    }
    if (is.numeric(Listjk) && !is.numeric(strain.map[,1])) {
      
    } else {
      if (!(all( as.character(Listjk[,1]) %in% as.character(strain.map[,1]) ) &&
        all( as.character(Listjk[,2]) %in% as.character(strain.map[,1])) )) {
        NewStrains=unique(c( Listjk[!(as.character(Listjk[,1]) %in% as.character(strain.map[,1])),1],  
          as.character(Listjk[!(as.character(Listjk[,2]) %in% as.character(strain.map[,1])),2]) )) 
        if (length(NewStrains) == 0) {
        } else if (length(NewStrains) == 1) {
          strain.map = rbind(strain.map, c(NewStrains,NROW(strain.map)+1));
        } else {
          strain.map = rbind(strain.map, 
            cbind(NewStrains, NROW(strain.map) + 1:length(NewStrains)));
        }
      }
      NewListjk = matrix(0, NROW(Listjk), 2);
      NewListjk[,1] = as.numeric(strain.map[match(as.character(Listjk[,1]), 
        as.character(strain.map[,1])),2]);
      NewListjk[,2] = as.numeric(strain.map[match(as.character(Listjk[,2]), 
        as.character(strain.map[,1])),2])    
      Listjk = NewListjk;   
      Listjjkk = Listjk;
    }  
  } else if (!is.numeric(Listjk) && is.character(Listjk) && is.null(strain.map)) {
    IdNames = sort(unique(as.character(Listjk)));
    numj = length(IdNames);
    Listjjkk = matrix(0,NROW(Listjk),2);
    Listjjkk[,1] = match(as.character(Listjk[,1]), IdNames);
    Listjjkk[,2] = match(as.character(Listjk[,2]), IdNames);
    Listjk = Listjjkk;
    strain.map = cbind(IdNames, 1:numj);
  } else {
    IdListjk = sort(unique( as.numeric(c(Listjk[,1], Listjk[,2]))));
    numj = length(IdListjk);
    Listjjkk = Listjk;
    Listjjkk[,1] = match(Listjk[,1], IdListjk);
    Listjjkk[,2] = match(Listjk[,2], IdListjk);
    Listjk = Listjjkk;
    strain.map = cbind(IdListjk, 1:numj);
  }
  ##Listjjkk = matrix(as.numeric(Listjjkk), length(Listjk[,1]), 2);
  if (DimObject(InFixedEffects) == 1) {
    InFixedEffects = matrix(InFixedEffects, length(InFixedEffects), 1);
    colnames(InFixedEffects) = "Fixed1"
  }
  if (length(tauFixedEffects) > 0 && length(InFixedEffects) > 0) {
    if (length(dim(InFixedEffects)) == 2) {
       if (length(tauFixedEffects) == length(InFixedEffects[1,])) {
         if (length(colnames(InFixedEffects)) > 0) {
           names(tauFixedEffects) = paste("FixedEffect:", 
             1:length(colnames(InFixedEffects)), ":", colnames(InFixedEffects), sep="");
         } else {
           names(tauFixedEffects) = paste("FixedEffect:", 
             1:length(InFixedEffects[1,]), sep="");         
         }
       } else {
         tauFixedEffects = rep(tauFixedEffects[1], length(InFixedEffects[1,]));
         if (length(colnames(InFixedEffects)) > 0) {
           names(tauFixedEffects) = paste("FixedEffect:", 
             1:length(colnames(InFixedEffects)), ":", colnames(InFixedEffects), sep="");
         } else {
           names(tauFixedEffects) = paste("FixedEffect:", 
             1:length(InFixedEffects[1,]), sep="");         
         }
       }
    } else {
      tauFixedEffects = tauFixedEffects[1];
      if (length(colnames(InFixedEffects)) > 0) {
        names(tauFixedEffects) = paste("FixedEffect:", 
        1:length(colnames(InFixedEffects)), ":", colnames(InFixedEffects), sep="");
      } else {
        names(tauFixedEffects) = paste("FixedEffect:", 
        1:length(InFixedEffects[1,]), sep="");         
      }
    }
  } else if (length(InFixedEffects) > 0) {
    if (length(dim(InFixedEffects)) == 2) {
      tauFixedEffects=rep(1000, length(InFixedEffects[1,]));
      if (length(colnames(InFixedEffects)) == length(tauFixedEffects)) {
        if (length(colnames(InFixedEffects)) > 0) {
           names(tauFixedEffects) = paste("FixedEffect:", 
             1:length(colnames(InFixedEffects)), ":", colnames(InFixedEffects), sep="");
         } else {
           names(tauFixedEffects) = paste("FixedEffect:", 
             1:length(InFixedEffects[1,]), sep="");         
         }
      } else {
        names(tauFixedEffects) = paste("FixedEffect:", 
          1:length(tauFixedEffects), sep="");
      }
    }   else {
      tauFixedEffects = 1000; 
      if (length(names(InFixedEffects)) >= 1) {
        names(tauFixedEffects) = paste("FixedEffect:1:", names(InFixedEffects)[1], sep="");
      } else {
        names(tauFixedEffects) = "FixedEffect:1"
      }
    }
  } else {
    tauFixedEffects=NULL; InFixedEffects = NULL;
  }
     
  if ((!is.null(dfRandomEffects) || !is.null(mRandomEffects)) &&
    length(dfRandomEffects) != length(mRandomEffects) && 
      length(dfRandomEffects) + length(mRandomEffects) > 0) {
    print("Error Degrees of Freedom of Random Effects is unequal to mean");
    dfRandomEffects= NULL; mRandomEffects=NULL;
  }
  if (!is.null(InRandomEffectsGroups) && !is.null(InRandomEffects) ) {
    if(sum(InRandomEffectsGroups) != NCOL(InRandomEffects)) {
      print(paste("FullDiallelAnalyze Error; sorry, InRandomEffectsGroups is ",
        sum(InRandomEffectsGroups), " column, but NCOL(InRandomEffects) is ",
        NCOL(InRandomEffects), sep="")); flush.console();
      tryCatch("Sorry FullDiallelAnalyze error.");
    }
    if (NROW(InRandomEffects) != NROW(Listjk)) {
      print(paste("FullDiallelAnalyze Error, sorry InRandomEffects is ",
        NROW(InRandomEffects), " rows but Listjk is ", 
        NROW(Listjk), sep="")); flush.console();
      tryCatch("Sorry FullDiallelAnalyze error.");
    }
    RandomEffects = InRandomEffects;
    RandomEffectsGroups = InRandomEffectsGroups;
    if (is.null(dfRandomEffects)) {
      dfRandomEffects <- rep(1, length(RandomEffectsGroups));
    } else if (length(dfRandomEffects) <= length(RandomEffectsGroups)) {
      dfRandomEffects <- c(dfRandomEffects, 
        rep(dfRandomEffects[length(dfRandomEffects)], length(RandomEffectsGroups)-
        length(dfRandomEffects)));
    }
    if (is.null(dfRandomEffects)) {
      mRandomEffects <- rep(1, length(RandomEffectsGroups));
    } else if (length(mRandomEffects) <= length(RandomEffectsGroups)) {
      mRandomEffects <- c(mRandomEffects, 
        rep(mRandomEffects[length(mRandomEffects)], length(RandomEffectsGroups)-
        length(mRandomEffects)));
    }
    if (is.null(names(RandomEffectsGroups))) {
      namesRandomEffects = paste("RandomEffect:", 1:length(RandomEffectsGroups), sep="");
      names(RandomEffectsGroups) = namesRandomEffects;
      names(InRandomEffectsGroups) = namesRandomEffects;
    } else {
      namesRandomEffects <- names(RandomEffectsGroups);
    }
  } else if (DimObject(InRandomEffects) >= 2) {
    if (length(dfRandomEffects) == length(InRandomEffects[1,])) {
    
    } else {
       if (length(dfRandomEffects) >= 1) {
         dfRandomEffects = rep(dfRandomEffects[1], length(InRandomEffects[1,]));
         mRandomEffects = rep(mRandomEffects[1], length(InRandomEffects[1,]));
       } else {
         dfRandomEffects = rep(dfStart, length(InRandomEffects[1,]));
         mRandomEffects = rep(mStart, length(InRandomEffects[1,]));
       }
    }
  }  else if (DimObject(InRandomEffects) == 1) {
    if (length(dfRandomEffects) >= 1) { dfRandomEffects = dfRandomEffects[1];
    } else {dfRandomEffects = dfStart;}
    if (length(mRandomEffects) >= 1) { mRandomEffects = mRandomEffects[1];
    } else {mRandomEffects = dfStart;}
  }
  df = RConstantsList(dfStart, StartRandomEffects=dfRandomEffects);
  m = RConstantsList(mStart, StartRandomEffects=mRandomEffects);
  
  
  if (is.null(ProbUnknownGender)  && exists("ProbFemaleUnknownSex") &&
    !is.null(ProbFemaleUnknownSex)) {
     ProbUnknownGender = ProbFemaleUnknownSex;  
  }
  if (is.null(ListUnknownGender) && exists("ListUnknownSex") &&
    !is.null(ListUnknownSex)) {
    ListUnknownGender = ListUnknownSex;  
  }
  rX = NULL;
  if (!is.null(SexVector) &&
    length(SexVector) > 0 && any(is.na(SexVector)) || 
    (any(SexVector == -1) && any(SexVector == 0))) {
    SexVector[SexVector == -1] = NA;
    if (is.null(ListUnknownGender) || length(ListUnknownGender) == 0) {
      ListUnknownGender = (1:length(Y))[is.na(SexVector)];
      if (length(ProbUnknownGender) != length(ListUnknownGender)) {
        ProbUnknownGender = rep(.5, length(ListUnknownGender));
      }
    } else if (length(SexVector[is.na(SexVector)]) != 
      length(ListUnknownGender)) {
      tryCatch("Error, SexVector has length NAs different from ListUnknownGender!");  
    } else if (length(ListUnknownGender) < length(Y)) {
      if (!all(ListUnknownGender == (1:length(SexVector))[is.na(SexVector)])) {
      tryCatch("Error, SexVector has NAs different from ListUnknownGender!");       
      }
    }
    SexVector[is.na(SexVector)] = rbinom(length(SexVector[is.na(SexVector)]),
     1, .5);
  }
  if (length(ListUnknownGender) == length(Y) &&  
    is.logical(ListUnknownGender)) {
    if (!is.null(ProbUnknownGender)  && 
      length(ProbUnknownGender) == length(ListUnknownGender)) {
      ProbUnknownGender = ProbUnknownGender[ListUnknownGender == FALSE] 
    }
    ListUnknownGender = (1:length(ListUnknownGender))[ListUnknownGender == FALSE] 
    if (length(ProbUnknownGender) != length(ListUnknownGender)) {
      if (length(ProbUnknownGender) == 1 &&
        ProbUnknownGender > 0.0 && ProbUnknownGender < 1.0) {
        ProbUnknownGender = .5;  
      }
      ProbUnknownGender = rep(ProbUnknownGender, length(ListUnknownGender));
    }
  } else if (length(ListUnknownGender) == length(Y) && 
    is.numeric(ListUnknownGender)  &&
    all(ListUnknownGender %in% c(0.0,1.0))) { 
    if (!is.null(ProbUnknownGender)  && 
      length(ProbUnknownGender) == length(ListUnknownGender)) {
      ProbUnknownGender = ProbUnknownGender[ListUnknownGender == FALSE] 
    }
    ListUnknownGender = (1:length(ListUnknownGender))[ListUnknownGender == FALSE] 
    if (length(ProbUnknownGender) != length(ListUnknownGender)) {
      if (length(ProbUnknownGender) == 1 &&
        ProbUnknownGender > 0.0 && ProbUnknownGender < 1.0) {
        ProbUnknownGender = .5;  
      }
      ProbUnknownGender = rep(ProbUnknownGender, length(ListUnknownGender));
    }
  } else if (length(ListUnknownGender) == length(Y) &&
    is.numeric(ListUnknownGender) && max(ListUnknownGender) <= 1.0 &&
    min(ListUnknownGender) >= 0.0) {
    ProbUnknownGender = ListUnknownGender[ListUnknownGender > 0.0 &&
      ListUnknownGender < 1.0]
    ListUnknownGender =(1:length(Y))[ListUnknownGender > 0.0 &&
      ListUnknownGender < 1.0]
  } else if (!is.null(ListUnknownGender) && length(ListUnknownGender) > 1
    && is.numeric(ListUnknownGender) && 
    all(round(ListUnknownGender) == ListUnknownGender) &&
    min(ListUnknownGender) > 0 && max(ListUnknownGender) <= length(Y)) {
    if (length(ProbUnknownGender) == length(ListUnknownGender)) {
    } else if (length(ProbUnknownGender) != length(ListUnknownGender)) {
      if (is.null(ProbUnknownGender) || (length(ProbUnknownGender) == 1 &&
        ProbUnknownGender < 0.0 || ProbUnknownGender > 1.0)) {
        ProbUnknownGender = .5;  
      }
      ProbUnknownGender = rep(ProbUnknownGender[1], length(ListUnknownGender));
    } 
  } else if (is.null(ListUnknownGender) &&
    length(ProbUnknownGender) == length(Y) &&
    min(ProbUnknownGender) >= 0.0  && max(ProbUnknownGender) <= 1.0) {
     ListUnknownGender =(1:length(Y))[ProbUnknownGender > 0.0 &&
      ProbUnknownGender < 1.0] 
     ProbUnknownGender = ProbUnknownGender[ProbUnknownGender > 0.0 &&
      ProbUnknownGender < 1.0]
  } else if (is.null(ListUnknownGender) && is.null(ProbUnknownGender)) {
  
  } else {
    print("Warning there was an error on Unknown Gender Input!"); flush.console();
  }
  if (!is.null(ListUnknownGender)) {
    SexVector[ListUnknownGender] = NA;
  }
  if (is.null(NoChainsUnknownGender) && exists("NoChainsUnknownSex") &&
    !is.null(NoChainsUnknownSex)) {
    NoChainsUnknownGender = NoCainsUnknownSex;
  }
  if (is.null(MissingYIndices) && any(is.na(Y))) {
    MissingYIndices = (1:length(Y))[is.na(Y)]
    Y[MissingYIndices] = 0.0;
  } else if (!is.null(MissingYIndices) && any(is.na(Y))) {
    AMissing = (1:length(Y))[is.na(Y)];
    MM = match(AMissing,MissingYIndices);
    if (any(is.na(MM))) {
      print("Error, over MissingYIndices AMissing is ");
      print(paste(AMissing, collapse=", "));
      print("  but MissingYIndices = ");
      print(paste(MissingYIndices, collapse=", ")); flush.console();
      tryCatch("A bit of an error!");
      return(-1);
    }
    Y[is.na(Y)] = 0.0;
  }
  ##print("GoingToFullDialllel"); flush.console();
  ##print(paste("dimListjjkk = ", dim(Listjjkk), collapse=", "));
  ##print(paste("lengthRandomEffects = ", length(InRandomEffects), sep=" "));  
  ListAddFunctions = c("SetupAnalyzeMethods",
  "SetupUnknownGender", "SetRandomValues", "AFDhglm", 
  "MysteryGender", "RenameChains", "SetupWeights", "findStartModel", "RunChains",
  "RunChainsOld", "RecalculateLikelihoods", "PrintDICAll", "PrintDICCAll",
  "SetupMissingYIters");
  ListAddElements = c("Y", "MaxExamineList", "X","dfTNoise", "WeightsKeep",
    ".TBSRoo", ".MBS", "dfRandomEffects", "mRandomEffects",
    "ListUnknownGender", "PriorGender", "ModelsList", "OnObs", "On",
    "BS", "chains", "CodaChains", "model", "raw.chains", "cent.chains",
    "ListUnknownSex", "ProbFemaleUnknownSex", "NoChainsUnknownSex",
    "ListUnknownGender", "ProbUnknownGender", "NoChainsUnknownGender",
    "burnin", "thin", "PosteriorPredictionsMeanSummary", "PosteriorPredictionsErrorSummary",
     "PosteriorPredictionsMeanChains", "PosteriorPredictionsErrorChains",
     "ImputeSexChains", "ImputedSex",
     "ImputeGenderChains", "ImputedGender",
          "MyRaw.Summary", "MyCent.Summary",
     "PosteriorHSqChains", "PosteriorHSqTable", "PosteriorHSqAll",
     "PosteriorHSqPoint",
     "PosteriorHSqChainsWithFixed", "PosteriorHSqTableWithFixed",
     "PosteriorHSqAllWithFixed",  "PosteriorHSqPointWithFixed",
     "PosteriorHSqChainsImproper", "PosteriorHSqTableImproper",
     "PosteriorHSqAllImproper",  "PosteriorHSqPointImproper",
     "PosteriorRSqChains", "PosteriorRSqTable",
     "PosteriorRSqAll", "PosteriorRSqAllImproper",
     "PosteriorRSqAllWithFixed", "PosteriorRSqPoint", 
     "PosteriorRSqPointImproper",
     "PosteriorRSqPointWithFixed", "nameFixedEffects", "nameRandomEffects",
     "PosteriorRSqChainsImproper", "PosteriorRSqTableImproper",
     "PosteriorRSqChainsWithFixed", "PosteriorRSqTableWithFixed",
     "TauChains", "SigmaChains", "FixedChains",
     "cent.DiallelChains", "cent.OtherRandomEffectChains",
     "raw.DiallelChains", "raw.OtherRandomEffectChains",
     "MissingYIndices", "LowCensorBound", "UpCensorBound",
     "NoChainsImputeY", "DoGelman", "HPDTarget", "HPDTable");
  extend(FullDiallel(numj=numj, Indf=df, Inm=m, 
            IntauFixed=FConstantsList(1000,tauFixedEffects),
            InSexVector = SexVector, InListjk = Listjjkk,
            InFixedEffects = InFixedEffects, 
            InRandomEffects = InRandomEffects, InRandomEffectsGroups = InRandomEffectsGroups,
            Inmtau = NULL, Indftau = NULL, Verbose = Verbose,  MyFullDiallelName =  MyFullDiallelName,
            strain.map = strain.map, nameFixedEffects=nameFixedEffects, nameRandomEffects=nameRandomEffects,
            ListAddFunctions = ListAddFunctions, ListAddElements = ListAddElements,
            LogTransformedFlag = LogTransformedFlag, SqrtTransformedFlag = SqrtTransformedFlag,
            phenotype.name = phenotype.name, DoFirstCenter = DoFirstCenter),
             "FullDiallelAnalyze", 
    Y = Y,
    MaxExamineList = NULL,
    X = rX,
    dfTNoise = dfTNoise,
    WeightsKeep = 0,.TBSRoo=NULL, .MBS=NULL, .dfRandomEffects= dfRandomEffects,
    .mRandomEffects= mRandomEffects, GGX = NULL, ListUnknownGender = NULL,
    PriorGender = PriorGender,
    ModelsList = NULL, OnObs = -1, .On = NULL, .BS = NULL,.BSAFD=NULL, .BayesSpike=NULL,
    .chains = NULL, .CodaChains = NULL, .model = NULL,
    .raw.chains=NULL, .cent.chains = NULL, .centered.chains = NULL, 
    ListUnknownGender = ListUnknownGender,
    ProbUnknownGender=ProbUnknownGender, NoChainsUnknownGender = NoChainsUnknownGender,
    burnin = burnin, thin=thin, .ListUnknownSex = NULL,
    .ProbFemaleUnknownSex=NULL,.NoChainsUnknownSex=NULL,
    .PosteriorPredictionsMeanSummary=NULL, .PosteriorPredictionsErrorSummary=NULL,
     .PosteriorPredictionsMeanChains = NULL, .PosteriorPredictionsErrorChains=NULL,
     .ImputeGenderChains=NULL, .ImputedGender = NULL,
     .MyRaw.Summary = NULL, .MyCent.Summary = NULL,
     .PosteriorHSqChains = NULL, .PosteriorHSqTable = NULL, .PosteriorHSqAll = NULL,
     .PosteriorHSqPoint = NULL,  WeHaveShrunkXMatrix = FALSE,
     .PosteriorHSqChainsWithFixed = NULL, .PosteriorHSqTableWithFixed = NULL,
     .PosteriorHSqAllWithFixed = NULL,  .PosteriorHSqPointWithFixed = NULL,
     .PosteriorHSqChainsImproper=NULL, .PosteriorHSqTableImproper=NULL,
     .PosteriorHSqAllImproper=NULL,  .PosteriorHSqPointImproper=NULL,
     .PosteriorRSqChains = NULL, .PosteriorRSqTable = NULL,
     .PosteriorRSqAll = NULL, .PosteriorRSqAllImproper = NULL,
     .PosteriorRSqAllWithFixed=NULL, .PosteriorRSqPoint=NULL, 
     .PosteriorRSqPointImproper=NULL,
     .PosteriorRSqPointWithFixed=NULL,
     .PosteriorRSqChainsImproper=NULL, .PosteriorRSqTableImproper=NULL,
     .PosteriorRSqChainsWithFixed = NULL, .PosteriorRSqTableWithFixed = NULL,
     .TauChains = NULL, .SigmaChains = NULL,
     .cent.DiallelChains=NULL, .cent.OtherRandomEffectChains = NULL,
     .FixedChains=NULL,
     .raw.DiallelChains=NULL, .raw.OtherRandomEffectChains = NULL,
      MissingYIndices= MissingYIndices, .CMissingIters=NULL, 
      LowCensorBound=LowCensorBound, 
      UpCensorBound=UpCensorBound, DDO1 = NULL, DDO2 = NULL,
      NoChainsImputeY=NoChainsImputeY,
      DoGelman = DoGelman,
      AllCenteredRandomVariables = BayesDiallel:::.DefaultAllRandomVariables,
      HPDTarget = .95, .HPDTable = NULL, .BSOther = list()
  )
});
setMethodS3("getCentered.chains", "FullDiallelAnalyze", function(this,...) {
 return(this$getCent.chains());
});
setMethodS3("getPhenotype", "FullDiallel", function(this,...) {
  return(this$Y);
});
setMethodS3("SetupUnknownSex", "FullDiallelAnalyze", function(this,
  ListUnknownSex=NULL, ProbFemaleUnknownSex=NULL, NoChainsUnknownSex=NULL,
  Verbose = -1, ListUnknownGender=NULL, ProbUnknownGender=NULL,
  NoChainsUnknownGender=NULL, ...) {
  if (is.null(ListUnknownGender) && exists("ListUnknownSex") &&
    !is.null(ListUnknownSex)) {
    ListUnknownGender = ListUnknownSex;  
  }
  if (is.null(ProbUnknownGender) && exists("ProbFemaleUnknownSex") &&
    !is.null(ProbFemaleUnknownSex)) {
    ProbUnknownGender = ProbFemaleUnknownSex;  
  }
  if (is.null(NoChainsUnknownGender) && exists("NoChainsUnknownSex") &&
    !is.null(NoChainsUnknownSex)) {
    NoChainsUnknownGender = NoChainsUnknownSex;  
  }
  this$SetupUnknownGender(ListUnknownGender=ListUnknownGender,
    ProbUnknownGender=ProbUnknownGender,
    NoChainsUnknownGender=NoChainsUnknownGender, Verbose=Verbose,...);
    
});

setMethodS3("SetupUnknownGender", "FullDiallelAnalyze", function(this,
  ListUnknownGender, ProbUnknownGender = NULL, 
  NoChainsUnknownGender = NULL, Verbose = -1,...) {
  
  if (Verbose < 0) {
    Verbose = this$Verbose;
  }
  if (is.null(NoChainsUnknownGender)) {
    NoChainsUnknownGender = this$NoChainsUnknownGender;
  }
  if (Verbose > 0) {
    print("SetupUnknownGender: Starting"); flush.console();
  }
  if (is.null(NoChainsUnknownGender)) {
    this$NoChainsUnknownGender = FALSE;
    NoChainsUnknownGender = this$NoChainsUnknownGender;
  } else { this$NoChainsUnknownGender = NoChainsUnknownGender; }
  
  if (this$NoChainsUnknownGender == TRUE) {
    if (Verbose > 0) {
      print("SetupUnknownGender: Won't have chains for Unknown Gender"); flush.console();
    }
  }
  GoBoy = 0;
  if (length(ListUnknownGender) == length(this$Y) &&  
    is.logical(ListUnknownGender) && GoBoy == 0) {
    GoBoy = 1;
    if (Verbose > 0) {
      print("SetupUnknownGender: You supplied Listunknown gender length of Y"); flush.console();
    }
    if (!is.null(ProbUnknownGender)  && 
      length(ProbUnknownGender) == length(ListUnknownGender)) {
      if (Verbose > 0) {
        print("SetupUnknownGender: Cutting ProbUnknown Gender similarly length of Y"); flush.console();
      }
      ProbUnknownGender = ProbUnknownGender[ListUnknownGender == FALSE] 
    }
    ListUnknownGender = (1:length(ListUnknownGender))[ListUnknownGender == FALSE] 
    if (is.null(ProbUnknownGender)) {
      if (Verbose > 0) {
          print(paste("SetupUnknownGender: Null ProbUnknownGender, ",
            "input all to .5.", sep="")); flush.console();
      }
      ProbUnknownGender = rep(.5, length(ListUnknownGender));
    } else if (length(ProbUnknownGender) != length(ListUnknownGender)) {
      if (Verbose > 0) {
        print(paste("SetupUnknownGender: ProbUnknownGender[", 
          length(ProbUnknownGender), "] so we'll take first for all")); flush.console();
      }
      if (length(ProbUnknownGender) == 1 &&
        ProbUnknownGender < 0.0 && ProbUnknownGender > 1.0) {
        if (Verbose > 0) {
          print(paste("SetupUnknownGender: ProbUnknownGender[", 
            length(ProbUnknownGender), "] = ", ProbUnknownGender,
            " but not length of Unknown = ",
            length(ListUnknownGender), ", so input  all to same", sep="")); flush.console();
        }
        ProbUnknownGender = .5;  
      }
      ProbUnknownGender = rep(ProbUnknownGender, length(ListUnknownGender));
    }
  } else if (length(ListUnknownGender) == length(this$Y) && 
    is.numeric(ListUnknownGender)  &&
    all(ListUnknownGender %in% c(0.0,1.0)) && GoBoy == 0) { 
    GoBoy = 1;
    if (Verbose > 0) {
      print("SetupUnknownGender: ListUnknownGender is only 0.0, 1.0");
      flush.console();
    }
    if (!is.null(ProbUnknownGender)  && 
      length(ProbUnknownGender) == length(ListUnknownGender)) {
      ProbUnknownGender = ProbUnknownGender[ListUnknownGender == FALSE] 
    }
    ListUnknownGender = (1:length(ListUnknownGender))[ListUnknownGender == FALSE] 
    if (length(ProbUnknownGender) != length(ListUnknownGender)) {
      if (length(ProbUnknownGender) == 1 &&
        ProbUnknownGender < 0.0 && ProbUnknownGender > 1.0) {
        ProbUnknownGender = .5;  
      }
      if (Verbose > 0) {
        print(paste("SetupUnknownGender: Put ProbUnknownGender all as ", 
          ProbUnknownGender, sep=""));
        flush.console();
      } 
      ProbUnknownGender = rep(ProbUnknownGender, length(ListUnknownGender));
    }
  } else if (length(ListUnknownGender) == length(this$Y) &&
    is.numeric(ListUnknownGender) && max(ListUnknownGender) <= 1.0 &&
    min(ListUnknownGender) >= 0.0 && GoBoy == 0) {
    GoBoy = 1;
    if (Verbose > 0) {
      print(paste("SetupUnknownGender: ListUnknownGender is actually Prob for all! ", 
        sep=""));
      flush.console();
    } 
    ProbUnknownGender = ListUnknownGender[ListUnknownGender > 0.0 &&
      ListUnknownGender < 1.0]
    ListUnknownGender =(1:length(this$Y))[ListUnknownGender > 0.0 &&
      ListUnknownGender < 1.0]
  } else if (!is.null(ListUnknownGender) && length(ListUnknownGender) > 1 
   && is.numeric(ListUnknownGender) &&
    all(round(ListUnknownGender) == ListUnknownGender) &&
    min(ListUnknownGender) > 0 && max(ListUnknownGender) <= length(this$Y) &&
    GoBoy == 0) {
    GoBoy = 1;
    ##ListUnknownGender = ListUnknownGender;
    if (Verbose > 0) {
      print(paste("SetupUnknownGender: ListUnknownGender a group of Integers ", 
        sep=""));
      flush.console();
    } 
    if (length(ProbUnknownGender) != length(ListUnknownGender)) {
      if (length(ProbUnknownGender) == 1 &&
        ProbUnknownGender > 0.0 && ProbUnknownGender < 1.0) {
        print(paste("SetupUnknownGender: Error, ProbUnknownGender has ",
          "length = ", length(ProbUnknownGender), " but length ",
          " ListUnknownGender = ", length(ListUnknownGender), sep=""));
        flush.console();
        ProbUnknownGender = .5;  
      }
      ProbUnknownGender = rep(ProbUnknownGender[1], length(ListUnknownGender));
    } else {
      if (Verbose > 0) {
        print(paste("SetupUnknownGender: Apparently ProbUnknownGender "
        , "valid to go with ListUnknownGender for this integer type")); flush.console();
      }
    }
  } else if (is.null(ListUnknownGender) &&
    length(ProbUnknownGender) == length(this$Y) &&
    min(ProbUnknownGender) >= 0.0  && max(ProbUnknownGender) <= 1.0 && GoBoy == 0) {
    GoBoy = 0;
    if (Verbose > 0) {
      print("ProbUnknownGender is good proxy for all ListUnknownGender");
      flush.console();
    }
     ListUnknownGender =(1:length(this$Y))[ProbUnknownGender > 0.0 &&
      ProbUnknownGender < 1.0] 
     ProbUnknownGender = ProbUnknownGender[ProbUnknownGender > 0.0 &&
      ProbUnknownGender < 1.0]
  } else if (is.null(ListUnknownGender) && is.null(ProbUnknownGender)) {
    print("SetupUnknownGender:  Hey, you wanted to set Unknown Gender but supplied only Nulls!"); flush.console();
  } else { 
    print("SetupUnknownGender: Warning there was an error on Unknown Gender Input!"); flush.console();
  }
  if (is.null(ListUnknownGender)) {
    print("SetupUnknownGender: Doh after all that ListUnknownGender is Null!"); flush.console();
  }
  if (Verbose > 0) {
    print("SetupUnknownGender:  now assigning ListUnknownGender to this!");
    flush.console();
  }
  this$ListUnknownGender = ListUnknownGender;
  this$ProbUnknownGender = ProbUnknownGender;
  if (Verbose > 0) {
    print("SetupUnknownGender: Got Things from Setup Gender");
    if (is.null(ListUnknownGender) && is.null(ProbUnknownGender)) {
      print("But all Defective Nulls!"); flush.console();
    } else if (is.null(ListUnknownGender)) {
      print("But ListUnknownGender is a null!"); flush.console();
    } else if (is.null(ProbUnknownGender)) {
      ProbUnknownGender = rep(.5, length(ListUnknownGender));
      this$ProbUnknownGender = ProbUnknownGender;
    }
  }
  if (is.null(ListUnknownGender) && is.null(ProbUnknownGender)) {
    print("Hey; We started Setup Unknown Gender but only have Nulls as inputs"); flush.console();
  }
  if (!is.null(this$SexVector)) {
    this$SexVector[ListUnknownGender] = NA;
  }
  if (!is.null(this$X)) {
     CG = round(this$X[,colnames(this$X) == "Gender:Av"]+.5);
     TCG = CG[ListUnknownGender]
     ACG = (1:length(TCG))[TCG == 0];
     PC = (1:length(colnames(this$X)))[substr(colnames(this$X), 1, nchar("Gender")) == "Gender" |
       colnames(this$X) == "BetaInbred:Gender:Av"]
     this$X[(1:length(CG))[ListUnknownGender[ACG]],PC] = -1.0 * 
       this$X[(1:length(CG))[ListUnknownGender[ACG]],PC]
  }
  this$MysteryGender(NULL, NULL, 
    NoChainsUnknownGender = NoChainsUnknownGender,
    Verbose = Verbose);
});

setMethodS3("SetupMissingYIndices", "FullDiallelAnalyze", function(this,
  MissingYIndices = NULL, LowCensorBound = NULL, 
  UpYBound = NULL, NoChainsImputeY = FALSE, ...) {
  if (is.null(LowCensorBound)) {
    this$LowCensorBound = NULL;
  } else {
    this$LowCensorBound = LowCensorBound;
  }
  if (is.null(UpCensorBound)) {
    this$UpCensorBound = NULL;
  } else {
    this$UpCensorBound = UpYBound;
  }  
  if (is.null(MissingYIndices)) {
    this$MissingYIndices = (1:length(this$Y))[is.na(this$Y)];
    if (!is.null(this$Sigma)) {
      this$Y[is.na(this$Y)] = rnorm(length(this$MissingYIndices), sqrt(this$Sigma))
    }  else {
      this$Y[is.na(this$Y)] = 0.0;
    }
  } else {
    this$MissingYIndices = round(MissingYIndices[ MissingYIndices > 0 &
      MissingYIndices < length(this$Y)])
  }
  if (length(this$MissingYIndices) == 0) {
    this$MissingYIndices = NULL;
  }
  this$NoChainsImputeY =  as.logical(NoChainsImputeY);
});

## Delete the full Diallel Analyze Object
setMethodS3("finalize", "FullDiallelAnalyze", function(this,...) {
  print(paste("FullDiallelAnalyze: ", this$MyFullDiallelName,
    " is about to be removed from memory", sep=""));
  if (!is.null(this$deleting) && this$deleting == 1) {
    return;
  }
  this$deleting = 1;
  flush.console();
  for (ii in length(this$AllDiallelObs):1) {
    MyText = paste(
      "try(ABackup <- this$AllDiallelObs[[", ii,"]], silent=TRUE);
       try(this$AllDiallelObs[[", ii, "]] <- 1, silent=TRUE);
       if (!is.null(ABackup)) {
         try(finalize(ABackup), silent=TRUE);
         try(rm(ABackup), silent=TRUE);
       }",
       sep="");  
    try(eval(parse(text=MyText)), silent=TRUE);
  
  }
  this$AllDiallelObs = NULL;
  this$X = NULL;  this$Y = NULL;
  this$BeingDestroyed = 1;
  this$ACrossLocations = NULL;
  if (!is.null(this$.MBS)  && !is.null(this$.MBS$BeingDestroyed) && 
    this$.MBS$BeingDestroyed != 1) {
    print("FullDiallelAnalyze: we're going to try to destry it's MBS"); flush.console();
    ##rm(this$.MBS);
    this$.MBS = NULL;
  }
  if (!is.null(this$.TBSRoo)  && !is.null(this$.TBSRoo$.BeingDestroyed)
    && this$.TBSRoo$.BeingDestroyed != 1) {
    print("FullDiallelAnalyze: we're going to try to destry it's TBSRoo"); flush.console();
    if (!is.null(this$.TBSRoo)) {
      try(finalize(this$.TBSRoo), silent=TRUE);
    }
  }
  return(NULL);
});
 

## Deprecated object for doing EM maximization Analysis
setConstructorS3("FullDiallelEMAnalyze",
  function(Y = c(0,0), SexVector = NULL, Listjk = matrix(0,2,2),
  FixedInput = c(-999), RandomInput = c(-999), 
  DoCM = FALSE, InFixedEffects = NULL, InRandomEffects = NULL, 
  WeightsKeep = 0, dfStart=.01, mStart=.01,
  tauFixedEffects = 1000, dfRandomEffects = 1, mRandomEffects = 1,
  dfTNoise = NULL, Verbose = -1, MyFullDiallelName = "My Default Full Analyze EM Diallel",
  PriorGender = .5, strain.map = NULL, numj = NULL,
  LogTransformedFlag = FALSE, SqrtTransformedFlag = FALSE,...)
  {
    iY = Y;  iSexVector = SexVector; iListjk = Listjk;
    if (is.null(Y) && is.null(Listjk)) {
     return;
    } else if (is.null(Y) && (!is.null(Listjk) && is.numeric(Listjk) &&
      sum(abs(Listjk)) == 0)) {
      return;
    } else if (!is.null(Y) && (is.numeric(Y) && length(Y) == 2 &&  sum(abs(Y)) == 0)) {
      if (is.null(Listjk) || (!is.null(Listjk) && is.numeric(Listjk) &&
        length(Listjk) == 4 || sum(abs(Listjk)) == 0)) {
        return;  
      }
      print("Something is wrong with default Lisjk, since Y seems to be c(0,0).");
      flush.console();
      return;
    }
    if (is.logical(Verbose) && Verbose == TRUE) { Verbose = 2;}
    if ( Verbose > 2) {
      print("fullDiallelEMAnalyze: Input Listj is: ");
      print(Listjk); flush.console();
    }
    numj = length( unique(as.vector(iListjk)));
    
    if (numj <= 2) {
      print(paste("Error: FullDiallelEMAnalyze, unfortunately, Listjk = (",
        paste(Listjk, collapse=", "), ")", sep=""));
      print(paste("Length listjk = ", length(iListjk), sep=""));
      flush.console();
      tryCatch("End Of FullDiallelEMAnalyze");
    }
    extend(FullDiallelAnalyze(Y=iY, SexVector=SexVector, Listjk=Listjk,
    numj = length(unique(Listjk)),
    strain.map = strain.map, PriorGender=PriorGender,
    mStart=mStart, dfStart=dfStart, WeightsKeep = WeightsKeep,
    dfRandomEffects=dfRandomEffects, mRandomEffects=mRandomEffects,
    dfTNoise = dfTNoise, Verbose=Verbose,
    MyFullDiallelName = MyFullDiallelName),
    "FullDiallelEMAnalyze", FinalBetaList = NULL,
    cauchy.delta = .01, DoCM = DoCM,
    LogTransformedFlag = LogTransformedFlag, SqrtTransformedFlag = SqrtTransformedFlag);   
});

##########################################################################
##  An attempt to standardize names given to additional random batch effects
SetNames <- function(Amatrix, txt="RandomEffects") {
  if (DimObject(Amatrix) >= 2) {
    if (is.null(colnames(Amatrix))) {
      colnames(Amatrix) = paste(txt, ":",1:DimObject(Amatrix), sep="");
    } 
    return(Amatrix);
  }
  if (DimObject(Amatrix) == 1) {
  Amatrix = matrix(Amatrix, length(Amatrix), 1);
  colnames(Amatrix) = txt;
  return(Amatrix);
  }
  return(NULL);
}

setMethodS3("getImputedGender", "FullDiallelAnalyze", function(this,...){
  this$AllDiallelObs[[this$On]]$ImputedGender
});
setMethodS3("getImputeGenderChains", "FullDiallelAnalyze", function(this,...){
  this$AllDiallelObs[[this$On]]$ImputeGenderChains
});
####################################################################
##  Full Diallel Simulate Object simulates a diallel: complete/incomplete
##   given inputs
##
setConstructorS3("FullDiallelSimulate", function(numj = defaultnumj, 
  NumRepetitions = defaultNumRepetitions,
  InFixedEffects=NULL, InRandomEffects=NULL,
  tauFixedEffects=NULL, dfRandomEffects=NULL,
  mRandomEffects=NULL, YesSex = NULL, InBalance = c(0,0),
   MyFullDiallelName =  "My Default Full DiallelSimulate ", 
   strain.map = NULL, phenotype.name = "", DoFirstCenter = FALSE, ...) {
  ##print(paste("FullDiallelSimulate, with numj = ", numj, sep=""));
  if (is.null(YesSex)) { YesSex=FALSE; }
  InRandomEffects = SetNames(InRandomEffects);
  if (is.null(InRandomEffects)) { dfRandomEffects=NULL; mRandomEffects=NULL;}
  if (is.null(InFixedEffects)) { tauFixedEffects=NULL; }
  if (!is.null(InRandomEffects)) {
    if (length(dfRandomEffects) != DimObject(InRandomEffects)) {
      if (!is.null(dfRandomEffects)) {
        dfRandomEffects=rep(dfRandomEffects, DimObject(InRandomEffects));
        names(dfRandomEffects) = colnames(InRandomEffects);
        names(mRandomEffects) = colnames(InRandomEffects);
      }
    }
  }
  if (!is.null(InFixedEffects)) {
    InFixedEffects = SetNames(InFixedEffects);
    if (is.null(tauFixedEffects)) {
      tauFixedEffects = rep(10, DimObject(InFixedEffects));
      names(tauFixedEffects) = colnames(InFixedEffects);
    }
  }
  if (!is.null(InRandomEffects) || !is.null(InFixedEffects)) { 
    MySize = max(dim(InRandomEffects)[1], dim(InFixedEffects)[1]);
    RM1 = sample(size=MySize, 1:numj, replace=TRUE); 
    RM2 = sample(size=MySize, 1:numj, replace=TRUE);
    if (YesSex  == FALSE) { 
      Listjk = cbind (RM1, RM2);
      SexVector = NULL;
    } else {
      Listjk =  rbind(cbind(RM1, RM2), 
	    cbind(RM1, RM2) );
      SexVector = c(rep(0, length(RM1)), rep(1, length(RM1)));
      if (!is.null(InRandomEffects)) {
        InRandomEffects = rbind(InRandomEffects, InRandomEffects);
      }
      if (!is.null(InFixedEffects)) {
        InFixedEffects = rbind(InFixedEffects, InFixedEffects);
      }
    }
    if (NumRepetitions > 1) {
      RS = SexVector;  RLS = Listjk;
      RIR = InRandomEffects; RIF = InFixedEffects
      for (ii in 2:round(NumRepetitions)) {
        SexVector = c(SexVector, RS);
        RLS = cbind(
        RM1 = sample(size=length(RS), 1:numj, replace=TRUE), 
        RM2 = sample(size=length(RS), 1:numj, replace=TRUE));
        Listjk = rbind(Listjk, RLS);
        if(!is.null(RIR)) {
          InRandomEffects = rbind(InRandomEffects, RIR);
        }
        if (!is.null(RIF)) {
          InFixedEffects = rbind(InFixedEffects, RIF);
        }
      }
    }
  } else if (!is.null(InBalance) && 
    length(InBalance) == 2 && all( InBalance != c(0,0)) ) {
    NFull = numj^2;  
    if (YesSex == TRUE) {
      NFull = NFull * 2;
    }
    SimAmount = ceiling(NumRepetitions * NFull);
    ProbSimulate = dbeta( 1:numj / (1+numj), InBalance[1], InBalance[2]);
    jList = sample(size = SimAmount, 1:numj, 
      prob = ProbSimulate, replace=TRUE);
    kList = sample(size = SimAmount, 1:numj, 
      prob = ProbSimulate, replace=TRUE);
    Listjk = cbind(jList, kList);
    if (YesSex == TRUE) {
      SexVector = rbinom(SimAmount, 1, .5);
    } else {
      SexVector = NULL;
    }
    ##print("Here we are: We've got Listjk = "); print(Listjk);
  } else if (NumRepetitions %% 1 == 0) {
    jList = rep(1:numj, each = numj);
    kList = rep(1:numj, numj); SexVector = NULL;
    if (YesSex == TRUE) {
      jList = c(jList, jList);  kList = c(kList, kList);
      SexVector = c(rep(0, numj^2), rep(1, numj^2));
    }
    tjList = jList;  tkList = kList;  tSexVector = SexVector;
    if (NumRepetitions > 1) {
      for (ii in 2:NumRepetitions) {
        jList = c(jList, tjList);  kList = c(kList, tkList);
        SexVector = c(SexVector, tSexVector);
      }
    }
    Listjk = cbind(jList, kList);
  }  else {
    SexVector = NULL; Listjk = NULL;
  }
  if (exists("SexVector") && !is.null(SexVector) &&
     length(SexVector) == length(Listjk[,1])) {
    YesSex = TRUE;   
  }
  if (!is.null(Listjk)) { numj = length(unique(as.vector(Listjk))); }
  ListAddFunctions = c("SetupSimulteMethods", "SetupFilledSimulatedListjk");
  ListAddElements = c("Y", "X", "YesSex", "InBalance", 
    "MyFullDiallelName", "strain.map");
  extend(FullDiallel(numj = numj,
    Indf = RConstantsList(5, StartRandomEffects=dfRandomEffects),
    Inm = RConstantsList(10, StartRandomEffects=mRandomEffects),
    IntauFixed=FConstantsList(5, tauFixedEffects=tauFixedEffects),
    InSexVector = SexVector, InListjk = Listjk,
    InRandomEffects=InRandomEffects, InFixedEffects=InFixedEffects,
    ListAddFunctions = ListAddFunctions, ListAddElements = ListAddElements,
    phenotype.name = phenotype.name, DoFirstCenter = DoFirstCenter), 
    "FullDiallelSimulate",
    .NumRepetitions = NumRepetitions, ADiallelOb = NULL,
    Y = NULL, X = NULL, YesSex = YesSex, InBalance = InBalance,
     MyFullDiallelName =  MyFullDiallelName, strain.map = strain.map,
     LogTransformedFlag = FALSE, SqrtTransformedFlag = FALSE  
  );
})

#################################################################
##  finalize DiallelOb object
##
setMethodS3("finalize", "DiallelOb", function(this, Verbose = -1, ...) {
  if (( !is.numeric(Verbose) && Verbose ==TRUE ) || 
      (is.numeric(Verbose) && Verbose > 0)) {
    this$Verbose = 5; 
    try(print(paste("finalize: Killing a DiallelOb with aj=", 
      ajModel = this$.ajModel, ", MM=", this$.MotherModel,
      " CM=", this$.CrossModel, " SM=", this$.SexModel,
      " BHL=", this$.BetaInbredLevel, sep="")));
    flush.console(); 
  }
  this$Beta = NULL;  this$CodaChains = NULL;
  this$.numj = NULL; 
  this$.ajModel = NULL;
  this$.MotherModel = NULL;
  this$.BetaInbredLevel = NULL;
  this$.CrossModel  = NULL;
  this$.SexModel = NULL;
  this$.BetaInbredTimesSex = NULL;
  this$XSubSetList = NULL;
  this$GotList = NULL; 
  this$tauCrosses = NULL; 
  this$tauCrossName = NULL;
  this$DpBeta = NULL;
  this$tauFixed = NULL;
  this$tau = NULL;
  this$Sigma = NULL;
  this$MyWantDiag = NULL;
  this$CodaChains = NULL;
  this$T1 = NULL; this$T2 = NULL; this$NetBetas = NULL;
  this$dfTNoise = NULL;
  this$PostKeeper = NULL; this$GXX = NULL;
  this$ListUnknownGender = NULL; this$FakeGenderChain=NULL; 
  if (!is.null(this$.AFD)) {
    if (!is.null(this$.AFD$.iOb)) {
  ##    if (!is.null(this$.AFD$AllDiallelObs) && is.list(this$.AFD$AllDiallelOBs)) {
  ##      try(this$.AFD$AllDiallelObs[[this$.iOb]] <- NULL, silent=TRUE);
  ##    }
      this$.AFD$.iOb = NULL;
    }
    this$.AFD = NULL;
  }   
  return();
});

setMethodS3("Copy", "DiallelOb", function(this, NewAFD = NULL, iOb = NULL, ...) {
 if (!exists("NewAFD")) { NewAFD = NULL; }
 if (!exists("iOb")) { iOb = NULL; }
 NR = DiallelOb(numj = this$.numj, ajModel = this$.ajModel,
   MotherModel = this$.MotherModel, CrossModel = this$.CrossModel, 
   SexModel = this$.SexModel, BetaInbredLevel = this$.BetaInbredLevel,
   BetaInbredTimesSex = this$.BetaInbredTimesSex, dfTNoise = this$dfTNoise,
   AFD = NewAFD, iOb = iOb, 
   DoFirstCenter = this$DoFirstCenter);
  NN = names(this);
  
  ## NR$aj = this$aj; NR;motherj = this$motherj;  NR$Gendmotherj = this$Gendmotherj;
  for (ii in 1:length(NN)) {
    if (NN[ii] == "CodaChains") {
      NewL = list();
      for (jj in 1:length(this$CodaChains)) {
        NewL[[jj]] = as.mcmc(this$CodaChains[[jj]]);
      }
      try(NewL <- as.mcmc.list(NewL), silent=TRUE);
      NR$CodaChains = NewL;
    } else if (NN[ii] == "ImputedYChains") {
      if (is.null(this$ImputedYChains)) {
      
      } else {
        NewL = list();
        for (jj in 1:length(this$ImputedYChains)) {
          NewL[[jj]] = as.mcmc(this$ImputedYChains[[jj]]);
        }
        try(NewL <- as.mcmc.list(NewL), silent=TRUE);
        try(NR$ImputedYChains <- NewL);
      }
    } else if (NN[ii] == "ImputeGenderChains") {
      if (is.null(this$ImputeGenderChains)) {
      
      } else {
        NewL = list();
        for (jj in 1:length(this$ImputeGenderChains)) {
          NewL[[jj]] = as.mcmc(this$ImputeGenderChains[[jj]]);
        }
        try(NewL <- as.mcmc(NewL), silent=TRUE);
        NR$ImputeGenderChains <- NewL;
      }
    } else if (NN[ii] == "UnknownGenderCoda") {
       if (is.null(this$UnknownGenderCoda)) {
      
      } else {
        NewL = list();
        for (jj in 1:length(this$UnknownGenderCoda)) {
          NewL[[jj]] = as.mcmc(this$UnknownGenderCoda[[jj]]);
        }
        try(NewL <- as.mcmc(NewL), silent=TRUE);
        NR$UnknownGenderCoda <- NewL;
      }
    } else if (!(NN[ii] %in% c(".AFD", ".iOb"))) {
      NT = paste("NR$", NN[ii], " <- Copy(this$", NN[ii], ")", sep="");
      eval(parse(text=NT));
    }
  }
  return(NR);
});

setMethodS3("Copy", "CrossLocations", function(this,...) {
 NR = CrossLocations(numj = this$.numj);   
  ## NR$aj = this$aj; NR;motherj = this$motherj;  NR$Gendmotherj = this$Gendmotherj;
  NN = names(this);
  for (ii in 1:length(NN)) {
    NT = paste("NR$", NN[ii], " <- Copy(this$", NN[ii], ")", sep="");
    eval(parse(text=NT));    
  }
  return(NR);
});

setMethodS3("finalize", "CrossLocations", function(this,...) {
    this$.numj = NULL;
    this$jCross = NULL;
    this$kCross = NULL;
    this$idCross = NULL;
    this$KDAlt = NULL;
    this$jCrossO = NULL;
    this$kCrossO = NULL;
    this$idCrossO = NULL;
    this$KDAll = NULL;
    return;  
});

setConstructorS3("CrossLocations", function(numj = defaultnumj) {
  if (length(numj) != 1 || numj <= 0)
    throw("Well CrossLocations: numj is invalid");
    
  jCross = matrix(rep(1:numj, numj), numj, numj);
  jCross = jCross[lower.tri(jCross)];
  jCross = c(1:numj, jCross);
  kCross = t(matrix(rep(1:numj, numj), numj, numj));
  kCross = kCross[lower.tri(kCross)];
  kCross = c(1:numj, kCross);
  idCross = 1:length(kCross);
  KDAlt = matrix(0,numj, numj);
  diag(KDAlt) = 1:numj;
  KDAlt[cbind(jCross, kCross)] = idCross;
  KDAlt[cbind(kCross, jCross)] = idCross;
  
  jCrossO = matrix(rep(1:numj, numj), numj, numj);
  jCrossO = jCrossO[lower.tri(jCrossO)];
  kCrossO = t(matrix(rep(1:numj, numj), numj, numj));
  kCrossO = kCrossO[lower.tri(kCrossO)];
  idCrossO = 1:length(kCrossO);
  
  KDAll = matrix(0, numj, numj);
  diag(KDAll) = 1:numj;
  KDAll[lower.tri(KDAll)] = numj + idCrossO;
  KDAll[upper.tri(KDAll)] = numj*(numj+1)/2 + idCrossO;   
  extend(Object(), "CrossLocations",
     .numj = numj,
     jCross = jCross,
     kCross = kCross,
     idCross = idCross,
     KDAlt = KDAlt,
     jCrossO = jCrossO,
     kCrossO = kCrossO,
     idCrossO = idCrossO,
     KDAll = KDAll  
  );
});


DimObject <- function(MaybeMatrix) {
  if (is.null(MaybeMatrix)) { return(0); }
  if (length(dim(MaybeMatrix)) == 2) {
     return(length(MaybeMatrix[1,]));
  }  else {
     return(1);
  }
}

setMethodS3("defaultSimulateParam", "FullDiallelSimulate", function(this, ...) {
	this$df$aj = 2; this$df$motherj = 2; this$df$GM = 2;
	this$m$aj = 10; this$m$motherj =  10; this$m$GM = 5*this$df$GM;
	this$df$GMaj = sqrt(this$df$aj * this$df$GM); this$m$GMaj = this$df$GMaj;
	this$df$Gendermotherj = 5; this$m$Gendermotherj = 5 * .75;
	this$df$dominancej = 10; this$m$dominancej = 10 * 5;
	this$df$Genderdominancej = 20; this$m$Genderdominancej = 0;
	this$df$cross = 1; this$m$cross = 5; 
	this$df$AllCrossjk = 5; this$m$AllCrossjk = 5 * 2;
	this$df$GenderAllCrossjk = 5; this$m$GenderAllCrossjk = 5 * 2;	
	this$df$SymCrossjk = 4; this$m$SymCrossjk = 4 * 2;
	this$df$GenderSymCrossjk = 4; this$m$GenderSymCrossjk = 4 * 2;
	this$df$SymCrossajk = 5; this$m$SymCrossajk = 5 * 2;
	this$df$GenderSymCrossajk = 5; this$m$GenderSymCrossajk = 5 * 2;
	this$df$ASymCrossjkDkj = 10; this$m$ASymCrossjkDkj = 10 * .25;
	this$df$GenderASymCrossjkDkj = 10; this$m$GenderASymCrossjkDkj = 10 * .25;
	this$df$ASymCrossajkDjai = 10; this$m$ASymCrossajkDjai = 10 * .25;
	this$df$GenderASymCrossajkDjai = 10; this$m$GenderASymCrossajkDjai = 10 * .25;
	this$df$ajcross = 1; this$m$ajcross = 5;
	this$df$hybridj = 1; this$m$hybridj = 1;
	this$df$AllCrossajk = 10; this$m$AllCrossajk = 5;
	this$df$GenderAllCrossajk = 8; this$m$GenderAllCrossajk = 4;	
	this$tauFixed$tauMu = 50; this$tauFixed$tauGender = 50; this$tauFixed$tauBetaInbred = 50;
	this$tauFixed$tauBetaInbredTimesSex = 25; 
	this$df$Sigma = -1; this$m$Sigma = 1;   ## Usually simulate noise at size 1
	this$tauFixed$tauFixedEffects = rep(20, DimObject(this$FixedEffects));
	this$df$RandomEffects = rep(10, length(this$RandomEffectsGroups));
	this$m$RandomEffects = rep(10, length(this$RandomEffectsGroups));		
  ##this$df$FixedEffects = 10; this$m$FixedEffects = 10;
  ##this$df$RandomEffects = 10; this$m$RandomEffects - 10;
})


setMethodS3("LenBetaUse", "DiallelOb", function(this,AFD,...) {
   KV1 = NULL;
   if (this$.BetaInbredLevel %in% c(2,3)) {
        KV1 = (fLenBetaAllListHybridTrue(numj = this$.numj)); 
   } else {
        KV1 = (fLenBetaAllListHybridFalse(numj = this$.numj));    
   }
   OT = 4;
   if (!is.null(AFD$FixedEffects)) {
     placer =  rep(1,DimObject(AFD$FixedEffects))
     names(placer) = colnames(AFD$FixedEffects);
     KV1 = c(KV1[1:4], placer, KV1[5:length(KV1)]);
     OT = 4 + DimObject(AFD$FixedEffects);
   } 
   if (!is.null(AFD$RandomEffects)) {
     if (is.null(AFD$RandomEffectsGroups)) {
       print("Random Effects Cannot work Because of bad RandomEffectsGroups");
       return(-1);
     }
     KV1 = c(KV1[1:OT],AFD$RandomEffectsGroups,KV1[(OT+1):length(KV1)]);
   }
   return(KV1);
});


setMethodS3("SetupFilledSimulatedListjk", "FullDiallelSimulate",
  function(this, numj = NULL, NumRepetitions = NULL,
           YesSex = NULL, InBalance = c(0,0), ...) {
  if ( is.null(this$FixedEffects) && is.null(this$RandomEffects) ) {
    if (is.null(YesSex) && is.null(this$YesSex)) {
      YesSex = TRUE; this$YesSex = TRUE;
    }
    if (is.null(YesSex)) {
      YesSex = this$YesSex;
    }
    if (is.null(this$YesSex)) {
      this$YesSex = YesSex;
    }
  }
  if (!is.null(numj) && length(numj) == 1) {
    this$.numj = numj;
  } else if (is.null(this$.numj) && is.null(numj)) {
    this$.numj = defaultnumj;
  } else if (is.null(this$.numj)) {
    this$.numj = defaultnumj;
  }  else if (this$.numj <= 0 || !is.numeric(this$.numj)) {
    this$.numj = defaultnumj;
  }
  if (!is.null(NumRepetitions)) {
    this$.NumRepetitions = NumRepetitions;
  } else if (is.null(this$.NumRepetitions) && is.null(NumRepetitions)) {
    this$.NumRepetitions = defaultNumRepetitions;
  }  
     
  if (!is.null(InBalance) && length(InBalance)==2 && all(InBalance != c(0,0))) {
    this$.InBalance = InBalance
  }
  if (!is.null(this$FixedEffects) || !is.null(this$RandomEffects)) {
    MySize = max(length(this$RandomEffects), length(this$FixedEffects));
    RM1 = sample(size=MySize, 1:numj, replace=TRUE); 
    RM2 = sample(size=MySize, 1:numj, replace=TRUE);
    if (YesSex  == FALSE) { 
      Listjk = cbind (RM1, RM2);
    } else {
      Listjk =  rbind(cbind(RM1, RM2), 
        cbind(RM1, RM2) );
      SexVector = c(rep(0, length(RM1)), rep(1, length(RM1)));
    }
    this$SexVector = SexVector;  this$Listjk = this$Listjk;
  } else if (this$.NumRepetitions %% 1 != 0) {
    NFull = (this$.numj)^2;
    if (this$YesSex != FALSE) {
      NFull = NFull * 2;
    } 
    if (!is.null(this$InBalance) && 
      length(this$InBalance) ==2 && all(this$InBalance != c(0,0)) ) {
       ProbList = dbeta( (1:this$.numj)/ (this$.numj+1), 
         InBalance[1], InBalance[2]);    
    } else {
       ProbList = rep(1, this$.numj);
    }
    jList = sample(1:this$.numj, size = NFull * this$.NumRepetitions, prob = ProbList, replace=TRUE);
    kList = sample(1:this$.numj, size = NFull * this$.NumRepetitions, prob = ProbList, replace=TRUE);
    Listjk = cbind(jList, kList);
    this$Listjk = Listjk
    if (this$YesSex != FALSE) {
      this$SexVector = rbinom(NFull* this$.NumRepetitions, 1, .5);
    }
  } else if (!is.null(InBalance) && 
    length(InBalance) == 2 && all( InBalance != c(0,0)) ) {
    NFull = this$.numj^2;  
    if (YesSex == TRUE) {
      NFull = NFull * 2;
    }
    SimAmount = ceiling(NumRepetitions * NFull);
    ProbSimulate = dbeta( 1:this$.numj / (1+this$.numj), InBalance[1], InBalance[2]);
    jList = sample(size = SimAmount, 1:numj, 
      prob = ProbSimulate, replace=TRUE);
    kList = sample(size = SimAmount, 1:numj, 
      prob = ProbSimulate, replace=TRUE);
    Listjk = cbind(jList, kList);
    if (YesSex == TRUE) {
      SexVector = rbinom(SimAmount, 1, .5);
    } else {
      SexVector = NULL;
    }
    ##print("Here we are: We've got Listjk = "); print(Listjk);
  } else if (NumRepetitions %% 1 == 0) {
    jList = rep(1:this$.numj, each = this$.numj);
    kList = rep(1:this$.numj, this$.numj); SexVector = NULL;
    if (YesSex == TRUE) {
      jList = c(jList, jList);  kList = c(kList, kList);
      SexVector = c(rep(0, this$.numj^2), rep(1, this$.numj^2));
    }
    tjList = jList;  tkList = kList;  tSexVector = SexVector;
    if (NumRepetitions > 1) {
      for (ii in 2:NumRepetitions) {
        jList = c(jList, tjList);  kList = c(kList, tkList);
        SexVector = c(SexVector, tSexVector);
      }
    }
    Listjk = cbind(jList, kList);
  }  else {
    SexVector = NULL; Listjk = NULL;
  }
});

setMethodS3("SetupSimulateMethod", "FullDiallelSimulate", function(
      this, ajModel = 1, MotherModel = 0, CrossModel = 0, SexModel = 0,
       BetaInbredLevel = 0, BetaInbredTimesSex = 0, dfTNoise = NULL, 
       ParamVec = NULL, Sigma = defaultSigma, ...) {
HH = FALSE;
if (!is.null(ParamVec) && !is.null(names(ParamVec)) &&
  any(names(ParamVec) %in% BayesDiallel:::.DefaultAllRandomVariables |
    names(ParamVec) %in% BayesDiallel:::.DefaultAllFixedVariables) ) {
  if (!is.null(this$Verbose) && this$Verbose > 1) {
    print("SetupSimulateMethod: We got a non-null ParamVec"); flush.console();
  }
  HH = TRUE;
  if (any(substr(names(ParamVec), 1, 2) == "aj")) {
    ajModel = 1;
    if (this$DoFirstCenter == TRUE && 
        length(ParamVec[substr(names(ParamVec), 1, nchar("aj")) == "aj"]) == 
      this$.numj) {
      ParamVec <- KillFromMeOneThis(ParamVec, "aj");    
    }
  }
  if (any(substr(names(ParamVec), 1, 6) == "mother")) {
    MotherModel = 1;
    if (this$DoFirstCenter == TRUE && 
        length(ParamVec[substr(names(ParamVec), 1, nchar("mother")) == "mother"]) == 
      this$.numj) {
      ParamVec <- KillFromMeOneThis(ParamVec, "mother");    
    }
  }
  if (any(substr(names(ParamVec), 1, 10) == "BetaInbred")) {
    BetaInbredLevel = 1;     CrossModel = 1;
  }
  if (any(substr(names(ParamVec), 1, 17) == "Gender:BetaInbred")) {
    BetaInbredTimesSex = 1;  CrossModel = 2;
  } 
  if (any(substr(names(ParamVec), 1, 6) == "Gender")) {
    SexModel = 1;
  }
  if (any(substr(names(ParamVec), 1, 13) == "Gender:mother")) {
    SexModel = 2;
    if (this$DoFirstCenter == TRUE && 
        length(ParamVec[substr(names(ParamVec), 1, nchar("Gender:mother")) == "Gender:mother"]) == 
      this$.numj) {
      ParamVec <- KillFromMeOneThis(ParamVec, "Gender:mother");    
    }
  }  
  if (any(substr(names(ParamVec), 1, nchar("dominance")) == "dominance")) {
    SexModel = 3;
    if (this$DoFirstCenter == TRUE && 
        length(ParamVec[substr(names(ParamVec), 1, nchar("dominance")) == "dominance"]) == 
      this$.numj) {
      ParamVec <- KillFromMeOneThis(ParamVec, "dominance");    
    }
  }   
  if (any(substr(names(ParamVec), 1, 16) == "Gender:dominance")) {
    SexModel = 3;
    if (this$DoFirstCenter == TRUE && 
        length(ParamVec[substr(names(ParamVec), 1, nchar("Gender:dominance")) == "Gender:dominance"]) == 
      this$.numj) {
      ParamVec <- KillFromMeOneThis(ParamVec, "Gender:dominance");    
    }
  }   
  if (any(substr(names(ParamVec), 1, 3) == "Sym")) {
    CrossModel = 2;
    if (this$DoFirstCenter == TRUE && 
        length(ParamVec[substr(names(ParamVec), 1, nchar("Sym")) == "Sym"]) == 
      this$.numj * (this$.numj-1) / 2) {
      ParamVec <- KillFromMeOneThis(ParamVec, "Sym");    
    }
  }     
  if (any(substr(names(ParamVec), 1, 10) == "Gender:Sym")) {
    CrossModel = 2; SexModel = 6;
    if (this$DoFirstCenter == TRUE && 
        length(ParamVec[substr(names(ParamVec), 1, nchar("Gender:Sym")) == "Gender:Sym"]) == 
      this$.numj * (this$.numj-1) / 2) {
      ParamVec <- KillFromMeOneThis(ParamVec, "Gender:Sym");    
    }
  }   
  if (any(substr(names(ParamVec), 1, 4) == "ASym")) {
    CrossModel = 5;
    if (this$DoFirstCenter == TRUE && 
        length(ParamVec[substr(names(ParamVec), 1, nchar("ASym")) == "ASym"]) == 
      this$.numj * (this$.numj-1) / 2) {
      ParamVec <- KillFromMeOneThis(ParamVec, "ASym");    
    }
  } 
  if (any(substr(names(ParamVec), 1, 10) == "Gender:ASym")) {
    CrossModel = 2; SexModel = 7;
    if (this$DoFirstCenter == TRUE && 
        length(ParamVec[substr(names(ParamVec), 1, nchar("Gender:ASym")) == "Gender:ASym"]) == 
      this$.numj * (this$.numj-1) / 2) {
      ParamVec <- KillFromMeOneThis(ParamVec, "Gender:ASym");    
    }
  } 
  if (any(substr(names(ParamVec), 1, 6) == "AllSym")) {
    CrossModel = 8;
    if (this$DoFirstCenter == TRUE && 
        length(ParamVec[substr(names(ParamVec), 1, 6) == "AllSym"]) == 
      this$.numj * this$.numj -this$.numj) {
      ParamVec <- KillFromMeOneThis(ParamVec, "AllSym");    
    }
  } 
  if (any(substr(names(ParamVec), 1, 12) == "Gender:AllSym")) {
    CrossModel = 8; SexModel = 7;
  } 
}
  if (!is.null(this$Sigma) && this$Sigma > 0) {
    if (Sigma == defaultSigma) {
    
    } else if (Sigma > 0) {
      names(Sigma) = "Sigma:1"
      this$Sigma = Sigma;
    }
  } else if (Sigma < 0) {
    print("SetupSimultion: Supply realistic Sigma"); flush.console();
  } else {
    names(Sigma) = "Sigma:1";
    this$Sigma = Sigma;
  }
  if (!is.null(dfTNoise)) { this$dfTNoise = dfTNoise; }
  if (SexModel > 0 && (is.null(this$YesSex) || this$YesSex == FALSE ||
    is.null(this$SexVector))) {
    print("SetupSimulateMethod: We can't generate Gendered Model without Gender Data");
    this$ADiallelOb = NULL;
    tryCatch("SetupSimulateMethod:  That's an Error we found!")
    return;
  }
  this$ADiallelOb = DiallelOb(numj=this$.numj, ajModel=ajModel, 
    MotherModel=MotherModel, CrossModel=CrossModel, 
    SexModel=SexModel, BetaInbredLevel=BetaInbredLevel, 
    BetaInbredTimesSex=BetaInbredTimesSex, 
    dfTNoise = this$dfTNoise, AFD = this, iOb = 1,
    DoFirstCenter = this$DoFirstCenter);
  this$ADiallelOb$Sigma = this$Sigma;
  if (!is.null(this$Verbose) && this$Verbose > 2) {
    Verbose = TRUE;
  } else {Verbose = FALSE;}
  this$X = ConstructXJK(numj = this$.numj, ajModel = this$ADiallelOb$.ajModel, 
    CrossModel = this$ADiallelOb$.CrossModel, 
    SexModel = this$ADiallelOb$.SexModel, 
    MotherModel=this$ADiallelOb$.MotherModel, 
    BetaInbredLevel=this$ADiallelOb$.BetaInbredLevel, 
    BetaInbredTimesSex = this$ADiallelOb$.BetaInbredTimesSex, 
    SexVector=this$SexVector, Listjk=this$Listjk,
    CO=this$ACrossLocations, FixedEffects=this$FixedEffects,
    RandomEffects=this$RandomEffects, Verbose=Verbose, 
    DoFirstCenter = this$DoFirstCenter); 
  CreateGotList(this$ADiallelOb, XColNames=colnames(this$X),
    Im =this$m, Idf = this$df, tauFixedAll = GettauFixedAll(this$tauFixed),
    RandomEffectsGroups = this$RandomEffectsGroups,
    FixedEffects = this$FixedEffects, RandomEffects = this$RandomEffects,
    AFD = this, Sigma = this$Sigma);
  if (!is.null(ParamVec) && HH == TRUE) {
    this$ADiallelOb$Beta = ParamVec;
  }
});


setMethodS3("SetupAnalysisEM", "FullDiallelEMAnalyze", function(
           this, ModelsList, numChains = defaultnumChains, 
           lengthChains = 100, 
            Sigma = defaultSigma, cauchy.delta = .01, dfTNoise = NULL, ...) {
      if (!is.null(dfTNoise)) { this$dfTNoise = dfTNoise; }
      SetupAnalysisMethods(this, ModelsList, numChains, lengthChains, Sigma,
        dfTNoise = this$dfTNoise);
      this$cauchy.delta = cauchy.delta;      
});


setMethodS3("GiveAllModelsBeta", "FullDiallel", function(
  this, ModelsList, Verbose=FALSE,...) {
  MaxOverAll = FindMaximizerTable(ModelsList);
  if (!is.null(dim(ModelsList)) && length(dim(ModelsList)) == 2) {
    CrossModelsList = NULL;
    NewText = "
    try(CrossModelsList <- sort(unique(ModelsList[,3])), silent=TRUE);
    if (is.null(CrossModelsList)) { try(CrossModelsList <- ModelsList[3]);} ";
    try(eval(parse(text=NewText)));
  } else {
    NewText=" try(CrossModelsList <- ModelsList[3]) ";
    try(eval(parse(text=NewText)));
  }
  if (Verbose == FALSE  && !is.null(this$Verbose)) {
    xjkVerbose = this$Verbose
  } else {
    xjkVerbose = Verbose;
  }
  FakeX = ConstructXJK(this$.numj, ajModel = MaxOverAll[1],
    MotherModel = MaxOverAll[2],
    CrossModelsList = CrossModelsList,
    CrossModel=MaxOverAll[3], SexModel=MaxOverAll[4], 
    BetaInbredLevel=MaxOverAll[5], 
    BetaInbredTimesSex=MaxOverAll[6], SexVector = c(1,1), 
    Listjk=cbind(c(1,1),c(2,2)), 
    CO = this$ACrossLocations, FixedEffects=this$FixedEffects,
    RandomEffectsGroups = this$RandomEffectsGroups,
    RandomEffects=this$RandomEffects,
    Verbose = xjkVerbose, ALLINCLUSIVE = TRUE,
    DoFirstCenter = this$DoFirstCenter);
    
   return(colnames(FakeX)); 
});

setMethodS3("GiveAllModelsTau", "FullDiallel", function(
  this, ModelsList, Verbose=FALSE,...) {

   return(names(this$ADiallelOb$tau)); 
});

###############################################################################
##  SetupAnalysisMethods
##
##   After Creating FullDiallelAnalyze, setup all of the Diallel Models to 
##   try to examine with this function
##
setMethodS3("SetupAnalysisMethods", "FullDiallelAnalyze", function(
           this, ModelsList=ReadModels(MyLines=c("Fulls", "Fullu")), numChains = defaultnumChains, 
           lengthChains = defaultlengthChains, 
           Sigma = defaultSigma,dfTNoise=NULL, WeightsKeepFlag = FALSE, 
           Verbose = 0, Wanted=NULL, Extractor=NULL,...) {
  
  if (!exists("Verbose") || is.null(Verbose) ||!is.numeric(Verbose)) {
   Verbose = 0;
  }   
  Verbose = Verbose;       
  if (Verbose > 0) {
    print("SetupAnalysisMethods: at very beginning "); flush.console();
  }
  if (length(ModelsList) < 6) {
    print("ModelsList for Analysis Not Long Enough, Give some Models!");
    return(-1);
  }
  if (Verbose > 0) {
    print("SetupAnalysisMethods: well, we're not less than zero"); flush.console();
  }
  if (Verbose == 0) {
    if (!is.null(this$Verbose) && this$Verbose > 0) {
      Verbose = this$Verbose;
    }
  }
  if (Verbose > 0) {
    print("Does Verbose exist in global environment?  Who cares?"); flush.console();
  }
  if (Verbose > 0) {
    if (!is.null(Extractor)) {
      print("SetupAnalysisMethods: Extractor is non Null, wonder what we'll do?"); flush.console(); 
    } else if (!is.null(Wanted)) {
      print(paste("SetupAnalysisMethods: ",
        "Wanted is not null, is length ", length(Wanted), ", will use.", sep=""));
    }
  }
  OndfTNoise = -1;
  if (!is.null(dfTNoise)) { OndfTNoise = dfTNoise[1]; } 
  ##if (!exists("Verbose", globalenv()) ) {Verbose = -1;}
  if (Verbose > 0) {
    print("SetupAnalysisMethods: Starting");  flush.console(); 
  }
  if (length(ModelsList) == 7) {
    dfTNoise = ModelsList[7];
    ModelsList = ModelsList[1:6];
    ModelsList = matrix(ModelsList,1,6)
  } else if (!is.null(dim(ModelsList)) && dim(ModelsList)[2] == 7) {
    dfTNoise = ModelsList[,7];
    ModelsList = ModelsList[,1:6];
  } else if (length(dfTNoise) == 1 && length(dim(ModelsList)) == 2) {
    dfTNoise = rep(dfTNoise, dim(ModelsList)[1]);
  }
  this$ModelsList = ModelsList;
  OndfTNoise = -1;
  if (!is.null(dfTNoise)) { OndfTNoise = dfTNoise[1]; } 
  if (Verbose > 0) {
    print("SetupAnalysisMethods: We just got past ModelsList shapes of 7");
    flush.console();
  }
  if (length(ModelsList) == 6) {
  } else if (!is.null(dim(ModelsList)) && dim(ModelsList)[2] != 6) {
    print(paste("SetupAnalysisMethods: error, dim(ModelsList) after work is (",
      paste(dim(ModelsList), collapse=", "), ")", sep="")); flush.console();
  } else if (!is.null(dim(ModelsList)) && dim(ModelsList)[2] == 6) {
  } else if (is.null(dim(ModelsList))) {
    print(paste("ModelsList has no dimension but is of bad length ", 
      length(ModelsList), sep="")); flush.console();
  } else {
    print("ModelsList is screwed up!");
  }
  if (Verbose > 0) {
    print("SetupAnalysis Methods: we got it down to ModelsList = ");
    print(ModelsList); flush.console();
  }
  if (is.null(this$YesSex) || this$YesSex == FALSE ||
    is.null(this$SexVector)) {
    if (is.null(dim(ModelsList)) || length(dim(ModelsList)) < 2) {
      if (ModelsList[4] > 0  || ModelsList[6] > 0) {
      print("SetupAnalysisMethods:  Issue, we don't have gender data ");
      print(" And we cannot fit gendered models");
      print(" We are shortening the models list as a result!")
      ModelsList[4] = 0;  ModelsList[6] = 0;
      tryCatch("Error: Give me Non-Gendered Models!")      
      }
    } else if (max(ModelsList[,4]) > 0 ||
      max(ModelsList[,6]) > 0 ) {
      print("SetupAnalysisMethods:  Issue, we don't have gender data ");
      print(" And we cannot fit gendered models");
      print(" We are shortening the models list as a result!")
      ModelsList[,4] = 0;  ModelsList[,6] = 0;
      tryCatch("Error: Give me Non-Gendered Models!")
    }
  }
  if (Verbose > 1) {
    print("SetupAnalysisMethods: FindingMaximizerTable of ModelsList"); 
    flush.console();   
  } 
  MaxOverAll = FindMaximizerTable(ModelsList, Verbose = Verbose);
  if (!IsInBunch(MaxOverAll, ModelsList)) {
    ModelsList = rbind(MaxOverAll, ModelsList);
  }
  if (is.null(dfTNoise)) {
    OndfTNoise = -1;
  } else if (!is.null(dfTNoise) && length(dfTNoise) == 1 && dfTNoise > 0) {
    this$dfTNoise = dfTNoise;
    OndfTNoise = dfTNoise;
  } else if (!is.null(dfTNoise) && length(dfTNoise) > 1) {
    this$dfTNoise = dfTNoise;
     OndfTNoise = dfTNoise;
  }

  if (Verbose > 1) {
    print("SetupAnalysisMethods: Constructing Maxmimizer's X"); 
    flush.console();   
  } 
  if (Verbose > 3) {
    print("SetupAnalysisMethods: We'll show ConstructXJK's Verbose");
    flush.console();
    xjkVerbose = TRUE;
  }  else { xjkVerbose = FALSE;}
  if (!is.null(dim(ModelsList)) && length(dim(ModelsList)) == 2) {
    CrossModelsList = NULL;
    NewText="
    try(CrossModelsList <- sort(unique(ModelsList[,3])));
    if (is.null(CrossModelsList)) {
      try(CrossModelsList  <- ModelsList[3]);
    } ";
    try(eval(parse(text=NewText)));
  } else {
    NewText="
    try(CrossModelsList <- ModelsList[3]) ";
    try(eval(parse(text=NewText)));
  }
  ASexVector = this$SexVector;
  if (!is.null(ASexVector) && length(ASexVector) >= 1) {
    if (!is.null(ASexVector) && any(is.na(ASexVector))) {
      ASexVector[is.na(ASexVector)] = 1;
    }
  }
  this$X = ConstructXJK(this$.numj, ajModel = MaxOverAll[1],
    MotherModel = MaxOverAll[2],
    CrossModelsList = CrossModelsList,
    CrossModel=MaxOverAll[3], SexModel=MaxOverAll[4], 
    BetaInbredLevel=MaxOverAll[5], 
    BetaInbredTimesSex=MaxOverAll[6], SexVector = ASexVector, 
    Listjk=this$Listjk, 
    CO = this$ACrossLocations, FixedEffects=this$FixedEffects,
    RandomEffectsGroups = this$RandomEffectsGroups,
    RandomEffects=this$RandomEffects,
    Verbose = xjkVerbose, ALLINCLUSIVE = TRUE,
    DoFirstCenter = this$DoFirstCenter) 
  if (Verbose > 1) {
    print("SetupAnalysisMethods: to allocate AllDiallelObs");
     flush.console();
  }
  this$AllDiallelObs = list();
  if (length(ModelsList) == 6) {
    if (length(this$dfTNoise) > 1) {
      OnDfTNoise = this$dfTNoise[1];
    } else {
      OnDfTNoise = this$dfTNoise;
    }
    if (Verbose > 1) {
      print(paste("SetupAnalysisMethods: OnDfTNoise = ", OnDfTNoise, sep=""));
       flush.console();
    }    
    if (Verbose > 1) {
      print(paste("SetupAnalysisMethods: Creating single AllDiallelObs", sep=""));
       flush.console();
    }
    this$OnObs = 1;
    this$AllDiallelObs[[1]] = DiallelOb( numj = this$.numj,
      ajModel = ModelsList[1], 
      MotherModel = ModelsList[2],
      CrossModel = ModelsList[3],
      SexModel = ModelsList[4],
      BetaInbredLevel = ModelsList[5],
      BetaInbredTimesSex = ModelsList[6],
      dfTNoise = OnDfTNoise, AFD = this, iOb = 1,
      DoFirstCenter = this$DoFirstCenter)
      
    if (Verbose > 1) {
      print(paste("SetupAnalysisMethods: Creating GotList", sep=""));
       flush.console();
    } 
    CreateGotList(this$AllDiallelObs[[1]], 
      XColNames=  colnames(this$X),
      Im =this$m, Idf = this$df, 
      tauFixedAll =   GettauFixedAll(this$tauFixed),
      Sigma = Sigma,FixedEffects=this$FixedEffects,
      RandomEffects=this$RandomEffects,
      RandomEffectsGroups = this$RandomEffectsGroups, 
      AFD = this);
    if (Verbose > 1) {
      print(paste("SetupAnalysisMethods: Setup Chains", sep=""));
       flush.console();
    } 
    SetupChains(this$AllDiallelObs[[1]], AFD=this, numChains,
      lengthChains, Wanted=Wanted, Extractor=Extractor)
     SetupWeights(this, OndfTNoise, WeightsKeepFlag);   
  } else {
     if (Verbose > 1) {
      print(paste("SetupAnalysisMethods:  length(ModelsList[,1]) = ", 
        NROW(ModelsList), sep=""));
      print(" Going to Loop and Create");
       flush.console();
    } 
    for (iii in 1:NROW(ModelsList))  {
      if (Verbose > 2) {
        print(paste("SetupAnalysisMethods: On model iii: ", iii, 
          " which is ", paste(ModelsList[iii,], collapse=", "), sep=""));
        flush.console();           
      }
      if (is.null(dfTNoise)) {
        OndfTNoise = -1;
      } else if (length(dfTNoise) == 1 && (is.na(dfTNoise) || dfTNoise < 0)) {
        OndfTNoise = -1;
      } else if (all(is.na(dfTNoise))) {
        dfTNoise = -1;
      } else if (!all(is.na(dfTNoise)) && !is.null(dfTNoise) && length(dfTNoise) >= iii && !is.na(dfTNoise[iii]) 
        && dfTNoise[iii] >= 0) {
        OndfTNoise = dfTNoise[iii];
      } else if (length(dfTNoise) == 1 && !is.na(dfTNoise) && dfTNoise >= 0) {
        OndfTNoise = dfTNoise;
      } else {
        OndfTNoise = -1;
      }
      this$AllDiallelObs[[iii]] = DiallelOb(numj = this$.numj,
        ajModel = ModelsList[iii,1], 
        MotherModel = ModelsList[iii,2],
        CrossModel = ModelsList[iii,3],
        SexModel = ModelsList[iii,4],
        BetaInbredLevel = ModelsList[iii,5],
        BetaInbredTimesSex = ModelsList[iii,6],
        dfTNoise = OndfTNoise, AFD = this, iOb = iii,
        DoFirstCenter = this$DoFirstCenter)
      CreateGotList(this$AllDiallelObs[[iii]], 
        XColNames = colnames(this$X), Idf = this$df,              
        Im = this$m, tauFixedAll = GettauFixedAll(this$tauFixed),
        Sigma = Sigma, FixedEffects=this$FixedEffects,
        RandomEffects=this$RandomEffects,
        RandomEffectsGroups=this$RandomEffectsGroups, 
        AFD = this);    
      SetupChains(this$AllDiallelObs[[iii]], AFD=this, numChains, lengthChains, 
        Wanted=Wanted, Extractor=Extractor)         
      SetupWeights(this$AllDiallelObs[[iii]], OndfTNoise, WeightsKeepFlag); 
      this$OnObs = iii;
    } 
  }
  this$OnObs = 1;
});

setConstructorS3("PartialDiallel", function(
   SexModel = 1, CrossModel = 2, BetaInbredLevel = 1, BetaInbredTimesSex = 1,
   ...) {
   if (!is.numeric(SexModel) || SexModel < 0)
    throw("SexModel Is Off Target ", mode(balance));
   if (!is.numeric(CrossModel) || SexModel < 0)
    throw("CrossModel Is Off Target ", mode(balance));
   if (!is.numeric(BetaInbredLevel) || SexModel < 0)
    throw("BetaInbredLevel Is Off Target ", mode(balance)); 
   if (!is.numeric(BetaInbredTimesSex) || SexModel < 0)
    throw("BetaInbredTimesSex Is Off Target ", mode(balance));       
  extend(Object(), "PartialDiallel", 
    .SexModel = SexModel,
    .CrossModel = CrossModel,
    .BetaInbredLevel = BetaInbredLevel,
    .BetaInbredTimesSex = BetaInbredTimesSex
  );
});



setMethodS3("CreateGotList", "DiallelOb", function(this, XColNames,Im, Idf,tauFixedAll, Sigma = defaultSigma,
 FixedEffects=NULL, RandomEffectsGroups = NULL, RandomEffects=NULL,
 RandomEffectsGorups=NULL,
 AFD = AFD,...) {
##print("Creating GotList");
if (!exists("RandomEffectsGroups")) { RandomEffectsGroups = NULL; }
if (!exists("FixedEffects")) { FixedEffects = NULL; }
if (!exists("RandomEffects")) { RandomEffects = NULL; }
if (!exists("tauFixedAll") && exists("AFD")) {
  tauFixedAll =  GettauFixedAll(AFD$tauFixed)
}
NTF = names(tauFixedAll);
try(tauFixedAll <- as.numeric(tauFixedAll));
try(names(tauFixedAll) <- NTF);

this$.GotList <- c("Mu");
if (this$.SexModel >= 1) { 
  if (AFD$YesSex == FALSE || is.null(AFD$SexVector)) {
     print("CreateGotList:,  sorry there's no Gender for data, so not using GenderTyped Model");
     return(NULL); 
  }
  this$.GotList <- c(this$.GotList, "Gender:Av");
}
if (any(this$.BetaInbredLevel == c(1,3))) { 
  this$.GotList <- c(this$.GotList, "BetaInbred:Av") };
if (any(this$.BetaInbredLevel == c(1,3)) && this$.SexModel >=  1 && this$.BetaInbredTimesSex > 0) {
	this$.GotList <- c(this$.GotList, "BetaInbred:Gender:Av");
}
if(!is.null(FixedEffects)) {
  this$.GotList <- c(this$.GotList,colnames(FixedEffects));
}
if (!is.null(RandomEffectsGroups)) {
    this$.GotList <- c(this$.GotList, names(RandomEffectsGroups));
} 
if (this$.ajModel >= 1) {
   this$.GotList <- c(this$.GotList, "aj");
}
if (this$.SexModel >= 2) {this$.GotList <- c(this$.GotList, "Gender:aj"); }
if (this$.MotherModel >= 1) {this$.GotList <- c(this$.GotList, "motherj"); }
if (this$.MotherModel >= 1 && this$.SexModel >= 3) {
	this$.GotList <- c(this$.GotList, "Gender:motherj");
}
if (this$.BetaInbredLevel >= 2) { this$.GotList <- c(this$.GotList, "dominancej"); }
if (this$.BetaInbredLevel >= 2 && this$.SexModel >= 4) {
	this$.GotList <- c(this$.GotList, "Gender:dominancej");
}
if (this$.CrossModel >= 2 && this$.CrossModel < 8) { 
      this$.GotList <- c(this$.GotList, "SymCrossjk"); }
if (this$.CrossModel >= 2 && this$.CrossModel < 8 && this$.SexModel >= 5) {
    this$.GotList <- c(this$.GotList, "Gender:SymCrossjk");	
}
if (this$.CrossModel >= 5 && this$.CrossModel < 8) { 
       this$.GotList <- c(this$.GotList, "ASymCrossjkDkj"); }
if (this$.CrossModel >= 5 && this$.CrossModel < 8 && this$.SexModel >= 5) {
	this$.GotList <- c(this$.GotList, "Gender:ASymCrossjkDkj");	
}
if (this$.CrossModel >=8) { this$.GotList = c(this$.GotList, "AllCrossjk"); }
if (this$.CrossModel >= 8 && this$.SexModel >= 5) {
	this$.GotList <- c(this$.GotList, "Gender:AllCrossjk");	
}

##print(paste("GotList Created = ", paste(this$.GotList, sep=","), sep=""));

this$.idREALVARIABLES = AFD$.idAllVariables[ AFD$.AllVariables %in% this$.GotList ] 
this$.idRandomVariables = (1:length(AFD$.AllRandomVariables))[
  AFD$.AllRandomVariables %in% this$.GotList ];

this$mtau = ListRList(AFD$m)[this$.idRandomVariables];
this$dftau = ListRList(AFD$df)[this$.idRandomVariables];

##if(length(this$RandomEffectsGroups) > 0) {
##  this$.NotFixedVariables = c(this$.NotFixedVariables, RandomEffectsGroups);
##}
this$.TAUUseNames = AFD$.AllVariables[this$.idREALVARIABLES];

this$.idFixedVariables = (1:length(AFD$.AllFixedVariables))[
  AFD$.AllFixedVariables %in% this$.GotList ];
this$.tauFixed = tauFixedAll[ this$.idFixedVariables ];
NTF = names(this$.tauFixed);
try(this$.tauFixed <- as.numeric(this$.tauFixed));
try(names(this$.tauFixed) <- NTF);


this$XSubSetList = GiveBetaNums(XNames = XColNames, this$.GotList,
  CBetaInbredLevel = this$.BetaInbredLevel,
  CBetaInbredTimesSex = this$.BetaInbredTimesSex);
this$CollapsedXSubSetList = CollapseGotList(this$XSubSetList, this$.GotList);
this$Beta = rep(0, length(this$XSubSetList));
names(this$Beta) = XColNames[this$XSubSetList];
##this$mtau = ListRList(Im)[this$.NotFixedVariables];
##this$dftau = ListRList(Idf)[this$.NotFixedVariables];
this$NeedF = 1:max(c(1,this$CollapsedXSubSetList[this$.TAUUseNames %in% AFD$.AllFixedVariables]));

if (this$.CrossModel %in% AllTauCrossModels) {
    SetupTauCrosses(this, Im, Idf); 
}
MakeDp(this);
  ##    print("Fake Stuff");
if (length(this$Beta) != length(this$DpBeta[,1])) {
  print("Error: this$Beta and DpBeta not same size");
  print(paste("this$Beta length = ", length(this$Beta), sep=""));
  print(paste("DpBeta dim = ", paste(dim(this$DpBeta), collapse=","), ""));
  print(paste("The Model = ", paste(as.numeric(getModel(this)),
       collapse=", "), sep=""));  flush.console();
  print(paste("The length = ", length(this$XSubSetList), sep=""));
  print("One More Time");
  this$XSubSetList =  GiveBetaNums(
    XNames = XColNames, this$.GotList, PrintForFun = TRUE,
    CBetaInbredLevel = this$.BetaInbredLevel,
    CBetaInbredTimesSex = this$.BetaInbredTimesSex);
  ##quit();
}
this$tau = rep(1, length(this$mtau));
names(this$tau) = names(this$mtau);
this$Sigma = Sigma;
names(this$Sigma) = paste("Sigma:", 1:length(this$Sigma), sep="");
} );


SRD <- function(Seq, numj, StrainSeq) {
  if (is.null(Seq)) {return(StrainSeq);}
  if (length(Seq) < numj) {
    Seq = c(Seq, rep(Seq[1], numj-length(Seq))   );
    Seq = Seq - mean(Seq);
    return(Seq);
  }
  if (length(Seq) > numj) {
    return(Seq[1:numj] - mean(Seq[1:numj]));
  }
  return(Seq[1:numj]);
}
setMethodS3("SetTau", "FullDiallelSimulate", function(this, tauaj = 0,
 tauGenderaj = 0, taumotherj = 0, tauGendermotherj = 0, taudominancej=0,
 tauGenderdomianncej = 0, tauSymCrossjk = 0, tauGenderSymCrossjk = 0,
 tauASymCrossjkDkj = 0, tauGenderASymCrossjkDkj = 0,  tauAllCrossjk = 0,
 tauGenderAllCrossjk = 0, Verbose = 0,...) {
 ##if (tauaj > 0) {
 ##  if (any(names(this$tau) == "aj") {
 ##    this$tau[names(this$tau) == "aj"] = tauaj;
 ##  }
 ##}
 if (Verbose > 0) { this$Verbose = Verbose; }
 if (!is.null(this$Verbose) && this$Verbose == TRUE) {
   print("Set Tau, setting. "); flush.console();
 }
 if (is.null(this$tau)) {
   print("FullDiallelSimulate: Go back and setup tau first"); flush.console();
   return(-1);
 }
 for (ii in 1: length(BayesDiallel:::.DefaultAllRandomVariables)) {
   Stt = NULL;
   VariableL = BayesDiallel:::.DefaultAllRandomVariables[ii]; 
   try(Stt <- this$ADiallelOb$tau[[VariableL]], silent=TRUE);
   if (!is.null(Stt)) {
     MySD = strsplit(BayesDiallel:::.DefaultAllRandomVariables[ii], ":");
     MySD = paste(unlist(MySD), collapse="");
     MyTau = paste("tau", MySD, sep="");
     A = 0;
     MyTextToEval = paste("  if (exists(\"", MyTau,
      "\") && ", MyTau," > 0) {","
      this$ADiallelOb$tau[[\"", BayesDiallel:::.DefaultAllRandomVariables[ii], "\"]] = ",
      MyTau, ";}
        A = 1;", sep="");
     try(eval(parse(text=MyTexttoEval)));
     if (A == 0) {
       print(paste("SetTau: we failed when we came to ii = ", ii, 
         "  and Set = ", BayesDiallel:::.DefaultAllRandomVariables[ii],
         " and MyTau = ", MyTau, sep="")); flush.console();
     }
   }
 }
 return(1);
 });
#########################################################################
## SetBeta
##
##  Artificially Set Beta Values for a Diallel Simulator
setMethodS3("SetBeta", "FullDiallelSimulate", function(this, 
  Mu = 0, GenderMu = 0, BetaInbred =0, BetaInbredTimesGender = 0,
  SymCrossjkSequence=NULL, ASymCrossjkDkjSequence = NULL,
  GenderASymCrossjkDkjSequence = NULL, GenderSymCrossjkSequence=NULL,
  AllCrossjkSequence=NULL,   GenderAllCrossjkSequence=NULL,
  IJKVals=NULL,
  ajSequence=NULL, GenderajSequence=NULL, motherjSequence = NULL,
  GendermotherjSequence = NULL, dominancejSequence = NULL,
  GenderdominancejSequence = NULL, NewBeta = NULL, Sigma = NULL,...
  ) {
  
  if (!is.null(Sigma)) { this$Sigma = Sigma;  this$ADiallelOb$Sigma = Sigma; } else {
    Sigma = this$Sigma;
  }
  VVec = BayesDiallel:::.DefaultAllRandomVariables;
  RTVVec = rep(0,length(VVec));
  for (ii in 1:length(VVec)) {
    RTVVec[ii] = paste(unlist(strsplit(VVec[ii], ":")), collapse="");
  }
  for (ii in 1:length(VVec)) {
    RDD = RTVVec[ii];
    ATruer = FALSE;
    RText = paste("  if (!exists(\"", RDD, "Sequence\")) {
       ", RDD, "Sequence = NULL;
    } else if ( !is.null(", RDD, "Sequence) && sum(", RDD, "Sequence^2) == 0) {
       ", RDD, "Sequence = NULL;
    }", sep="");
    eval(parse(text=RText));
    MyText =paste("if (!is.null(",RDD, "Sequence)) {  ATruer=TRUE; }", sep="");
    eval(parse(text=MyText));
    if (ATruer==FALSE && !is.null(NewBeta) && length(NewBeta) > 0) {
      RTN = names(NewBeta); RTC = substr(RTN, 1, nchar(RDD));
      if (any(RTC == RDD)) {
        NTC = (1:length(RTC))[RTC == RDD];
        RText = paste(" ", RDD, "Sequence = this$ADiallelOb$Beta[NTC];" , sep="");
        eval(parse(text=RText));
      }
    } else if (ATruer==FALSE && !is.null(this$ADiallelOb$Beta) && length(this$ADiallelOb$Beta) > 0) {
      RTN = names(this$ADiallelOb$Beta);  RTC = substr(RTN, 1, nchar(RDD));
      if (any(RTC == RDD)) {
         NTC = (1:length(RTC))[RTC == RDD];
         RText = paste(" ", RDD, "Sequence = this$ADiallelOb$Beta[NTC];" , sep="");
         eval(parse(text=RText));
      }
    }
  }
  if (!is.null(NewBeta) && length(NewBeta) > 0) {
    nBeta = names(NewBeta);
    if (any(nBeta == "Mu") && (is.null(Mu) || Mu == 0)) {
      Mu = NewBeta[["Mu"]];
    }
    if (any(nBeta == "Gender:Av") && (is.null(GenderMu) || GenderMu == 0)) {
      GenderMu = NewBeta[["Gender:Av"]];
    }
    if (any(nBeta == "BetaInbred:Av") && (is.null(BetaInbred) || BetaInbred == 0)) {
      BetaInbred = NewBeta[["BetaInbred:Av"]];
    }
    if (any(nBeta == "BetaInbred:Gender:Av") && (is.null(BetaInbredTimesGender) || BetaInbredTimesGender == 0)) {
      BetaInbredTimesGender = NewBeta[["BetaInbred:Gender:Av"]];
    }
  } else if (!is.null(this$ADiallelOb$Beta)) {
    nBeta = names(this$ADiallelOb$Beta);
    if (any(nBeta == "Gender:Av") && (is.null(GenderMu) || GenderMu == 0)) {
      GenderMu = this$ADiallelOb$Beta[["Gender:Av"]];
    }
    if (any(nBeta == "BetaInbred:Av") && (is.null(BetaInbred) || BetaInbred == 0)) {
      BetaInbred = this$ADiallelOb$Beta[["BetaInbred:Av"]];
    }
    if (any(nBeta == "BetaInbred:Gender:Av") && (is.null(BetaInbredTimesGender) || BetaInbredTimesGender == 0)) {
      BetaInbredTimesGender = this$ADiallelOb$Beta[["BetaInbred:Gender:Av"]];
    }
  }
  
  BetaInbredLevel = 0;  BetaInbredLevelTimesSex = 0;
  ajModel = 0;  MotherModel = 0;  CrossModel = 0; SexModel = 0;
  if (GenderMu != 0) {SexModel = 1;}
  if (BetaInbred != 0) { BetaInbredLevel = 1; }
  if (BetaInbredTimesGender != 0) { BetaInbredLevelTimesSex = 1; }
  if (exists("ajSequence") && !is.null(ajSequence) && max(abs(ajSequence)) > 0) {ajModel = 1; }
  if (exists("GenderajSequence") &&
    !is.null(GenderajSequence) && max(abs(GenderajSequence)) > 0) {ajModel = 1; SexModel = 2;}
  if (exists("motherjSequence") && !is.null(motherjSequence) &&
    max(abs(motherjSequence)) > 0) { MotherModel = 1; }
  if (exists("GendermotherjSequence") && !is.null(GendermotherjSequence) &&
    max(abs(GendermotherjSequence)) > 0) { MotherModel = 1; SexModel = 3;}
  if (exists("dominancejSequence") && !is.null(dominancejSequence) &&
    max(abs(dominancejSequence)) > 0) { CrossModel = 1; 
    if (BetaInbredLevel == 1) {BetaInbredLevel = 3;} else { BetaInbredLevel = 2;} 
  }
  if (exists("GenderdominancejSequence") && !is.null(GenderdominancejSequence) &&
    max(abs(GenderdominancejSequence)) > 0) { CrossModel = 1; SexModel = 4;
    if (BetaInbredLevelTimesSex == 1) {BetaInbredLevelTimesSex = 3;} else { BetaInbredLevelTimesSex = 2;} 
  }
  if (exists("SymCrossjkSequence") && !is.null(SymCrossjkSequence) &&
    max(abs(SymCrossjkSequence)) > 0) { CrossModel = 2; }
  if (exists("GenderSymCrossjkSequence") && !is.null(GenderSymCrossjkSequence) &&
    max(abs(GenderSymCrossjkSequence)) > 0) { CrossModel = 2;  SexModel = 5; }
  if (exists("ASymCrossjkDkjSequence") && !is.null(ASymCrossjkDkjSequence) &&
    max(abs(ASymCrossjkDkjSequence)) > 0) { CrossModel = 5; }    
  if (exists("GenderASymCrossjkDkjSequence") && !is.null(GenderASymCrossjkDkjSequence) &&
    max(abs(GenderASymCrossjkDkjSequence)) > 0) { CrossModel = 5;  SexModel = 5; }
  if (exists("AllCrossjkSequence") && !is.null(AllCrossjkSequence) &&
    max(abs(AllCrossjkSequence)) > 0) { CrossModel = 8; }    
  if (exists("GenderAllCrossjkSequence") && !is.null(GenderAllCrossjkSequence) &&
    max(abs(GenderAllCrossjkSequence)) > 0) { CrossModel = 8;  SexModel = 6; }

  this$ADiallelOb = DiallelOb(numj=this$.numj, ajModel=ajModel, 
    MotherModel=MotherModel, CrossModel=CrossModel, 
    SexModel=SexModel, BetaInbredLevel=BetaInbredLevel, 
    BetaInbredTimesSex=BetaInbredLevelTimesSex, 
    dfTNoise = this$dfTNoise, AFD = this, iOb = 1,
    DoFirstCenter = this$DoFirstCenter);
  if (!is.null(this$Verbose) && this$Verbose > 2) {
    Verbose = TRUE;
  } else {Verbose = FALSE;}
  ASexVector = this$SexVector;
  if (!is.null(ASexVector)) {
    if (!is.null(ASexVector) && any(is.na(ASexVector))) {
      ASexVector[is.na(ASexVector)] = 1;
    }
  }
  this$X = ConstructXJK(numj = this$.numj, ajModel = this$ADiallelOb$.ajModel, 
    CrossModel = this$ADiallelOb$.CrossModel, 
    SexModel = this$ADiallelOb$.SexModel, 
    MotherModel=this$ADiallelOb$.MotherModel, 
    BetaInbredLevel=this$ADiallelOb$.BetaInbredLevel, 
    BetaInbredTimesSex = this$ADiallelOb$.BetaInbredTimesSex, 
    SexVector=ASexVector, Listjk=this$Listjk,
    CO=this$ACrossLocations, FixedEffects=this$FixedEffects,
    RandomEffects=this$RandomEffects, Verbose=Verbose,
    DoFirstCenter = this$DoFirstCenter); 
  CreateGotList(this$ADiallelOb, XColNames=colnames(this$X),
    Im =this$m, Idf = this$df, tauFixedAll = GettauFixedAll(this$tauFixed),
    RandomEffectsGroups = this$RandomEffectsGroups,
    FixedEffects = this$FixedEffects, RandomEffects = this$RandomEffects,
    AFD = this, Sigma = Sigma);
  nBeta = names(this$ADiallelOb$Beta);
  NNewBeta = this$ADiallelOb$Beta;
  if (Mu != 0 && any(nBeta == "Mu")) { NNewBeta[["Mu"]] = Mu; }
  if (GenderMu != 0 && any(nBeta == "Gender:Av")) { NNewBeta[["Gender:Av"]] = GenderMu; }
  if (BetaInbred != 0 && any(nBeta == "BetaInbred:Av")) { NNewBeta[["BetaInbred:Av"]] = BetaInbred; }  
  if (BetaInbredTimesGender != 0 && any(nBeta == "BetaInbred:Gender:Av")) { 
    NNewBeta[["BetaInbred:Gender:Av"]] = BetaInbredTimesGender; }
    
  ##VDD = BayesDiallel:::.DefaultAllRandomVariables;
  for (ii in 1:length(RTVVec)) {
    RDD = RTVVec[ii];
   
   
    RText = paste( "",
      "if (exists(\"", RDD, "Sequence\") && !is.null(", RDD, "Sequence) && sum(",RDD,"Sequence^2) > 0) {
         RTN = (1:length( EatFingColons(nBeta)))[substr( EatFingColons(nBeta),1,nchar(RDD)) == RDD];
         if (length(RTN) > 0) {
           nRTN = nBeta[RTN];
           nSS = names(",RDD,"Sequence);
           if (is.null(nSS) && !any(nSS %in% nRTN)) {
             if (length(nRTN) < length(", RDD,"Sequence)) {
               NNewBeta[RTN] = ", RDD, "Sequence[1:length(RTN)];
             }  else if (length(nRTN) > length(", RDD, "Sequence)) {
               NNewBeta[RTN[1:length(",RDD,"Sequence)]] = ", RDD, "Sequence;
             } else {
               NNewBeta[RTN] = ", RDD, "Sequence;             
             }
           } else {
             RM = match(nSS, nRTN);
             RMnNA = (1:length(RM))[!is.na(RM)];
             RMFNA = RM[!is.na(RM)];
             NNewBeta[RTN[RMFNA]] = ", RDD, "Sequence[RMnNA];
           }
         }
       }", sep="");
       eval(parse(text=RText));
    }
    this$ADiallelOb$Beta = NNewBeta; 
  return(1);
  if (is.null(SymCrossjkSequence) &&  max(SymCrossjkSequence) > 0) {
    if (this$ADiallelOb$.BetaInbredLevel < 2) {
      SymCrossjkSequence = (1:(this$.numj * (this$.numj+1)/2));    
    } else {
      SymCrossjkSequence = (1:(this$.numj * (this$.numj-1)/2));
    }
    this$ADiallelOb$.CrossModel = 2;
  } else if (!is.null(SymCrossjkSequence) && this$ADiallelOb$.CrossModel > 1) {
    if (this$ADiallelOb$.BetaInbredLevel < 2  &&
       length(SymCrossjkSequence) > this$.numj * (this$.numj +1) / 2 ) {
      SymCrossjkSequence =  SymCrossjkSequence[1:(this$.numj * (this$.numj +1) / 2)];  
    } else if (this$ADiallelOb$.BetaInbredLevel < 2  &&
       length(SymCrossjkSequence) < this$.numj * (this$.numj +1) / 2 ) {
       SymCrossjkSequence =  c(SymCrossjkSequence, rep(
         SymCrossjkSequence[1],(this$.numj * (this$.numj +1) /2) -
           length(SymCrossjkSequence))); 
    }  else if (this$ADiallelOb$.BetaInbredLevel >= 2  &&
       length(SymCrossjkSequence) > this$.numj * (this$.numj -1) / 2 ) {
      SymCrossjkSequence =  SymCrossjkSequence[1:(this$.numj * (this$.numj -1) / 2)];  
    } else if (this$ADiallelOb$.BetaInbredLevel >= 2  &&
       length(SymCrossjkSequence) < this$.numj * (this$.numj -1) / 2 ) {
       SymCrossjkSequence =  c(SymCrossjkSequence, rep(
         SymCrossjkSequence[1],(this$.numj * (this$.numj -1) /2) -
           length(SymCrossjkSequence))  ); 
    }
  }
  if (!is.null(SymCrossjkSequence)) {
    SymCrossjkSequence = SymCrossjkSequence - mean(SymCrossjkSequence);
  }
  if (is.null(ASymCrossjkDkjSequence) && this$ADiallelOb$.CrossModel > 4) {
    ASymCrossjkDkjSequence = (1:(this$.numj * (this$.numj-1) / 2));
  } else if (!is.null(ASymCrossjkDkjSequence) && this$ADiallelOb$.CrossModel > 4) {
    if (length(ASymCrossjkDkjSequence) > this$.numj * (this$.numj -1) / 2 ) {
      ASymCrossjkDkjSequence =  ASymCrossjkDkjSequence[1:(this$.numj * (this$.numj -1) / 2)];  
    } else if (
       length(ASymCrossjkDkjSequence) < this$.numj * (this$.numj -1) / 2 ) {
       ASymCrossjkDkjSequence =  c(ASymCrossjkDkjSequence, rep(
         ASymCrossjkDkjSequence[1],(this$.numj * (this$.numj -1) /2 )-
           length(ASymCrossjkDkjSequence))  ); 
    }
  }
  if (!is.null(ASymCrossjkDkjSequence)) {
    ASymCrossjkDkjSequence = ASymCrossjkDkjSequence - mean(ASymCrossjkDkjSequence);
  }
  if (is.null(AllCrossjkSequence) && this$ADiallelOb$.CrossModel > 1) {
    if (this$ADiallelOb$.BetaInbredLevel < 2) {
      AllCrossjkSequence = (1:(this$.numj^2));    
    } else {
      AllCrossjkSequence = (1:(this$.numj^2 - this$.numj));
    }
  } else if (!is.null(AllCrossjkSequence) && this$ADiallelOb$.CrossModel >= 8) {
    if (this$ADiallelOb$.BetaInbredLevel < 2  &&
      length(AllCrossjkSequence) > this$.numj * (this$.numj) ) {
      AllCrossjkSequence =  AllCrossjkSequence[1:(this$.numj * (this$.numj))];  
    } else if (this$ADiallelOb$.BetaInbredLevel < 2  &&
       length(AllCrossjkSequence) < this$.numj * (this$.numj) ) {
       AllCrossjkSequence =  c(AllCrossjkSequence, rep(
         AllCrossjkSequence[1],(this$.numj * (this$.numj)) -
           length(AllCrossjkSequence)) ); 
    }  else if (this$ADiallelOb$.BetaInbredLevel >= 2  &&
       length(AllCrossjkSequence) > this$.numj * (this$.numj -1) ) {
      AllCrossjkSequence =  AllCrossjkSequence[1:(this$.numj * (this$.numj -1))];  
    } else if (this$ADiallelOb$.BetaInbredLevel >= 2  &&
       length(AllCrossjkSequence) < this$.numj * (this$.numj -1)  ) {
       AllCrossjkSequence =  c(AllCrossjkSequence, rep(
         AllCrossjkSequence[1],(this$.numj * (this$.numj -1) )-
           length(AllCrossjkSequence))  ); 
    }
  }
  if (!is.null(AllCrossjkSequence)) {
    AllCrossjkSequence = AllCrossjkSequence - mean(AllCrossjkSequence);
  }
  if (any(names(this$ADiallelOb$CollapsedXSubSetList) %in% .DefaultAllnumjVariables)) {
     MyNames =  (names(this$ADiallelOb$CollapsedXSubSetList))[
       names(this$ADiallelOb$CollapsedXSubSetList) %in% .DefaultAllnumjVariables];
    for (ii in 1:length(MyNames)) {
     this$ADiallelOb$Beta[substr(names(this$ADiallelOb$Beta), 1, nchar(MyNames[ii])) == 
       MyNames[ii]] = StrainSequence;    
    }
  }
          

  if(!is.null(GenderajSequence) &&
   length(GenderajSequence) == this$.numj) { 
    GenderMu = GenderMu + 2 * mean(GenderajSequence); 
    GenderajSequence = GenderajSequence - mean(GenderajSequence); } else {
    GenderajSequence = NULL;  
  }    
  if(!is.null(dominancejSequence)) {
    BetaInbred = BetaInbred + 2 * mean(dominancejSequence); 
  }
  ##ajSequence=NULL, GenderajSequence=NULL, MotherSequence = NULL,
  ##GenderMotherSequence = NULL, DominanceSequence = NULL,
  ##GenderDominanceSequence = NULL
  
  nAOCX = names(this$ADiallelOb$CollapsedXSubSetList);
  if (any(nAOCX %in% c("aj", "additive"))) {
    if(!is.null(ajSequence)) { Mu = Mu + 2 * mean(ajSequence); 
      ajSequence = ajSequence - mean(ajSequence); } else {
      Mu = Mu + 2 * mean(ajSequence); 
      ajSequence = ajSequence - mean(ajSequence); 
    }  
    this$ADiallelOb$Beta[substr(names(this$ADiallelOb$Beta), 1, nchar("aj")) == 
       "aj"] = SRD(ajSequence, this$.numj, StrainSequence);    
  }
  if (any(nAOCX %in% c("Gender:aj", "sex.additive") )) {
    if(!is.null(GenderSequence)) { GenderMu = GenderMu + 2 * mean(GenderSequence); 
      GenderSequence = GenderSequence - mean(GenderSequence); } else {
      GenderSequence = StrainSequence; 
      GenderMu = GenderMu + 2 * mean(GenderSequence); 
      GenderSequence = GenderSequence - mean(GenderSequence); 
    }  
    this$ADiallelOb$Beta[substr(names(this$ADiallelOb$Beta), 1, nchar("Gender:aj")) == 
       "Gender:aj"] = SRD(GenderSequence, this$.numj, StrainSequence);    
  }
  if (any(nAOCX %in% c("motherj", "parent.origin"))) {
    if(!is.null(motherjSequence)) { Mu = Mu + mean(motherjSequence); 
      motherjSequence = motherjSequence - mean(motherjSequence); } else {
      Mu = Mu + mean(motherjSequence); 
      motherjSequence = motherjSequence - mean(motherjSequence); 
    }
    this$ADiallelOb$Beta[substr(names(this$ADiallelOb$Beta), 1, nchar("motherj")) == 
       "motherj"] = SRD(motherjSequence, this$.numj, StrainSequence);    
  } 
  if (any(nAOCX %in% c("sex.parent.origin", "Gender:motherj"))) {                 
    if(!is.null(GendermotherjSequence)) { GenderMu = GenderMu + mean(GendermotherjSequence); 
      GendermotherjSequence = GendermotherjSequence - mean(GendermotherjSequence); } else {
      GendermotherjSequence = GendermotherjSequence; 
      GenderMu = GenderMu + mean(GendermotherjSequence); 
      GendermotherjSequence = GendermotherjSequence - mean(GendermotherjSequence); 
    }  
    this$ADiallelOb$Beta[substr(names(this$ADiallelOb$Beta), 1, nchar("Gender:motherj")) == 
       "Gender:motherj"] = SRD(GendermotherjSequence, this$.numj, StrainSequence);    
  }   
  if (any(nAOCX %in% c("dominancej", "inbreeding") )) {
      if(!is.null(dominancejSequence)) { 
      BetaInbred = BetaInbred + 2*mean(dominancejSequence); 
      DominanceSequence = dominancejSequence - mean(dominancejSequence); } else {
      BetaInbred = BetaInbred + 2*mean(dominancejSequence); 
      dominancejSequence = dominancejSequence - mean(dominancejSequence); 
    }
  
    this$ADiallelOb$Beta[substr(names(this$ADiallelOb$Beta), 1, nchar("dominancej")) == 
       "dominancej"] = SRD(dominancejSequence, this$.numj, StrainSequence);    
  }  
  if (any(nAOCX == "Gender:dominacej")) {
      if(!is.null(GenderdominancejSequence)) { 
      BetaInbredTimesGender = BetaInbredTimesGender + mean(GenderdominancejSequence); 
      GenderdominancejSequence = GenderdominancejSequence - mean(GenderdominancejSequence); } else {
      GenderdominancejSequence = StrainSequence; 
      BetaInbredTimesGender = BetaInbredTimesGender + 2*mean(GenderdominancejSequence); 
      GenderdominancejSequence = GenderdominancejSequence - mean(GenderdominancejSequence); 
    }  
    this$ADiallelOb$Beta[substr(names(this$ADiallelOb$Beta), 1, nchar("Gender:dominancej")) == 
       "Gender:dominancej"] = SRD(GenderdominancejSequence, this$.numj, StrainSequence);    
  }  
  
  
  if (any(names(this$ADiallelOb$CollapsedXSubSetList) %in% .DefaultHalfnumjSqVariables)) {
     MyNames =  (names(this$ADiallelOb$CollapsedXSubSetList))[
       names(this$ADiallelOb$CollapsedXSubSetList) %in% .DefaultHalfnumjSqVariables];
    for (ii in 1:length(MyNames)) {
     this$ADiallelOb$Beta[substr(names(this$ADiallelOb$Beta), 1, nchar(MyNames[ii])) == 
       MyNames[ii]] = SymCrossjkSequence;    
    }
  }
  if (any(names(this$ADiallelOb$CollapsedXSubSetList) %in% .DefaultOffHalfnumjSqVariables)) {
     MyNames =  (names(this$ADiallelOb$CollapsedXSubSetList))[
       names(this$ADiallelOb$CollapsedXSubSetList) %in% .DefaultOffHalfnumjSqVariables];
    for (ii in 1:length(MyNames)) {
     this$ADiallelOb$Beta[substr(names(this$ADiallelOb$Beta), 1, nchar(MyNames[ii])) == 
       MyNames[ii]] = ASymCrossjkDkjSequence;    
    }
  }
  if (any(names(this$ADiallelOb$CollapsedXSubSetList) %in% .DefaultnumjSqVariables)) {
     MyNames =  (names(this$ADiallelOb$CollapsedXSubSetList))[
       names(this$ADiallelOb$CollapsedXSubSetList) %in% .DefaultnumjSqVariables];
    for (ii in 1:length(MyNames)) {
     this$ADiallelOb$Beta[substr(names(this$ADiallelOb$Beta), 1, nchar(MyNames[ii])) == 
       MyNames[ii]] = AllCrossjkSequence;    
    }
  }
     
   if (any(names(this$ADiallelOb$Beta) == "Mu")) {
     this$ADiallelOb$Beta[names(this$ADiallelOb$Beta) =="Mu"] = Mu[1];
   }
   if (any(names(this$ADiallelOb$Beta) == "Gender:Av")) {
     this$ADiallelOb$Beta[names(this$ADiallelOb$Beta) == "Gender:Av"] = GenderMu[1];
   }
   if (any(names(this$ADiallelOb$Beta) == "BetaInbred:Av")) {
     this$ADiallelOb$Beta[names(this$ADiallelOb$Beta) == "BetaInbred:Av"] = BetaInbred[1];
   }   
   if (any(names(this$ADiallelOb$Beta) == "BetaInbred:Gender:Av")) {
     this$ADiallelOb$Beta[names(this$ADiallelOb$Beta) == "BetaInbred:Gender:Av"] = BetaInbredTimesGender[1];
   }  
   if (any(is.na(this$ADiallelOb$Beta)) || any(is.nan(this$ADiallelOb$Beta) )) {
     print("AFDS Error: some Beta were set to NAN!"); flush.console();
   
   }  
});

################################################################################
##   Use this Method to Simulate the values of a Diallel
##
##
setMethodS3("SimValues", "FullDiallelSimulate", function(this, Sigma = NULL, 
  dfTNoise = NULL, MiceOnly = FALSE, BetaOnly = FALSE, ...) {
  if (BetaOnly == FALSE && MiceOnly == FALSE)  { 
    if (!is.null(Sigma)) {
      this$Sigma = Sigma;
      this$ADiallelOb$Sigma = Sigma;
    }
    if (!is.null(dfTNoise)) {
      this$ADiallelOb$dfTNoise = dfTNoise;
      this$dfTNoise = dfTNoise;
    }
    this$ADiallelOb$tau[1:length(this$ADiallelOb$tau)] <- this$ADiallelOb$mtau / 
      rgamma( length(this$ADiallelOb$mtau), this$ADiallelOb$dftau);
      ##names(this$ADiallelOb$tau) = OrderAllList[ OrderAllList %in% this$ADiallelOb$.GotList & !IsFixed];
      this$ADiallelOb$Sigma = Sigma;
      names(this$ADiallelOb$Sigma) = "Sigma";
  }
	if (MiceOnly == FALSE) {
	this$ADiallelOb$Beta[1:length(this$ADiallelOb$Beta)] <- sqrt(
    this$ADiallelOb$DpBeta %*% c(this$ADiallelOb$.tauFixed,
    this$ADiallelOb$tau))*
    rnorm( length(this$ADiallelOb$DpBeta[,1]), 
    0,1);
  ##names(this$ADiallelOb$Beta) = colnames(this$X)

	if (this$ADiallelOb$.CrossModel %in% c(3,4,6,7,9,10)) {
		SimCrossBeta(this$ADiallelOb, this$ACrossLocations);	
	}
	}
  if (is.null(this$ADiallelOb$dfTNoise) || length(this$ADiallelOb$dfTNoise) <= 0 ||
    this$ADiallelOb$dfTNoise[1] <= 0) { 
	  this$Y =  this$X %*% this$ADiallelOb$Beta + 
      sqrt(this$ADiallelOb$Sigma) * rnorm(length(this$X[,1]), 0, 1)
  } else {
    this$ObservedSigmaDraw =   sqrt( this$ADiallelOb$dfTNoise /
      rchisq(length(this$X[,1]), df = this$ADiallelOb$dfTNoise));
    this$ObservedTNoise = this$ObservedSigmaDraw * 
      rnorm(length(this$X[,1]), 0, 1);
    this$ObservedSigmaTNoise = this$ObservedTNoise * sqrt(this$ADiallelOb$Sigma);
    this$VecOWeights = (this$ADiallelOb$dfTNoise+1) / 
      (this$ADiallelOb$dfTNoise + this$ObservedTNoise^2);
	  this$Y =  this$X %*% this$ADiallelOb$Beta + 
      this$ObservedSigmaTNoise;
  }
  if (any(is.na(this$Y)) || any(is.nan(this$Y))) {
    print("Error: FullDiallelSimulate, there are NAN Y's"); flush.console();
  }
  if (any(is.na(this$ADiallelOb$Beta)) || any(is.nan(this$ADiallelOb$Beta))) {
    print("Error: FullDiallelSimulate, there are NAN Beta's"); flush.console();
  }

});
setMethodS3("SetRandomValues", "FullDiallelAnalyze", function(this, Sigma, 
   OnDOB = 1, MT = 10, ...) {
	this$AllDiallelObs[[OnDOB]]$tau[
      1:length(this$AllDiallelObs[[OnDOB]]$tau)] <- 
            MT*this$AllDiallelObs[[OnDOB]]$mtau / 
            rgamma( length(this$AllDiallelObs[[OnDOB]]$mtau), 
            MT*this$AllDiallelObs[[OnDOB]]$dftau);
  ##names(this$AllDiallelObs[[OnDOB]]$tau) = 
  ##  OrderAllList[ OrderAllList %in% 
  ##                this$AllDiallelObs[[OnDOB]]$.GotList & !IsFixed];
  this$AllDiallelObs[[OnDOB]]$tau[ 
            this$AllDiallelObs[[OnDOB]]$tau > 10^5 ] = 10^5
 
	this$AllDiallelObs[[OnDOB]]$Sigma = Sigma;
	names(this$AllDiallelObs[[OnDOB]]$Sigma) = "Sigma";
	this$AllDiallelObs[[OnDOB]]$Beta[
       1:length(this$AllDiallelObs[[OnDOB]]$Beta)] <- 
         sqrt( this$AllDiallelObs[[OnDOB]]$DpBeta %*% 
               c(this$AllDiallelObs[[OnDOB]]$.tauFixed,
                 this$AllDiallelObs[[OnDOB]]$tau) ) *
         rnorm( length(this$AllDiallelObs[[OnDOB]]$XSubSetList), 
               0,1);
  names(this$AllDiallelObs[[OnDOB]]$Beta) = colnames(this$X)[
                        this$AllDiallelObs[[OnDOB]]$XSubSetList];

	if (this$AllDiallelObs[[OnDOB]]$.CrossModel %in% c(3,4,6,7,9,10)) {
		SimCrossBeta(this$AllDiallelObs[[OnDOB]], this$ACrossLocations);	
	}
});

setMethodS3("RegenerateCurrentX", "DiallelOb", function(AFD=NULL,...) {
  AFD = this$.AFD;
  Verbose = AFD$Verbose;
  ASexVector = AFD$SexVector;
  if (!is.null(this$ImputedGender)) {
    ASexVector[this$ListUnknownGender] = this$ImputedGender;
  }
  RX = ConstructXJK(numj = AFD$.numj, ajModel = this$.ajModel, 
    CrossModel = this$.CrossModel, 
    SexModel = this$.SexModel, 
    MotherModel=this$.MotherModel, 
    BetaInbredLevel=this$.BetaInbredLevel, 
    BetaInbredTimesSex = this$.BetaInbredTimesSex, 
    SexVector=ASexVector, Listjk=AFD$Listjk,
    CO=AFD$ACrossLocations, FixedEffects=AFD$FixedEffects,
    RandomEffects=AFD$RandomEffects, Verbose=Verbose,
    DoFirstCenter = this$DoFirstCenter); 
  return(RX);
})

setMethodS3("MakeDp", "DiallelOb", function(this,AFD=NULL, ...) {

  if (!exists("AFD") || is.null(AFD)) {
    AFD = this$.AFD;
  }
  if (length(this$CollapsedXSubSetList)  == 1 && 
    names(this$CollapsedXSubSetList)[1] == "Mu") {
    Dp = matrix(0, 1,1);
    colnames(Dp) = "tau:Mu"; rownames(Dp) = "Mu";
    this$DpBeta = Dp;  
    this$colSumsDpBeta  = colSums(this$DpBeta);
	  this$.TDFTau <- length(this$NeedF)
  } 
  this$.TDLenBeta <- this$CollapsedXSubSetList;
  TotalLenBeta = max(this$CollapsedXSubSetList);
  TotalLenTau = length(this$CollapsedXSubSetList);
	
  TDStart  <- c(1, this$.TDLenBeta[1:(length(this$.TDLenBeta)-1)] +1);
  Dp = matrix(0, TotalLenBeta, TotalLenTau);
  for (ii in 1:length(this$.idREALVARIABLES)) {
    if (ii > TotalLenTau) {
       tryCatch(paste("Error:, length(this$idREALVARIABLES = ", ii,
         "but, you have TotalLenTau = ", TotalLenTau, 
         "  and also, TotalLenBeta = ", TotalLenBeta,
         " but you have TDStart[", ii, "] = ",
         TDStart[ii], " and this$.TDLenBeta[",ii,"] = ",
         this$.TDLenBeta, sep=""));
    }
    Dp[TDStart[ii]:this$.TDLenBeta[ii],ii] = 1;	
  }

  OrderAllList = c(AFD$.AllFixedVariables, AFD$.AllRandomVariables);
  colnames(Dp) = paste("tau", OrderAllList[this$.idREALVARIABLES], sep="");
  this$DpBeta <- Dp;
  this$colSumsDpBeta  = colSums(this$DpBeta);
  this$.TDFTau <- length(this$NeedF)

  ##print(paste("length(Beta) = ", length(this$Beta), sep=""));
  ##print(paste("dim(Dp) = ", paste(dim(this$DpBeta), collapse=", "), sep=""));
  ##print(paste("TotalLenBeta = ", TotalLenBeta, sep=""));
  ##print(paste("colnames(Dp) ", paste(colnames(Dp), collapse=", " ), sep=""));
  ##print(paste("thisTDLen = ", paste(this$.TDLenBeta, collapse=", "),
  ##                       sep=""));

} );

setMethodS3("AFDhglm", "FullDiallelAnalyze", function(
  this, On= NULL, DoMax = TRUE, ...) {
  if (!exists("On") || is.null(On) || (is.numeric(On)[1] < 1)) {
    if (DoMax == TRUE) {On = 1;} else {On = this$OnObs;}
  }
  return(AFDhglm(this$AllDiallelObs[[On]], this));
});
setMethodS3("AFDhglm", "DiallelOb", function(this,AFD=NULL,...) {

  if (!exists("AFD") || is.null(AFD)) { AFD = this$.AFD; }
  library(hglm);
  this = AFD$AllDiallelObs[[1]];
  RDV =(1:NCOL(this$DpBeta))[substr(colnames(this$DpBeta),
    nchar("tau")+1, nchar(colnames(this$DpBeta)) ) %in% AFD$.AllRandomVariables]
  SR = rowSums(this$DpBeta[,RDV]);
  ZCols = (1:NROW(this$DpBeta))[SR > 0];
  RandC = colSums(this$DpBeta[,RDV]);
  if (is.null(this$X)) {
    this$X = AFD$X[,this$XSubSetList];
  }
  XX = this$X[,(1:NROW(this$DpBeta))[SR==0]]
  Z = this$X[,ZCols];   cnX = colnames(XX); cnZ = colnames(Z); cnR = names(RandC)
  colnames(XX) = NULL; colnames(Z) = NULL; names(RandC) = NULL;
  AHg = hglm(X=XX, Z=Z, RandC = RandC, y = AFD$Y);
  try( names(AHg$fixef) <- cnX);
  try( names(AHg$ranef) <- cnZ );
  names(AHg$varRanef) = names(this$tau);
  AsHg = summary(AHg);
  RS = 0; for (ii in 1:length(AsHg$RandCoefMat)) { 
    try(RS <- RS + NROW(AsHg$RandCoefMat[[ii]])); }
  
  RandTable =  matrix(0, RS, 4);
  Oni = 0;
  coefNames = c();
  tauSqEst = c();
  for (ii in 1:length(AsHg$RandCoefMat)) {
    try(RandTable[Oni + 1:NROW(AsHg$RandCoefMat[[ii]]),1:2] <- 
      AsHg$RandCoefMat[[ii]])
    DFF = AsHg$devdf;
    NewT  <-  AsHg$RandCoef[[ii]][,1]/  AsHg$RandCoef[[ii]][,2];
    try(tauSqEst <- c(tauSqEst, var(AsHg$RandCoef[[ii]][,1])));
    NewP = 2 * pt( - abs(NewT), df = DFF);
    try(RandTable[Oni + 1:NROW(AsHg$RandCoefMat[[ii]]),3:4] <- 
      NewP);
    coefNames = c(coefNames, rownames(AsHg$RandCoefMat[[ii]]));
    Oni = Oni + NROW(AsHg$RandCoefMat[[ii]]);
  }
  rownames(RandTable) = coefNames;
  LastRow = c(AsHg$varFix[1],0,0,0)
  
  try( AMerge <- rbind(AsHg$FixCoefMat, RandTable, LastRow));
  rownames(AMerge)[NROW(AMerge)] = "Sigma:1"
  AHg$sum.table  = AMerge;
  try(AHg$tauSqEst <- tauSqEst);
  return(AHg);
});

setMethodS3("getProbFemaleUnknownSex", "FullDiallelAnalyze", function(this,...) {
  return(this$ProbUnknownGender);
});
setMethodS3("ListUnknownSex", "FullDiallelAnalyze", function(this,...) {
  return(this$ListUnknownGender);
});
setMethodS3("NoChainsUnknownGender", "FullDiallelAnalyze", function(this,...) {
  return(this$NoChainsUnknownGender);
});

if (FALSE) {
setMethodS3("MysteryGender", "FullDiallelAnalyze", function(this, 
  ListUnknownSex= NULL, ProbFemaleUnknownSex=NULL, NoChainsUnknownSex = NULL,
  ListUnknownGender= NULL, ProbUnknownGender = NULL,
  NoChainsUnknownGender = NULL, Verbose = -1, ...) {
  if (is.null(ListUnknownGender) && exists("ListUnknownSex") &&
    !is.null(ListUnknownSex)) {
    ListUnknownGender = ListUnknownSex;  
  }
  if (is.null(ProbUnknownGender) && exists("ProbFemaleUnknownSex") &&
    !is.null(ProbFemaleUnknownSex)) {
    ProbUnknownGender = ProbFemaleUnknownSex;  
  }
  if (is.null(NoChainsUnknownGender) && exists("NoChainsUnknownSex") &&
    !is.null(NoChainsUnknownSex)) {
    NoChainsUnknownGender = NoChainsUnknownSex;  
  }  
  this$MysteryGender(ListUnknownGender= ListUnknownGender, 
    ProbUnknownGender = ProbUnknownGender,
    NoChainsUnknownGender = NoChainsUnknownGender, Verbose = Verbose, ...)
});
}

setMethodS3("MysteryGender", "FullDiallelAnalyze", function(this, 
  ListUnknownGender= NULL, ProbUnknownGender = NULL,
  NoChainsUnknownGender = NULL, Verbose = -1, 
  ListUnknownSex=NULL, ProbFemaleUnknownSex=NULL, NoChainsUnknownSex=NULL,...) {
  if (is.null(ListUnknownGender) && exists("ListUnknownSex") &&
    !is.null(ListUnknownSex)) {
    ListUnknownGender = ListUnknownSex;  
  }
  if (is.null(ProbUnknownGender) && exists("ProbFemaleUnknownSex") &&
    !is.null(ProbFemaleUnknownSex)) {
    ProbUnknownGender = ProbFemaleUnknownSex;  
  }
  if (is.null(NoChainsUnknownGender) && exists("NoChainsUnknownSex") &&
    !is.null(NoChainsUnknownSex)) {
    NoChainsUnknownGender = NoChainsUnknownSex;  
  }  
  if (is.numeric(Verbose) && Verbose < 0) {
    Verbose = this$Verbose;
  } else if (is.logical(Verbose) && Verbose == FALSE) {
    Verbose = 0;
  } else if (is.logical(Verbose) && Verbose == TRUE) {
    Verbose = 2;
  }
  if (Verbose > 0) {
    print("MysteryGender: Starting"); flush.console();
  }
  if (is.null(NoChainsUnknownGender)) {
    NoChainsUnknownGender = this$NoChainsUnknownGender;
  }
  if (!is.null(ListUnknownGender) && !is.null(ProbUnknownGender)) {
    if (Verbose > 0) {
      print("MysteryGender: NonNull ListUnknownGender and ProbUnknownGender inputs, starting up!"); flush.console();
    }
    this$SetupUnknownGender( ListUnknownGender=ListUnknownGender, 
      ProbUnknownGender = ProbUnknownGender, 
      NoChainsUnknownGender=NoChainsUnknownGender, Verbose = Verbose);
    ListUnknownGender = this$ListUnknownGender;  ProbUnknownGender = this$ProbUnknownGender;
  } else if (!is.null(ProbUnknownGender)) {
    if (Verbose > 0) {
      print("MysteryGender: NonNull ProbUnknownGender input"); flush.console();
    }
    this$SetupUnknownGender( ListUnknownGender=ListUnknownGender, 
      ProbUnknownGender = ProbUnknownGender, 
      NoChainsUnknownGender=NoChainsUnknownGender, Verbose = Verbose);
    ListUnknownGender = this$ListUnknownGender;  ProbUnknownGender = this$ProbUnknownGender;  
  } else if (is.null(ListUnknownGender) && is.null(ProbUnknownGender) ) {
    if (Verbose > 0) {
      print("MysteryGender; Now taking ListUnknownGender/ProbUnknownGender from this!"); flush.console();
    }
    ListUnknownGender = this$ListUnknownGender;
    ProbUnknownGender = this$ProbUnknownGender;
  }
  
  if (is.null(ListUnknownGender) || length(ListUnknownGender) < 1) {
     if (Verbose > 0) {
      print("MysteryGender; DefectiveListUnknownGender, get it from this!"); flush.console();
    }
    ListUnknownGender = this$ListUnknownGender;
    ProbUnknownGender = this$ProbUnknownGender
  } 
  if (is.null(ListUnknownGender) || length(ListUnknownGender) < 1) {
    print("MysteryGender: FullDiallelAnalyze, Setup fails for bad unknown Gender, must have ListUnknownGender!");
    return;
  }
  if (Verbose > 1) {
    print("MysteryGender: Now to check on X"); flush.console();
  }
  if (is.null(this$X)) {
    tryCatch("Mystery Gender Error: setup X first! ");
  }
  GGX = this$X[ListUnknownGender,];
  IDXs = 1:length(this$X[1,]);
  qGender= "Gender";
  ngIDXs = IDXs[ substr(colnames(this$X), 1, nchar(qGender)) != qGender];
  GGX[, ngIDXs] = 0;
  colnames(GGX) = colnames(this$X);
  this$GGX = GGX; this$ListUnknownGender = ListUnknownGender
  if (!is.null(this$AllDiallelObs) && length(this$AllDiallelObs) > 0) {
    for (ii in 1:length(this$AllDiallelObs)) {
      if (!is.null(this$AllDiallelObs[[ii]])) {
        if (!is.null(this$AllDiallelObs[[ii]]$CodaChains) &&
          length(this$AllDiallelObs[[ii]]$CodaChains[[1]]) > 0) {
          if (Verbose > 0) {
            print(paste("MysteryGender: FullDiallelAnalyze, setting up ii = ",
              ii, ", the Unknown Gender for length(CodaChains) = ",
              length(this$AllDiallelObs[[ii]]$CodaChains), " with ",
              "dim = (", 
              paste(dim(this$AllDiallelObs[[ii]]$CodaChains[[1]]),
              collapse = ", "), ")", sep="")); flush.console();
          }
          SetupUnknownGender(this$AllDiallelObs[[ii]], this, Verbose = Verbose);
        }
      }
    }
  }
  if (Verbose > 1) {
    print("MysteryGender: Now Quitting!");
  }
})



setMethodS3("RenameChains", "FullDiallelAnalyze", function(this, ...) {
    for (jj in 1:length(this$AllDiallelObs) ) {
         RenameChains(this$AllDiallelObs[[jj]],...);   
    }
});
setMethodS3("RenameChains", "DiallelOb", function(this, DoMu = TRUE, 
  DoTreat=FALSE, NoJK = TRUE, DoCentered=TRUE, ...)  {
 if (is.null(this$Wanted) && is.null(this$Extractor)) {
 Itau = NULL; ItauCross = NULL;
  if (length(this$tau) > 0) { 
    Itau = names(this$tau);
    FDS = (1:length(Itau))[ substr(Itau,1,nchar("tau:")) != "tau:" ];
    Itau[FDS] = paste("tau:", Itau[FDS], sep="");
  }
  if (length(this$tauCrosses) > 0) { 
    ItauCross = names(this$tauCrosses);
    FDS = (1:length(ItauCross))[ substr(ItauCross,1,
      nchar("tauCrosses:")) != "tauCrosses:" ];
    ItauCross[FDS] = paste("tauCrosses:", ItauCross[FDS], sep="");
  }
  this$namesChainsMatrix = c(names(this$Beta), 
    Itau, ItauCross, names(this$Sigma));  
 }
 for (ii in 1:length(this$CodaChains)) {
   colnames(this$CodaChains[[ii]]) = this$namesChainsMatrix;   
 }

});

setMethodS3("SetupWeights", "DiallelOb", function(
  this, dfTNoise = 0, YLen = 0, WeightsKeepFlag = FALSE,...) {
  if (is.null(dfTNoise)) { dfTNoise <- 0.0; }
  if (length(dfTNoise) <= 0) { dfTNoise <- 0.0; }
  if (!is.numeric(dfTNoise)) { dfTNoise <- 0.0; }
  if (is.na(dfTNoise[1])) { dfTNoise <- 0.0; }
  if (dfTNoise[1] > 0) {
    this$dfTNoise = dfTNoise[1];
  }
  this$VecOWeights = rep(0, YLen);
  if (WeightsKeepFlag == 2) {
    numChains = length(this$CodaChains);    
    lengthChains = length(this$CodaChains[[1]][,1]);
    WeightsMatrix = as.mcmc(matrix(0,lengthChains, YLen));
    this$AllWeightsL[[1]] = WeightsMatrix;
    if (numChains > 1) {
      for (ii in 2:numChains) {
        WeightsMatrix = as.mcmc(matrix(0,lengthChains, YLen));
        this$AllWeightsL[[ii]] = WeightsMatrix;
      }
    }
    this$AllWeightsL = as.mcmc(this$AllWeightsL);
  }
  if (WeightsKeepFlag >= 1) {
    numChains = length(this$CodaChains);
    this$MeanWeightsL = list();
    this$MeanWeightsL[[1]] = rep(0, YLen);
    if (numChains > 1) {
      for (ii in 2:numChains) {
        this$MeanWeightsL[[ii]] = rep(0, YLen);
      }
    }
  }
}
);
setMethodS3("SetupWeights", "FullDiallelAnalyze", function(this, 
  dfTNoise = 0, WeightsKeepFlag = FALSE,...) {
  if (!is.null(dfTNoise) && length(dfTNoise) > 0 && !is.na(dfTNoise[1]) &&
    dfTNoise[1] > 0) {
    this$dfTNoise = dfTNoise;
  }
  if (!is.null(this$dfTNoise) && length(this$dfTNoise) > 0) {
    for (jtii in 1:length(this$AllDiallelObs)) {
      if (length(this$dfTNoise) >= jtii) {
        OndfTNoise = this$dfTNoise[jtii];
      } else {
        OndfTNoise = this$dfTNoise[1];
      }
      SetupWeights(this$AllDiallelObs[[jtii]], dfTNoise = OndfTNoise, 
        YLen = length(this$Y), WeightsKeepFlag);
    }
  }
});

setMethodS3("ReplaceAndRerunUpdatedChains", "DiallelOb", function(this,
  AFD=NULL, InformEvery = -1,...) {
  if (is.null(this$Verbose)) {
    if (is.null(this$.AFD)) {
      Verbose = 1;
    } else {
      Verbose = this$.AFD$Verbose;
    }
  } else {
    try(Verbose <- this$Verbose);
  }
  if (is.numeric(Verbose) && Verbose > -1) {
    print("---------------------------------------------------------------------");
    flush.console();
    print(paste("We are Replacing and rerunning chains for Model #", this$iOb, sep=""));
    try(print(paste("Current length of chains is", NROW(this$CodaChains), 
      ", we will 3X that", sep="")));  flush.console();
    InformEvery = 200;
  }
  numChains = length(this$CodaChains);
  if (is.null(AFD)) {
    tryCatch("ReplaceAndRerunUpdatedChains: We ain't running without AFD");
  }
  ParamList = list();
  for (ii in 1:length(this$CodaChains)) {
    ParamList[[ii]] = this$CodaChains[[ii]][length(this$CodaChains[[ii]][,1]),];
  }
  UpLenX = 3;  OldLen = length(this$CodaChains[[1]][,1]);
  NewLen = ceiling(OldLen * UpLenX)
  NChainsMatrix = matrix(0, NewLen, this$LengthChainsMatrix);
  if (is.null(this$Wanted) && is.null(this$Extractor)) {
  Itau = NULL; ItauCross = NULL;
  if (length(this$tau) > 0) { 
    Itau = names(this$tau);
    FDS = (1:length(Itau))[ substr(Itau,1,nchar("tau:")) != "tau:"];
    Itau[FDS] = paste("tau:", Itau[FDS], sep="");
  }
  if (length(this$tauCrosses) > 0) { 
    ItauCross = names(this$tauCrosses);
    FDS = (1:length(ItauCross))[ substr(ItauCross, 1, nchar("tauCrosses:")) !=
      "tauCrosses:"];
    ItauCross[FDS] = paste("tauCrosses:", ItauCross[FDS], sep="");
  }
    this$namesChainsMatrix = c(names(this$Beta), 
    Itau, ItauCross, names(this$Sigma));
  }
  colnames(NChainsMatrix) = this$namesChainsMatrix;
  listAll = list(); 
  listAll[[1]] = as.mcmc(NChainsMatrix);
  listLike = list();
  listLike[[1]] = rep(0, NewLen);
  listLike[[1]][1:OldLen] = this$LikelihoodChains[[1]][1:OldLen];
  listAll[[1]][1:OldLen,] = this$CodaChains[[1]][1:OldLen,];
  if (numChains > 1) {
    for (jj in 2:numChains){ 
      NChainsMatrix = matrix(0, NewLen, this$LengthChainsMatrix );
      colnames(NChainsMatrix) = this$namesChainsMatrix;       
      listAll[[jj]] =  as.mcmc(NChainsMatrix);
      listAll[[jj]][1:OldLen,] = this$CodaChains[[jj]][1:OldLen,];
      this$T1[[jj]] = 0; this$T2[[jj]] = 0;
      listLike[[jj]] = rep(0, NewLen);
      listLike[[jj]][1:OldLen] = this$LikelihoodChains[[jj]][1:OldLen];
    }
  }
  this$LikelihoodChains = listLike;
  this$CodaChains = as.mcmc(listAll);
   
  if (!is.null(this$MeanWeightsL)) { 
    NWeightsL = NULL;
    NWeightsL = list();
    NWeightsL <- list();
    for (jj in 1:numChains) {
      NWeightsL[[jj]] = 
        rep(0,NewLen*length(AFD$Y));
      NWeightsL[[jj]][1:length(this$MeanWeightsL[[jj]])] =
         this$MeanWeightsL[[jj]][1:length(this$MeanWeightsL[[jj]])]
    }
    this$MeanWeightsL = NWeightsL;
    this$AllWeightsL = NULL;
  }
  
  for (jj in 1:numChains) {
    LT = 0;
    this$Beta = this$CodaChains[[jj]][OldLen,1:length(this$Beta)];
    LT = LT + length(this$Beta);
    if (!is.null(this$tau)) {
      this$tau = this$CodaChains[[jj]][
        OldLen,length(this$Beta) + 1:length(this$tau)];  
      LT = LT + length(this$tau);  
    }
    if (!is.null(this$tauCrosses)) {
      this$tau = this$CodaChains[[jj]][
        OldLen, LT + 1:length(this$tauCrosses)];
      LT = LT + length(this$tauCrosses);     
    }
    this$Sigma = this$CodaChains[[jj]][OldLen,LT+1];
    try(AR <- 0);
    try(AR <- RunChainsCC(this, AFD = AFD, 
      ChainIter = jj, HackTau = NULL, dfTNoise = this$dfTNoise, 
      CheckNaFlag = 0, StartIter = OldLen, InformEvery = InformEvery));
    if (is.numeric(AR) && length(AR) >= 1 && AR[1] == -129) {
      print("We receive an RChains fail returning!"); return(-129);
    }
  }  
});

setMethodS3("getOn", "FullDiallelAnalyze", function(this,...) {
  if (is.null(this$OnObs) || this$OnObs < 0 || this$OnObs >
    length(this$AllDiallelObs)) {
    print("getOn Error: OnObs is not set"); flush.console();
    return(-1);
  }
  return(this$AllDiallelObs[[this$OnObs]]);
});
setMethodS3("getCodaChains", "FullDiallelAnalyze", function(this,...) {
  if (is.null(this$OnObs) || this$OnObs < 0 || this$OnObs >
    length(this$AllDiallelObs)) {
    print("getOn Error: OnObs is not set"); flush.console();
    return(-1);
  }
  return(this$AllDiallelObs[[this$OnObs]]$CodaChains);
});
setMethodS3("getChains", "FullDiallelAnalyze", function(this,...) {
  if (is.null(this$OnObs) || this$OnObs < 0 || this$OnObs >
    length(this$AllDiallelObs)) {
    print("getOn Error: OnObs is not set"); flush.console();
    return(-1);
  }
  return(this$AllDiallelObs[[this$OnObs]]$getChains());
});

setMethodS3("getCent.chains", "FullDiallelAnalyze", function(this,...) {
  if (is.null(this$OnObs) || this$OnObs < 0 || this$OnObs >
    length(this$AllDiallelObs)) {
    print("getOn Error: OnObs is not set"); flush.console();
    return(-1);
  }
  return(this$AllDiallelObs[[this$OnObs]]$getCent.chains());
});

setMethodS3("getRaw.chains", "FullDiallelAnalyze", function(this,...) {
  if (is.null(this$OnObs) || this$OnObs < 0 || this$OnObs >
    length(this$AllDiallelObs)) {
    print("getOn Error: OnObs is not set"); flush.console();
    return(-1);
  }
  return(this$AllDiallelObs[[this$OnObs]]$CodaChains);
});

setMethodS3("SetupChains", "DiallelOb", function(this, 
  numChains = defaultnumChains, lengthChains = defaultlengthChains, 
  XColNames = NULL, WeightChainFlag = FALSE,
  RecordTWeights = 0, AFD = NULL, Extractor = NULL, Wanted = NULL, ...) {
  if (is.null(AFD)) {
    AFD = this$.AFD;
    ##tryCatch("SetupChains: You should supply AFD"); flush.console();
  }
  if (!is.null(AFD$Verbose) && 
    ((is.logical(AFD$Verbose) && AFD$Verbose == TRUE) ||
     (is.numeric(AFD$Verbose) && AFD$Verbose[1] > 1))) {
    print(paste("SetupChains: DiallelOb = ", AFD$OnObs, " lets see inputs"));
    if (is.null(Wanted)) {
      print("Wanted input is null"); 
    }
    if (is.null(Extractor)) {
      print("Extractor input is null");
    }
    flush.console();
  }
    
  KeeperList = NULL;
  if (!is.null(Extractor)) {
    if (!is.function(Extractor)) {
      tryCatch("SetupChains: your Extractor is not a function!");
    }
    if (is.null(AFD$Verbose)) { AFD$Verbose = FALSE; }
    if ((is.logical(AFD$Verbose) && AFD$Verbose == TRUE) ||
      (is.numeric(AFD$Verbose) && AFD$Verbose > 1)) {
      print(paste("SetupChains: DiallelOb = ", AFD$OnObs, " we'll set Extractor!"));
      flush.console();
    }
    ASet = NULL;
    try(ASet <- Extractor(this$getState()));
    if (is.null(ASet)) {
      print(paste("Error on Model ", this$.ajLevel, this$.MotherModel,
        this$.CrossModel, this$.SexModel, this$.BetaInbredLevel, this$.BetaInbredTimesSex,
        sep=""));
      tryCatch("SetupChains: your Extractor returns a NULL Set!")
    }
    McMcKeep = this$getState();
    if (is.null(names(ASet))) {
      names(ASet) = 1:length(ASet);
    }
    MyM = match(names(ASet), names(McMcKeep));
    if (sum(is.na(MyM)) <= 0) {
      this$Wanted = ASet;
      this$KeeperList = MyM - 1;
      this$LengthChainsMatrix = length(ASet);
      this$namesChainsMatrix = names(Aset);
      this$Extractor = NULL;
      if (is.null(AFD$Verbose)) { AFD$Verbose = FALSE; }
      if ((is.logical(AFD$Verbose) && AFD$Verbose == TRUE) ||
        (is.numeric(AFD$Verbose) && AFD$Verbose > 1)) {
        print(paste("SetupChains: DiallelOb = ", AFD$OnObs, ", Extractor is converted to Wanted!"));
        flush.console();
      }
    } else {
      this$Wanted = NULL;
      this$LengthChainsMatrix = length(ASet);
      this$Extractor = Extractor;
      this$namesChainsMatrix = names(ASet);
    }
  } else if (!is.null(Wanted)) {
    if (is.null(AFD$Verbose)) { AFD$Verbose = FALSE; }
    if ((is.logical(AFD$Verbose) && AFD$Verbose == TRUE) ||
        (is.numeric(AFD$Verbose) && AFD$Verbose > 1)) {
      print(paste("SetupChains: DiallelOb = ", AFD$OnObs, " using Non Null Wanted"));
      flush.console();
    }
    McMcKeep = names(this$getState());  
    MyM = match(Wanted, McMcKeep);
    this$LengthChainsMatrix = (length(MyM));
    this$KeeperList = MyM -1;
    this$namesChainsMatrix = Wanted;
  } else {
    KeeperList = NULL;
    this$LengthChainsMatrix = 
      length(this$Beta) + length(this$tau) + length(this$tauCrosses) +
      length(this$Sigma);
    Itau = NULL; ItauCross = NULL;
    if (length(this$tau) > 0) { 
      Itau = paste(names(this$tau), sep="");
      FDS = (1:length(Itau))[substr(Itau,1,nchar("tau:")) != "tau:"]
      Itau[FDS] = paste("tau:", Itau[FDS], sep="");
    }
    if (length(this$tauCrosses) > 0) { 
      ItauCross = paste(names(this$tauCrosses), sep="");
      ItauCross = paste(names(this$tauCrosses), sep="");
      FDS = (1:length(ItauCross))[
        substr(ItauCross,1,nchar("tauCrosses:")) != "tauCrosses:"]
       ItauCross[FDS] = paste("tauCrosses:", 
         ItauCross[FDS], sep="");
    }
    this$namesChainsMatrix = c(names(this$Beta), 
       Itau, ItauCross, names(this$Sigma)); 
  }
  ##if (is.null(names(this$Sigma))) {
  names(this$Sigma) = paste("Sigma:", 1:length(this$Sigma), sep="");
  ##}
  ChainMatrix = matrix(0, lengthChains, this$LengthChainsMatrix);
  colnames(ChainMatrix) = this$namesChainsMatrix;

   ##print(paste("length(Sigma) = ", length(this$Sigma), 
   ##  " and length(names(Sigma)) = ", 
   ## length(names(this$Sigma)),
   ## sep=""));
            
   ##print(paste(" length other stuff = ", 
   ##       length(  c(names(this$Beta), names(this$tau), 
   ##       names(this$tauCrosses), names(this$Sigma) )
   ##        ), sep="") ) ;

  
   listAll = list(); this$T1 = list(); this$T2 = list(); this$TDiff = list();
   listAll[[1]] = as.mcmc(ChainMatrix);
   this$T1[[1]] = 0; this$T2[[1]] = 0;
   listLike = list();
   listLike[[1]] = rep(0, lengthChains);
   if (numChains > 1) {
     for (jj in 2:numChains){ 
       ##print( " As McMC 1 ?")
       ChainMatrix = matrix(0, lengthChains, 
         this$LengthChainsMatrix );
       colnames(ChainMatrix) = this$namesChainsMatrix;       
       listAll[[jj]] =  as.mcmc(ChainMatrix);
       this$T1[[jj]] = 0; this$T2[[jj]] = 0;
       listLike[[jj]] = rep(0, lengthChains);
     }
   }
   
   if (RecordTWeights == 0) {
     this$MeanWeightsL = NULL;
     this$AllWeightsL = NULL;
   } else if (RecordTWeights == 1) {
     this$MeanWeightsL = list();
     this$AllWeightsL = NULL;
     for (jj in 1:numChains) {
       this$MeanWeightsL[[jj]] = rep(0,lengthChains*length(AFD$Y))
     }
   }
   ##print( " As McMc 2 ? ");
   ##this$NonCodaChains = listAll;
   
   this$CodaChains = as.mcmc(listAll);
   this$LikelihoodChains = listLike;
});



###### Density of inverse Gamma
ldinvgamma <- function(X, shape, scale =1) {
	-lgamma(shape)  + shape * log(scale) - (shape+1)*log(X) - scale / X;
}
#########
##   Pretend set of ii,jj pairs used in simulation
##
NumRepeats = 200;

setMethodS3("findStartModel","FullDiallelAnalyze", function(
      this, StartModel= c(0,0,0,0,0,0), ...) {
  StrStartMode = paste(StartModel, collapse="o");
  for (ii in 1:length(this$AllDiallelObs)) {
       if (StrStartMode == 
            paste(getModel(this$AllDiallelObs[[ii]]), collapse="o") ) {
          return(ii);               
       }
  }
  print("findStartModel does not find Model!");          
});

setMethod("getModel", "FullDiallelAnalyze", function(this,...) {
  if (is.null(this$OnObs) || this$OnObs < 1 || round(this$OnObs) != this$OnObs) {
    return(-1); 
  }
  return(this$AllDiallelObs[[this$OnObs]]$getModel());
});

setMethodS3("RunChains", "FullDiallelAnalyze", function(
             this, ChainIter = 1, HackTau = NULL, StartModel = NULL,
             SaveFile = "", Verbose = NULL, dfTNoise = NULL, NoReject = FALSE,
             InformEvery = 200,
             ...) {
  if (length(StartModel) == 6) {
    iiStart = findStartModel(this, StartModel);
  } else { iiStart = 1; }
     
  if (!is.null(Verbose)) {
    this$Verbose = Verbose;
  } else {
    Verbose = this$Verbose
  }
  if (is.null(Verbose)) {Verbose = FALSE}
  if (!is.null(dfTNoise) && dfTNoise > 0) { this$dfTNoise = dfTNoise; }
    for(ii in iiStart:length(this$AllDiallelObs)) {
      if (!is.null(Verbose) && Verbose == TRUE) {
        print(paste("Fitting Model: ",
          paste(getModel(this$AllDiallelObs[[ii]]), collapse=", "),
          sep="")); flush.console();
      }
      for (ChainIter in 1:length(this$AllDiallelObs[[ii]]$CodaChains)) {
        if (Verbose == TRUE) {
          print(paste("----  Fitting Model: ChainIter = ", ChainIter, ": ",
            paste(getModel(this$AllDiallelObs[[ii]]), collapse=", "),
            sep="")); flush.console();
        }
        if (!is.null(this$dfTNoise) && length(this$dfTNoise) >= ii) {
          OndfTNoise = this$dfTNoise;
          ##print(paste(" Here we test in dfTNow : ", this$AllDiallelObs[[ii]]$dfTNoise,
          ## "  against ", OndfTNoise, sep=""));  flush.console();
          if (is.null(this$AllDiallelObs[[ii]]$dfTNoise) || 
            this$AllDiallelObs[[ii]]$dfTNoise != OndfTNoise){
            tryCatch(paste("Error, dfTNoise in Full DiallelObject does not ",
              "match current in model ii = ", ii, sep=""))
          }
        } else if (!is.null(this$dfTNoise) && length(this$dfTNoise) >= 1 &&
          !is.na(this$dfTNoise[1]) && this$dfTNoise[1] > 0) {
          OndfTNoise = this$dfTNoise[1];
        } else {
          OndfTNoise = -1;
        }
        SetRandomValues(this, Sigma = 1 / rchisq(1,df=2),
          OnDOB = ii);
        this$OnObs = ii;
        AR = 0;
        try(AR <- RunChainsCC(this$AllDiallelObs[[ii]], AFD = this, 
          ChainIter=ChainIter, HackTau = HackTau,
          dfTNoise = NULL, InformEvery = InformEvery)); 
        if (this$Verbose >= 2) {
          print(paste("** At end Running OnObs = ", ii, " and Chain = ", ChainIter)); flush.console();
        }
        if (is.numeric(AR) && length(AR) >= 1 && AR[1] == -129) {
          print("RunChainsCC: we reach negative return, investigate!"); flush.console();
          if (any(is.nan(this$AllDiallelObs[[ii]]$Beta)) ||
             any(is.na(this$AllDiallelObs[[ii]]$Beta))) {
            print(paste(" Indices: ",
             paste( (1:length(this$AllDiallelObs[[ii]]$Beta))[
               is.nan((1:length(this$AllDiallelObs[[ii]]$Beta))) |
               is.na((1:length(this$AllDiallelObs[[ii]]$Beta)))
               ], collapse=", "), " of Beta are NAN ", sep=""));
            flush.console();
          }
          if (any(is.nan(this$AllDiallelObs[[ii]]$tau)) ||
            any(is.na(this$AllDiallelObs[[ii]]$tau)) ) {
            print(paste(" Indices: ",
             paste( (1:length(this$AllDiallelObs[[ii]]$tau))[
               is.nan((1:length(this$AllDiallelObs[[ii]]$tau))) |
               is.na((1:length(this$AllDiallelObs[[ii]]$tau)))
               ], collapse=", "), " of tau are NAN ", sep=""));
            flush.console();
          }
          return(-1);
        }
     
      }
      this$OnObs = ii;
      if (!is.null(this$DoGelman) && is.logical(this$DoGelman) &&
        this$DoGelman == TRUE) {
        MyQ <- 0;
          MyText <- "
           GelmanAnalysis = gelman.diag(this$AllDiallelObs[[ii]]$CodaChains,
            autoburnin=TRUE);
          MyQ <- 1; 
        ";
        try(eval(parse(text=MyText)));
        if (MyQ == 0) {
          print("************************************************************");
          print("RunChains: On First Gelman Analysis we receive a fail! "); flush.console();
          print("Writing AFD to global!");
          try(eval(parse(text=SetGText("AFD", "globalenv()", S=1))));
          return(AFD);
        }
      if (is.null(GelmanAnalysis$psrf) || is.null(GelmanAnalysis$msprf)) {
        tryCatch("Error, we looked at GelmanAnalysis, but no psrf or msprf!");
      }
      if (max(GelmanAnalysis$psrf, na.rm=TRUE) > 1.2 || GelmanAnalysis$mpsrf[1] > 1.1) {    
        MyQ <- 1;
        MyText <- "
        GelmanAnalysis = gelman.diag(this$AllDiallelObs[[ii]]$CodaChains,
          transform=TRUE,autoburnin=TRUE);
        MyQ <- 1;
        ";
        try(eval(parse(text=MyText)));
        if (MyQ == 0) {
          print("**************************************************************");
          print("RunChains: Hey, we get a fail on performing Gelman Analysis on second Try!...");
          print(paste("*** when we were on chain length ", NROW(this$AllDiallelObs[[ii]]$CodaChains[[1]])));
        }      
      }
      FT = 0;
      if (NoReject == FALSE) {
      while (max(GelmanAnalysis$psrf, na.rm = TRUE) > 1.2 || GelmanAnalysis$mpsrf[1] > 1.1) {
        if ((is.numeric(Verbose) && Verbose > -1) || Verbose == TRUE) {
          print(paste("----  Rejected Chains: ChainIter = ", ChainIter, ": ",
            paste(getModel(this$AllDiallelObs[[ii]]), collapse=", "),
            sep="")); flush.console(); 
        }
        ReplaceAndRerunUpdatedChains(this$AllDiallelObs[[ii]], AFD=this);
        MyQ <- 0;
        MyText <- "
        GelmanAnalysis = gelman.diag(this$AllDiallelObs[[ii]]$CodaChains,
          transform = TRUE, autoburnin=TRUE);
        MyQ <- 1; ";
        try(eval(parse(text=MyText)));
        if (MyQ == 0) {
          print("**************************************************************");
          print("RunChains: Hey, we get a fail on performing Gelman Analysis...")
          print(paste("*** when we were on chain length ", NROW(this$AllDiallelObs[[ii]]$CodaChains[[1]])));
        }
        if (is.null(GelmanAnalysis$psrf) || is.null(GelmanAnalysis$msprf)) {
          tryCatch("Error, we looked at GelmanAnalysis on NoReject loop, but no psrf or msprf!");
        }   
        if (max(GelmanAnalysis$psrf, na.rm=TRUE) > 1.2 || GelmanAnalysis$mpsrf[1] > 1.1) {
          GelmanAnalysis = gelman.diag(this$AllDiallelObs[[ii]]$CodaChains,
            transform=TRUE,autoburnin=TRUE);      
        }
        if (FT > 2) {
          print(paste("We're upping the Gelman analysis now to : ",
            length(this$AllDiallelObs$CodaChains[[1]][,1]), sep=""));
        }
        FT = FT + 1;
        if (FT > 10) {
          print(paste("We've upped the length to huge ",
            length(this$AllDiallelObs$CodaChains[[1]][,1]), 
            " and no Convergence!", sep=""));
          break;
        }
      }
      } 
    } 
      if (Verbose == TRUE) {
        print(paste("-- Fitted Model: ",
          paste(getModel(this$AllDiallelObs[[ii]]), collapse=", "),
          sep="")); flush.console();
      }
      PointerTothis = this;
      if (SaveFile != ""  && !is.null(SaveFile)) {
        save(this, file=SaveFile);
      }
    }
    return(1);
});

setMethodS3("RunChainsOld", "FullDiallelAnalyze", function(
             this, ChainIter = 1, HackTau = NULL, StartModel = NULL,
             SaveFile = "", ...) {
     if (length(StartModel) == 6) {
        iiStart = findStartModel(this, StartModel);
     } else { iiStart = 1; }
     
     for(ii in iiStart:length(this$AllDiallelObs)) {
         this$OnObs = ii;
         print(paste("Fitting Model: ",
              paste(getModel(this$AllDiallelObs[[ii]]), collapse=", "),
              sep="")); flush.console();
         for (ChainIter in 1:length(this$AllDiallelObs[[ii]]$CodaChains)) {
         print(paste("----  Fitting Model: ChainIter = ", ChainIter, ": ",
              paste(getModel(this$AllDiallelObs[[ii]]), collapse=", "),
              sep="")); flush.console();
              SetRandomValues(this, Sigma = 1 / rchisq(1,df=2),
                               OnDOB = ii);
              RunChain(this$AllDiallelObs[[ii]], AFD = this, 
                       ChainIter=ChainIter, HackTau = HackTau);        
         }
         print(paste("-- Fitted Model: ",
              paste(getModel(this$AllDiallelObs[[ii]]), collapse=", "),
              sep="")); flush.console();
         PointerTothis = this;
         if (SaveFile != ""  && !is.null(SaveFile)) {
            save( this, 
                  file=SaveFile);
         
         }
     }       
});

setMethodS3("RunEM", "FullDiallelEMAnalyze", function(
             this, ChainIter = 1, HackTau = NULL, StartModel = NULL,
             SaveFile = "", cauchy.delta = .01,...) {
     if (length(StartModel) == 6) {
        iiStart = findStartModel(this, StartModel);
     } else { iiStart = 1; }
     
     for(ii in iiStart:length(this$AllDiallelObs)) {
         print(paste("EM Fitting Model: ",
              paste(getModel(this$AllDiallelObs[[ii]]), collapse=", "),
              sep="")); flush.console();
         for (ChainIter in 1:length(this$AllDiallelObs[[ii]]$CodaChains)) {
         print(paste("----  Fitting Model: ChainIter = ", ChainIter, ": ",
              paste(getModel(this$AllDiallelObs[[ii]]), collapse=", "),
              sep="")); flush.console();
              SetRandomValues(this, Sigma = 1 / rchisq(1,df=2),
                               OnDOB = ii);
              this$AllDiallelObs[[ii]]$cauchy.delta = cauchy.delta;
              RunEM(this$AllDiallelObs[[ii]], AFD = this, 
                       ChainIter=ChainIter, HackTau = HackTau);        
         }
         print(paste("-- Fitted Model: ",
              paste(getModel(this$AllDiallelObs[[ii]]), collapse=", "),
              sep="")); flush.console();
         PointerTothis = this;
         if (SaveFile != ""  && !is.null(SaveFile)) {
            save( this, 
                  file=SaveFile);
         
         }
     }       
});



setMethodS3("RecalculateLikelihoods", "FullDiallelAnalyze",
  function(this, SaveFile = NULL,...) {
    for(jj in 1:length(this$AllDiallelObs)) {
      print(paste(" On jj = ", jj, " out of ", 
                    length(this$AllDiallelObs), sep=""));
      RecalculateLikelihood(this$AllDiallelObs[[jj]], this);
      if (SaveFile != ""  && !is.null(SaveFile)) {
        save( this, 
             file=SaveFile);
        
      }   
    }
})
setMethodS3("RecalculateLikelihood", "DiallelOb", 
    function(this, AFD=NULL,...) {
  if (!is.null(AFD$XtX)) {
    XtX = AFD$XtX[this$XSubSetList, this$XSubSetList];
  } else {
    AFD$XtX = t(AFD$X) %*% AFD$X;
    XtX = AFD$XtX[this$XSubSetList, this$XSubSetList];
  }
  if (!is.null(AFD$XtY)) {
    XtY = AFD$XtY[this$XSubSetList]
  } else {
    AFD$XtY = t(AFD$X) %*% AFD$Y;
    XtY = AFD$XtY[this$XSubSetList];
  }
  if (!is.null(AFD$sumYSq)) {
    sumYSq = AFD$sumYSq;
  }  else {
    AFD$sumYSq = sum(AFD$Y^2);
    sumYSq = AFD$sumYSq;
  }
  for (ChainIter in 1:length(this$CodaChains)) {
    for (jj in 1:length(this$CodaChains[[ChainIter]][,1])) {
      OSigma = this$CodaChains[[ChainIter]][jj,
        length(this$CodaChains[[ChainIter]][1,]) ]; 
      OBeta = this$CodaChains[[ChainIter]][jj,
        1:length(this$Beta) ];
      SumDeviance = sumYSq - 2 * sum(XtY * OBeta) +
        t(OBeta) %*% XtX %*% OBeta
      this$LikelihoodChains[[ChainIter]][jj] = - length(AFD$Y) /2 * 
           log( OSigma) - SumDeviance / (2 * OSigma);
    }
    
  }
});


setMethodS3("SetupInbredNoise", "DiallelOb", function(this,
  AFD = NULL, tauInbredNoise = 0, ...)
  {
 if (AFD == NULL) {
   print("No Full DiallelObject to setup HybridNoise");
 }
 if (tauInbredNoise > 0) {
   this$toggleInbred = rep(-1, length(AFD$Y));
   this$toggleHybrid[Listjk[,1] == Listjk[,2]] = 1;
   this$tauInbredNoise = tauInbredNoise;
   this$SigmaDeltaInbred = 0;
 }
}
);
setMethodS3("getX", "DiallelOb", function(this, AFD = this$.AFD,...) {
  if (is.null(this$.X) || NROW(this$.X) != length(AFD$Y) ) { 
    this$.X = AFD$X[,this$XSubSetList]; 
  }
  return(this$.X);
});
setMethodS3("RunChainsCC", "DiallelOb", function(this, AFD = this$.AFD, 
  ChainIter = 1, HackTau = NULL, dfTNoise = NULL, CheckNaFlag = 0, 
  StartIter = 1, InformEvery = -1, Verbose = NULL, ...) {
  if (!exists("HackTau")) { HackTau = NULL; }
  if (!exists("CheckNaFlag")) { CheckNaFlag = NULL; }
  if (!exists("StartIter")) { StartIter = 1; }
  if (!exists("ChainIter")) { ChainIter = 1; }
  if (!exists("dfTNoise")) { dfTNoise = this$dfTNoise; }
  if (!exists("InformEvery")) { InformEvery = -1; }
  if (!exists("Verbose")) { Verbose = this$Verbose; }
 
  if (!exists("AFD") || is.null(AFD)) {
    AFD = this$.AFD;
  }
  if (!is.null(Verbose)) {
    if (is.logical(Verbose)) {
      if (Verbose == FALSE) {
        Verbose = -4;
      } else if (Verbose == TRUE) {
        Verbose = 2;
      }
    } else if (is.character(Verbose)) {
      Verbose = 0;
    }
  } else {
    if (is.null(AFD$Verbose)) {
      tryCatch("RunChainsCC: Error, AFD has no Verbose variable!");
    }
    if (is.null(AFD$Verbose)) { AFD$Verbose = FALSE; }
    if (is.null(AFD$Verbose)) { AFD$Verbose = FALSE; }
    if (is.logical(AFD$Verbose)) {
      if (AFD$Verbose == FALSE) {
        Verbose = -4;
      } else if (AFD$Verbose == TRUE) {
        Verbose = 2;
      }
    } else {
      Verbose = AFD$Verbose -1;
    }
  }
  if (Verbose > 0) {
    print("RunChainsCC: Looking at this$X"); flush.console();
  }
  
  if (is.null(AFD)) {
    tryCatch("RunChainsCC: false AFD supplied");
  }

  
  if (!is.null(AFD$ListUnknownGender) && length(AFD$ListUnknownGender) > 0) {
    FF = FALSE;
    AText = "SetupUnknownGender(this, AFD);  FF = TRUE";
    try(eval(parse(text=AText)));
    if (FF == FALSE) {
      print("Attempt to setup Gender using AFD$listUnknownGender Failed"); flush.console();
    }
  }
  if (is.numeric(Verbose) && Verbose > 2)  {
    print("RunChainsCC: On AdiallelOb: start"); flush.console();
  }
  if (!exists("this")) {
    print("RunChainsCC: `this' doesn't exist?"); flush.console();
  }
  if (!is.null(dfTNoise)) { this$dfTNoise = dfTNoise; }
  if (length(ChainIter) >= 1 && (min(ChainIter) > 0 
    && max(ChainIter) <= length(this$CodaChains))) {
    ChainIters = ChainIter;
  } else {
    ChainIters = 1:length(this$CodaChains);
  }

  if (length(AFD$Y) <= 0) {
    print(paste("We cannot pass go, AFD$Y has length less than zero!")); flush.console();
  }
  if (is.null(this$.X) || NROW(this$.X) != length(AFD$Y) ) { 
    this$.X = AFD$X[,this$XSubSetList]; 
  }
  MyY = AFD$Y; MyX = this$X;
  if (!is.matrix(MyX) || !is.numeric(MyX)) {
    AX = matrix(0, NROW(MyX), NCOL(MyX));
    for (ii in 1:NCOL(MyX)) {
      AX[,ii] = as.numeric(MyX[,ii]);
    }
    colnames(AX) = colnames(MyX);
    this$X = AX;
    MyX = AX;
  }
  
  MyXtX = t(MyX) %*% MyX;
  if (is.null(AFD$Y) || length(AFD$Y) != NROW(MyX)) {
    print(paste("Uh oh, before Multiplying, dim(X) = (", 
      paste(dim(X), collapse=", "),") and length(Y) = ", length(Y), sep=""));
    flush.console();
  }
  MyXtY = t(MyX) %*% AFD$Y;
  
  this$SumYSq = sum(AFD$Y^2);
  MySumYSq = this$SumYSq;
  if (length(this$VecOWeights) > 0) {
    try(MySumYSq <- sum(AFD$Y * AFD$Y * this$VecOWeights));
    try(this$SumYSq <- MySumYSq);
  }
  
  dfTNoise = this$dfTNoise;

  
  MyBeta = this$Beta;
  Mytau = this$tau  
  MySigmaSq = this$Sigma;
  if (MySigmaSq <= 0) {
    this$Sigma = rchisq(1,df=1.0);
    MySigmaSq = this$Sigma;
  }
  MyLikelihood = 0;


  MyQ = matrix(as.numeric(MyXtX), length(MyXtX[,1]), length(MyXtX[1,]));
  if (MaxInvert < dim(MyQ)[1]) {
    MyInvQ = matrix(as.numeric(MyXtX), MaxInvert, MaxInvert);
    MyInvSqQ = matrix(as.numeric(MyXtX), MaxInvert, MaxInvert);  
  } else {
    MyInvQ = matrix(as.numeric(MyXtX), length(MyXtX[,1]), length(MyXtX[1,]));
    MyInvSqQ = matrix(as.numeric(MyXtX), length(MyXtX[,1]), length(MyXtX[1,]));
  }
  MyDpBeta = this$DpBeta;
  MyTauFixed = this$.tauFixed;
  Mymtau = this$mtau;
  Mydftau = this$dftau;
  mSigma = AFD$m$Sigma;
  dfSigma = AFD$df$Sigma;
  MyWantDiag = rep(0, length(MyXtX[1,]));
  MyCrossModel = this$.CrossModel
  MyBetaInbredLevel = this$.BetaInbredLevel
  MytauCrosses = this$tauCrosses;
  jCross = AFD$ACrossLocations$jCross;
  jCrossO = AFD$ACrossLocations$jCrossO;
  kCross = AFD$ACrossLocations$kCross;
  kCrossO = AFD$ACrossLocations$kCrossO;

  ##print("Testing to see whether to setup ImputedYChains!");
  ##print()
  if (!is.null(AFD$MissingYIndices) && (!is.logical(AFD$NoChainsImputeY) ||
    AFD$NoChainsImputeY == FALSE) ) {
    this$ImputedYChains = 999;
    ImputedYChains=list();
    ##print("Creating ImputedYChains!"); flush.console();
    for (iji in 1:length(this$CodaChains)) {
      ImputedYChains[[iji]]  = as.mcmc(matrix(0, NROW(this$CodaChains[[1]]),
        length(AFD$MissingYIndices))); 
    }
    FF = FALSE;
    ##print("Assigning ImputedYChains!"); flush.console();
    AText = "this$ImputedYChains <- as.mcmc.list(ImputedYChains);  FF = TRUE;"
    try(eval(parse(text=AText)));
    if (FF == FALSE) {
      try(this$ImputedYChains <- ImputedYChains);
    }
    if (is.null(this$ImputedYChains)) {
      print("Doh, ImputedYChains is still NULL for this!"); flush.console();
    }
  }
    ListUnknowns = this$ListUnknownGender;  GXX = this$GXX;
    ImputedGender = NULL;
    if (!is.null(ListUnknowns) && this$.SexModel > 0) {
      MyS = (1:NCOL(MyX))[colnames(MyX) == "Gender:Av"]
      ##if (max(this$ListUnknownGender)
      ImputedGender = round(MyX[this$ListUnknownGender, MyS] +.5);  
      this$ImputedGender = ImputedGender; 
      NewImputedGender = rbinom(length(this$ListUnknownGender),1,this$ProbUnknownGender );
      if (any(abs(MyX[,MyS]) <= .1) || any(abs(MyX[,MyS]) > .5)) {
        MyX = AFD$X[,this$XSubSetList];
        this$.X = MyX;
        ImputedGender = round(MyX[this$ListUnknownGender, MyS] +.5); 
        this$ImputedGender = ImputedGender;   
      } 
      if (any(abs(MyX[,MyS]) <= .1)) {
        print("Before MyX imputation we have a zero, uh oh!"); flush.console();
        tryCatch("Error in MyX, we zeroed out when we NewImputedGender!");
      }
      FF = FALSE;
      AText = "
      MyX[this$ListUnknownGender,] =  MyX[this$ListUnknownGender,] +
        2*(NewImputedGender - ImputedGender) * GXX;  FF = TRUE;";
      try(eval(parse(text=AText)));
      if (FF == FALSE) {
        print("RunChainsCC:  Error, running MyX assignment was a fail."); flush.console();
      }
      this$ImputedGender = NewImputedGender;
      ImputedGender = NewImputedGender;
      if (any(abs(MyX[,MyS]) <= .1)) {
        if (any(GXX[,MyS] != .5)) {
          print("Well, thats why imputation failed GXX vector is :");
          print(as.vector(GXX[,MyS])); flush.console();
          tryCatch("Can't make up for that!");
        }
        if (any(MyX[this$ListUnknownGender,MyS] != .5 * ( 2* ImputedGender -1))) {
          print("Well, thats why imputation failed, ImputedGender = ");
          print(as.vector(ImputedGender));
          print("But MyX[this$ListUnknownGender,MyS] == ");
          print(MyX[this$ListUnknownGender,MyS]); flush.console();
          print("Failure at: ");
          print(paste( (1:length(ImputedGender))[
            MyX[this$ListUnknownGender,MyS] != .5 * (2 * ImputedGender -1 )],
            collapse=", ")); flush.console();
        }
        if (any(!(NewImputedGender %in% c(0,1)))) {
          print("Well, thats why imputation failed, NewImputedGender = ");
          print(NewImputedGender);
          print("Failure at: ");
          print(paste( (1:length(NewImputedGender))[!(NewImputedGender %in% c(0,1))],
            collapse=", ")); flush.console();
        }
        ANew = MyX[this$ListUnknownGender,];
        for (ijk in 1:length(ImputedGender)) {
          ANew[ijk,] = 2 * (NewImputedGender[ijk] - 
            ImputedGender[ijk]) * GXX[ijk,];
        }
        try(MyX[this$ListUnknownGender,] <- ANew);
        
      }
      if (any(abs(MyX[,MyS]) <= .1)) {
        print("After MyX imputation we have a zero, uh oh!"); flush.console();
        tryCatch("Error in MyX, we zeroed out when we NewImputedGender!");
      }
      this$.X = MyX; 
      MyXtX = t(MyX) %*% MyX;
      this$XtX = MyXtX;
      if (!is.null(this$VecOWeights) && length(this$VecOWeights) > 0) {
        try(MyXtY <- t(MyX) %*% (this$VecOWeights * MyY));
      }  else {
        MyXtY = t(MyX) %*% MyY;
      }
      this$XtY = MyXtY;
    }
    

    PriorGender = this$ProbUnknownGender;
    
    ImputeGenderChains = this$ImputeGenderChains;  KeeperList = this$KeeperList;
    if (length(ListUnknowns) > 0 &&
      is.null(ImputeGenderChains) || length(ImputeGenderChains[[1]]) < length(ImputedGender)) {
      ImputeGenderChains = NULL;
    }
    if (length(ListUnknowns) > 0 && is.null(ImputedGender)  && this$.SexModel > 0) {
      this$ImputedGender = rbinom(length(ListUnkowns), 1, .5);
      ImputedGender = this$ImputedGender;
    } else {
      ImputedGender = NULL;
    }
  
    if (!is.null(ListUnknowns)) {
      CListUnknowns = ListUnknowns -1;
    } else {
      CListUnknowns = NULL;
    }
    Extractor = this$Extractor;  State = this$State;
    if (is.null(Verbose)) { Verbose = -2; }
    if  (is.numeric(Verbose) && Verbose > 2) {
      if (!is.null(KeeperList)) {
        print("Note: RunChainsCC: KeeperList is non NULL"); flush.console();
      } else if (!is.null(Extractor)) {
        print("Note: RunChainsCC: Extractor is non NULL"); flush.console();
      } else {
        print("Note: RunChainsCC: Extractor and KeeperList are NULL!"); flush.console();
      }
    }
  stauInbredNoise = 0; stoggleInbred = 0; sSigmaDeltaInbred = 0;
 
  for (ChainIteri in ChainIters) {
    if (!exists("ChainIteri")) {
      ChainIteri = 1;
    }
    if (is.null(AFD$Verbose)) { AFD$Verbose = FALSE; }
    if (is.numeric(AFD$Verbose) && AFD$Verbose > 2) {
      print(paste("RunChainsCC: On ChainIteri = ", ChainIteri, sep="")); flush.console();
    }
    FF = FALSE;
    if (any(is.na(this$Beta)) || any(is.nan(this$Beta))) {
      print("RunChainsCC: Error, before start, we have nan this$Beta! ");
      flush.console();
      return(-1);
    }
    if (any(is.na(this$tau)) || any(is.nan(this$tau))) {
      print("RunChainsCC: Error, before start, we have nan this$tau! ");
      flush.console();
      return(-1);
    }
    if (any((this$tau) <= 0) || any(is.nan(this$tau))) {
      print("RunChainsCC: Error, before start, we have this$tau <= 0! ");
      flush.console();
      return(-1);
    }
    AText = "
    if(!is.null(this$dfTNoise)  && this$dfTNoise > 0) {
      this$VecOWeights = rchisq(length(AFD$Y), df=1.0);
      VecOWeights = this$VecOWeights;
      this$fW = rep(1.0, max(dim(MyX)));
      fW = this$fW;
      if (any(is.na(VecOWeights)) || any(is.nan(VecOWeights))) {
        print(\" RunChainsCC Error in dfTNoise simming of new weights, nan weights! \");  flush.console();
        this$XtX = t(MyX) %*% (VecOWeights * MyX);
        this$.X = MyX;
        return(-1);
      }
      if (any(is.na(MyX)) || any(is.nan(MyX))) {
         print(\" RunChainsCC Error in dfTNoise, there are start nan MyX!\");
         flush.console();
         this$.X = MyX;
         return(-1);
      }
      if (length(this$MeanWeightsL) >= ChainIteri) {
        MeanWeights = this$MeanWeightsL[[ChainIteri]];
      } else {MeanWeights = NULL;}
      if (length(this$AllWeightsL) >= ChainIteri) {
        AllWeights = this$AllWeightsL[[ChainIteri]];
      } else {AllWeights = NULL; }
      MyXtX  = t(MyX) %*% (VecOWeights * MyX);
      this$XtX = MyXtX;
      if (any(is.na(this$XtX)) || any(is.nan(this$XtX))) {
        print(\" Error in dfTNoise simming of new XtX, nan XtX \");  flush.console();
        this$.X = MyX;
        return(-1);
      }
      MyXtY = t(MyX) %*% (VecOWeights * AFD$Y);
      if (any(is.na(MyXtY)) || any(is.nan(MyXtY))) {
        print(\" Error in dfTNoise simming of new MyXtY, nan MyXtY \");  flush.console();
        this$XtY = MyXtY;
        return(-1);
      }
      this$XtY = MyXtY;
      MySumYSq = sum(AFD$Y * AFD$Y * VecOWeights);
      try(this$SumYSq <- MySumYSq);
    } else {
      VecOWeights = NULL; fW = c(0,0);  
      this$fW = rep(1.0, length(MyX[1,]));
      fW = this$fW;
      MeanWeights = NULL; AllWeights = NULL;
    }
    FF = TRUE;
    ";
    try(eval(parse(text=AText)));
    if (FF == FALSE) {
      print("RunChainsCC:: Attempt to setup t degrees of freedom Failed"); flush.console();
    }

     ##print(paste("ChainIteri = ", paste(ChainIteri, collapse=", "),sep="")); flush.console();
     this$T1[[ChainIteri]] = proc.time();
     FF = FALSE;
     AText = "
     MyCodaChain = this$CodaChains[[ChainIteri]];
     MyLikelihoodChain  = this$LikelihoodChains[[ChainIteri]];  FF = TRUE;
     ";
     try(eval(parse(text=AText)));
     if (FF == FALSE) {
       print(paste("RunDiallelCC:  Error on assigning MyCodaChain for ", ChainIteri, sep=""));
       flush.console();
     }
     OldBeta = NULL;
     ImputeYString = "
     if (!is.null(CListUnknowns)  && this$.SexModel > 0) {
        MyX = AFD$X[,this$XSubSetList]
        MyS = (1:NCOL(MyX))[colnames(MyX) == \"Gender:Av\"]
        ##if (max(this$ListUnknownGender)
        ImputedGender = round(MyX[this$ListUnknownGender, MyS] +.5);  
        this$ImputedGender = ImputedGender; 
        NewImputedGender = rbinom(length(this$ListUnknownGender),1,this$ProbUnknownGender );
        if (any(abs(MyX[,MyS]) <= .1)) {
          print(\"Before MyX imputation we have a zero, uh oh!\"); flush.console();
          tryCatch(\"Error in MyX, we zeroed out when we NewImputedGender!\");
        }
        if (any(!(abs(MyX[,MyS]) == .5))) {
          print(paste(\"BeforeMyX imputation, one of MyX[,\", MyS, \"] is not .5!\", sep=\"\"));
          print(as.vector(MyX[,MyS]));
          print(paste((1:length(MyX[,MyS]))[abs(MyX[,MyS]) != .5], collapse=\", \"));
          flush.console();
          tryCatch(\"Error in MyX, we got a non 1 for MyX[,MyS]!\");
        }
        FF = FALSE;
        AText = \"MyX[this$ListUnknownGender,] <-  MyX[this$ListUnknownGender,] +
          2*(NewImputedGender - ImputedGender) * GXX;  FF = TRUE\";
        try(eval(parse(text=AText)));
        if (FF == FALSE) {
          print(\"Error, in trying to convert MyX with NewImputed Gender.\"); flush.console();
        }
        this$ImputedGender = NewImputedGender;
        ImputedGender = NewImputedGender;
        this$.X = MyX; 
        if (any(abs(MyX[,MyS]) <= .1)) {
          print( \" Well After MyX imputation we have a zero, uh oh!\"); flush.console();
          tryCatch(\"Error in MyX, we zeroed out when we NewImputedGender!\");
        }
        FF = FALSE;
        if (!is.null(this$VecOWeights) && length(this$VecOWeights) > 0) {
        AText = \"
        MyXtX = t(MyX) %*% (this$VecOWeights * MyX);
        this$XtX = MyXtX;
        if (!is.null(this$VecOWeights) && length(this$VecOWeights)> 0) {
         try(MyXtY <- t(MyX) %*% (this$VecOWeights * MyY));
        } else {
          try(MyXtY <- t(MyX) %*% MyY);
        }
        this$XtY = MyXtY;
        try(MySumYSq <- sum(AFD$Y * AFD$Y * this$VecOWeights));
        try(this$SumYSq <- MySumYSq);
        FF = TRUE;\"
        } else {
        AText = \"
        MyXtX = t(MyX) %*% ( MyX);
        this$XtX = MyXtX;
        if (!is.null(this$VecOWeights) && length(this$VecOWeights) > 0) {
         try(MyXtY <- t(MyX) %*% (this$VecOWeights * MyY));
        } else {
          try(MyXtY <- t(MyX) %*% MyY);
        }
        this$XtY = MyXtY;
        MySumYSq = sum(AFD$Y * AFD$Y);
        FF = TRUE;\"        
        }
        try(eval(parse(text=AText)));
        if (FF == FALSE) {
          print(paste(\"RunDiallelCC:  Error on iter \", ChainIteri, \" could not gender recreate MyXtX\", sep=\"\"));
          flush.console();
        }
      }";
     try(eval(parse(text=ImputeYString)))

     if (!is.null(this$ListUnknownGender) && any(colnames(MyX) == "Gender:Av")) {
       AT = NULL;
       try(AT <- (1:NCOL(MyX))[colnames(MyX) == "Gender:Av"]);
       if (is.null(AT) || length(AT) <= 0) {
         print("RunDiallelCC:  Error, well we could not find room for AT from Gender:Av column");
         flush.console();
       }
       if (any(!(MyX[,AT] %in% c(-.5,.5)))) {
         print("RunDiallelCC: We catch an issue where though Gender imputed but Gender Column has Zeroes!");
         flush.console();
         tryCatch("Get onto this please! Get a look on this!");
       }
     }
     FF = FALSE;
     if (!is.null(this$ImputedYChains)) {
       ImputeYChain = this$ImputedYChains[[ChainIteri]];
     } else {
       ImputeYChain = NULL;
     }
     CMissingYIndices = AFD$CMissingYIndices;
     if (any(is.na(MyXtX)) || any(is.nan(MyXtX))) {
       print("Error right before RunDiallelAlgorithm we get a nan MyXtX!");
       flush.console();
       this$XtX = MyXtX;
       return(-1);
     }
     MyText = "
     MyCall = .Call(\"RunDiallelAlgorithmNoNet\",
       AFD$.numj, MyX, MyY, MyXtX, MyXtY,
       MySumYSq, MyBeta, Mytau, MySigmaSq, MyLikelihood,
       MyCodaChain,
       MyLikelihoodChain,
       MyQ, MyInvQ, MyInvSqQ,
       MyDpBeta, MyTauFixed, Mydftau, Mymtau,
       mSigma, dfSigma,
       MyWantDiag,
       MyCrossModel, MyBetaInbredLevel,
       MytauCrosses,ASymNotASym = 0,
       jCross, kCross, jCrossO, kCrossO,
       VecOWeights, fW, dfTNoise,                   
       stauInbredNoise, stoggleInbred, sSigmaDeltaInbred,
       Verbose, MeanWeights, AllWeights, CheckNaFlag,
       StartIter, c(InformEvery, ChainIteri),
       CListUnknowns, this$GXX,
       this$ImputedGender, this$ProbUnknownGender,
       this$ImputeGenderChains[[ChainIteri]], 
       KeeperList, Extractor,
       State, globalenv(), OldBeta, NULL, 
       CMissingYIndices, AFD$LowCensorBound,  AFD$UpCensorBound,
       ImputeYChain,
       NULL, NULL
       );
       FF = TRUE ";
       try(eval(parse(text=MyText)));
       FailError = 0;
       if (MyCall[1] == -1 || any(is.nan(MyCodaChain))) {
         print("Temporary Fail investigation!"); flush.console();
         this$MyY = MyY;  this$MyX = MyX;  this$MyXtX = MyXtX;
         try(this$MyWantDiag <- MyWantDiag);
         try(this$MyTauFixed <- MyTauFixed);
         try(this$MyQ <- MyQ);
         try(this$MyInvQ <- MyInvQ);
         try(this$MyInvSqQ <- MyInvSqQ);
         print(paste("tau = ", paste(round(this$tau,3), collapse=","), sep=""));
         print(paste("Is Beta Nan? Length=", sum(is.nan(this$Beta)), " and is Beta Na? ", sum(is.na(this$Beta)), sep=""));
         flush.console();
         return(-129);
         while(any(is.nan(MyCodaChain))) {
           FailError = FailError + 1;
           print(paste("RunChainsCC:  We have a Nan sequence Error on ", FailError, "\n",sep="")); flush.console();
           this$CodaChains[[ChainIteri]][1:length(this$CodaChains[[ChainIteri]])] = 0;
           MyCodaChain = this$CodaChains[[ChainIteri]];
           this$Beta[1:length(this$Beta)] = 0;
           this$Sigma[1] = 1.0; 
           this$tau[1:length(this$tau)] = 1.0;  Mytau = this$tau;
           try(MyX <- AFD$X[, this$XSubSetList]);
           try(MyX <- as.matrix(MyX));
           try(colnames(MyX) <- names(this$XSubSetList));
           try(MyY <- AFD$Y);
           if (length(this$VecOWeights) > 0) {
             this$VecOWeights[1:length(this$VecOWeights)] = 1.0;
             
             try(MyXtX <- t(MyX) %*% ( this$VecOWeights * MyX));
             try(this$XtX <- MyX);
             try(this$XtY <- t(MyX) %*% (this$VecOWeights * MyY));
           } else {
             try(MyXtX <- t(MyX) %*% MyX);
             try(MyXtY <- t(MyX) %*% MyY);
           }
           if (!is.null(this$ImputedGender)) {
             try(eval(parse(text=ImputeYString)));
           }
           try(eval(parse(text=MyText)));
            if (FailError > 10 ) {
              tryCatch("We've tried 10 times but we still fail with the CodaChain!  big error")
            }
         }
       }
       if (FF == FALSE) {
         print(paste("RunChainsCC: Error, failed to runDiallelAlgorithm iter ", ChainIteri, sep="")); flush.console();
       }
       if (!is.null(ImputeYChain)) {
         try(this$ImputedYChains[[ChainIteri]][1:length(this$ImputedYChains[[ChainIteri]])] <-
            ImputeYChain[1:length(ImputeYChain)]);
       }

   ## Last few Nulls are for undone Sex Impute.
     try(this$T2[[ChainIteri]] <- proc.time()); 
     if (any(is.na(MyCodaChain)) || (any(is.nan(MyCodaChain))) 
         || any(!is.finite(MyCodaChain)) ) {
       CheckNaFlag = 1;       
     }
     if (dfTNoise > 0 && length(this$MeanWeightsL) >= ChainIteri) {
       try(this$MeanWeightsL[[ChainIteri]] <- MeanWeights);
     } else {MeanWeights = NULL;}
     if (dfTNoise > 0 && length(this$AllWeightsL) >= ChainIteri) {
       try(this$AllWeightsL[[ChainIteri]] <- AllWeights);
     } else {AllWeights = NULL; }   
     try(this$TDiff[[ChainIteri]] <- this$T2[[ChainIteri]] - this$T1[[ChainIteri]]);  
  }
  return(1);
});
setMethodS3("getCMissingYIndices", "FullDiallelAnalyze", function(this) {
  if (is.null(this$MissingYIndices)) {
    return(NULL);
  } else {
    return(this$MissingYIndices-1);
  }
});
setMethodS3("RunChain", "DiallelOb", function(
             this, AFD = NULL, ChainIter = 1, HackTau = NULL, ...) {
             
    this$T1[[ChainIter]] = proc.time();         
    if(!is.null(this$dfTNoise)  && this$dfTNoise > 0) {
      this$VecOWeights = rep(1, length(AFD$Y));
      VecOWeights = this$VecOWeights;
    }
    ##print(paste("dim(AFD$X) = ", paste(dim(AFD$X), collapse=", "), sep=""));
    if (!is.null(AFD$XtX)) {
        XtX = AFD$XtX[this$XSubSetList, this$XSubSetList];
    } else {
        AFD$XtX = t(AFD$X) %*% AFD$X;
        XtX = AFD$XtX[this$XSubSetList, this$XSubSetList];
    }
    if (!is.null(AFD$XtY)) {
        XtY = AFD$XtY[this$XSubSetList]
    } else {
        AFD$XtY = t(AFD$X) %*% AFD$Y;
        XtY = AFD$XtY[this$XSubSetList];
    }
    if (!is.null(AFD$sumYSq)) {
        sumYSq = AFD$sumYSq;
    }  else {
         AFD$sumYSq = sum(AFD$Y^2);
         sumYSq = AFD$sumYSq;
    }
    if (length(this$NetBetas) <= 0) {
       CreateNetBetas(this);
    }
    
    if (is.null(this$CodaChains)) {
      print("Error, the CodaChains here are null!");
    }
    this$Beta[is.nan(this$Beta)] = 0;
    this$tau[is.nan(this$tau)] = 1;
    this$Sigma[is.nan(this$Sigma)] = 1;
    dfTNoise = this$dfTNoise;
    if (is.null(dfTNoise)) {dfTNoise = -1;}
    if (!is.null(dfTNoise) && dfTNoise > 0) {
       X = AFD$X[, this$XSubSetList];
       Y = AFD$Y;
    }           
    ChainLength = length( (this$CodaChains[[ChainIter]])[,1] );
    Beta = this$Beta;
    tau = this$tau;
    mtau = this$mtau;
    dftau = this$dftau;
    NeedF = this$NeedF;
    DpBeta = this$DpBeta;
    colSumsDpBeta = this$colSumsDpBeta;
    tauFixed = this$.tauFixed; .tauFixed = this$.tauFixed;
    tauHybridNoise = this$tauHybridNoise;
    MeanWeights = this$MeanWeightsL[[ChainIter]];
    AllWeights = this$AllWeightsL[[ChainIter]];
    
    for (ii in 1:ChainLength) {
      this$Beta[is.nan(this$Beta)] = 0;
      if (!is.null(dfTNoise) && dfTNoise > 0) {
        sumYSq = sum(VecOWeights* Y^2);
        XtX = t(X) %*% (VecOWeights * X);
        XtY = t(X) %*% (VecOWeights * Y);
      }
      if (!is.null(tauHybridNoise) && tauHybridNoise >0) {
        sumYSq = sum(VecOWeights * Y^2);
        XtX = t(X) %*% (VecOWeights * X);
        XtY = t(X) %*% (VecOWeights * Y);
      }
      if (length(Beta) != length(DpBeta[,1])) {
        print(paste("Error This$Beta has length:", length(Beta), sep=""));
        print(paste(" but Dp has dim : ", 
          paste(dim(DpBeta), collapse=", "), sep=""));
      }		
		  tau[1:length(tau)] = (mtau + ((as.vector((Beta)^2) %*% 
                            DpBeta )/ 2)[NeedF] ) / 
		             (rgamma(length(dftau), 
                   dftau + colSumsDpBeta[NeedF] / 2) );
       this$tau = tau;
       if (!is.null(HackTau)) { tau = HackTau; }
		   if (this$.CrossModel %in% c(3,4,6,7,9,10)) {
			   CrossImpute(this, AFD$ACrossLocations);
		   }
       tau = this$tau;
		   this$MyWantDiag = as.vector(DpBeta %*% 
                        as.vector(1/c(.tauFixed, tau)));
		   if (this$.CrossModel %in% c(3,4,6,7,9,10)) {
			    FillCrossWantDiag(this, CO = AFD$ACrossLocations);					   
		   }		

		   if (MaxInv < length(this$MyWantDiag)) {
		     this$XtYResid = XtY - XtX %*% this$.Beta;
		     for (jjGroup in 1:length(this$NetBetas)) {
           if (length(this$NetBetas[[jjGroup]]) <= 0) {
			     } else if (length(this$NetBetas[[jjGroup]]) < MaxInv) {
             SSet = this$NetBetas[[jjGroup]];
               QSmall = this$XtX[SSet,SSet] + this$Sigma * diag( this$MyWantDiag[SSet] );
			       SQSmall = try(solve(QSmall), silent=TRUE);
			       if (length(SQSmall) <= 4 || is.null(dim(SQSmall))) {
		 			     SQSmall = pseudoinverse(QSmall);	
		  	     }
	 		       SimMatSmall = try( sqrt(this$Sigma) * t(chol(SQSmall)) );
			       if (length(SimMatSmall) <= 4 || is.null(dim(SimMatSmall))) {
				       SimMatSmall = diag(sqrt(this$Sigma *diag(SQSmall)));
			       }
			       this$BetaNew = SQSmall %*% (
					       this$XtYResid[SSet] + this$XtX[SSet,SSet] %*% this$Beta[SSet]) +
					       SimMatSmall  %*% rnorm( length(SimMatSmall[,1]),0,1);
			       this$XtYResid = this$XtYResid + this$XtX[,SSet] %*% 
                      (this$Beta[SSet] - this$BetaNew);
			       this$Beta[SSet] = this$BetaNew;            
			     } else {
				     Resamp = sample(this$NetBetas[[jjGroup]], 
               size= length(this$NetBetas[[jjGroup]]), replace=FALSE);
			       IDD = ceiling( length(Resamp) / MaxInv);
			       Ends = round((length(Resamp)/IDD) * (1:IDD))
		         for (jti in 1:length(Ends)) {
                 if (jti == 1) { SetI = 1:Ends[1] 
                 } else {SetI = (Ends[jti-1]+1):Ends[jti]}
			       SSet = Resamp[SetI];
			       QSmall = XtX[SSet,SSet] + this$Sigma * diag( this$MyWantDiag[SSet] );
			       SQSmall = try(solve(QSmall), silent=TRUE);
			       if (length(SQSmall) <= 4 || is.null(dim(SQSmall))) {
				       SQSmall = pseudoinverse(QSmall);	
			       }
			       SimMatSmall = try( sqrt(this$Sigma) * t(chol(SQSmall)) );
			       if (length(SimMatSmall) <= 4 || is.null(dim(SimMatSmall))) {
				 	     ##print("Went To diag Mistake" );
				       SimMatSmall = diag(sqrt(this$Sigma *diag(SQSmall)));
			       }
			       this$BetaNew = SQSmall %*% (this$XtYResid[SSet] +
							 XtX[SSet,SSet] %*% this$Beta[SSet]) +
			                 SimMatSmall  %*% rnorm( length(SimMatSmall[,1]),0,1);
			       this$XtYResid = this$XtYResid + XtX[,SSet] %*%
                                      (this$Beta[SSet] - this$BetaNew);
			       this$Beta[SSet] = this$BetaNew;
		      }
		   }
		  }
   } else {
     Sigma = this$Sigma;
     Q = XtX + Sigma *  diag( this$MyWantDiag );
     SQ = try(solve(Q), silent=TRUE);
     if (length(SQ) <= 4 || is.null(dim(SQ)) ) {
       SQ <- try(pseudoinverse(Q));	
     }
			
     SimMat2 = try( sqrt(Sigma) * t(chol(SQ)),silent=TRUE );
     if (length(SimMat2) <= 4 || is.null(dim(SimMat2))) {
       if (dim(SQ) <= 2 || is.null(SQ)) {
         print("SQ cannot be diagonalized"); flush.console();
       }
       SimMat = diag( sqrt(Sigma) * sqrt(diag(SQ)) );	
     } else {
       SimMat = SimMat2;
     }
     Beta[1:length(Beta)] =  
       as.vector(SQ %*% XtY + SimMat  %*% rnorm( length(SimMat[,1]),0,1));
   }
		
   SumDeviation = as.numeric(sumYSq - 2 * sum(Beta * XtY) +
     t(Beta) %*% XtX %*% Beta);
   this$Sigma[1:length(Sigma)] = as.numeric(
     (AFD$m$Sigma + SumDeviation) /  
     rchisq(1,  AFD$df$Sigma + dim(AFD$X)[1]));
   		
   if (!is.null(dfTNoise) && dfTNoise > 0) {
     VecOWeights = ((Y - X %*% Beta)^2/this$Sigma + dfTNoise) /
                         rchisq(length(Y), dfTNoise+1)
   }
   ##if (!is.null(tauHy))
  
     this$Beta = Beta;
     if (!is.list(this$CodaChains)) {
         this$CodaChains[ii,] = c(this$Beta, this$tau, this$tauCrosses, this$Sigma);
      } else {
         this$CodaChains[[ChainIter]][ii,]  = 
                c(this$Beta, this$tau, this$tauCrosses, this$Sigma);
      }
      if (!is.null(this$WeightsChains)) {
           this$WeightsChains[[ChainIter]][ii,] = VecOWeights;
      }
      
		this$LikelihoodChains[[ChainIter]][ii] =  - length(AFD$Y) / 2.0 *
      log(this$Sigma) - (SumDeviation) / (2*this$Sigma);
		##print(paste("Finished ii = ", ii, sep=""));
		##flush.console();
    }
  if (!is.null(this$VecOWeights)) {
    this$VecOWeights = VecOWeights
  }
	this$T2[[ChainIter]] = proc.time();
	##this$NonCodaChains[[ChainIter]] = FakeNonCodaChain;

});


####################################################################
##   CreateNetBetas:
##
##   If number of strains .numj is large, then it is likely that
##    the full XtX design matrix is computationally intense to invert
##   Hence, for a better McMc strategy, one would like to update
##    sets of variables.  This attempts to encode which sets of variables
##    should be stored.
##
##
setMethodS3("CreateNetBetas", "DiallelOb", 
              function(this,...) {
this$NetBetas = list();

	TotalLenBeta = sum((LenBetaUse(this))[this$.idREALVARIABLES]);
	TotalLenTau = length(OrderAllList[this$.idREALVARIABLES]);
	this$.TDLenBeta = cumsum((LenBetaUse(this))[this$.idREALVARIABLES]);
	
NetRelationsNum = list();
for (ii in 1:length(NetRelations)) {
NetRelationsNum[[ii]] = match(NetRelations[[ii]], OrderAllList);
   NOrd = match(NetRelationsNum[[ii]], this$.idREALVARIABLES)
   NOrd = NOrd[!is.na(NOrd)];
   if (length(NOrd)> 0) {
   NetBetasStart = c(1, this$.TDLenBeta+1)[NOrd];
   NetBetasEnd = this$.TDLenBeta[NOrd];
   this$NetBetas[[ii]] = c(0);
   for (jj in 1:length(NOrd)) {
      this$NetBetas[[ii]] = c(this$NetBetas[[ii]], 
                                 NetBetasStart[jj]:NetBetasEnd[jj]);
   }
   this$NetBetas[[ii]] = (this$NetBetas[[ii]])[2:length(this$NetBetas[[ii]])]
   } else {
      this$NetBetas[[ii]] = c();
   }
}
});


 setMethodS3("PrintItersSamples", "DiallelOb",
            function(this, Start=1, End=1000, ChainIter=1,
                     AFSTrue = NULL,
                  Forcetau = NULL, ForceX = NULL, ...) {
   
     Beta = this$Beta; tau = this$tau; tauCrosses = this$tauCroses;
   					 Sigma = this$Sigma;
 	  				 Simjj = ChainIter; CrossModel = this$.CrossModel;
     if (is.null(this$CodaChains)) {
             this$CodaChains = as.mcmc.list(this$NonCodaChains); 
       }
     BetaChain= t((this$CodaChains[[ChainIter]])[,1:length(Beta)]);
     if (length(this$tau)> 0) {
         tauChain = t((this$CodaChains[[ChainIter]])[,length(Beta) + 1:length(tau)]);
         rownames(tauChain) = colnames((this$CodaChains[[ChainIter]])[,length(Beta) + 1:length(tau)]);
     	}
   	 if (length(this$tauCrosses) > 0) {
         tauCrossChain = t((this$CodaChains[[ChainIter]])[,length(this$Beta) + 
                                                           length(this$tau) +
                                                           1:(length(this$tauCrosses))]);
       }
     if (length(this$Sigma) > 0)  {
        SigmaChain = t((this$CodaChains[[ChainIter]])[,length(Beta) + length(tau) +
                                                                         length(tauCrosses) +
                                                                         1:(length(Sigma))]);  
       }
     if (!is.null(AFSTrue)) {
           BetaReal = AFSTrue$ADiallelOb$Beta;
           tauReal = AFSTrue$ADiallelOb$tau;
           tauCrossesReal = AFSTrue$ADiallelOb$tauCrosses;
           SigmaReal = AFSTrue$ADiallelOb$Sigma;
       } else {
       	  BetaReal = NULL; tauReal = NULL; tauCrossesReal = NULL;
       	  SigmaReal = NULL;
         }	  
     tauNames = names(this$tau)
     if (!is.null(Forcetau)) {
         GoForTau = Forcetau;
       } else {
       	  GoForTau = c(1,2,sort(sample( 3:length(this$tau), size=3, replace=FALSE))); 
         }
   ##print(paste("GoForTau = ", paste(GoForTau, collapse=", "), sep=""));
                         
   ##= c(1,2,3,4,5,6);
   	GoForTauCrosses = -1;
   	
   	if (length(this$tau) < max(GoForTau)) {
     		GoForTau = GoForTau[GoForTau < length(this$tau)]
     	}
   	if (is.null(this$tauCrosses)  || length(this$tauCrosses) == 0) {
     		par(mfrow=c(2,length(GoForTau)+1));
     		tauCrossChain = NULL;
    } else {
       		par(mfrow=c(3,length(GoForTau)+1));
       		GoForTauCrosses = sort(sample(1:length(tauCrossChain[,1]), 
                                         size = length(GoForTau)+1, replace=TRUE));
       		TauCrossNamesUse = names(this$tauCrosses)
    }
   	mtV = tauNames[GoForTau];
   	
   	if (End > length(tauChain[1,])) { End = length(tauChain[1,]); }
   			chainIters = Start:End;
       for (Onii in 1:length(GoForTau)) {
     		
           tmax = max(tauChain[GoForTau[Onii], chainIters]); if (!is.null(tauReal)) {
               tmax= max(tmax, tauReal[GoForTau[Onii]]);
             }
     		plot(chainIters~tauChain[GoForTau[Onii],chainIters], type="l", 
                			 main=paste("Simjj = ", ChainIter, "\nVariance ", tauNames[GoForTau[Onii]], sep=""),
                			 xlab= paste("tauSq Draw ", mtV[Onii], sep=""), ylab="chain iteration",
                       xlim = c(0,tmax));
     		if (!is.null(tauReal)) { lines(chainIters~rep(tauReal[GoForTau[Onii]], length(chainIters)), col="red", lwd=2) };
     		lines(chainIters~rep(mean(tauChain[GoForTau[Onii],chainIters]), length(chainIters)), col="blue", lwd=2, lty =3);
             qChain = quantile(tauChain[GoForTau[Onii],chainIters], c(.025, .975));
     		lines(chainIters~rep(qChain[1], length(chainIters)), col="orange", lwd=1, lty=5);
     		lines(chainIters~rep(qChain[2], length(chainIters)), col="orange", lwd=1, lty=5);
     	}  
   	plot(chainIters~SigmaChain[chainIters], type="l", main=paste("Noise Sigma ", sep=""),
            		 xlab= paste("SigmaSq Draw ", sep=""), ylab="chain iteration");
   	if (!is.null(SigmaReal)) { lines(chainIters~rep(SigmaReal, length(chainIters)), col="red", lwd=2) };
   	lines(chainIters~rep(mean(SigmaChain[chainIters]), length(chainIters)), col="blue", lwd=2, lty =3);
   	qChain = quantile(SigmaChain, c(.025, .975));
   	lines(chainIters~rep(qChain[1], length(chainIters)), col="orange", lwd=1, lty=5);
   	lines(chainIters~rep(qChain[2], length(chainIters)), col="orange", lwd=1, lty=5);
   
   	if (!is.null(tauCrossChain) && 
          length(tauCrossChain) > 0 && 
          this$.CrossModel %in% c(3,4,6,7,9,10)  && 
          GoForTauCrosses[1] >= 1) {
       for (Onii in 1:length(GoForTauCrosses)) {		
           plot(chainIters~tauCrossChain[Onii,chainIters], type="l", 
                 main=paste("Simjj = ", ChainIter, "\nVariance ", TauCrossNamesUse[Onii], sep=""),
                    				 xlab= paste(TauCrossNamesUse[Onii], sep=""), ylab="chain iteration");
       			if(!is.null(tauCrossesReal)) { lines(chainIters~rep(tauCrossesReal[GoForTauCrosses[Onii]], length(chainIters)), col="red", lwd=2) };
       			lines(chainIters~rep(mean(tauCrossChain[GoForTauCrosses[Onii],chainIters]), length(chainIters)), col="blue", lwd=2, lty =3);
       			qChain = quantile(tauCrossChain[GoForTauCrosses[Onii],chainIters], c(.025, .975));
            lines(chainIters~rep(qChain[1], length(chainIters)), col="orange", lwd=1, lty=5);
       			lines(chainIters~rep(qChain[2], length(chainIters)), col="orange", lwd=1, lty=5);
       		} 
     	}
   	
   	namesX = names(this$Beta);
   	if (!is.null(ForceX)) {
          Loc = ForceX;
       } else {
           Loc = c(1,2,3, sort(sample(4:length(this$Beta), size=4, replace=FALSE)) );
           Loc = this$.TDLenBeta[c(1,3,4,5,6,7)];
       	}  
   	if (length(Loc) > length(GoForTau)+1) {
     		Loc = Loc[1:(length(GoForTau)+1)]
     	}
   	if (length(Loc) > length(BetaChain[,1])) {
     		Loc = Loc[(1:length(Loc)) <= length(Betchain[,1])];
     	}
   	 
      Nii = namesX[Loc];
   	for (Onii in 1:length(Loc)) {  
     		Fii = Loc[Onii];
         LISR = BetaChain[Fii, chainIters];
         if (!is.null(BetaReal)) {LISR = c(LISR, BetaReal[Fii]); }
         
     		plot(chainIters,BetaChain[Fii,chainIters], type="l", main=paste("Chain ", Nii[Onii], sep=""),
               			 xlab= paste("Draw ", Nii[Onii], sep=""), ylab="chain iteration", ylim=c(min(LISR), max(LISR)));
     		if (!is.null(BetaReal)) {lines(chainIters,rep(BetaReal[Fii], length(chainIters)), col="red", lwd=2);}
     		lines(chainIters,rep(mean(BetaChain[Fii,chainIters]), length(chainIters)), col="blue", lwd=2, lty =3);
             qChain = quantile(BetaChain[Fii,chainIters], c(.025, .975));
     		lines(chainIters,rep(qChain[1], length(chainIters)), col="orange", lwd=1, lty=5);
 		lines(chainIters,rep(qChain[2], length(chainIters)), col="orange", lwd=1, lty=5);
 	}  
 
 });
 

### Helpful for thinning chains, CODA doesnt Work on burnin!!
mcmc.subset <- function(mcmc, burnin=0, thin=1)
{
  total <- nrow(mcmc[[1]])
  num.wanted <- floor((total-burnin)/thin)
  wanted <- burnin + (1:num.wanted)*thin
  
  for (i in 1:length(mcmc))
  {
    mcmc[[i]] <- as.mcmc(mcmc[[i]][wanted,])
  }
  as.mcmc.list(mcmc)
}

 setMethodS3("CalcDIC", "DiallelOb", function(
     this, AFD, start = -1, end = -1,...) {
    if (end < 0) {end = length(this$CodaChains[[1]][,1]);}  
    if (start < 0) {start = round(.1 * end); }
       if (start < 1) { start = 1;}
    
       thinnedCoda = mcmc.subset(this$CodaChains, burnin=start-1, thin=1);
    
    likeLihoodChains = c();
    for (ii in 1:length(this$LikelihoodChains)) {
       likeLihoodChains = c(likeLihoodChains, 
              this$LikelihoodChains[[ii]][start:end]);
    }
    MeansumMcMc = summary(thinnedCoda)[[1]][,1];
    BetaMean = MeansumMcMc[1:length(this$Beta)];
    SigmaMean = MeansumMcMc[length(MeansumMcMc)];
    DofMean = as.numeric( length(AFD$Y)  *log(SigmaMean) + sum( (AFD$Y - 
                         AFD$X[,this$XSubSetList] %*% BetaMean)^2 ) /
               SigmaMean);
    BarD = -2 *mean(likeLihoodChains);
    PID = BarD - DofMean;
    DIC = PID + BarD;
    return(list(DIC = DIC, PID = PID, BarD =BarD, DofMean = DofMean));                       
 });
 
setMethodS3("PrintDICAll", "FullDiallelAnalyze", 
   function(this, PrintFlag = TRUE, start = -1, end = -1, ...) {
   print("PrintDICAll ----------- Beginning "); flush.console();
    ReturnerMatrix = matrix(0, length(this$AllDiallelObs), 6 + 4);
    colnames(ReturnerMatrix) = c( names(getModel(this$AllDiallelObs[[1]])),
                                  "DIC", "PID", "BarD", "DofMean");
    for (ii in 1:length(this$AllDiallelObs)) {
       if (PrintFlag == TRUE) {
         print(paste(" On Model: ", ii, " is : ", 
           paste(getModel(this$AllDiallelObs[[ii]]), collapse=", "),
           sep=""));  flush.console();
       }
       try(GetDIC <- CalcDIC(this$AllDiallelObs[[ii]], 
         AFD=this$AllDiallelObs[[ii]]$.AFD, start, end));
       ReturnerMatrix[ii,] = unlist(c( getModel(this$AllDiallelObs[[ii]]),
                                GetDIC ));
       
       if (PrintFlag == TRUE) {
         print(paste( names(GetDIC), " : ", GetDIC, collapse = ", "));
         flush.console();
       }
    }
    print("PrintDICAll -------- Returning "); flush.console();
    return(ReturnerMatrix);
 });

 setMethodS3("RunEMcc", "DiallelOb", function(this, AFD = NULL, ChainIter  = 1,
   HackTau = NULL, CheckNaFlag = 0, StartIter = 0, InformEvery = 100,
   ...) {
   if (is.null(AFD)) { AFD = this$.AFD; }
   
   dfTNoise = this$dfTNoise; 
  if (is.null(AFD)) {
    tryCatch("RunChainsCC: false AFD supplied");
  }
  if (is.null(AFD$Verbose)) {
    tryCatch("RunChainsCC: Error, AFD has no Verbose variable!");
  }
  if (is.null(AFD$Verbose)) { AFD$Verbose = FALSE; }
  if  (is.numeric(AFD$Verbose) && AFD$Verbose > 2) {
    print("RunChainsCC: On AdiallelOb: start"); flush.console();
  }
  if (!exists("this")) {
    print("RunChainsCC: `this' doesn't exist?"); flush.console();
  }
  if (!is.null(dfTNoise)) { this$dfTNoise = dfTNoise; }
  if (length(this$CodaChains) > 0) {
    this$ChainIters = length(this$CodaChains);
  }
  if (length(ChainIter) >= 1 && (min(ChainIter) > 0 
    && max(ChainIter) <= length(this$CodaChains))) {
    ChainIters = ChainIter;
  } else {
    ChainIters = 1:length(this$CodaChains);
  }
  if (is.null(AFD$Verbose)) { AFD$Verbose = FALSE; }
  if  (is.numeric(AFD$Verbose) && AFD$Verbose > 2) {
    print("RunChainsCC: Looking at this$X"); flush.console();
  }
  if (is.null(this$.X)) { this$.X = AFD$X[,this$XSubSetList]; }
  MyY = AFD$Y; MyX = this$X;
  
  MyXtX = t(MyX) %*% MyX;
  MyXtY = t(MyX) %*% AFD$Y;
  
  this$SumYSq = sum(AFD$Y^2);
  MySumYSq = this$SumYSq;
  
  dfTNoise = this$dfTNoise;

  
  MyBeta = this$Beta;
  Mytau = this$tau  
  MySigmaSq = this$Sigma;
  if (MySigmaSq <= 0) {
    this$Sigma = rchisq(1,df=1);
    MySigmaSq = this$Sigma;
  }
  MyLikelihood = 0;


  MyQ = matrix(MyXtX, length(MyXtX[,1]), length(MyXtX[1,]));
  if (MaxInvert < dim(MyQ)[1]) {
    MyInvQ = matrix(as.numeric(MyXtX), MaxInvert, MaxInvert);
    MyInvSqQ = matrix(as.numeric(MyXtX), MaxInvert, MaxInvert);  
  } else {
    MyInvQ = matrix(as.numeric(MyXtX), length(MyXtX[,1]), length(MyXtX[1,]));
    MyInvSqQ = matrix(as.numeric(MyXtX), length(MyXtX[,1]), length(MyXtX[1,]));
  }
  MyDpBeta = this$DpBeta;
  MyTauFixed = this$.tauFixed;
  Mymtau = this$mtau;
  Mydftau = this$dftau;
  mSigma = AFD$m$Sigma;
  dfSigma = AFD$df$Sigma;
  MyWantDiag = rep(0, length(MyXtX[1,]));
  MyCrossModel = this$.CrossModel
  MyBetaInbredLevel = this$.BetaInbredLevel
  MytauCrosses = this$tauCrosses;
  jCross = AFD$ACrossLocations$jCross;
  jCrossO = AFD$ACrossLocations$jCrossO;
  kCross = AFD$ACrossLocations$kCross;
  kCrossO = AFD$ACrossLocations$kCrossO;
  VecOWeights = this$VecOWeights;
  if (!is.null(VecOWeights)) { fW = rep(0, max(NROW(X), NCOL(X))); 
    MySumYSq = sum( AFD$Y * VecOWeights * AFD$Y); }
  MeanWeights = this$MeanWeights;
  AllWeights = this$AllWeights;
  
  ListUnknowns = this$ListUnknownGender;  GXX = this$GXX;
  ImputedGender = this$ImputedGender;  PriorGender = this$PriorGender;
  ImputeGenderChains = this$ImputeGenderChains;  KeeperList = this$KeeperList;
  Extractor = this$Extractor;  State = this$State;
    if (AFD$Verbose > 2) {
      if (!is.null(KeeperList)) {
        print("Note: RunChainsCC: KeeperList is non NULL"); flush.console();
      } else if (!is.null(Extractor)) {
        print("Note: RunChainsCC: Extractor is non NULL"); flush.console();
      } else {
        print("Note: RunChainsCC: Extractor and KeeperList are NULL!"); flush.console();
      }
    }
  stauInbredNoise = 0; stoggleInbred = 0; sSigmaDeltaInbred = 0;
  Verbose = 0;  if (!is.null(AFD$Verbose) && AFD$Verbose > 1) {
    Verbose = AFD$Verbose -1;
  }
   
   CauchyEffect = this$cauchy.delta;
   if (!is.null(AFD$DoCM) && AFD$DoCM == TRUE) {
     CauchyEffect = t(CauchyEffect, 1);
   }
   if (!is.null(AFD$SumYSq)) { 
     MySumYSq = AFD$SumYSq
     if (!is.null(this$VecOWeights) && length(this$VecOWeights) >= 1) {
       try(MySumSq <- sum(AFD$Y * AFD$Y * this$VecOWeights));
       try(this$SumYSq <- MySumSq);
     } 
   } else {
     MySumYSq = sum(AFD$Y^2);  AFD$SumYSq = MySumYSq;
   }
   MyQ = matrix(0, NROW(MyXtX), NCOL(MyXtX));
   MyInvQ = matrix(0, NROW(MyXtX), NCOL(MyXtX));
   MyInvSqQ = matrix(0, NROW(MyXtX), NCOL(MyXtX));
   if (length(this$ChainIters) > 1) {
   this$FinalBetaList = matrix(0, length(this$Beta), length(this$ChainIters));
   } else {
     this$FinalBetaList = this$Beta*0;
   }
   CMissingYIndices = AFD$CMissingYIndices;
   for (ii in 1:this$ChainIters)   {
     if (!is.null(this$VecOWeights)) {
       this$VecOWeights = rchisq(length(this$VecOWeights),df=1);
       this$XtY = MyX %*%(this$VecOWeights * AFD$Y);
       this$SumYSq = sum( AFD$Y * AFD$Y * tihs$VecOWeights);
       VecOWeights = this$VecOWeights;  MySumYSq = this$SumYSq;
       MyXtY = this$XtY;
       MyXtX = t(MyX)  %*%  (this$VecOWeights * MyX);
       this$XtX = MyXtX;
     }
     ChainIteri  = ii;
         MyCall = .Call("RunDiallelAlgorithmNoNet",
       AFD$.numj, this$.X, AFD$Y, MyXtX, MyXtY,
       MySumYSq, this$Beta, this$tau, MySigmaSq, MyLikelihood,
       this$CodaChains[[ii]],
       this$LikelihoodChains[[ii]],
       MyQ, MyInvQ, MyInvSqQ,
       this$DpBeta, this$.tauFixed, this$dftau, Mymtau,
       mSigma, dfSigma,
       MyWantDiag,
       MyCrossModel, MyBetaInbredLevel,
       MytauCrosses,ASymNotASym = 0,
       jCross, kCross, jCrossO, kCrossO,
       VecOWeights, fW, dfTNoise,                   
       stauInbredNoise, stoggleInbred, sSigmaDeltaInbred,
       Verbose, MeanWeights, AllWeights, CheckNaFlag,
       StartIter, c(InformEvery, ChainIteri),
       ListUnknowns, GXX,
       ImputedGender, PriorGender,
       ImputeGenderChains, KeeperList, Extractor,
       State, globalenv(), OldBeta = rep(0, length(MyBeta)), CauchyEffect,
       CMissingYIndices, AFD$LowCensorBound,  AFD$UpCensorBound,
       NULL
   );
   this$FinalBetaList[,ii] = this$Beta;
 }
 if (length(this$ChainIters) > 1) {
   rownames(this$FinalBetaList) = names(this$Beta);
   colnames(this$FinalBetaList) = (1:NCOL(this$FinalBetaList));
 } else {
  names(this$FinalBetaList) = names(this$Beta)
 }
});
 setMethodS3("RunEM", "DiallelOb", function(
             this, AFD = NULL, ChainIter = 1, HackTau = NULL, ...) {
             
    this$T1[[ChainIter]] = proc.time();         
    if(!is.null(this$dfTNoise)  && this$dfTNoise > 0) {
      this$VecOWeights = rep(1, length(AFD$Y));
    }
    ##print(paste("dim(AFD$X) = ", paste(dim(AFD$X), collapse=", "), sep=""));
    if (!is.null(AFD$XtX)) {
        XtX = AFD$XtX[this$XSubSetList, this$XSubSetList];
    } else {
        AFD$XtX = t(AFD$X) %*% AFD$X;
        XtX = AFD$XtX[this$XSubSetList, this$XSubSetList];
    }
    if (!is.null(AFD$XtY)) {
        XtY = AFD$XtY[this$XSubSetList]
    } else {
        AFD$XtY = t(AFD$X) %*% AFD$Y;
        XtY = AFD$XtY[this$XSubSetList];
    }
    if (!is.null(AFD$sumYSq)) {
        sumYSq = AFD$sumYSq;
    }  else {
         AFD$sumYSq = sum(AFD$Y^2);
         sumYSq = AFD$sumYSq;
    }
    if (length(this$NetBetas) <= 0) {
       CreateNetBetas(this);
    }
    if (this$dfTNoise > 0) {
       X = AFD$X[, this$XSubSetList];
       Y = AFD$Y;
    }
    if (is.null(this$CodaChains)) {
      print("Error, the CodaChains here are null!");
    }
    this$Beta[is.nan(this$Beta)] = 0;
    this$tau[is.nan(this$tau)] = 1;
    this$Sigma[is.nan(this$Sigma)] = 1;
               
    ChainLength = length( (this$CodaChains[[ChainIter]])[,1] );
    this$BetaPrev =this$Beta;
    
   tauHybridNoise = NULL;  
   if (!is.null(this$tauHybridNoise)) {
     tauHybridNoise = this$tauHybridNoise
     toggleInbred = this$toggleInbred;
     SigmaDeltaInbred = this$SigmaDeltaInbred;
     VecOWeights = exp(-toggleInbred * SigmaDeltaInbred);
     VecOWeights = VecOWeights / sum(VecOWeights);
   }

    for (ii in 1:ChainLength) {
       this$Beta[is.nan(this$Beta)] = 0;
		   if (!is.null(this$dfTNoise) && this$dfTNoise > 0) {
			    sumYSq = sum(this$VecOWeights* AFD$Y^2);
			    XtX =t(X) %*% (this$VecOWeights * AFD$X);
			    XtY = t(X) %*% (this$VecOWeights * AFD$Y);
		   }
       if (length(this$Beta) != length(this$DpBeta[,1])) {
          print(paste("Error This$Beta has length:", length(this$Beta), sep=""));
          print(paste(" but Dp has dim : ", 
              paste(dim(this$DpBeta), collapse=", "), sep=""));
       }		
		   this$tau[1:length(this$tau)] = (this$mtau + ((as.vector((this$Beta)^2) %*% 
                            this$DpBeta )/ 2)[this$NeedF] ) / 
		             (  this$dftau + this$colSumsDpBeta[this$NeedF] / 2 ) ;
      if (!is.null(HackTau)) { this$tau = HackTau; }
		   if (this$.CrossModel %in% c(3,4,6,7,9,10)) {
		     print("No Support for EMImpute in these models.")
			   EMImpute(this, AFD$ACrossLocations);
			   return();
		   }
		   this$MyWantDiag = as.vector(this$DpBeta %*% 
                        as.vector(1/c(this$.tauFixed, this$tau)));
		   if (this$.CrossModel %in% c(3,4,6,7,9,10)) {
		      print("No Support for EM Impute in these models");
			    FillCrossWantDiag(this, CO = AFD$ACrossLocations);
          return();					   
		   }		

		   if (MaxInv < length(this$MyWantDiag)) {
		      this$XtYResid = XtY - XtX %*% this$.Beta;
		        for (jjGroup in 1:length(this$NetBetas)) {
              if (length(this$NetBetas[[jjGroup]]) <= 0) {
			      } else if (length(this$NetBetas[[jjGroup]]) < MaxInv) {
              SSet = this$NetBetas[[jjGroup]];
              QSmall = this$XtX[SSet,SSet] + this$Sigma * diag( this$MyWantDiag[SSet] );
			        SQSmall = try(solve(QSmall), silent=TRUE);
			        if (length(SQSmall) <= 4 || is.null(dim(SQSmall))) {
		 			      SQSmall = pseudoinverse(QSmall);	
		  	      }
			        this$BetaNew = SQSmall %*% (
					       this$XtYResid[SSet] + this$XtX[SSet,SSet] %*% this$Beta[SSet]);
			        this$XtYResid = this$XtYResid + this$XtX[,SSet] %*% 
                      (this$Beta[SSet] - this$BetaNew);
			        this$Beta[SSet] = this$BetaNew;            
			      } else {
				      Resamp = sample(this$NetBetas[[jjGroup]], 
                              size= length(this$NetBetas[[jjGroup]]), replace=FALSE);
			        IDD = ceiling( length(Resamp) / MaxInv);
			        Ends = round((length(Resamp)/IDD) * (1:IDD))
		          for (jti in 1:length(Ends)) {
                 if (jti == 1) { SetI = 1:Ends[1] 
                 } else {SetI = (Ends[jti-1]+1):Ends[jti]}
			        SSet = Resamp[SetI];
			        QSmall = XtX[SSet,SSet] + this$Sigma * diag( this$MyWantDiag[SSet] );
			        SQSmall = try(solve(QSmall), silent=TRUE);
			        if (length(SQSmall) <= 4 || is.null(dim(SQSmall))) {
				        SQSmall = pseudoinverse(QSmall);	
			        }
			        SimMatSmall = try( sqrt(this$SigmaS) * t(chol(SQSmall)) );
			        if (length(SimMatSmall) <= 4 || is.null(dim(SimMatSmall))) {
				 	      ##print("Went To diag Mistake" );
				        SimMatSmall = diag(sqrt(this$Sigma *diag(SQSmall)));
			        }
			        this$BetaNew = SQSmall %*% (this$XtYResid[SSet] +
							  XtX[SSet,SSet] %*% this$Beta[SSet]);
			        this$XtYResid = this$XtYResid + XtX[,SSet] %*%
                                      (this$Beta[SSet] - this$BetaNew);
			        this$Beta[SSet] = this$BetaNew;
		      }
		   }
		  }
     } else {
			 Q = XtX + this$Sigma *  diag( this$MyWantDiag );
			 SQ = try(solve(Q), silent=TRUE);
			 if (length(SQ) <= 4 || is.null(dim(SQ)) ) {
				 SQ <- try(pseudoinverse(Q));	
			 }
			
			 this$Beta[1:length(this$Beta)] =  
           as.vector(SQ %*% XtY);
		 }
		 ##print(paste("sum Difference = ", sum(abs(this$Beta-this$BetaPrev)), paste=""));
		 ##flush.console();
		 ##print(paste(" But AFD$cauchy.delta is ", AFD$cauchy.delta));
		 if (sum(abs(this$Beta - this$BetaPrev)) < AFD$cauchy.delta) {
         break;
     }
     this$BetaPrev = this$Beta;
     
     this$SumDeviation = as.numeric(sumYSq - 2 * sum(this$Beta * XtY) +
       t(this$Beta) %*% XtX %*% this$Beta);
     this$Sigma[1:length(this$Sigma)] = as.numeric(
       (AFD$m$Sigma + this$SumDeviation) /  
       (AFD$df$Sigma + dim(AFD$X)[1]));
		
     if (exists("dfTNoise") && !is.null(dfTNoise) && dfTNoise > 0) {
       VecOWeights = ((AFD$Y-AFD$X %*% this$Beta)^2/this$Sigma + dfTNoise) /
         rchisq(length(Y), dfTNoise+1);
       VecOWeights = VecOWeights / sum(VecOWeights);
       if (!is.null(this$WeightsChains)) {
         this$WeightsChains[[ChainIter]][ii,] = VecOWeights;
       }
     }
     
     if (!is.null(tauHybridNoise)) {
       tauHybridNoise = this$tauHybridNoise
       toggleInbred = this$toggleInbred;
       SigmaDeltaInbred = this$SigmaDeltaInbred;
       VecOWeights = exp(-toggleInbred * SigmaDeltaInbred);
       VecOWeights = VecOWeights / sum(VecOWeights);
     }

		

      if (!is.list(this$CodaChains)) {
         this$CodaChains[ii,] = c(this$Beta, this$tau, this$tauCrosses, this$Sigma);
      } else {
         this$CodaChains[[ChainIter]][ii,]  = 
                c(this$Beta, this$tau, this$tauCrosses, this$Sigma);
      }
		this$LikelihoodChains[[ChainIter]][ii] =    - length(AFD$Y) / 2.0 * log(this$Sigma) -
		        (this$SumDeviation) / (2*this$Sigma);

    }
	this$T2[[ChainIter]] = proc.time();
});


 setMethodS3("CalcDICC", "DiallelOb", function(
     this, AFD= NULL, start = -1, end = -1, CheckNA = 0, ...) {
    if (is.null(AFD) && !is.null(this$.AFD)) {
      AFD = this$.AFD;
    }
    if (!is.numeric(end)) {
      end = length(this$CodaChains[[1]][,1]);
    } else if (end < 0) {end = length(this$CodaChains[[1]][,1]);}  
    if (start < 0) {start = round(.1 * end); }
       if (start < 1) { start = 1;}
    
    BetaMean = rep(0, length(this$Beta)); 
    SigmaMean = 0; 
    LikelihoodMean = 0;
    for (ii in 1:length(this$CodaChains)) {
      MyCodaChain = this$CodaChains[[ii]];
      if (any(is.na(MyCodaChain)) || (any(is.nan(MyCodaChain))) 
         || any(!is.finite(MyCodaChain)) ) {
        CheckNA = 1;       
      }  
    }
    BetaMean = .Call("CCalculateDIC", this$CodaChains, BetaMean, SigmaMean,
      start, end, this$LikelihoodChains, LikelihoodMean, CheckNA);
    DofMean = as.numeric( length(AFD$Y)  *log(SigmaMean) + sum( (AFD$Y - 
                         AFD$X[,this$XSubSetList] %*% BetaMean)^2 ) /
               SigmaMean);
    BarD = -2.0 *LikelihoodMean;
    PID = BarD - DofMean;
    DIC = PID + BarD;
    return(list(DIC = DIC, PID = PID, BarD =BarD, DofMean = DofMean));                       
 });
 
 setMethodS3("PrintDICCAll", "FullDiallelAnalyze", 
   function(this, PrintFlag = TRUE, start = -1, end = -1, Verbose = 0,...) {
    ReturnerMatrix = matrix(0, length(this$AllDiallelObs), 6 + 4);
    colnames(ReturnerMatrix) = c( names(GetModel(this$AllDiallelObs[[1]])),
                                  "DIC", "PID", "BarD", "DofMean");
    for (ii in 1:length(this$AllDiallelObs)) {
       if (Verbose > 0) {
       print(paste(" On Model: ", ii, " is : ", 
             paste(GetModel(this$AllDiallelObs[[ii]]), collapse=", "),
             sep=""));  flush.console();
       }
       GetDIC = CalcDICC(this$AllDiallelObs[[ii]], this, start, end);
       ReturnerMatrix[ii,] = unlist(c( GetModel(this$AllDiallelObs[[ii]]),
                                GetDIC ));
       if (Verbose > 0) {
         print(paste( names(GetDIC), " : ", GetDIC, collapse = ", ")); flush.console();
       }
    }
     return(ReturnerMatrix);
 });

 setMethodS3("ConstrictX", "FullDiallelAnalyze", function(this) {
   if (!is.null(this$WeHaveShrunkXMatrix) && this$WeHaveShrunkXMatrix == TRUE) {
     return(1);
   }
   CNX <-  colnames(this$X);
   ATOKeep <- 1:length(CNX);
   BList <- list();   ANO = 0;
   for (ii in 1:length(.DefaultAllRandomVariables)) {
     ATOKeep = ATOKeep[
       substr(CNX[ATOKeep],1, nchar(.DefaultAllRandomVariables[ii])) != 
       .DefaultAllRandomVariables[ii]];
     FF <- (1:length(CNX))[substr(CNX[ATOKeep],1, nchar(.DefaultAllRandomVariables[ii])) == 
       .DefaultAllRandomVariables[ii]];
     if (!is.null(FF) && length(FF) >= 1) {
       ANO <- ANO+1; BList[[ANO]] <- FF;
     }
   }
   NewLen <- length(ATOKeep) + length(unlist(BList)) - length(BList);
   NewMatrix <- matrix(0, NROW(this$X), NewLen);
   NewNames <- rep("", NewLen);
   NewMatrix[,1:length(ATOKeep)] <- this$X[,ATOKeep];
   NewNames[1:length(ATOKeep)] <- CNX[ATOKeep];
   ANT <- length(ATOKeep);
   if (length(BList) >= 1) {
     for (ii in 1:length(BList)) {
       AL <- length(BList[[ii]]);
       BTK <- BList[[ii]];  BTK <- BTK[1:(length(BTK)-1)]
       DNM <- matrix(
         c(rep(c(1,rep(0,AL)), AL-2),1,0) -1/AL, AL, AL-1)
       NewMatrix[, ANT + 1:(AL-1)] <- this$X[,BList[[ii]]] %*% DNM;
       NewNames[ANT + 1:(AL-1)] <- CNX[BTK];
       ANT <- ANT + AL;
     }
   }
   colnames(NewMatrix) <- NewNames;
   this$X <- NewMatrix;
   this$WeHaveShrunkXMatrix <- TRUE;
 });

 setMethodS3("PlotStrawPlot", "FullDiallelAnalyze", function(this, DoCentered = TRUE, DoRaw = FALSE,
  wanted = NULL, prob.wide=.95, prob.narrow = .5,xlim=NULL, GiveHeadings=TRUE, 
  DoCC = 0, DoMu=FALSE, DoMedian = FALSE, 
  ylab="range(data)", yline=1, ...) {
   this$AllDiallelObs[[this$OnObs]]$PlotStrawPlot(DoCentered=DoCentered,DoRaw=DoRaw,
   wanted=wanted,prob.wide=prob.wide,prob.narrow=prob.narrow, xlim=xlim, GiveHeadings=GiveHeadings, 
   ylab=ylab, yline=yline, DoMu=DoMu, DoMedian=DoMedian, DoCC=DoCC, ...);
   });

 setMethodS3("MIP", "FullDiallelAnalyze", function(this,...) {
   if (is.null(this$.BSAFD)) {
     print("No MIP vector, this has no BSAFD BayesSpike component");
     return(NULL);
   }
   return(this$.BSAFD$MIP);
 });
 

setMethodS3("PlotHPD", "FullDiallelAnalyze", function(this,
  DoCentered = TRUE, DoRaw = FALSE,
  wanted = NULL, prob.wide=.95, prob.narrow = .5, 
   MapChainNames = NULL, UseMapChainNames1 = FALSE, UseMapChainNamesHPD = TRUE,
   DoMu = TRUE, 
   DoTreat=FALSE, NoJK = TRUE, plt.lefts=NULL, ...) {
   this$AllDiallelObs[[this$OnObs]]$PlotHPD(DoCentered=DoCentered,
     DoRaw=DoRaw,wanted=wanted,prob.wide=prob.wide,prob.narrow=prob.narrow,
     MapChainNames=MapChainNames,UseMapChainNames1=UseMapChainNames1,
     UseMapChainNamesHPD = UseMapChainNamesHPD,
     DoMu = DoMu, DoTreat=DoTreat, NoJK = NoJK, plt.lefts = plt.lefts, ...);
});  



MapChainNames1 = cbind(  c("Mu", "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av",
    "aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej", "Gender:dominancej",
    "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk"), c("mean", "female.overall", "inbreed.overall",
    "female.inbreed.overall", "additive", "sex.additive", "parent.origin", "sex.parent.origin",
    "inbreeding", "sex.inbreeding", "symmetric",
    "sex.symmetric", "asymmetric", "sex.asymmetric",
    "cross", "sex.cross") );
MapChainNames1NoSex = cbind(  c("Mu", "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av",
    "aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej", "Gender:dominancej",
    "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk"), c("mean", "female.overall", "inbreed.overall",
    "female.inbreed", "additive", "sex.additive", "parent.origin", "sex.parent.origin",
    "inbreeding", "sex.inbreeding", "symmetric",
    "sex.symmetric", "asymmetric", "sex.asymmetric",
    "cross", "sex.cross") );
    
MapChainNamesHPD = cbind(  c("Mu", "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av",
    "aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej", "Gender:dominancej",
    "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk"), c("mean", "female.overall", "inbreed.overall",
    "female.inbreed.overall", "additive", "sex.additive", "maternal", "sex.maternal",
    "inbreeding", "sex.inbreeding", "v",
    "sex.v", "w", "sex.w",
    "cross", "sex.cross") );
MapChainNamesHPDNoSex = cbind(  c("Mu", "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av",
    "aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej", "Gender:dominancej",
    "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk"), c("mean", "female.overall", "inbreed.overall",
    "female.inbreed", "additive", "sex.additive", "maternal", "sex.maternal",
    "inbreeding", "sex.inbreeding", "v",
    "sex.v", "w", "sex.w",
    "cross", "sex.cross") );


    
MapChainNames2 = cbind(  c("Mu", "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av",
    "aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej", "Gender:dominancej",
    "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk"), c("Mean", "Overall Female Effect", "Overall Inbreed Penalty",
    "Female*Inbreed Penalty", "additive", "Female additive", "maternal", "Female*maternal",
    "Inbred Strain add", "Sex*Inbred Strain add", "Sym-SCA",
    "Sex*Sym-SCA", "Asym-SCA", "Sex*Asym-SCA",
    "Cross SCA", "Sex*Cross SCA") );
    
MapChainNames2NoSex = cbind(  c("Mu", "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av",
    "aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej", "Gender:dominancej",
    "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk"), c("Mean", "Overall Female Effect", "Overall Inbreed Penalty",
    "Female*Inbreed Penalty", "additive", "sex.additive", "maternal", "sex.maternal",
    "Inbred Strain add", "sex.Inbred Strain add", "Sym-SCA",
    "sex.Sym-SCA", "Asym-SCA", "sex.Asym-SCA",
    "Cross SCA", "sex.Cross SCA") );
  
MapChainNamesDefaultWanted2 = cbind(  c( "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av",
    "aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej", "Gender:dominancej",
    "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk"), c("Overall Female", "Overall Inbreed",
    "Female*Inbreed", "additive", "Female additive", "maternal", "Female*maternal",
    "Inbred Strain add", "Sex*Inbred Strain add", " ",
    " ", " ", " ",
    " ", " ") );
MapChainNamesDefaultWanted2NoSex = cbind(  c( "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av",
    "aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej", "Gender:dominancej",
    "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk"), c("Overall Female", "Overall Inbreed",
    "Inbreed", "additive", "sex.additive", "maternal", "sex.maternal",
    "Inbred Strain add", "sex.Inbred Strain add", " ",
    " ", " ", " ",
    " ", " ") );
  
MapChainNamesDefaultWanted1 = cbind(  c("Mu", "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av",
    "aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej", "Gender:dominancej",
    "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk"), c("mean", "female.overall", "inbreed.overall",
    "female.inbreed.overall", "additive", "sex.additive", "parent.origin", "sex.parent.origin",
    "inbreeding", "sex.inbreeding", "symmetric",
    "sex.symmetric", "asymmetric", "sex.asymmetric",
    "cross", "sex.cross") );

MapChainNamesDefaultWanted1NoSex = cbind(  c("Mu", "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av",
    "aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej", "Gender:dominancej",
    "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk"), c("mean", "female.overall", "inbreed.overall",
    "female.inbreed", "additive", "sex.additive", "parent.origin", "sex.parent.origin",
    "inbreeding", "sex.inbreeding", "symmetric",
    "symmetric", "sex.asymmetric", "sex.asymmetric",
    "cross", "sex.cross") );

RemoveMu<- function(HPDSet) {
  if (is.matrix(HPDSet) || is.data.frame(HPDSet)) {
    try(HPDSet <- HPDSet[,
      !(colnames(HPDSet) %in% c("Mu", "mu", "Mean", "mean"))]);
  }
  library(coda);
  if (is.list(HPDSet) || is.mcmc.list(HPDSet)) {
    NewList <- list();
    for (ii in 1:length(HPDSet)) {
      NewHPD <- HPDSet[[ii]];
      try(NewHPD <- 
        NewHPD[,!(colnames(NewHPD) %in% c("Mu", "mu", "Mean", "mean"))])
      try(NewHPD <- as.mcmc(NewHPD));
      try(NewList[[ii]] <- NewHPD);
    }
    try(NewList <- as.mcmc.list(NewList));
    return(NewList);
  }
  return(HPDSet);
}
MapChainNamesDefaultWanted1 = cbind(  c("Mu", "Gender:Av", "BetaInbred:Av", "BetaInbred:Gender:Av",
    "aj", "Gender:aj", "motherj", "Gender:motherj", "dominancej", "Gender:dominancej",
    "SymCrossjk", "Gender:SymCrossjk",
    "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
    "AllCrossjk", "Gender:AllCrossjk"), c("Mean", "Overall Female", "Overall Inbreed",
    "Female*Inbreed", "additive", "Female additive", "maternal", "Female*maternal",
    "Inbred Strain add", "Sex*Inbred Strain add", " ",
    " ", " ", " ",
    " ", " ") );
 
StackChain <- function(coda.object, burnin = 1, thin = 1) {
  if (burnin <= 0) { burnin = 1; }
  if (burnin >= NROW(coda.object[[1]])) { burnin = 1; }
  burnin = round(burnin);
  if (thin <= 0) { thin = 1; }
  if (thin > NROW(coda.object[[1]]) - burnin) { thin = 1; }
  thin = round(thin);
  Keeper = burnin + (0:( (NROW(coda.object[[1]]) - burnin) %/% thin)) * thin;
  Keeper = Keeper[Keeper <= NROW(coda.object[[1]])];
  NewChain = matrix(0, length(coda.object) *length(Keeper),
    NCOL(coda.object[[1]]));
  colnames(NewChain) = colnames(coda.object[[1]]);
  AS = 0;
  for (ii in 1:length(coda.object)) {
    NewChain[AS + 1:length(Keeper),] = coda.object[[ii]][Keeper,];
    AS  = AS + length(Keeper); 
  }
  try(NewChain <- as.mcmc(NewChain));
  return(NewChain);
}  

setMethodS3("RenameChain", "DiallelOb", function(
  this, MapChainNames = NULL, UseMapChainNames1 = FALSE,
  UseMapChainNamesHPD = FALSE,
  wanted = NULL, DoStack = FALSE, DoMu = TRUE, DoTreat = FALSE, NoJK = TRUE,
  AddSpace = FALSE, DoCentered = TRUE, NoSex=FALSE, DoRawAnyWay = FALSE, DoBS=FALSE,...) {
  if (!exists("DoCentered")) { DoCentered = TRUE; }
  if (!exists("DoRaw")) { DoRaw = FALSE; }
  if (!exists("wanted")) { wanted = NULL; }
  if (!exists("MapChainNames")) { MapChainNames = NULL; }
  if (!exists("DoRawAnyWay")) { DoRawAnyWay = FALSE; }
  if (!exists("UseMapChainNames1")) { UseMapChainNames1 = FALSE; }
  if (exists("DoTreat") && is.logical(DoTreat) && DoTreat == TRUE) {
    DoMu = TRUE;
  }
  if (!exists("NoSex")) { NoSex = FALSE; }
  
     
  AFD = this$.AFD;

  if (DoBS == TRUE && !is.null(this$.AFD$.BS)) {
    if ((is.logical(AFD$DoFirstCenter) && AFD$DoFirstCenter==TRUE) || 
    (is.numeric(AFD$DoFirstCenter) && AFD$DoFirstCenter >= 1)) {         
     if (exists("DoRawAnyWay") && is.logical(DoRawAnyWay) && DoRawAnyWay == TRUE) {
        ACodaList <- this$getBSUnCent.chains();
        ARawList <- ACodaList;
        AllN <- colnames(ACodaList[[1]]);
      } else {  
        ACodaList <- this$getBSCent.chains();
        ARawList <- ACodaList;
        AllN <- colnames(ACodaList[[1]]);
      }
    } else {
      ACodaList <- this$getBSUnCent.chains();
      ARawList <- ACodaList;
      AllN <- colnames(ACodaList[[1]]);
    }
  } else if ((is.logical(AFD$DoFirstCenter) && AFD$DoFirstCenter == TRUE) || 
    (is.numeric(AFD$DoFirstCenter) && AFD$DoFirstCenter >= 1)) {
    if (exists("DoRawAnyWay") && is.logical(DoRawAnyWay) && DoRawAnyWay == TRUE) {
      try(ARawList <- this$CodaChains);    
    } else {
      try(ARawList <- this$cent.chains);
    }
  } else if ((is.logical(DoCentered) && DoCentered == FALSE) || 
    (is.logical(DoRaw) && DoRaw == TRUE)) {
    try(ARawList <-  this$raw.chains);
  } else {
    try(ARawList <- this$centered.chains);
  }
  if (is.null(AFD$Verbose)) { AFD$Verbose <- 1; }
  if (is.logical(AFD$Verbose) && AFD$Verbose == TRUE) {
    AFD$Verbose <- 2;
  } else if (is.logical(AFD$Verbose) && AFD$Verbose == FALSE) {
    AFD$Verbose <- 0;
  }
  if (AFD$Verbose >= 2) {
    print("RenameChains.  Start."); flush.console();
  }
  if (DoBS == TRUE && !is.null(AFD$.BS)) {
    AllN <- colnames(ACodaList[[1]])
  } else if ((is.logical(AFD$DoFirstCenter) && AFD$DoFirstCenter == TRUE) || 
    (is.numeric(AFD$DoFirstCenter) && AFD$DoFirstCenter >= 1)) {
    if (exists("DoRawAnyWay") && is.logical(DoRawAnyWay) && DoRawAnyWay == TRUE) {
      try(ACodaList <- this$CodaChains);
      try(AllN <- colnames(ACodaList[[1]]));    
    } else {
      try(ACodaList <- this$centered.chains);
      try(AllN <- colnames(ACodaList[[1]]));
    }
  } else {
    ACodaList = this$CodaChains
    AllN =  colnames(ACodaList[[1]]); 
  }

  burnin = 1; thin = 1;
  if (!is.null(AFD$burnin)) {
    burnin = AFD$burnin;
  }       
  if (!is.null(AFD$thin)) {
    thin = AFD$thin;
  }  
  AllFixedVariables <- NULL;  AllRandomVariables <- NULL; 
  try(AllFixedVariables <- AFD$.AllFixedVariables);
  try(AllRandomVariables <- AFD$.AllRandomVariables)
  DefaultAllRandomVariables <- NULL;
  try(DefaultAllRandomVariables <- BayesDiallel:::.DefaultAllRandomVariables);

  if (!is.null(MapChainNames)) {
    if (dim(MapChainNames)[2] != 2) {
      print("Sorry, We must have a table of two columns to  rename MapChain names.")
    }
    if (exists("DoTreat") && is.logical(DoTreat) && DoTreat==TRUE) {
      if (any(MapChainNames[,1] %in% c("Mu", "mu", "Mean", "mean", "MU"))) {
        try(MapChainNames[MapChainNames[,1] %in% 
          c("Mu", "mu", "Mean", "mean", "MU"),2] <- "treat.overall");
      } else {
        try(MapChainNames <- rbind(
          cbind(c("Mu", "mu", "Mean", "mean", "MU"),
            rep("treat.overall",5)), MapChainNames
        ));
      }
    }
    ATTY = 0;
    BList = rep(0, length(AllN));
    for (ii in 1:length(MapChainNames[,1])) {
      if (any(MapChainNames[ii,1] == substr(AllN, 1, nchar(MapChainNames[ii,1])) )) {
        ATTY = ATTY + 1;
        try(BList[MapChainNames[ii,1] == substr(AllN, 1, nchar(MapChainNames[ii,1]))] <- ii);
      }
    }
    if (ATTY == 0) {
      print("Sorry, MapChainNames first column does not map to anything in the first row!");
      return(-1);
    }
    if (any(BList == 0)) {
      if (length(BList[BList == 0]) == 1) {
        try(MapChainNames <- rbind(MapChainNames,
          c( AllN[BList == 0], AllN[BList == 0] )));
      } else {
         try(MapChainNames <- rbind(MapChainNames,
          cbind( AllN[BList == 0], AllN[BList == 0] )));
      }
    }
  } else if (UseMapChainNamesHPD == TRUE) {
    if (NoSex == FALSE) {
      try(MapChainNames <- MapChainNamesHPD);
    } else {
      try(MapChainNames <- BayesDiallel:::MapChainNamesHPDNoSex);  
    }
  } else if (UseMapChainNames1 == TRUE) {
    if (NoSex == FALSE) {
      MapChainNames = MapChainNames1;
    } else {
      MapChainNames = BayesDiallel:::MapChainNames1NoSex;
    }
  } else {
    if (NoSex == FALSE) {
      MapChainNames = cbind(c(AFD$.AllFixedVariables, AFD$.AllRandomVariables),
         c(AFD$.AllFixedVariables, AFD$.AllRandomVariables) );
    } else {
      OTT <- AFD$.AllFixedVariables;
      ATR <- AFD$.AllRandomVariables;
      ABB <- substr(OTT,1,nchar("Gender:")) == "Gender:" & OTT != "Gender:Av";
      OTT[ABB] <- substr(OTT[ABB], nchar("Gender:")+1, nchar(OTT[ABB]));
      ABB <- substr(ATR,1,nchar("Gender:")) == "Gender:" & ATR != "Gender:Av";
      ATR[ABB] <- substr(ATR[ABB], nchar("Gender:")+1, nchar(ATR[ABB]));
      ABB <- substr(OTT,1,nchar("sex:")) == "sex:" & OTT != "sex:Av";
      OTT[ABB] <- substr(OTT[ABB], nchar("sex:")+1, nchar(OTT[ABB]));
      ABB <- substr(ATR,1,nchar("sex:")) == "sex:" & ATR != "sex:Av";
      ATR[ABB] <- substr(ATR[ABB], nchar("sex:")+1, nchar(ATR[ABB]));
      MapChainNames = cbind(c(AFD$.AllFixedVariables, AFD$.AllRandomVariables),
         c(OTT, ATR) );      
                  
    }
  }
  if (any(substr(AFD$.AllFixedVariables, 1, nchar("FixedEffect")) == "FixedEffect")) {
    try(MapChainNames <- rbind(MapChainNames, cbind(
      paste("FixedEffect:", 1:length(AFD$nameFixedEffects), sep=""), 
      AFD$nameFixedEffects)));
  }
  if (length(AFD$nameRandomEffects) > 0) {
     try(MapChainNames <- rbind(MapChainNames, cbind(
      paste("RandomEffect:", 1:length(AFD$nameRandomEffects), sep=""), 
      AFD$nameRandomEffects)));
  }
  if (exists("DoTreat") && is.logical(DoTreat) && DoTreat==TRUE) {
      if (any(MapChainNames[,1] %in% c("Mu", "mu", "Mean", "mean", "MU"))) {
        try(MapChainNames[MapChainNames[,1] %in% 
          c("Mu", "mu", "Mean", "mean", "MU"),2] <- "treat.overall");
      } else {
        try(MapChainNames <- rbind(
          cbind(c("Mu", "mu", "Mean", "mean", "MU"),
            rep("treat.overall",5)), MapChainNames
        ));
      }
  }
  if (exists("DoTreat") && is.logical(DoTreat) && DoTreat==TRUE) {
      if (any(MapChainNames[,1] %in% c("Mu", "mu", "Mean", "mean", "MU", "mean.overall"))) {
        MapChainNames[MapChainNames[,1] %in% 
          c("Mu", "mu", "Mean", "mean", "MU", "mean.overall"),2] <- "treat.overall";
      }
  } 
  if (!is.null(AFD$strain.map)) {
  for (ii in 1:length(DefaultAllRandomVariables)) {
    if (any(substr(AllN,1,nchar(DefaultAllRandomVariables[ii])) == 
       DefaultAllRandomVariables[ii])) {
      MyStuff = AllN[ substr(AllN,1,nchar(DefaultAllRandomVariables[ii])) == 
       DefaultAllRandomVariables[ii] ]
      MyStuff = substr(MyStuff, nchar(DefaultAllRandomVariables[ii])+1, nchar(MyStuff));
      if (DefaultAllRandomVariables[ii] %in% 
        c("SymCrossjk","Gender:SymCrossjk",
          "ASymCrossjkDkj", "Gender:ASymCrossjkDkj",
          "AllCrossjk", "Gender:AllCrossjk") ) {
        ATT = strsplit(MyStuff, ";");  
        for (jj in 1:length(ATT)) {
          ABT = paste(unlist(strsplit(ATT[[jj]][1],":")), collapse="");
          ABT = paste(unlist(strsplit(ABT, " ")), collapse="");
          ABT = paste(unlist(strsplit(ABT, "j")), collapse="");
          ABT = AFD$strain.map[match(ABT, AFD$strain.map[,2]),1]
          BBT = paste(unlist(strsplit(ATT[[jj]][2],":")), collapse="");
          BBT = paste(unlist(strsplit(BBT, " ")), collapse="");
          BBT = paste(unlist(strsplit(BBT, "k")), collapse="");
          BBT = AFD$strain.map[match(BBT, AFD$strain.map[,2]),1] 
          if (exists("NoJK") && is.logical(NoJK) && NoJK == TRUE) {
            MyStuff[jj] = paste(":",ABT,";",BBT,sep=""); 
          } else { 
            MyStuff[jj] = paste(":j:",ABT,";k:",BBT,sep=""); 
          }     
        }  
      } else {
         
        for (jj in 1:length(MyStuff)) {
          ABT = paste(unlist(strsplit(MyStuff[jj],":")), collapse="");
          ABT = paste(unlist(strsplit(ABT, " ")), collapse="");
          ABT = paste(unlist(strsplit(ABT, "j")), collapse="");
          ABT = AFD$strain.map[match(ABT, AFD$strain.map[,2]),1]
          MyStuff[jj] = paste(":",ABT,sep="");      
        }  
      }
      AllN[substr(AllN,1,nchar(DefaultAllRandomVariables[ii])) == 
       DefaultAllRandomVariables[ii]] = paste( DefaultAllRandomVariables[ii], MyStuff, sep="");
       
    }
   }
  }
  if (AFD$Verbose >= 2) {
    print("RenameChain: We have renamed DefaultAllRandomVariables"); flush.console();
  }
  if (!is.null(MapChainNames)) {
    if (AFD$Verbose >= 2) {
      print("RenameChain: We are replacing v, w, sex:v, sex:w"); flush.console();
    }
    if (any(substr(MapChainNames[,2],1, nchar("symmetric")) == "symmetric") ||  
      any(substr(MapChainNames[,2],1,1) == "v") ||
      any(substr(MapChainNames[,2],1,nchar("Symmetric")) == "Symmetric") ||
      any(substr(MapChainNames[,2],1,nchar("SymCrossjk")) == "SymCrossjk")) {
      alt <- (1:NROW(MapChainNames))[
        substr(MapChainNames[,2],1, nchar("symmetric")) == "symmetric" |
        substr(MapChainNames[,2],1, nchar("v")) == "v" |
        substr(MapChainNames[,2],1, nchar("Symmetric")) == "Symmetric" |
        substr(MapChainNames[,2],1,nchar("SymCrossjk")) == "SymCrossjk"];
      MapChainNames[alt,2] <- sub("j:", "", MapChainNames[alt,2]); 
      MapChainNames[alt,2] <- sub("k:", "", MapChainNames[alt,2]); 
    }
    if (any(substr(MapChainNames[,2],1, nchar("female.symmetric")) == "female.symmetric") ||  
      any(substr(MapChainNames[,2],1,1) == "sex.v") ||
      any(substr(MapChainNames[,2],1,nchar("Gender:SymCrossjk")) == "Gender:SymCrossjk") ||
      any(substr(MapChainNames[,2],1,nchar("sex.SymCrossjk")) == "sex.SymCrossjk") ||
      any(substr(MapChainNames[,2],1,nchar("sex.SymCrossjk")) == "sex.symmetric") 
      ) {
      alt <- (1:NROW(MapChainNames))[
        substr(MapChainNames[,2],1, nchar("female.symmetric")) == "female.symmetric" |
        substr(MapChainNames[,2],1, nchar("sex.v")) == "sex.v" |
        substr(MapChainNames[,2],1, nchar("female.v")) == "female.v" |
        substr(MapChainNames[,2],1, nchar("Gender:SymCrossjk")) == "Gender:SymCrossjk" 
         ];
      MapChainNames[alt,2] <- sub("j:", "", MapChainNames[alt,2]); 
      MapChainNames[alt,2] <- sub("k:", "", MapChainNames[alt,2]); 
    }
  
  }
  ATT <- "
  if (!is.null(MapChainNames) && !all(MapChainNames[,1] == MapChainNames[,2])) {
    for (ii in 1:length(MapChainNames[,1])) {
      if (any(substr(AllN,1,nchar(MapChainNames[ii,1])) == MapChainNames[ii,1])) {
        AllN[substr(AllN,1,nchar(MapChainNames[ii,1])) == MapChainNames[ii,1]] = 
          paste( MapChainNames[ii,2], 
          substr(AllN[substr(AllN,1,nchar(MapChainNames[ii,1])) == MapChainNames[ii,1]],
            nchar(MapChainNames[ii,1])+1, 
            nchar(AllN[substr(AllN,1,nchar(MapChainNames[ii,1])) == MapChainNames[ii,1]])), sep=\"\");
      }
    }
  }
  ";
  if (AFD$Verbose >= 2) {
    print("RenameChain:  About to execute substitution to generate AllN"); flush.console();
  }
  try(eval(parse(text=ATT)));
  
  if (!is.null(AFD$burnin)) {
    burnin = AFD$burnin;
  }  else {
    burnin = 1;
  }
  if (!is.null(AFD$thin)) {
    thin = AFD$thin
  } else {
    thin = 1;
  }
  if (thin <= 0) { thin = 1; }
  if (burnin <= 0) { burnin = 1; }
  burnin = round(burnin);
  thin = round(thin);
  if (burnin > NROW(ARawList[[1]])) {
    burnin = 1;
  }
  KeepIters = (burnin) + (0:((NROW(ARawList[[1]])-burnin+1) %/% thin)) * thin
  if (any(KeepIters > NROW(ARawList[[1]]))) {
    KeepIters = KeepIters[KeepIters <= NROW(ARawList[[1]])];
  }
  HPDSet = list();
  if (is.null(dim(ARawList[[1]])) || dim(ARawList[[1]])[2] != length(AllN)) {
    print("********************************************************************");
    print(paste("** RenameChain: We don't have the right size AllN[", length(AllN),
     "] relative to RawList[", dim(ARawList)[1], ",", dim(ARawList)[2], "]", sep=""));
    flush.console();
    if (is.null(dim(ARawList[[1]]))) {
      print("In fact, ARawList has null dimensions! "); flush.console();
    } else {
      print(paste("ARawList has NROW = ", NROW(ARawList[[1]]), " and NCOL = ",
        NCOL(ARawList[[1]]), sep="")); flush.console();
    }
    print("**"); flush.console();
    print(paste("** We have that AllN is (",
      paste(AllN, ", "), ") ", sep="")); flush.console();
    print(paste("** And colnames of RawList are (",
      paste(colnames(ARawList[[1]]), collapse=", "), ")", sep="")); flush.console();
    eval(parse(text=SetGText("AllN", "globalenv()", S=1)));
    print("**"); flush.console();
    CARaw <- colnames(ARawList[[1]]);
    eval(parse(text=SetGText("CARaw", "globalenv()", S=1)));
    SettledMapChainNames <- MapChainNames;
    try(eval(parse(text=SetGText("SettledMapChainNames", "globalenv()", S=1))));  
    print("The MapChainNames we settled upon were: "); flush.console();
    print(MapChainNames);  flush.console(); 
    if (length(AllN) > length(unique(AllN)) ) {
      print(paste("Note that UniqueAllN is length ", length(unique(AllN)), sep=""));  flush.console();
      print("  We have that a table for AllN is :");  flush.console();
      print(table(AllN)); flush.console();
    }
    if (exists("DoTreat") && ( (is.logical(DoTreat) && DoTreat==TRUE) ||
      (is.numeric(DoTreat) && DoTreat >= 1)) ) {
      print("We have that Do Treat was TRUE. "); flush.console();  
    }
    print("** RenameChain is doomed to fail, return AllN without Rename"); flush.console();
    print("** My Recommendation is to save current object and return. "); 
    print("*******************************************************************"); flush.console();
    return(ARawList);
  }

  for (ii in 1:length(ARawList)) {
    try(AT  <- ARawList[[ii]][KeepIters,]);
    try(colnames(AT) <- AllN);
    try(HPDSet[[ii]]  <- as.mcmc(AT));
  }
  try(HPDSet <- as.mcmc.list(HPDSet));
  if (!exists("wanted") || is.null(wanted)  || length(wanted) ==  0) {
    if (AFD$Verbose >= 2) {
      print("RenameChain: wanted is NULL and doesn't exist! "); flush.console();
    }
    if (DoStack == TRUE) {
      SC <- StackChain(HPDSet, burnin = 1, thin = 1);
      if (NoSex == TRUE) {
        ACC <- colnames(SC);
        NewACC <- ACC;  
        SV <-   substr(ACC,1, nchar("sex.")) == "sex."
        NewACC[SV] <-  substr(ACC[SV], nchar("sex.")+1, nchar(ACC[SV]));
        ANewMatrix <- matrix(as.numeric(SC), NROW(SC), NCOL(SC));
        colnames(ANewMatrix) <- NewACC;
        SC <- as.mcmc(ANewMatrix);
      }
      return(SC);
    } else if (NoSex == TRUE) {
      NewL <- list();
      for (ii in 1:length(HPDSet)) {
        HC <- colnames(HPDSet[[ii]]);
        SV <- substr(HC, 1, nchar("sex.")) == "sex.";
        NewACC <- HC;  
        NewACC[SV] <- substr(HC[SV], nchar("sex.")+1, nchar(HC[SV]));
        ANew <- matrix(as.numeric(HPDSet[[ii]]), 
          NROW(HPDSet[[ii]]), NCOL(HPDSet[[ii]]));
        colnames(ANew) <- NewACC;
        NewL[[ii]] <- as.mcmc(ANew);
      }
      HPDSet <- NewL;
    }
    if (AFD$Verbose >= 2) {
      print("RenameChain: There is no wanted variable returning HPDSet back renamed in full. "); flush.console();
    }
    return(HPDSet);
    wanted = AllN;
  } else if (is.numeric(wanted)) {
    if (AFD$Verbose >= 2) {
      print("RenameChain: Wanted exists, it is numeric"); flush.console();
    }
  } else {
    if (AFD$Verbose >= 2) {
      print("RenameChain: Wanted exists in multiple columns will loop through."); flush.console();
    }
    Awanted = c();
    for (ii in 1:length(wanted)) {
      if (wanted[ii] == "FixedEffect") {  
        for (jj in 1:length(AFD$nameFixedEffects)) {     
          Awanted = c(Awanted, AllN[substr(AllN,1,
            nchar(paste("FixedEffect:", jj, sep=""))) == paste("FixedEffect:", jj, sep="")])  
          if (!is.null(MapChainNames)) {
            Bwant = sort(unique(MapChainNames[ MapChainNames[,1] == paste("FixedEffect:", jj, sep=""),2]))
            if (!is.null(Bwant) && length(Bwant) == 1) {
              Awanted = c(Awanted, AllN[substr(AllN,1,nchar(Bwant)) == Bwant])
            }
          }
        }      
      } else if (wanted[ii] == "RandomEffect") {
        for (jj in 1:length(AFD$nameRandomEffects)) {
          Awanted = c(Awanted, AllN[substr(AllN,1,
            nchar(paste("RandomEffect:", jj, sep=""))) == paste("RandomEffect:", jj, sep="")])
          if (!is.null(MapChainNames)) {
            Bwant = MapChainNames[ MapChainNames[,1] == paste("RandomEffect:", jj, sep=""),2]
            if (!is.null(Bwant) && length(Bwant) == 1) {
              Awanted = c(Awanted, AllN[substr(AllN,1,nchar(Bwant)) == Bwant])
            }
          }
        }
      } else {
      BAllN <- AllN[!(substr(AllN,1,nchar("FixedEffect")) == "FixedEffect" |
        substr(AllN,1,nchar("RandomEffect")) == "RandomEffect")];
      if (!is.null(AFD$nameRandomEffects) && length(AFD$nameFixedEffects) >= 1) {
        for (jj in 1:length(AFD$nameFixedEffects)) {
          BAllN <- BAllN[substr(BAllN, 1, length(AFD$nameFixedEffects)) != AFD$nameFixedEffects[jj]];
        }
      }
      if (!is.null(AFD$nameRandomEffects) && length(AFD$nameRandomEffects) >= 1) {
        for (jj in 1:length(AFD$nameRandomEffects)) {
          BAllN <- BAllN[substr(BAllN, 1, length(AFD$nameRandomEffects)) != AFD$nameRandomEffects[jj]];
        }
      }
      Awanted = c(Awanted, BAllN[substr(BAllN,1,nchar(wanted[ii])) == wanted[ii]])
      if (!is.null(MapChainNames)) {
        Bwant = MapChainNames[ MapChainNames[,1] == wanted[ii],2]
        if (!is.null(Bwant) && length(Bwant) == 1) {
          Awanted = c(Awanted, BAllN[substr(BAllN,1,nchar(Bwant)) == Bwant])
        }
      }
      }
    }
    Awanted = unique(Awanted);
    wanted = Awanted;
  }
  if (AFD$Verbose >= 2) {
    print("RenameChain: wanted was reconfigured!"); flush.console();
  }
  ALT = list();
  for (ii in 1:length(HPDSet)) {
    try(ALT[[ii]] <- as.mcmc(HPDSet[[ii]][, wanted]));
  }
  try(ALT <- as.mcmc.list(ALT));
  if (NoSex == TRUE) {
    NewL <- list();
    for (ii in 1:length(ALT)) {
      ACC <- colnames(ALT[[ii]]);
      SV <- (1:length(ACC))[substr(ACC, 1, nchar("sex.")) == "sex."];
      NewACC <- ACC;
      NewACC[SV] <- substr(ACC[SV], nchar("sex.")+1, nchar(ACC[SV]));
      NewN <- matrix(as.numeric(ALT[[ii]]), NROW(ALT[[ii]]), NCOL(ALT[[ii]]));
      colnames(NewN) <- NewACC;
      NewL[[ii]] <- as.mcmc(NewN);
    }
    try(NewL <- as.mcmc.list(NewL));
    try(ALT <- NewL);
  }
  if (DoStack == TRUE) {
    return(StackChain(ALT, burnin = 1, thin = 1));
  }
  return(ALT);
});
DefaultWanted1 <- list( FirstGroup = c("Mu", "BetaInbred:Av", "FixedEffect", "RandomEffect", "aj", "motherj", "dominancej"),
  SecondGroup = c("SymCrossjk", "ASymCrossjkDkj", "AllCrossjk"),
  ThirdGroup = c("Gender:Av", "BetaInbred:Gender:Av", "Gender:aj", "Gender:motherj", "Gender:dominancej"),
  FourthGroup = c("Gender:SymCrossjk", "Gender:ASymCrossjkDkj", "Gender:AllCrossjk"));
DefaultWantedColumnNames <- c("Individual Strain \n Effects", "Cross-specific \n Effects",
  "Sex*Strain \n Effects", "Sex*Cross-Specific\n Effects");
PlotHPDdiff<-function(AFD1=NULL, AFD2=NULL, ModelChoose =1, DoCentered = TRUE, DoRaw = FALSE,
  wanted = NULL, prob.wide=.95, prob.narrow = .5, 
  MapChainNames = NULL, UseMapChainNamesHPD = FALSE, UseDefaultWanted1 = FALSE,
  UseABLine=TRUE,xlims=NULL, EvenXlims = TRUE, 
  plt.left = NULL, plt.right = NULL, plt.bottom=NULL, plt.title=NULL,
  name.margin=NULL, name.line=NULL, title.margin=NULL, title.line=NULL,
  bottom.margin=NULL, bottom.line=NULL, right.margin=NULL, right.line=NULL, 
  ylab="", DoMu = TRUE, DoTreat = TRUE,
  UseMapChainNames1 = FALSE, NoJK=TRUE, HPDWidths=NULL, plt.lefts = NULL, DoEvensPlot=FALSE,
  cex.rownames= 1, DoBS=FALSE, ...) {
  if (!exists(ModelChoose)) { ModelChoose = 1; }
  if (!exists(AFD1) || is.null(AFD1)) {  
    print("PlotHPDdiff: Must supply AFD1"); flush.console(); return(-1);
  }
  if (!exists(AFD2) || is.null(AFD2)) {  
    print("PlotHPDdiff: Must supply AFD2"); flush.console(); return(-1);
  }
  if (!exists("DoEvensPlot")) { DoEvensPlot <- FALSE; }
  if (!exists("cex.rows")) { cex.rows <- 1; }
  if (!exists("DoCentered")) { DoCentered = TRUE; }
  if (!exists("DoRaw")) { DoRaw = FALSE; }
  if (!exists("wanted")) { wanted = NULL; }
  if (!exists("prob.wide")) { prob.wide = .95; }
  if (!exists("prob.narrow")) { prob.narrow = .5; }
  if (!exists("MapChainNames")) { MapChainNames = NULL; }
  if (!exists("UseMapChainNamesHPD")) { UseMapChainNamesHPD = FALSE; }
  if (!exists("UseMapChainNames1")) { UseMapChainNames = FALSE; }
  
  if (!exists("title.margin") || is.null(title.margin)) { title.margin= 4.1; title.line=3.5}
  if (!exists("title.line") || is.null(title.line)) { title.line = .8 * title.margin; }
  if (!exists("right.margin") || is.null(right.margin)) { right.margin= 2.1; right.line=1.6}
  if (!exists("right.line") || is.null(right.line)) { right.line = .8 * right.margin; }      
  if (!exists("bottom.margin") || is.null(bottom.margin)) { bottom.margin= 5.1; bottom.line=4.6}
  if (!exists("bottom.line") || is.null(bottom.line)) { bottom.line = .8 * bottom.margin; }    

  if (is.null(MapChainNames)) {
    MapChainNames = MapChainNamesHPD
  }
  if (UseDefaultWantedTreat == TRUE) {
    eval(parse(text=GetG0Text("MapChainNamesTreatHPD", "globalenv()")));
    if (is.numeric(MapChainNamesTreatHPD) && length(MapChainNamesTreatHPD) == 1) {
     MapChainNamesTreatHPD = rbind(MapChainNamesHPD,
       cbind(paste("Treat:", MapChainNamesHPD[,1], sep=""),
        paste(MapChainNamesHPD[,2], sep="")) );
    eval(parse(text=SetGText("MapChainNamesTreatHPD", "globalenv()", S=1)));
    try(eval(parse(text=SetGText("MapChainNamesTreatHPD", "BayesDiallel:::RSIMNAMESPACE", S=1))));    
    }
    MapChainNames = MapChainNamesTreatHPD;
  }
  ARawList =  this$raw.chains;
  if (DoCentered == FALSE || DoRaw == TRUE) {
  } else {
    ARawList = this$centered.chains;
  }
  if (DoCentered == TRUE) {
    ACodaList1 = AFD1$AllDiallelObs[[ModelChoose]]$centered.chains;
    ACodaList2 = AFD2$AllDiallelObs[[ModelChoose]]$centered.chains;
  } else if (DoCentered == FALSE) {
    ACodaList1 = AFD1$AllDiallelObs[[ModelChoose]]$raw.chains;
    ACodaList2 = AFD2$AllDiallelObs[[ModelChoose]]$raw.chains;  
  } else {
    print(paste("Error: DoCentered = ", DoCentered, ", pick a true or a false!", sep=""));
    flush.console();
    return(-1)
  }
  ACodaList = list();
  for (ii in 1:length(ACodaList1)) {
    if (NROW(ACodaList2[[ii]]) != NROW(ACodaList1[[ii]]) ||
       NCOL(ACodaList2[[ii]]) != NCOL(ACodaList2[[ii]]) ) {
      tryCatch(paste(
        "Error: Chains must be same dimension in AFD1[[", ii, "]](",
          paste(dim(ACodaList1[[ii]]), collapse=", "), ")  and  AFD2[[",
          ii, "]](", paste(dim(ACodaList2[[ii]]), collapse=", "),
          ")!", sep=""));
    }
    ACodaList[[ii]] = as.mcmc(ACodaList2[[ii]] - ACodaList1[[ii]] );
    colnames(ACodaList[[ii]]) = colnames(ACodaList[[ii]]);
  }
  
  AllN =  colnames(ACodaList[[1]]);
  WantedColumnNames = NULL;
  if (UseDefaultWanted1 == TRUE) {
   wanted = DefaultWanted1;
   WantedColumnNames = DefaultWantedColumnNames;
  }
  if (UseDefaultWantedTreat == TRUE)  {
    eval(parse(text=GetG0Text("DefaultWantedTreat", "BayesDiallel:::RSIMNAMESPACE", S=1)));
    DefaultWantedTreat = DefaultWanted1;
    WantedColumnNames = DefaultWantedColumnNames;
    for (ii in 1:length(DefaultWantedTreat)) {
      DefaultWantedTreat[[ii]] <- paste("Treat:", DefaultWantedTreat[[ii]], sep="");
    }
    WantedColumnNames = paste("Treatment Interaction\n", WantedColumnNames, sep="");
    try(eval(parse(text=SetGText("DefaultWantedTreat", "BayesDiallel:::RSIMNAMESPACE", S=1))));
    try(eval(parse(text=SetGText("DefaultWantedTreat", "globalenv()", S=1))));
    wanted=DefaultWantedTreat;
  }
  
  if (exists("DoTreat") && (is.logical(DoTreat)) && DoTreat==TRUE) {
    DoMu = TRUE;
  }
  AllFixedVariables = AFD1$.AllFixedVariables
  if (DoMu == FALSE) {
    AllFixedVariables = AllFixedVariables[!(AllFixedVariables %in% c("mu", "Mu"))]
  }
  DefaultAllRandomVariables = BayesDiallel:::.DefaultAllRandomVariables
   if (!exists("prob.wide") || is.null(prob.wide) || prob.wide >= 1.0) {
    prob.wide = .95;
  }
  if (!exists("prob.narrow") || is.null(prob.narrow) || prob.narrow >= 1.0) {
    prob.wide = .95;
  }
if (!is.list(wanted)) {
  if (!exists("DoMu")) { DoMu = TRUE; }
  HPDSet <- this$RenameChain(
    MapChainNames = MapChainNames, UseMapChainNames1 = UseMapChainNames1,
    UseMapChainNamesHPD = UseMapChainNamesHPD, DoCentered=DoCentered,
    wanted = wanted, DoStack = FALSE, DoMu=DoMu, DoBS=DoBS, ...)
  if (DoMu == FALSE) {
    try(HPDSet <- RemoveMu(HPDSet));
  }
    if (is.null(name.margin)) {
     name.margin = 6.1;
      MxC = max(nchar(varnames(HPDSet)));
      if (MxC /4 > 6.1) { name.margin = MxC / 4+1; }
      name.line= name.margin-1;
    }
    if (is.null(name.line)) { name.line = name.margin-1; }
  plot.hpd(coda.object = HPDSet, prob.wide=prob.wide,
      prob.narrow = prob.narrow, ylab=ylab, plt.left=plt.left, plt.title=plt.title,
       plt.right=plt.right,plt.bottom=plt.bottom,
       name.margin=name.margin,
       name.line = name.line, bottom.margin=bottom.margin,
       bottom.line=bottom.line, right.margin=right.margin,
       right.line=right.line, title.margin=title.margin,
       title.line=title.line,...);
  if (UseABLine == TRUE) {
    abline(v=0, col="gray80");
  }
  return(1);
}  

  if (is.list(wanted)) {
    if (!is.null(xlims)) {
      if (is.null(dim(xlims)) && length(xlims) == 2) {
        xlims = cbind(rep(xlims[1], length(wanted)), 
          rep(xlims[2], length(wanted)) );
      } else if (is.null(dim(xlims))) {
        print(paste("Error inputting xlims, length(wanted) == ", 
          length(wanted), ", default xlims to NULL", sep="")); flush.console();
        xlims = NULL;
      } else if (dim(xlims)[1] == length(wanted)) {
      
      } else {
        print(paste("Error inputting xlims, length(wanted) == ", 
          length(wanted), ", default xlims to NULL", sep="")); flush.console();
        xlims = NULL;
      }
    }
  
 if (!is.null(xlims)) {
      par(mfrow=c(1,length(wanted)));
    } else if (EvenXlims == TRUE) {
      ABounds = c(0,0);
      NNlength = rep(0, length(wanted));
      for (ii in 1:length(wanted)) {
        HPDSet <- this$RenameChain(
          MapChainNames = MapChainNames, 
          UseMapChainNames1 = UseMapChainNames1,
          UseMapChainNamesHPD = UseMapChainNamesHPD, DoCentered=DoCentered,
          wanted = wanted[[ii]], DoStack = TRUE, DoMu = DoMu, DoBS=DoBS, ...)
        if (!exists("DoMu")) { DoMu = TRUE; }
        if (DoMu == FALSE) {
          try(HPDSet <- RemoveMu(HPDSet));
        }
        MyLD = HPDinterval(as.mcmc(HPDSet));
        ABounds[1] = min(c(ABounds[1], MyLD[,1]));
        ABounds[2] = max(c(ABounds[2], MyLD[,2]));
        NNlength[ii] = max(nchar(varnames(HPDSet)));
      }
    
      xlims = ABounds;
      if (DoEvensPlot == FALSE) {
        layout(matrix(1:length(wanted),1,length(wanted)), 
          widths=c(10 + 2 + NNlength *2.5), 
          heights = c(1) );
      } else  {
         AW <- as.vector(rbind(NNlength*2.5+1, rep(10+1, length(NNlength))));
         layout(matrix(1:(2*length(wanted)),1,2*length(wanted)), 
          widths=AW, 
          heights = c(1) );     
      }
    } else {
      xlims = NULL;
       par(mfrow=c(1,length(wanted)));
    }
    
   
                
    name.margin.back = name.margin;
    name.line.back = name.line;
 
    for (ii in 1:length(wanted)) {
      if (!exists("DoMu")) { DoMu = TRUE; }
      HPDSet <- this$RenameChain(
        MapChainNames = MapChainNames, UseMapChainNames1 = UseMapChainNames1,
        UseMapChainNamesHPD = UseMapChainNamesHPD,  DoCentered=DoCentered,
        wanted = wanted[[ii]], DoStack = FALSE, DoMu=DoMu, DoTreat = DoTreat, 
        DoBS=DoBS, ...)
      if (is.null(name.margin.back)) {
        name.margin = 6.1;
        MxC = max(nchar(varnames(HPDSet)));
        if (MxC /2.5 > 6.1) { name.margin = MxC / 2.5+1; }
        name.line = name.margin - .8;
      } 
      if (is.null(name.line.back)) { name.line = name.margin-.8; } 
      if (DoMu == FALSE) {
        try(HPDSet <- RemoveMu(HPDSet)); 
      }
      mainT <- "";
      if (is.null(WantedColumnNames)) { mainT = ""} else {
        try(mainT <- WantedColumnNames[ii]);
      }
      if (DoEvensPlot == FALSE) {
      plot.hpd(coda.object = HPDSet, prob.wide=prob.wide,
       prob.narrow = prob.narrow, ylab=ylab, xlim=xlims,
       name.margin = name.margin, plt.left=plt.left, plt.title=plt.title,
       plt.right=plt.right,plt.bottom=plt.bottom,
       name.line= name.line, bottom.margin=bottom.margin,
       bottom.line=bottom.line, right.margin=right.margin,
       right.line=right.line, title.margin=title.margin,
       title.line=title.line, main=mainT, ...);
      } else {
        if (is.list(HPDSet)) {
          ABT <- colnames(HPDSet[[1]]);
          NewS <- list();
          for (jj in 1:length(HPDSet)) {
            AS <- matrix(as.numeric(HPDSet[[jj]]), NROW(HPDSet[[jj]]), NCOL(HPDSet[[jj]]));
            colnames(AS) <- rep("", NCOL(AS));
            NewS[[jj]] <- as.mcmc(AS);
          }
          NewS <- as.mcmc.list(NewS); 
        } else {
          ABT <- colnames(HPDSet);  
          AS <- matrix(as.numeric(HPDSet), NROW(HPDSet), NCOL(HPDSet));
          colnames(AS) <- rep("", NCOL(AS));
          NewS <- as.mcmc(AS);
        } 
        par(plt=c(0,1,plt.bottom, plt.title));
        if (!exists(cex.rownames)) { cex.rownames = 1; }
        plot(x=c(0,1), y=c(0,1), xlim=c(0,1), ylim=c(0,length(ABT)), type="n",
          pch="n");
        text(label=ABT, x=rep(.9, length(ABT)), y=(1:length(ABT))-.5,
          cex=cex.rownames)
        plot.hpd(coda.object = HPDSet, prob.wide=prob.wide,
       prob.narrow = prob.narrow, ylab=ylab, xlim=xlims,
       name.margin = name.margin, plt.left=plt.left, plt.title=plt.title,
       plt.right=plt.right,plt.bottom=plt.bottom,
       name.line= name.line, bottom.margin=bottom.margin,
       bottom.line=bottom.line, right.margin=right.margin,
       right.line=right.line, title.margin=title.margin,
       title.line=title.line, main=mainT, ...);
      }
      if (UseABLine == TRUE) {
         abline(v=0, col="gray80");
      }
    }
    return(1);
  
  }

  return(1);
}
setMethodS3("PlotHPD", "DiallelOb", function(this, DoCentered = TRUE, DoRaw = FALSE,
  wanted = NULL, WantedColumnNames = NULL, prob.wide=.95, prob.narrow = .5, 
  MapChainNames = NULL, UseMapChainNames1 = FALSE, 
  UseMapChainNamesHPD = TRUE, UseDefaultWanted1 = FALSE,
  UseDefaultWantedTreat = FALSE,
  UseABLine=TRUE,xlims=NULL, EvenXlims = TRUE, 
  plt.left = NULL, plt.right = NULL, plt.bottom=NULL, plt.title=NULL,
  name.margin=NULL, name.line=NULL, title.margin=NULL, title.line=NULL,
  bottom.margin=NULL, bottom.line=NULL, right.margin=NULL, right.line=NULL, 
  ylab="", DoMu = TRUE, DoTreat = FALSE,  mainText = "", NoJK = TRUE, 
  HPDWidths = NULL, plt.lefts = NULL, DoEvensPlot = TRUE, cex.rows = 1, 
  NoSex = NULL, DoElipsis = TRUE, DoRawAnyWay = FALSE, DoBS=FALSE, ...) {
  if (!exists("DoEvensPlot")) { DoEvensPlot = TRUE; }
  if (!exists("cex.rows")) { cex.rows = 1; }
  if (!exists("name.margin")) { name.margin = NULL; }
  if (!exists("name.line")) { name.line = NULL; }
  if (!exists("DoCentered")) { DoCentered = TRUE; }
  if (!exists("DoRaw")) { DoRaw = FALSE; }
  if (!exists("ylab")) { ylab = ""; }
  if (!exists("NoJK")) { NoJK = TRUE; }
  if (!exists("DoElipsis")) { DoElipsis = FALSE; }
  if (!exists("wanted")) { wanted = NULL; }
  if (!exists("prob.wide")) { prob.wide = .95; }
  if (!exists("prob.narrow")) { prob.narrow = .5; }
  if (!exists("MapChainNames")) { MapChainNames = MapChainNamesHPD; }
  if (!exists("UseMapChainNames1")) { UseMapChainNames1 = FALSE; }
  if (!exists("EvenXlims")) { EvenXlims = TRUE; }
  if (!exists("DoRawAnyWay")) { DoRawAnyWay = FALSE; }
  if (!exists("plt.left")) { plt.left = NULL; }
  if (!exists("plt.right")) { plt.right = NULL; }
  if (!exists("plt.bottom")) { plt.bottom = NULL; }
  if (!exists("plt.title")) { plt.title=NULL; }
  if (!exists("UseABLine")) { UseABLine = TRUE; }
  if (!exists("mainText")) { mainText = ""; }
  if (!exists("DoMu")) { DoMu = FALSE; }
  if (!exists("HPDWidths")) { HPDWidths = NULL; }
  if (!exists("UseMapChainNamesHPD")) { UseMapChainNamesHPD = FALSE; }
  if (!exists("UseDefaultWanted1")) { UseDefaultWanted1 = TRUE; }
  if (!exists("UseDefaultWantedTreat")) { UseDefaultWantedTreat = FALSE; }
  if (!exists("plt.lefts")) { plt.lefts = NULL; }
  if (!exists("NoSex")) { NoSex = NULL; }
  if (!exists("wanted")) { wanted <- NULL; }
  if (!exists("WantedColumnNames")) { WantedColumnNames <- NULL; }
  
  if (!exists("title.margin") || is.null(title.margin)) { 
    title.margin= 4.1; title.line=3.5}
  if (!exists("title.line") || is.null(title.line)) { 
    title.line = .8 * title.margin; }
  if (!exists("right.margin") || is.null(right.margin)) { 
    right.margin= 2.1; right.line=1.6}
  if (!exists("right.line") || is.null(right.line)) { 
    right.line = .8 * right.margin; }      
  if (!exists("bottom.margin") || is.null(bottom.margin)) { 
    bottom.margin= 5.1; bottom.line=4.6}
  if (!exists("bottom.line") || is.null(bottom.line)) { 
    bottom.line = .8 * bottom.margin; }    
  AFD = this$.AFD;
  try(eval(parse(text=GetG0Text("Verbose", "globalenv()", S=1))));
  try(Verbose <- AFD$Verbose);
  if (is.null(Verbose) || (is.character(Verbose) && Verbose == "") || 
    !is.numeric(Verbose)) {
    Verbose <- 0;  try(AFD$Verbose <- 0);
  }
  if (is.logical(Verbose) && Verbose == TRUE) { Verbose <- 2; 
  } else if (is.logical(Verbose)) { Verbose <- 0; }
  if (is.null(Verbose) || is.na(Verbose) || !is.numeric(Verbose)) { Verbose <- 0; }
  if (Verbose >= 1) {
    print("PlotHPD Starting. "); flush.console();
  }
  if (is.null(AFD$DDO1) || is.null(AFD$DDO2) ||
    length(AFD$DDO1) <= 0 || length(AFD$DDO2) <= 0) {
    DoTreat <- FALSE;  
  } 
  library(coda);
  if (DoBS == TRUE && !is.null(this$.AFD$.BS)) {
    if ((is.logical(AFD$DoFirstCenter) && AFD$DoFirstCenter==TRUE) || 
    (is.numeric(AFD$DoFirstCenter) && AFD$DoFirstCenter >= 1)) {         
     if (exists("DoRawAnyWay") && is.logical(DoRawAnyWay) && DoRawAnyWay == TRUE) {
        ACodaList <- this$getBSUnCent.chains();
        ARawList <- ACodaList;
        AllN <- colnames(ACodaList);
        DoRawAnyWay = TRUE;
      } else {
        ACodaList <- this$getBSCent.chains();
        ARawList <- ACodaList;
        AllN <- colnames(ACodaList);
        DoRawAnyWay = FALSE;
      }
    } else {
        ACodaList <- this$getBSUnCent.chains();
        ARawList <- ACodaList;
        AllN <- colnames(ACodaList);
        ACodaList = NewCodaList; ARawList = NewCodaList;
        DoRawAnyWay = TRUE;
    }
  } else if ((is.logical(AFD$DoFirstCenter) && AFD$DoFirstCenter==TRUE) || 
    (is.numeric(AFD$DoFirstCenter) && AFD$DoFirstCenter >= 1))  {
    if (exists("DoRawAnyWay") && is.logical(DoRawAnyWay) && DoRawAnyWay == TRUE) {
      ACodaList = this$CodaChains; ARawList = this$CodaChains;
      DoRawAnyWay = TRUE;
    } else {
      ACodaList = this$centered.chains;
      ARawList = this$centered.chains;
      DoRawAnyWay = FALSE;
    }
  } else if ((is.logical(DoCentered) && DoCentered == FALSE)|| (is.logical(DoRaw) && DoRaw == TRUE)) {
    ARawList =  this$raw.chains;
    ACodaList = this$CodaChains;
  } else {
    ARawList = this$centered.chains;
    ACodaList = this$CodaChains;
  }

  
  if (is.null(NoSex)) {
    if ((is.logical(DoEvensPlot) && DoEvensPlot == TRUE)||
      (is.numeric(DoEvensPlot) && DoEvensPlot > 0) ) {
      NoSex = TRUE;  
    } else {
      NoSex = FALSE;
    }
  }
  
  AllN =  colnames(ACodaList[[1]]);
  if (UseDefaultWanted1 == TRUE) {
   wanted = DefaultWanted1;
   WantedColumnNames <- DefaultWantedColumnNames;
   if (is.null(this$SexVector) && !(any(
     substr(colnames(this$CodaChains),1,nchar("Gender"))) %in%
     c("Gender", "gender"))) {
     wanted = list(FirstGroup=c("Mu", "BetaInbred:Av", "FixedEffect", "RandomEffect", "aj"),
       SecondGroup= c("motherj", "dominancej"), 
       ThirdGroup = "SymCrossjk", FourthGroup="ASymCrossjkDkj" );   
     WantedColumnNames = c("Fixed and Individual Strain \n Additive Effects",
       "Parent Of Origin \n and Inbreeding Effects",
       "Cross-specific \n Symmetric Effects", "Cross-specific \n Parent of Origin");
   }
  } else if (!exists("wanted") || is.null(wanted) || length(wanted) <= 0) {
    wanted = MapChainNamesHPD[,1];
    WantedColumnNames <- "";
  }
  
  if (UseDefaultWantedTreat == TRUE) {
    if (NoSex == FALSE) {
      eval(parse(text=GetG0Text("MapChainNamesTreatHPD", envir="globalenv()", S=1)));
    } else {
      eval(parse(text=GetG0Text("MapChainNamesTreatHPDNoSex", envir="globalenv()", S=1)));
      MapChainNamesTreatHPD = MapChainNamesTreatHPDNoSex;
    }
    if (is.numeric(MapChainNamesTreatHPD) && length(MapChainNamesTreatHPD) == 1) {
      MapChainNamesTreatHPD = rbind(MapChainNamesHPD,
      cbind(paste("Treat:", MapChainNamesHPD[,1], sep=""),
      paste(MapChainNamesHPD[,2], sep="")),
      c("Treat:Mu:Treat:Mu", "mean"),
      c("FixedEffect:1:Treat:Mu", "mean"),
      c("FixedEffect:2:Treat:Gender:Av", "female.overall"),
      c("FixedEffect:3:Treat:BetaInbred:Av", "inbreed.overall"), 
      c("FixedEffect:4:Treat:BetaInbred:Gender:Av", "female.inbreed.overall"),
      c("FixedEffect:4:Treat:Gender:BetaInbred:Av", "female.inbreed.overall"));
      eval(parse(text=SetGText("MapChainNamesTreatHPD", "globalenv()", S=1)));
      try(eval(parse(text=SetGText("MapChainNamesTreatHPD", "BayesDiallel:::RSIMNAMESPACE", S=1))));    
    }
    MapChainNames = MapChainNamesTreatHPD;
    eval(parse(text=GetG0Text("DefaultWantedTreat", "BayesDiallel:::RSIMNAMESPACE", S=1)));
    DefaultWantedTreat = DefaultWanted1;
    if (is.null(this$SexVector) && !(any(
       substr(colnames(this$CodaChains),1,nchar("Gender"))) %in%
       c("Gender", "gender"))) {
     wanted = list(FirstGroup=c("Mu", "BetaInbred:Av", "FixedEffect", "RandomEffect", "aj"),
       SecondGroup= c("motherj", "dominancej"), 
       ThirdGroup = "SymCrossjk", FourthGroup="ASymCrossjkDkj" );  
      WantedColumnNames = c("Fixed and Individual Strain \n Additive Effects",
       "Parent Of Origin \n and Inbreeding Effects",
       "Cross-specific \n Symmetric Effects", "Cross-specific \n Parent of Origin");
    }
    WantedColumnNames <- DefaultWantedColumnNames;
    WantedColumnNames <- paste("Treatment Interaction\n ", WantedColumnNames, sep="");
    for (ii in 1:length(DefaultWantedTreat)) {
      if (ii == 1) {
        DefaultWantedTreat[[ii]] <- c("FixedEffect:1:Treat:Mu",
          "FixedEffect:3:Treat:BetaInbred:Av", 
          paste("Treat:", DefaultWantedTreat[[ii]], sep=""));
      } else if (ii == 3) {
        DefaultWantedTreat[[ii]] <- c("FixedEffect:2:Gender:Av",
          "FixedEffect:4:Treat:Gender:BetaInbred:Av",
          "FixedEffect:4:Treat:BetaInbred:Gender:Av",
          paste("Treat:", DefaultWantedTreat[[ii]], sep=""));
      } else {
        DefaultWantedTreat[[ii]] <- paste("Treat:", DefaultWantedTreat[[ii]], sep="");      
      }
    }
    try(eval(parse(text=SetGText("DefaultWantedTreat", "BayesDiallel:::RSIMNAMESPACE", S=1))), silent=TRUE);
    try(eval(parse(text=SetGText("DefaultWantedTreat", "globalenv()", S=1))));
    wanted=DefaultWantedTreat;  DoMu = TRUE;  DoTreat = FALSE;
    UseMapChainNames1 = FALSE;  UseMapChainNamesHPD = FALSE;
    if (is.null(Verbose) || is.na(Verbose) || !is.numeric(Verbose)) { Verbose <- 0; }
    if (Verbose >= 1) {
      print("PlotHPD:  We are using DefaultWantedTreat = TRUE; ");
    }
  }
  if (exists("DoTreat") && is.logical(DoTreat) && DoTreat == TRUE) {
    DoMu = TRUE;
  }
  AllFixedVariables <- AFD$.AllFixedVariables;
  if (DoMu == FALSE) {
    AllFixedVariables = AllFixedVariables[!(AllFixedVariables %in% c("Mu", "mu"))]
  }
  DefaultAllRandomVariables = BayesDiallel:::.DefaultAllRandomVariables
   if (!exists("prob.wide") || is.null(prob.wide) || prob.wide >= 1.0) {
    prob.wide = .95;
  }
  if (!exists("prob.narrow") || is.null(prob.narrow) || prob.narrow >= 1.0) {
    prob.wide = .95;
  }
  OldPLT <- par("plt");
  if (UseMapChainNamesHPD == TRUE) {
    if (NoSex == FALSE) {
      eval(parse(text=GetG0Text("MapChainNamesHPD", S=1)));
      MapChainNames <- MapChainNamesHPD;
    } else {
      MapChainNamesHPDNoSex = BayesDiallel:::MapChainNamesHPDNoSex;
      MapChainNames <- MapChainNamesHPDNoSex;
    }
  }
  if (!is.null(MapChainNames) && length(AFD$nameFixedEffects) >= 1) {
    MapChainNames <- rbind(MapChainNames, cbind(paste("FixedEffect:", 
      1:length(AFD$nameFixedEffects), sep=""),  AFD$nameFixedEffects));
  }
  if (!is.null(MapChainNames) && length(AFD$nameRandomEffects) >= 1) {
    MapChainNames <- rbind(MapChainNames, cbind(paste("RandomEffect:", 
      1:length(AFD$nameRandomEffects), sep=""),  AFD$nameRandomEffects));
  }
  if (is.null(Verbose) || is.na(Verbose) || !is.numeric(Verbose)) { Verbose <- 1; }
  if (Verbose >= 1) {
    print("Setting MapChainNames to GlobalEnv");  flush.console();
  }
  eval(parse(text=SetGText("MapChainNames", "globalenv()", S=1)));
  
  if (Verbose >= 1) {
    print("Setting wanted to GlobalEnv"); flush.console();
  }
  eval(parse(text=SetGText("wanted", "globalenv()", S=1)));
  if (!exists("xlims")) { xlims = NULL;}
  if (is.list(wanted)) {
    if (Verbose >= 2) {
      print("Object \"wanted\" is a List, will attempt to use."); flush.console();
    }
    if (exists("xlims") && !is.null(xlims)) {
      if (is.null(dim(xlims)) && length(xlims) == 2) {
        try(xlims <- cbind(rep(xlims[1], length(wanted)), 
          rep(xlims[2], length(wanted)) ));
      } else if (is.null(dim(xlims))) {
        print(paste("Error inputting xlims, length(wanted) == ", 
          length(wanted), ", default xlims to NULL", sep="")); flush.console();
        xlims = NULL;
      } else if (dim(xlims)[1] == length(wanted)) {
      
      } else {
        print(paste("Error inputting xlims, length(wanted) == ", 
          length(wanted), ", default xlims to NULL", sep="")); flush.console();
        try(xlims <- NULL);
      }
    }
    if (!exists("xlims") || is.null(xlims)) {
      try(ABounds <- c(0,0));
      try(NNlength <- rep(0, length(wanted)));
      if (!exists("DoMu")) { DoMu = TRUE; }
      NoCols = c();
      for (ii in 1:length(wanted)) {
        MySaveii = ii;
        HPDSet <- NULL;
        eval(parse(text=SetGText("MySaveii", "globalenv()", S=1)));
        try(HPDSet <- this$RenameChain(
          MapChainNames = MapChainNames, UseMapChainNames1 = UseMapChainNames1,
          UseMapChainNamesHPD = UseMapChainNamesHPD, DoCentered=DoCentered,
          wanted = wanted[[ii]], DoStack = TRUE, DoMu=DoMu, DoTreat=DoTreat,
          NoJK = NoJK,NoSex=NoSex,DoRawAnyWay = DoRawAnyWay,
          DoBS=DoBS, ...), silent=TRUE);
        if (is.null(HPDSet)) {
         try(HPDSet <- this$RenameChain(
            MapChainNames = MapChainNames, UseMapChainNames1 = UseMapChainNames1,
            UseMapChainNamesHPD = UseMapChainNamesHPD, DoCentered=DoCentered,
            wanted = wanted[[ii]], DoStack = TRUE, DoMu=DoMu, DoTreat=DoTreat,
            NoJK = NoJK,NoSex=NoSex, DoRawAnyWay = DoRawAnyWay,
            DoBS=DoBS));
        }
        if (is.null(HPDSet)) {
          print("******************************************************************************");
          print("**  An Error.  "); flush.console();
          print(paste("** Error: XLims supplied, but we do not successfuly rename HPDSet on ii = ", ii, sep="")); flush.console();
          try(print(paste("** We have that MapChainNames was: (",
            paste(MapChainNames, collapse=", "), ")", sep="")));  
          flush.console();
          try(print(paste("** We have that Wanted[[ii=", ii,"]] = (",
            paste(wanted[[ii]], collapse=", "), ")", sep="")));
          try(print("**  What should we do about this ? ")); flush.console();
        }
        if (Verbose >= 2) {
          print(paste("Hey we read in HPDSet[ii=", ii, "] and colnames are ",
            paste(colnames(HPDSet), collapse=", "), sep="")); flush.console();
        }
        ColnamesHPDSet <- colnames(HPDSet);
        eval(parse(text=SetGText("ColnamesHPDSet", "globalenv()", S=1)));
        if (Verbose >= 2) {
          print("Maybe Try to Remove Mu?");
        }
        if (DoMu == FALSE) {
          BackHPDSet <- NULL;
          try(BackHPDSet <- RemoveMu(HPDSet));
          if (is.null(BackHPDSet)) {
            print("***************************************************");
            print("**  PlotHPD():  RemoveMu returned an error.  ");
            print(paste("** we had that colnamesHPDSet was: (",
              paste(colnames(HPDSet), collapse=", "), ")", sep=""));
            print("**  Will not perform Remove Mu");
            flush.console();
          } else {
            HPDSet <- BackHPDSet;
          }
        }
        if (length(HPDSet) != 0) {
          MyLD = HPDinterval(as.mcmc(HPDSet));
          ABounds[1] = min(c(ABounds[1], MyLD[,1]));
          ABounds[2] = max(c(ABounds[2], MyLD[,2]));
          NNlength[ii] = max(nchar(varnames(HPDSet)));
        } else {
          NoCols <- c(NoCols, ii);
        }
      }
      APretty <- pretty(ABounds);
      LimPretty <- c(min(APretty), max(APretty));

      if (is.null(plt.lefts) || length(plt.lefts) != length(wanted)) {
        if (is.null(HPDWidths) || length(HPDWidths) != length(wanted)) {
          HPDWidths <-  1 + .1+NNlength /50;
        } else {
          HPDWidths <- HPDWidths + .12+NNlength / 25;
        }
        plt.lefts = .12+NNlength / 25;
      } else {
        if (is.null(HPDWidths) || length(HPDWidths) != length(wanted)) {
          HPDWidths <-  1 + plt.lefts;
        } else {
          HPDWidths <- HPDWidths + plt.lefts;
        }
      }
      if (length(NoCols) >= 1) {
        Newwanted = list();   OnGo = 1;
        NewWantedColumnNames = c();
        for (ii in 1:length(wanted)) {
          if (ii %in% NoCols) {
            
          } else {
            Newwanted[[OnGo]] = wanted[[ii]];
            NewWantedColumnNames  <- c(NewWantedColumnNames,
              WantedColumnNames[ii])
            OnGo <- OnGo+1;
          }  
        }
        wanted = Newwanted;
        WantedColumnNames = NewWantedColumnNames;
      }
      ##xlims = ABounds;
      if (mainText != "") {
        if (DoEvensPlot == FALSE) {
          layout(cbind(c(1,1),rbind(rep(2, length(wanted)),
            2+(1:length(wanted)))), 
            widths=c(.1,HPDWidths), 
            heights = c(.1,1) ); 
        } else {
          ABadVec <-  as.vector(rbind(2+(1:length(wanted)-1)*3+2,
            2+(1:length(wanted)-1)*3+3));
          AWidth <- as.vector(rbind(plt.lefts,rep(1, length(plt.lefts))));
          layout(cbind(c(1,1,1),rbind(rep(2, 2*length(wanted)),
            rep(2+(1:length(wanted)-1)*3+1, each=2),
            ABadVec )), 
            widths=c(.1,AWidth), 
            heights = c(.1,.1, 1) );         
        }
        try(par(plt = c(0,1,0,1)));
        plot(c(0,1),c(0,1), main="", xlab="", ylab="", axes=FALSE, type="n");
        plot(c(0,1),c(0,1), xlim=c(0,1), ylim=c(0,1),
          main="", xlab="", ylab="", axes=FALSE, type="n");
        text(x=.5, y=.99, labels=mainText, pos=1, cex=2.5)    
        try(par(plt = OldPLT), silent=TRUE); 
      } else {
        if (DoEvensPlot == FALSE) {
        layout(matrix(1:(length(wanted)+1),1,1+length(wanted)), 
          widths=c(.1,HPDWidths), 
          heights = c(1) );
        } else {
          ABadVec <-  as.vector(rbind(1+(1:length(wanted)-1)*3+2,
            1+(1:length(wanted)-1)*3+3));
          AWidth <- as.vector(rbind(plt.lefts,rep(1, length(plt.lefts))));
          layout(cbind(c(1,1),  rbind(
            rep(1+(1:length(wanted)-1)*3+1, each=2),
            ABadVec)),
          widths=c(.1,AWidth), 
          heights = c(.1,1) );      
        }
        try(par(plt = c(0,1,0,1)));
        plot(c(0,1),c(0,1), main="", xlab="", ylab="", axes=FALSE, type="n");
        try(par(plt = OldPLT), silent=TRUE);
      }
    } else if (EvenXlims == TRUE) {
      ABounds = c(0,0);
      NNlength = rep(0, length(wanted));
      if (!exists("DoMu")) { DoMu = TRUE; }
      for (ii in 1:length(wanted)) {
        MySaveii = ii;
        HPDSet = NULL;
        eval(parse(text=SetGText("MySaveii", "globalenv()", S=1)));
        try(HPDSet <- this$RenameChain(
          MapChainNames = MapChainNames, UseMapChainNames1 = UseMapChainNames1,
          UseMapChainNamesHPD = UseMapChainNamesHPD, DoCentered=DoCentered,
          wanted = wanted[[ii]], DoStack = TRUE, DoMu=DoMu, DoTreat=DoTreat,
          NoJK = NoJK, NoSex=NoSex, DoRawAnyWay = DoRawAnyWay, DoBS=DoBS, ...), silent=TRUE);
        if (is.null(HPDSet)) {
          try(HPDSet <- this$RenameChain(
          MapChainNames = MapChainNames, UseMapChainNames1 = UseMapChainNames1,
          UseMapChainNamesHPD = UseMapChainNamesHPD, DoCentered=DoCentered,
          wanted = wanted[[ii]], DoStack = TRUE, DoMu=DoMu, DoTreat=DoTreat,
          NoJK = NoJK, NoSex=NoSex, DoRawAnyWay = DoRawAnyWay, DoBS=DoBS));
        }
        if (is.null(HPDSet)) {
          print(paste("EvenXLims == TRUE, we do not successfuly Rename HPDSet on ii = ", ii, sep=""));
          flush.console();
        }
        if (Verbose >= 2) {
          print(paste("Hey we read in HPDSet[ii=", ii, "] and colnames are ",
            paste(colnames(HPDSet), collapse=", "), sep="")); flush.console();
        }
        ColnamesHPDSet <- colnames(HPDSet);
        eval(parse(text=SetGText("ColnamesHPDSet", "globalenv()", S=1)));
        if (DoMu == FALSE) {
          try(HPDSet <- RemoveMu(HPDSet));
        }
        MyLD = HPDinterval(as.mcmc(HPDSet));
        ABounds[1] = min(c(ABounds[1], MyLD[,1]));
        ABounds[2] = max(c(ABounds[2], MyLD[,2]));
        NNlength[ii] = max(nchar(varnames(HPDSet)));
      }
      APretty <- pretty(ABounds);
      LimPretty <- c(min(APretty), max(APretty));
    
      if (is.null(plt.lefts) || length(plt.lefts) != length(wanted)) {
        if (is.null(HPDWidths) || length(HPDWidths) != length(wanted)) {
          HPDWidths <-  1 + NNlength /25;
        } else {
          HPDWidths <- HPDWidths + NNlength / 25;
        }
        plt.lefts = .12+NNlength / 25;
      } else {
        if (is.null(HPDWidths) || length(HPDWidths) != length(wanted)) {
          HPDWidths <-  1 + plt.lefts;
        } else {
          HPDWidths <- HPDWidths + plt.lefts;
        }
      }
      if (is.list(wanted)) {
        xlims = cbind(rep(LimPretty[1], length(wanted)), 
          rep(LimPretty[2], length(wanted)));
      } else {
        xlims <- LimPretty;
      }
      if (mainText != "") {
        if (DoEvensPlot == FALSE) {
          layout(cbind(c(1,1),rbind(rep(2, length(wanted)),
            2+(1:length(wanted)))), 
            widths=c(.1,HPDWidths), 
            heights = c(.1,1) ); 
        } else {
          ABadVec <-  as.vector(rbind(2+(1:length(wanted)-1)*3+2,
            2+(1:length(wanted)-1)*3+3));
          AWidth <- as.vector(rbind(plt.lefts,rep(1, length(plt.lefts))));
          layout(cbind(c(1,1,1),rbind(rep(2, 2*length(wanted)),
            rep(2+(1:length(wanted)-1)*3+1, each=2),
            ABadVec )), 
            widths=c(.1,AWidth), 
            heights = c(.1,.1, 1) );         
        }
        try(par(plt = c(0,1,0,1)), silent=TRUE);
        plot(c(0,1),c(0,1), main="", xlab="", ylab="", axes=FALSE, type="n");
        plot(c(0,1),c(0,1), xlim=c(0,1), ylim=c(0,1),
          main="", xlab="", ylab="", axes=FALSE, type="n");
        text(x=.5, y=.99, labels=mainText, pos=1, cex=2.5)    
        try(par(plt = OldPLT), silent=TRUE); 
      } else {
        if (DoEvensPlot == FALSE) {
        layout(matrix(1:(length(wanted)+1),1,1+length(wanted)), 
          widths=c(.1,HPDWidths), 
          heights = c(1) );
        } else {
          ABadVec <-  as.vector(rbind(1+(1:length(wanted)-1)*3+2,
            1+(1:length(wanted)-1)*3+3));
          AWidth <- as.vector(rbind(plt.lefts,rep(1, length(plt.lefts))));
          layout(cbind(c(1,1),  rbind(
            rep(1+(1:length(wanted)-1)*3+1, each=2),
            ABadVec)),
          widths=c(.1,AWidth), 
          heights = c(.1,1) );      
        }
        try(par(plt = c(0,1,0,1)), silent=TRUE);
        plot(c(0,1),c(0,1), main="", xlab="", ylab="", axes=FALSE, type="n");
        try(par(plt = OldPLT), silent=TRUE);
      }
    } else {
      xlims = NULL;
      if (is.null(plt.lefts) || length(plt.lefts) != length(wanted) ) {
        par(mfrow=c(1,length(wanted)));
        HPDWidths <- NULL;
      } else {       
        if (DoEvensPlot == FALSE) {
        HPDWidths <- 1 + plt.lefts;
        layout(matrix(1:(length(wanted)+1),1,1+length(wanted)), 
          widths=c(.1,HPDWidths), 
          heights = c(1) );
        } else {
          ABadVec <-  as.vector(rbind(1+(1:length(wanted)-1)*3+2,
            1+(1:length(wanted)-1)*3+3));
          AWidth <- as.vector(rbind(plt.lefts,rep(1, length(plt.lefts))));
          layout(cbind(c(1,1),  rbind(
            rep(1+(1:length(wanted)-1)*3+1, each=2),
            ABadVec)),
          widths=c(.1,AWidth), 
          heights = c(.1, 1) );      
        }
        try(par(plt = c(0,1,0,1)), silent=TRUE);
        plot(c(0,1),c(0,1), main="", xlab="", ylab="", axes=FALSE, type="n");
        try(par(plt = OldPLT), silent=TRUE);
      }
    }
    
   

    name.margin.back = name.margin;
    name.line.back = name.line;
 
    if (!exists("DoMu")  || is.null(DoMu)) { DoMu = TRUE; }
    if (AFD$Verbose >= 3) {
      if (!exists("DoStack")) { DoStack = FALSE; }
      if (!exists("DoTreat")) { DoTreat = FALSE; }
      if (!exists("pAddSpace")) { pAddSpace = FALSE; }
      try(print(paste("About to start plot with UseMapChainNames1 = ", UseMapChainNames1,
        ", DoMu = ", DoMu, ", NoSex = ", NoSex, ", DoEvensPlot = ", DoEvensPlot,
        ", DoCentered = ", DoCentered, ", DoStack = ", DoStack, ", DoTreat = ", DoTreat,
        ", AddSpace = ", pAddSpace, ", NoJK = ", NoJK, ", UseMapChainNamesHPD = ", UseMapChainNamesHPD,
        sep=""))); flush.console();
    }
    for (ii in 1:length(wanted)) {
      if (ii == 1) {
        pAddSpace = TRUE;
      } else {
        pAddSpace = FALSE;
      }
      MySaveii = ii;
      eval(parse(text=SetGText("MySaveii", "globalenv()", S=1)));
      HPDSet = NULL;
      try(HPDSet <- this$RenameChain(
        MapChainNames = MapChainNames, UseMapChainNames1 = UseMapChainNames1,
        UseMapChainNamesHPD = UseMapChainNamesHPD, DoCentered=DoCentered,
        wanted = wanted[[ii]], DoStack = FALSE, DoMu=DoMu, DoTreat=DoTreat, 
        NoJK = NoJK, AddSpace = pAddSpace, NoSex=NoSex, DoRawAnyWay = DoRawAnyWay, 
        DoBS=DoBS, ...),
          silent=TRUE);
      if (is.null(HPDSet)) {
        try(HPDSet <- this$RenameChain(
        MapChainNames = MapChainNames, UseMapChainNames1 = UseMapChainNames1,
        UseMapChainNamesHPD = UseMapChainNamesHPD, DoCentered=DoCentered,
        wanted = wanted[[ii]], DoStack = FALSE, DoMu=DoMu, DoTreat=DoTreat, 
        NoJK = NoJK, AddSpace = pAddSpace, NoSex=NoSex, DoRawAnyWay = DoRawAnyWay,
        DoBS=DoBS));      
      }
      if (Verbose >= 2) {
          print(paste("Hey During Finally plot in HPDSet[ii=", ii, "] and colnames are ",
            paste(colnames(HPDSet), collapse=", "), sep="")); flush.console();
        }
      ColnamesHPDSet <- colnames(HPDSet);
      eval(parse(text=SetGText("ColnamesHPDSet", "globalenv()", S=1)));
      if (is.null(name.margin.back)) {
        name.margin = 6.1;
        MxC = max(nchar(varnames(HPDSet)));
        if (MxC /2.5 > 6.1) { name.margin = MxC / 2.5+1; }
        name.line = name.margin - .8;
      } 
      if (is.null(name.line.back)) { name.line = name.margin-.8; } 
      if (DoMu == FALSE) {
        try(HPDSet <- RemoveMu(HPDSet));
      }
      if (!is.null(plt.lefts) && length(plt.lefts) == length(wanted)) {
        plt.left = plt.lefts[ii];
      }
      if (ii == 1  && !is.null(plt.left)) {
        Aplt.left = plt.left
      } else {
        Aplt.left = plt.left;
      }
      if (DoEvensPlot == FALSE) {
       if (DoElipsis == TRUE) {
        plot.hpd(coda.object = HPDSet, prob.wide=prob.wide,
         prob.narrow = prob.narrow, ylab=ylab, xlim=xlims,
         name.margin = name.margin, plt.left=Aplt.left, plt.title=plt.title,
         plt.right=plt.right,plt.bottom=plt.bottom,
         name.line= name.line, bottom.margin=bottom.margin,
         bottom.line=bottom.line, right.margin=right.margin,
         right.line=right.line, title.margin=title.margin,
         title.line=title.line,...);
       } else {
        plot.hpd(coda.object = HPDSet, prob.wide=prob.wide,
         prob.narrow = prob.narrow, ylab=ylab, xlim=xlims,
         name.margin = name.margin, plt.left=Aplt.left, plt.title=plt.title,
         plt.right=plt.right,plt.bottom=plt.bottom,
         name.line= name.line, bottom.margin=bottom.margin,
         bottom.line=bottom.line, right.margin=right.margin,
         right.line=right.line, title.margin=title.margin,
         title.line=title.line);
        }
      } else {
        WantName <- WantedColumnNames[ii];
        if (!exists("cex.columnnames") || is.null(cex.columnnames) || !is.numeric(cex.columnnames) ) { cex.columnnames = 2.0; }
        par(plt = c(0,1,0,1)); 
        plot(x=c(0,1),y=c(0,1), type="n", axes=FALSE, xlim=c(0,1),ylim=c(0,1));
        text(x=.5,y=.99, label=WantName, pos = 1, cex=cex.columnnames, font=2)
        if (is.list(HPDSet)) {
          ABT <- colnames(HPDSet[[1]]);
          NewS <- list();
          for (jtj in 1:length(HPDSet)) {
            AS <- matrix(as.numeric(HPDSet[[jtj]]), NROW(HPDSet[[jtj]]), NCOL(HPDSet[[jtj]]));
            colnames(AS) <- rep("", NCOL(AS));
            AS <- as.mcmc(AS);
            NewS[[jtj]] <- AS;
          }
          try(NewS <- as.mcmc.list(NewS));
        } else {
          ABT <- colnames(HPDSet);
          NewS <- matrix(as.numeric(HPDSet), NROW(HPDSet), NCOL(HPDSet));
          colnames(NewS) <- rep("", NCOL(NewS));
          NewS <- as.mcmc(NewS);
        }
        if (is.null(plt.title)) { plt.title = .96; }
        if (is.null(plt.bottom)) { plt.bottom = .15; }
        title.margin=4.1* (1.0-plt.title) / .12; 
        mar.update <- sides() 
        bottom.margin=5.1* plt.bottom / .16;  
        name.margin=0;  right.margin = 0;
        mar <- c(bottom.margin+.1, name.margin, title.margin+.1, right.margin);
        mar=update.sides(mar, mar.update)
        oldmar <- par(mar=mar); on.exit(par(mar=oldmar))
        plot(x=c(0,1), y=c(0,1), ylim=c(0, length(ABT)), xlim=c(0,1),  type="n", axes=FALSE, 
          main="", xlab="", ylab="");
        if (!exists("cex.rownames")) { cex.rownames = 1; }
        text(x=rep(.99, length(ABT)), y=length(ABT):1-.5,
          label=ABT, cex=cex.rownames, pos=2); 
        if(exists("DoElipsis") && DoElipsis==TRUE) {
          plot.hpd(coda.object = NewS, prob.wide=prob.wide,
           prob.narrow = prob.narrow, ylab=ylab, xlim=xlims[ii,],
           name.margin = name.margin, plt.left=0, plt.title=plt.title,
           plt.right=plt.right,plt.bottom=plt.bottom,
           name.line= name.line, bottom.margin=bottom.margin,
           bottom.line=bottom.line, right.margin=right.margin,
           right.line=right.line, title.margin=title.margin,
           title.line=title.line, wanted=1:length(ABT),...);
        } else {
          try(plot.hpd(coda.object = NewS, prob.wide=prob.wide,
           prob.narrow = prob.narrow, ylab=ylab, xlim=xlims[ii,],
           name.margin = name.margin, plt.left=0, plt.title=plt.title,
           plt.right=plt.right,plt.bottom=plt.bottom,
           name.line= name.line, bottom.margin=bottom.margin,
           bottom.line=bottom.line, right.margin=right.margin,
           right.line=right.line, title.margin=title.margin,
           title.line=title.line, wanted=1:length(ABT)));        
        }
      }
      if (UseABLine == TRUE) {
         abline(v=0, col="gray80");
      }
    }
    return(1);
  
  }
  if (exists("DoTreat") && is.logical(DoTreat) && DoTreat == TRUE) {
    DoMu = TRUE;
  }
  if (!exists("DoMu")) { DoMu = TRUE; }
    if (DoElipsis == TRUE) {
     HPDSet <- this$RenameChain(
      MapChainNames = MapChainNames, UseMapChainNames1 = UseMapChainNames1,
      UseMapChainNamesHPD = UseMapChainNamesHPD, DoCentered=DoCentered,
      wanted = wanted, DoStack = FALSE, DoMu=DoMu, DoTreat=DoTreat, 
      NoJK = NoJK, NoSex=NoSex, DoRawAnyWay = DoRawAnyWay,DoBS=DoBS,...)
    } else {
     HPDSet <- this$RenameChain(
      MapChainNames = MapChainNames, UseMapChainNames1 = UseMapChainNames1,
      UseMapChainNamesHPD = UseMapChainNamesHPD, DoCentered=DoCentered,
      wanted = wanted, DoStack = FALSE, DoMu=DoMu, DoTreat=DoTreat, 
      NoJK = NoJK, NoSex=NoSex, DoRawAnyWay = DoRawAnyWay,DoBS=DoBS)    
    }
    if (is.null(name.margin)) {
     name.margin = 6.1;
      MxC = max(nchar(varnames(HPDSet)));
      if (MxC /4 > 6.1) { name.margin = MxC / 4+1; }
      name.line= name.margin-1;
    }
    if (is.null(name.line)) { name.line = name.margin-1; }
    if (DoMu == FALSE) {
      try(HPDSet <- RemoveMu(HPDSet));  
    }
  plot.hpd(coda.object = HPDSet, prob.wide=prob.wide,
      prob.narrow = prob.narrow, ylab=ylab, plt.left=plt.left, plt.title=plt.title,
       plt.right=plt.right,plt.bottom=plt.bottom,
       name.margin=name.margin,
       name.line = name.line, bottom.margin=bottom.margin,
       bottom.line=bottom.line, right.margin=right.margin,
       right.line=right.line, title.margin=title.margin,
       title.line=title.line,main=mainText,...);
  if (UseABLine == TRUE) {
    abline(v=0, col="gray80");
  }
  return(1);
});