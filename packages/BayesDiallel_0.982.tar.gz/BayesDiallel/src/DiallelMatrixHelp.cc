
#ifndef DIALLELEH
  #include "DialleleMatrixHelp.h"
  #define DIALLELEH 0
#endif


int RecalculateUnweightedXtXandXtY(SEXP sY, SEXP sX, SEXP sXtX, SEXP sXtY,
  SEXP sSumYSq) {
   int nY = Rf_length(sY); int One = 1;
   REAL(sSumYSq)[0] = F77_CALL(ddot)(&nY, REAL(sY), &One, REAL(sY), &One);
   return(1);
}
/////////////////////////////////////////////////////////////////////////////
//  CalculateWeightedXtXandXtY
//
//  Given a new series of weights in sW, vector sY, and matrix sW
//   we need to reweight sXtWY and sXtWX
//  This uses efficient BLAS functions, noting that sXtWX will be symmetric
int CalculateWeightedXtXandXtY(SEXP sY, SEXP sX, SEXP sW, SEXP sfW, 
       SEXP sXtWY, SEXP sXtWX, SEXP sSumYSq) {
   //Rprintf("Re Calculating Weights of XtX and XtY"); R_FlushConsole();
   int ii;
   int nY = length(sY);
   int One = 1; double OneD = 1.0; double ZeroD = 0.0;
   
   //char MyUpperLo = UpLo;
   char PleaseT = 'T';
   if (length(sfW) < nY) {
     Rprintf("Error, fW is not large enough to do weighting work\n");
     R_FlushConsole();
   }

   for (ii = 0; ii < nY; ii++) {
     REAL(sfW)[ii] = REAL(sY)[ii] * REAL(sW)[ii]; 
   }
   //REAL(sSumYSq)[0] = 0;
   //for (ii = 0; ii < nY; ii++) {
   //  REAL(sSumYSq)[0] += REAL(sY)[ii] * REAL(sY)[ii] * REAL(sW)[ii];
   //}
   REAL(sSumYSq)[0] = F77_CALL(ddot)(&nY, REAL(sfW), &One, REAL(sY), &One);
   
   SEXP sdimX = GET_DIM(sX);
   int lengthn = INTEGER(sdimX)[0]; int lBeta = INTEGER(sdimX)[1];
   
   //int NBeta = INTEGER(sdimX)[1];
   F77_CALL(dgemv)(&PleaseT,  &lengthn, &lBeta, &OneD,
	        REAL(sX), &lengthn ,
		REAL(sfW), &One, &ZeroD ,
		REAL(sXtWY), &One);
	
   int wjj; int onxjj = 0; //int jStart;
   int lNeedBeta = lBeta;
   for (wjj = 0; wjj < lBeta; wjj++) {
     for (ii =0; ii < lengthn; ii++) {
        REAL(sfW)[ii] = REAL(sX)[onxjj + ii] * REAL(sW)[ii];
     }	
     //Rprintf("REAL(sfW)[%d] = %f, REAL(sX)[%d] = %f, REAL(sW)[%d] = %f \n ",
     //  0, REAL(sfW)[0], onxjj, REAL(sX)[onxjj], 0, REAL(sW)[0]);
     OneD = 1.0;
     F77_CALL(dgemv)(&PleaseT, &lengthn, &lNeedBeta, &OneD,
		   REAL(sX) + (int) onxjj, &lengthn, REAL(sfW), &One, &ZeroD,
		   REAL(sXtWX) + wjj * lBeta + wjj, &One);
		 //Rprintf("AfterMultiplier, sXtWX[%d,%d] = %f\n",
     //  wjj, wjj, REAL(sXtWX)[wjj * lBeta + wjj]); R_FlushConsole();
     lNeedBeta--;
     if (lNeedBeta > 0) {
       F77_CALL(dcopy)(&lNeedBeta, REAL(sXtWX) + lBeta * wjj + wjj+ 1, &One,
         REAL(sXtWX) + (lBeta) * (wjj+1) + wjj, &lBeta);
     }
     onxjj +=lengthn;
     //Rprintf("Finished doing wjj = %d, lengthn =%d, ii =%d, lNeedBeta = %d, lBeta = %d\n",
     //   wjj, lengthn, ii, lNeedBeta, lBeta); R_FlushConsole();
   }
   
   //error("We calculated Weights, let's see what you say!");
   return(1);      
}

int CalculateCholAndInverse(SEXP sQ, SEXP sOutiChol, SEXP sI) {
  int AllLen = length(sQ);
  int One = 1;
  F77_CALL(dcopy)(&AllLen, REAL(sQ), &One, REAL(sOutiChol), &One);
  int nBeta = INTEGER(GET_DIM(sQ))[0];
  int Info1 = 0; int Info2 = 0; int Info3 = 0;
  char MyUpperLo = UpLo;
  
  int nBetaSq = nBeta * nBeta;
  if (length(sI) != nBetaSq) {
    error("sI is not long enough (%d,%d) to nBeta = %d\n",
     INTEGER(GET_DIM(sI))[0], INTEGER(GET_DIM(sI))[1], nBeta);
  }
  if (length(sOutiChol) != nBetaSq) {
    error("sOutiChol is not long enough (%d,%d) to nBeta = %d\n",
     INTEGER(GET_DIM(sOutiChol))[0], INTEGER(GET_DIM(sOutiChol))[1], nBeta);
  }  

  
  F77_NAME(dpotf2)(&MyUpperLo, &nBeta, REAL(sOutiChol), &nBeta, &Info1);
  
  if (Info1 > 0) {
    Rprintf("Do you want to know, we have an inverse fail!\n"); R_FlushConsole();
    return(Info1);
  } 
	F77_CALL(dcopy)(&AllLen, REAL(sOutiChol), &One, REAL(sI), &One);
  
  char TheN = 'N';
  
	F77_CALL(dtrtri)(&MyUpperLo, &TheN, &nBeta, REAL(sOutiChol), &nBeta, &Info2);
	F77_CALL(dpotri)(&MyUpperLo, &nBeta, REAL(sI), &nBeta, &Info3);


  return(Info3);
  
	  // dpotrf Cholesky of a positivie definite matrix
 // dtrtri inverse of triangular matrix (inverse of Chol);
 // Create an inverse
}


int CalculateCholAndInverse(SEXP sQ, SEXP sOutiChol, SEXP sI, SEXP sUseBeta,
  SEXP sStartBeta) {

  int LDA = 0;  INTEGER(GET_DIM(sOutiChol))[0];
  int nBeta = 0;
  if (Rf_isInteger(sUseBeta)) { nBeta = INTEGER(sUseBeta)[0];} else {
    nBeta = (int) REAL(sUseBeta)[0];
  }
  int StartBeta = 0;
  if (Rf_isInteger(sStartBeta)) { StartBeta = INTEGER(sStartBeta)[0];} else {
    StartBeta = (int) REAL(sStartBeta)[0];
  }
  int One = 1;
  for (int ii = 0; ii < nBeta; ii++) {
    F77_CALL(dcopy)(&nBeta, REAL(sQ) +
      (StartBeta + ii) * INTEGER(GET_DIM(sQ))[0] + StartBeta, &One,
      REAL(sOutiChol) + ii * INTEGER(GET_DIM(sOutiChol))[0], &One);
  }
  
  int Info1 = 0; int Info2 = 0; int Info3 = 0;
  char MyUpperLo = UpLo;
  
  int nBetaSq = nBeta * nBeta;
  if (length(sI) != nBetaSq) {
    error("sI is not long enough (%d,%d) to nBeta = %d\n",
     INTEGER(GET_DIM(sI))[0], INTEGER(GET_DIM(sI))[1], nBeta);
  }
  if (length(sOutiChol) != nBetaSq) {
    error("sOutiChol is not long enough (%d,%d) to nBeta = %d\n",
     INTEGER(GET_DIM(sOutiChol))[0], INTEGER(GET_DIM(sOutiChol))[1], nBeta);
  }  

  
  F77_NAME(dpotf2)(&MyUpperLo, &nBeta, REAL(sOutiChol), &LDA, &Info1);
  
  if (Info1 > 0) {
    Rprintf("Do you want to know, we have an inverse fail!\n"); R_FlushConsole();
    return(Info1);
  }
  for (int ii = 0; ii < nBeta; ii++) {
    F77_CALL(dcopy)(&nBeta, REAL(sOutiChol) + INTEGER(GET_DIM(sOutiChol))[0] * ii,
      &One, REAL(sI) + INTEGER(GET_DIM(sI))[0] * ii, &One);
  }
  
  char TheN = 'N';
  
  F77_CALL(dtrtri)(&MyUpperLo, &TheN, &nBeta, REAL(sOutiChol), &LDA, &Info2);
  LDA = INTEGER(GET_DIM(sI))[0];
  F77_CALL(dpotri)(&MyUpperLo, &nBeta, REAL(sI), &LDA, &Info3);


  return(Info3);
  
	  // dpotrf Cholesky of a positivie definite matrix
 // dtrtri inverse of triangular matrix (inverse of Chol);
 // Create an inverse
}

int DrawABayesRegression(SEXP sQ, SEXP sXtY, SEXP sSigmaSq,
//  SEXP sOutiChol, SEXP sI, SEXP sGiveBeta, int iIter, SEXP sTestDraws) {
    SEXP sOutiChol, SEXP sI, SEXP sGiveBeta) {
  int iSig = CalculateCholAndInverse(sQ, sOutiChol, sI);
  int ii,jj;
  int nBeta = INTEGER(GET_DIM(sQ))[0];
  if (length(sGiveBeta) != nBeta) {
    error("DrawABayesRegression, length nBeta is %d is Wrong!\n",
      length(sGiveBeta));
  }
  if (length(sXtY) != nBeta) {
    error("DrawABayesRegression: sXtY is not right Length = %d!\n",
      length(sXtY));
  }
  double sqrtSigma = sqrt(REAL(sSigmaSq)[0]);
  //sqrtSigma = 0.0;
  if (iSig != 0) {
    jj = 0;
    int nBetaSq = nBeta * nBeta;
    for (ii = 0; ii < nBeta; ii++) {
      if (jj >= nBetaSq)  {
        error("jj Got to Large Doh!!\n");
      } 
      REAL(sGiveBeta)[ii] = (1.0/REAL(sQ)[jj]) * REAL(sXtY)[ii] + 
                            sqrtSigma * sqrt( 1.0 / REAL(sQ)[jj]) * rnorm(0,1);
      jj += nBeta + 1;                    
      if (ii >= length(sXtY) || ii  >= length(sGiveBeta)) {
        error("ii %d, Give Beta %d or sXtY=%d are too short", 
           ii, length(sXtY), length(sGiveBeta));
      }
    }
    //error("We're going to quit on an Inverse Fail here\n");
    return(-1);
  }
  char MyUpperLo = 'L';
  // Note That If XtX = L L^{T} for L lower triangular then
  //   (XtX)^(-1) = (L^{T})^{-1} L^{-1}
  //
  //  Hence we really want to multiply (L^{T})^{-1} By the normal vector
  char DoIWantTransBasedUponMyUpperLo = 'T';
  char TheN = 'N';
  
  
  int One = 1; nBeta = length(sGiveBeta);
  double OneD = 1.0;
  for (ii = 0; ii < nBeta; ii++) { REAL(sGiveBeta)[ii] = rnorm(0,1); }
  //if (iIter >= 0 &&
  //  !isNull(sTestDraws) &&
  //  !isNull(GET_DIM(sTestDraws)) &&
  //  INTEGER(GET_DIM(sTestDraws))[0] > iIter &&
  //  INTEGER(GET_DIM(sTestDraws))[1] == length(sGiveBeta)) {
  //  F77_CALL(dcopy)(&nBeta, REAL(sGiveBeta), &One, REAL(sTestDraws) + iIter,
  //   INTEGER(GET_DIM(sTestDraws)));
  //}
  //F77_CALL(dscal)(&nBeta, &sqrtSigma, REAL(sGiveBeta), &One);
  F77_CALL(dtrmv)(&MyUpperLo, &DoIWantTransBasedUponMyUpperLo, &TheN, 
    &nBeta, REAL(sOutiChol), &nBeta, REAL(sGiveBeta), &One);
  

   
  //double ZeroD = 0.0;
  F77_CALL(dsymv)(&MyUpperLo, &nBeta, &OneD,
  		REAL(sI), &nBeta,
  		REAL(sXtY), &One,
                &sqrtSigma, REAL(sGiveBeta), &One);

  //error("Check Out after the Fill in?");
    
  return(1);
}


int DrawABayesRegression(SEXP sXtX, SEXP sQ, SEXP sXtY, SEXP sSigmaSq,
//  SEXP sOutiChol, SEXP sI, SEXP sGiveBeta, int iIter, SEXP sTestDraws) {
    SEXP sXtResid, SEXP sMiniOutiChol, SEXP sMiniI, SEXP sGiveBeta,
    SEXP sUseBeta, SEXP sStartBeta) {
  
  int StartBeta = 0;  int UseBeta = 0;
  while( StartBeta < Rf_length(sXtY)) {
  UseBeta = Rf_length(sXtResid);
  if (INTEGER(GET_DIM(sMiniOutiChol))[0] < UseBeta) {
    Rf_error("DrawABayesRegression: Error for large data, sMiniOutiChol only dim %d, %d, sXtResid length = %d",
      INTEGER(GET_DIM(sMiniOutiChol))[0],INTEGER(GET_DIM(sMiniOutiChol))[1],
      Rf_length(sXtResid));
  }
  if (INTEGER(GET_DIM(sMiniI))[0] < UseBeta) {
    Rf_error("DrawABayesRegression: Error for large data, sMiniI only dim %d, %d, sXtResid length = %d",
      INTEGER(GET_DIM(sMiniI))[0],INTEGER(GET_DIM(sMiniI))[1],
      Rf_length(sXtResid));
  }
  if (Rf_isInteger(sStartBeta)) {
    INTEGER(sStartBeta)[0] = StartBeta;
  } else { REAL(sStartBeta)[0] = StartBeta; }
  if (Rf_length(sXtY) <= StartBeta + UseBeta) {
    UseBeta = Rf_length(sXtY) - StartBeta;
  }
  if (Rf_isInteger(sUseBeta)) { INTEGER(sUseBeta)[0] = UseBeta;
  } else {REAL(sUseBeta)[0] = UseBeta; }
  
  
  int iSig = CalculateCholAndInverse(sQ, sMiniOutiChol, sMiniI, sUseBeta, sStartBeta);
  int ii,jj;
  int nBeta = INTEGER(GET_DIM(sQ))[0];
  if (length(sGiveBeta) != nBeta) {
    error("DrawABayesRegression, length nBeta is %d is Wrong!\n",
      length(sGiveBeta));
  }
  if (length(sXtY) != nBeta) {
    error("DrawABayesRegression: sXtY is not right Length = %d!\n",
      length(sXtY));
  }
  double sqrtSigma = sqrt(REAL(sSigmaSq)[0]);
  
  int One = 1; F77_CALL(dcopy)(&UseBeta, REAL(sXtY) + StartBeta, &One, REAL(sXtResid), &One);
  double ZeroD = 0.0; double NegOneD = -1.0; double OneD = 1.0;
  F77_CALL(dscal)(&UseBeta, &ZeroD, REAL(sGiveBeta) + StartBeta, &One);
  char Trans =  'N'; int M = INTEGER(GET_DIM(sXtX))[0];
  F77_CALL(dgemv)(&Trans, &UseBeta, &M, &NegOneD, 
    REAL(sXtX) + StartBeta, &M, REAL(sGiveBeta), &One, &OneD, REAL(sXtResid), &One);
  //DGEMV(TRANS,M,N,ALPHA,A,LDA,X,INCX,BETA,Y,INCY)
  
  //sqrtSigma = 0.0;
  if (iSig != 0) {
    jj = 0;
    int nBetaSq = nBeta * nBeta;
    for (ii = 0; ii < nBeta; ii++) {
      if (jj >= nBetaSq)  {
        error("jj Got to Large Doh!!\n");
      } 
      REAL(sGiveBeta)[ii] = (1.0/REAL(sQ)[jj]) * REAL(sXtY)[ii] + 
                            sqrtSigma * sqrt( 1.0 / REAL(sQ)[jj]) * rnorm(0,1);
      jj += nBeta + 1;                    
      if (ii >= length(sXtY) || ii  >= length(sGiveBeta)) {
        error("ii %d, Give Beta %d or sXtY=%d are too short", 
           ii, length(sXtY), length(sGiveBeta));
      }
    }
    //error("We're going to quit on an Inverse Fail here\n");
    return(-1);
  }
  char MyUpperLo = 'L';
  // Note That If XtX = L L^{T} for L lower triangular then
  //   (XtX)^(-1) = (L^{T})^{-1} L^{-1}
  //
  //  Hence we really want to multiply (L^{T})^{-1} By the normal vector
  char DoIWantTransBasedUponMyUpperLo = 'T';
  char TheN = 'N';
  
  
  nBeta = length(sGiveBeta);

  for (ii = StartBeta; ii < StartBeta + UseBeta; ii++) { REAL(sGiveBeta)[ii] = rnorm(0,1); }
  //if (iIter >= 0 &&
  //  !isNull(sTestDraws) &&
  //  !isNull(GET_DIM(sTestDraws)) &&
  //  INTEGER(GET_DIM(sTestDraws))[0] > iIter &&
  //  INTEGER(GET_DIM(sTestDraws))[1] == length(sGiveBeta)) {
  //  F77_CALL(dcopy)(&nBeta, REAL(sGiveBeta), &One, REAL(sTestDraws) + iIter,
  //   INTEGER(GET_DIM(sTestDraws)));
  //}
  //F77_CALL(dscal)(&nBeta, &sqrtSigma, REAL(sGiveBeta), &One);
  int LDA = INTEGER(GET_DIM(sMiniOutiChol))[0];
  F77_CALL(dtrmv)(&MyUpperLo, &DoIWantTransBasedUponMyUpperLo, &TheN, 
    &UseBeta, REAL(sMiniOutiChol), &LDA, REAL(sGiveBeta) + StartBeta, &One);
  
  LDA = INTEGER(GET_DIM(sMiniI))[0];
   
  //double ZeroD = 0.0;
  F77_CALL(dsymv)(&MyUpperLo, &UseBeta, &OneD,
  		REAL(sMiniI), &LDA,
  		REAL(sXtResid), &One,
                &sqrtSigma, REAL(sGiveBeta), &One);

  //error("Check Out after the Fill in?");
    StartBeta = StartBeta + UseBeta;
  }  
  return(1);
}




void PrintVector(int *Vec, int Len) {
	 const int MaxVec = 10;
	 int LLen = Len;
	 if (Len > MaxVec) {
		   LLen = MaxVec;
     }
     Rprintf("c( ");
     int ii; 
     for (ii = 0; ii < LLen-1; ii++) {
	     Rprintf(" %d,", (int) Vec[ii]);
     }
     if (LLen < Len) {
	     Rprintf(" %d, ... )\n", (int) Vec[ii]);
     } else {
	     Rprintf(" %d)", (int) Vec[ii]);
     }
     R_FlushConsole();
     return;
}

void PrintRMatrix(double *Mat, int NR, int NC) {
	const int maxNR = 8;
	const int maxNC = 8;
	const int MorePrintC = 5;
	int NRR, NCC;
	if (NR > maxNR) {
		 NRR = maxNR;
    } else {
	     NRR = NR;
    }
    if (NC > maxNC) {
		 NCC = maxNC;
    } else {
	     NCC = NC;
    } 
	int ii, jj, ptot;
	if (PRMATRIX == 1) {
	Rprintf( (char *) "        ");
	for (jj = 0; jj < NCC; jj++) {
		Rprintf( (char *) "  %d   ", jj);
    }
    Rprintf( (char *) "\n");
	Rprintf( (char *) "        ");
	for (jj = 0; jj < NCC; jj++) {
		Rprintf( (char *) "-------", jj);
    }
    Rprintf( (char *) "\n");
    R_FlushConsole();    
     
	for (ii = 0; ii < NRR; ii++) {
		ptot = ii;
		Rprintf( (char *) "Row %d:[ ", ii);
		for (jj = 0; jj < NCC;jj++) {
			if ( fabs((double) Mat[ptot]) > .001) {
			  Rprintf( (char *) " %.3f", (double) Mat[ptot]);
		    } else {
			  Rprintf( (char *) " %.4e", (double) Mat[ptot]);
		    }
			R_FlushConsole();
			ptot += NR;
        }
        Rprintf( (char *) "\n");
        R_FlushConsole();
        R_ProcessEvents();
    }
    Rprintf( (char *) "\n");
    }
    //R_FlushConsole();
    //Rprintf( (char *) "\n");
    R_FlushConsole();
    if ( NC <= NCC && NR <= NRR) {
	    //Rprintf((char*)"  <- rbind( \n");
	    Rprintf((char*)"  rbind( \n");
	    for (ii = 0; ii < NRR; ii++) {
		    Rprintf("c( ");
		    for (jj = 0; jj < NCC-1; jj++) {
				if (NCC <= MorePrintC) {
					if ( fabs((double) Mat[jj * NR + ii]) > .001) {
					  Rprintf( (char *) " %.9f,", (double) Mat[jj * NR + ii]);
				    } else {
					  Rprintf( (char *) " %.9e,", (double) Mat[jj * NR + ii]);
				    }			    
	            } else {
					if ( fabs((double) Mat[jj * NR + ii]) > .001) {
					  Rprintf( (char *) " %.3f,", (double) Mat[jj * NR + ii]);
				    } else {
					  Rprintf( (char *) " %.4e,", (double) Mat[jj * NR + ii]);
				    }		            
	            }
		    }
            if (NCC <= MorePrintC) {		    
				if ( fabs((double) Mat[(NCC-1) * NR + ii]) > .001) {
				  Rprintf( (char *) " %.9f )", (double) Mat[(NCC-1) * NR + ii]);
			    } else {
				  Rprintf( (char *) " %.9e )", (double) Mat[(NCC-1) * NR + ii]);
			    }	
		    } else {
				if ( fabs((double) Mat[(NCC-1) * NR + ii]) > .001) {
				  Rprintf( (char *) " %.3f )", (double) Mat[(NCC-1) * NR + ii]);
			    } else {
				  Rprintf( (char *) " %.4e)", (double) Mat[(NCC-1) * NR + ii]);
			    }				   
		    } 	    
			if (ii < NRR-1) {
				Rprintf(",");
	        } else {
		        Rprintf( " ) \n");
	        } 
	        Rprintf("\n");
	        R_FlushConsole();
       }
   }  else {
	    //Rprintf((char*)"  <- rbind( \n");
	    Rprintf((char*)"  rbind( \n");
	    for (ii = 0; ii < NRR; ii++) {
		    Rprintf("c( ");
		    for (jj = 0; jj < NCC-1; jj++) {
				if (NCC <= MorePrintC) {
					if ( fabs((double) Mat[jj * NR + ii]) > .001) {
					  Rprintf( (char *) " %.9f,", (double) Mat[jj * NR + ii]);
				    } else {
					  Rprintf( (char *) " %.9e,", (double) Mat[jj * NR + ii]);
				    }			    
	            } else {
					if ( fabs((double) Mat[jj * NR + ii]) > .001) {
					  Rprintf( (char *) " %.3f,", (double) Mat[jj * NR + ii]);
				    } else {
					  Rprintf( (char *) " %.4e,", (double) Mat[jj * NR + ii]);
				    }		            
	            }
		    }
            if (NCC <= MorePrintC) {		    
				if ( fabs((double) Mat[(NCC-1) * NR + ii]) > .001) {
				  Rprintf( (char *) " %.9f )", (double) Mat[(NCC-1) * NR + ii]);
			    } else {
				  Rprintf( (char *) " %.9e )", (double) Mat[(NCC-1) * NR + ii]);
			    }	
		    } else {
				if ( fabs((double) Mat[(NCC-1) * NR + ii]) > .001) {
				  Rprintf( (char *) " %.3f )", (double) Mat[(NCC-1) * NR + ii]);
			    } else {
				  Rprintf( (char *) " %.4e)", (double) Mat[(NCC-1) * NR + ii]);
			    }				   
		    } 	    
			if (ii < NRR-1) {
				Rprintf(",");
	        } else {
		        Rprintf( " ) \n");
	        } 
	        Rprintf("\n");
	        R_FlushConsole();
       }
   }     
    return;
}
