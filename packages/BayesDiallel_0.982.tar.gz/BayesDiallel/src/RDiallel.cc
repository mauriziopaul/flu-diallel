/*
 *  RDiallel.cc
 *  
 *
 *  Created by Alan Lenarcic on 10/12/10.
 *  Copyright 2010 Valdar Lab. All rights reserved.
 *
 */
 
#ifndef RNeeds 
 #include <R.h>
 #include <Rmath.h>
 #include <Rinternals.h>
 #include <R_ext/BLAS.h>
 #include <R_ext/Lapack.h>
 #include <Rdefines.h>
 #define RNeeds 0
#endif 
 #include "DialleleMatrixHelp.h"
 #include "TruncNorm.h"
 
 // Get an Integer out of an Integer SEXP
 #define ANINT(RR, ii) Rf_isInteger((RR)) ? INTEGER((RR))[(ii)] : (int)REAL((RR))[(ii)]
 
 #define GetLenX(sDp, x) ((sDp)->LengthOftauX[(x)])
 #define GetListX(sDp,x) ((sDp)->AllListOfXs + sDp->WhereIstauX[(x)])
 #ifndef GetFirstInteger
 #define GetFirstInteger(sInt)  isInteger(sInt) ? INTEGER(sInt)[0] : (int) REAL(sInt)[0]
 #endif
 #define Sq(Mynum)  (Mynum) * (Mynum)
 
 typedef struct StructDpBeta_t {
   int TotLen;
   int nBeta;
   int ntau;
    unsigned short int *WhereIstauX;
    unsigned short int *LengthOftauX;
    unsigned short int *AllListOfXs;
 } StructDpBeta;
  
 StructDpBeta * MakeStructDpBeta(SEXP sDpBeta);
 void deleteStDpBeta(StructDpBeta *StDpBeta);
 
 
 
 int SampleTau(SEXP OnBeta, SEXP stau, SEXP sTauFixed, StructDpBeta *StDpBeta, 
               SEXP mtau, SEXP dftau, SEXP OldBeta, SEXP Convergence);
 int UpdateSigma(SEXP sSigma, SEXP sY, SEXP sBeta, SEXP sXtX, SEXP sXtY, 
                 SEXP sfW, SEXP sSumYSq,
                 SEXP smSigma, SEXP sdfSigma, SEXP sLikelihood, SEXP OldBeta,
                 SEXP Convergence);
 int FillsQ(SEXP sQ, SEXP sXtX, int IfWeight, int IfImputeG, SEXP sMyWantDiag, SEXP sSigmaSq);
 int FillMyWantDiag(SEXP sMyWantDiag, SEXP stau, SEXP sTauFixed,
                    int CrossModel, int BetaHybridLevel, SEXP stauCrosses,
                    StructDpBeta *StDpBeta, SEXP sQ) ;
 int FillCrossWantDiag(int numj, int CrossLevel, int BetaHybridLevel, SEXP stau,
   SEXP stauCrossStarts, SEXP sAsymNotASym,
   SEXP stauCrosses, SEXP sjCrosses, SEXP sjCrossesO, SEXP skCrosses, SEXP skCrossesO);
 int UpdateTNoise(SEXP sSigma, SEXP sBeta, SEXP sX, SEXP sY, SEXP sXtX, SEXP sXtY,
   SEXP sSumYSq,
   SEXP sfW, SEXP sVecOWeights, double dfTNoise, SEXP sLikelihood,
   SEXP sMeanWeights, SEXP OldBeta, SEXP Convergence);  
 int  TestAlgorithmInputs(SEXP snumj, SEXP sX, SEXP sY, SEXP sXtX, SEXP sXtY,
   SEXP sSumYSq, SEXP sBeta, SEXP stau, SEXP sSigmaSq, SEXP sLikelihood,
   SEXP sCodaChain,
   SEXP sChainLikelihood,
   SEXP sQ, SEXP sInvQ, SEXP sInvSqQ,
   SEXP sDpBeta, SEXP sTauFixed, SEXP dftau, SEXP mtau,
   SEXP smSigma, SEXP sdfSigma,
   SEXP sMyWantDiag,
   SEXP sCrossModel, SEXP sBetaHybridLevel,
   SEXP stauCrosses, SEXP sAsymNotASym,
   SEXP jCross, SEXP kCross, SEXP jCrossO, SEXP kCrossO,
   SEXP sVecOWeights, SEXP sfW, SEXP sdfTNoise, 
   SEXP stauHybridNoise, SEXP stoggleHybrid, SEXP sSigmaDeltaHybrid,
   SEXP sVerbose, SEXP sMeanWeights, SEXP sAllWeights, SEXP sCheckNANINF,
   SEXP sStartIter,  SEXP sInformEvery,
   SEXP ListUnknownGender, SEXP GXX, 
   SEXP ImputedGender, SEXP PriorGender,
   SEXP ImputeGenderChains, SEXP Wanted, SEXP Extractor, SEXP sState,
   SEXP NamesSpace, SEXP OldBeta, SEXP Convergence);
 
 int ReplayGender(SEXP AllY, SEXP AllX, SEXP GXX, SEXP ListUnknownGender,
   SEXP ImputedGender, SEXP PriorGender, SEXP OnSigmaSq, SEXP OnWeights,
   SEXP OnBeta, SEXP sXtX, SEXP sXtY, SEXP sVecOWeights, int iIter);
 void PrintFeatures(SEXP a, const char*CName); 
 int CrossImpute47(int numj, double *Onstaus, double *OnstauCrosses, int UseDiag,
    double *BetaCrosses,
    SEXP sjCrosses, SEXP sjCrossesO, SEXP skCrosses, SEXP skCrossesO, double mtau, double dftau);
 
 int ImputeMissingY(SEXP MissingYIndices, SEXP sY, SEXP sXtY,
  SEXP SumYSq, SEXP sX, SEXP sBeta, SEXP sOnSigma, SEXP dfTNoise, SEXP sVecOWeights,
  SEXP sLowCensorBound, SEXP sUpCensorBound, int iOnIter, SEXP sImputedYChain, int Verbose);
     
  void PrintFeatures(SEXP a, const char*CName){
   if (Rf_isNull(a)) {
     Rprintf("Object %s is a NIL\n", CName);R_FlushConsole();
   } else if (Rf_isInteger(a)) {
     Rprintf("Object %s is an integer array of length %d, first member %d\n",
       CName, Rf_length(a), INTEGER(a)[0]);R_FlushConsole();
   } else if (Rf_isReal(a)) {
     Rprintf("Object %s is a real array of length %d, first member %f\n",
       CName, Rf_length(a), REAL(a)[0]);R_FlushConsole();
   } else if (a == NULL) {
      Rprintf("Object %s is a NULL pointer\n", CName);  R_FlushConsole();
   } else {
     Rprintf("I don't know what %s is! \n", CName); R_FlushConsole();
   }
   return;
 }   
 extern "C" {
 
 SEXP CreateNewVector(SEXP OneMat, SEXP OneVec) {
   SEXP sOn = R_NilValue;
   if (Rf_isNull(OneMat)) {
     return(OneVec);
   }
   int One = 1; int NLen = 0;
   int LDA;
   if (Rf_isNull(GET_DIM(OneMat))) {
     if (Rf_length(OneMat) != Rf_length(OneVec)) {
       Rprintf("ERROR HERE: RDiallel.cc: CreateNewVector, OneMat's a vector but OneVec");
       Rprintf("Length OneMat = %d (NoDim), length(OneVec) = %d \n", OneMat, OneVec);
       R_FlushConsole();
       return(R_NilValue);
     }
     Rf_protect(sOn = Rf_allocMatrix(REALSXP, 2, Rf_length(OneVec)));
     NLen = Rf_length(OneVec); LDA = 2;
     F77_CALL(dcopy)(&NLen, REAL(OneMat), &One, REAL(sOn), &LDA);
     F77_CALL(dcopy)(&NLen, REAL(OneVec), &One, REAL(sOn)+1, &LDA);
     Rf_unprotect(1); return(sOn); 
   }
   int L1 = INTEGER(GET_DIM(OneMat))[0];
   int L2 = INTEGER(GET_DIM(OneMat))[1];
   int LV = Rf_length(OneVec);
   if (LV != L2) {
     Rprintf("ERROR HERE: RDiallel.cc: CreateNewVector, L1,L2 = (%d, %d), but LV = %d\n",
       L1, L2, LV);
     R_FlushConsole();
     return(R_NilValue);
   }
   Rf_protect(sOn = Rf_allocMatrix(REALSXP, L1 +1, LV));
   int ii;
   LDA = L1+1; NLen = L2;
   for (ii = 0; ii < L1; ii++) {
     F77_CALL(dcopy)(&NLen, REAL(OneMat) + ii, &L1, REAL(sOn)+ii, &LDA);
   } 
   F77_CALL(dcopy)(&NLen, REAL(OneVec), &One, REAL(sOn) + L1, &LDA);
   Rf_unprotect(1); return(sOn);
 
 }
 SEXP FillSecondDerivative(SEXP sX, SEXP sEpsilon, SEXP sAlpha, SEXP sExp,
   SEXP spD) {
   int One = 1;  SEXP dimX= Rf_getAttrib(sX, R_DimSymbol);
   int p = INTEGER(dimX)[1];  int n = INTEGER(dimX)[0];
   if (p != Rf_length(sAlpha)) {
     Rf_error("FillSecondDerivative: Alpha and sX are wrong!\n");
   }
   if (Rf_length(sExp) != n) {
     Rf_error("FillSecondDerivative: sExp is not right length!\n");
   }
   char Trans ='N'; double ZeroD = 0.0;  double aalpha = 1.0;
   F77_CALL(dgemv)(&Trans, &n, &p, &aalpha, REAL(sX), &n, REAL(sAlpha), &One,
     &ZeroD, REAL(sExp), &One);
   for (int ii = 0; ii < n; ii++) {
     REAL(sExp)[ii] = exp(REAL(sExp)[ii]);
   }
   int Oo = 0;
 }
 
 SEXP RunDiallelAlgorithmNoNet(SEXP snumj, SEXP sX, SEXP sY, SEXP sXtX, 
   SEXP sXtY, SEXP sSumYSq, SEXP sBeta, SEXP stau, SEXP sSigmaSq, 
   SEXP sLikelihood, SEXP sCodaChain, SEXP sChainLikelihood,
   SEXP sQ, SEXP sInvQ, SEXP sInvSqQ,
   SEXP sDpBeta, SEXP sTauFixed, SEXP dftau, SEXP mtau,
   SEXP smSigma, SEXP sdfSigma,
   SEXP sMyWantDiag,
   SEXP sCrossModel, SEXP sBetaHybridLevel,
   SEXP stauCrosses, SEXP sAsymNotASym,
   SEXP jCross, SEXP kCross, SEXP jCrossO, SEXP kCrossO,
   SEXP sVecOWeights, SEXP sfW, SEXP sdfTNoise, 
   SEXP stauHybridNoise, SEXP stoggleHybrid, SEXP sSigmaDeltaHybrid,
   SEXP sVerbose, SEXP sMeanWeights, SEXP sAllWeights, SEXP sCheckNANINF,
   SEXP sStartIter,
   SEXP sInformEvery,
   SEXP ListUnknownGender, SEXP GXX, 
   SEXP ImputedGender, SEXP PriorGender,
   SEXP ImputeGenderChains, SEXP Wanted, SEXP Extractor, SEXP sState,
   SEXP NamesSpace, SEXP OldBeta, SEXP Convergence,
   SEXP MissingYIndices, SEXP sLowCensorBound, SEXP sUpCensorBound, SEXP ImputedYChain) {
  
 
 TestAlgorithmInputs( snumj,  sX,  sY,  sXtX,  sXtY,
    sSumYSq,  sBeta,  stau,  sSigmaSq,  sLikelihood,
    sCodaChain,
    sChainLikelihood,
    sQ,  sInvQ,  sInvSqQ,
    sDpBeta,  sTauFixed,  dftau,  mtau,
    smSigma,  sdfSigma,
    sMyWantDiag,
    sCrossModel,  sBetaHybridLevel,
    stauCrosses,  sAsymNotASym,
    jCross,  kCross,  jCrossO,  kCrossO,
    sVecOWeights,  sfW,  sdfTNoise, 
    stauHybridNoise,  stoggleHybrid,  sSigmaDeltaHybrid,
    sVerbose, sMeanWeights, sAllWeights,
    sCheckNANINF, sStartIter,
   sInformEvery,
   ListUnknownGender, GXX, 
   ImputedGender, PriorGender,
   ImputeGenderChains,
   Wanted, Extractor, sState, NamesSpace, OldBeta, Convergence);
 

 /*SEXP State = R_NilValue; 
 if (!Rf_isNull(Extractor)) {
   Rf_protect(State = Rf_allocVector(REALSXP, 
     Rf_length(sBeta) + Rf_length(stau)+ Rf_length(sSigmaSq)+
     Rf_length(sVecOWeights)));
   SEXP sStrings = R_NilValue;
   Rprintf("Making sStrings\n"); R_FlushConsole();
   Rf_protect(sStrings = Rf_allocVector(VECSXP, Rf_length(sBeta)+
     Rf_length(stau) + Rf_length(sSigmaSq) + Rf_length(sVecOWeights));
     SEXP NewString =  R_NilValue;
   SEXP NewString;
   int iti = 0; int att = 0;
   for (iti = 0; iti < Rf_length(sBeta); iti++) {
     NewString = Rf_mkString(CHAR(STRING_ELT(GET_VECTOR_ELT(Rf_getAttrib(sBeta, R_NameSymbol),
       iti),0)));
     SET_VECTOR_ELT(sStrings,att, NewString); att++;
   }
   for (iti = 0; iti < Rf_length(stau); iti++) {
     NewString = Rf_mkString(CHAR(STRING_ELT(GET_VECTOR_ELT(Rf_getAttrib(sSigmaSq, R_NameSymbol),
       iti),0)));
     SET_VECTOR_ELT(sStrings,att, NewString); att++;
   }
     NewString = Rf_mkString(CHAR(STRING_ELT(GET_VECTOR_ELT(Rf_getAttrib(sBeta, R_NameSymbol),
       iti),0)));
     SET_VECTOR_ELT(sStrings,att, NewString); att++;
   }
   Rprintf("Allocated first member of sStrings "); R_FlushConsole();
 }*/
 int InformEvery = -1;
 if (!Rf_isNull(sInformEvery)) {
   InformEvery = (int) GetFirstInteger(sInformEvery);
 }
  
 int ProtectedNum = 0;
 SEXP sXtResid = R_NilValue;  SEXP sUseBeta = R_NilValue;  SEXP sStartBeta = R_NilValue;
 int D1 = INTEGER(GET_DIM(sInvQ))[0];
 int D2 = INTEGER(GET_DIM(sInvSqQ))[0];
 int DM = D1; if (D2 < DM) { DM = D1; }
 if (DM < INTEGER(GET_DIM(sXtX))[0]) {
   ProtectedNum = 3;
   Rf_protect( sXtResid = Rf_allocVector(REALSXP, DM));
   Rf_protect( sUseBeta = Rf_allocVector(INTSXP, 2));
   Rf_protect( sStartBeta = Rf_allocVector(INTSXP, 2));
 }
 
 
 int Verbose = GetFirstInteger(sVerbose);
 //int Verbose = 0;
 
 int StartIter = GetFirstInteger(sStartIter);
 if (StartIter < 0 || StartIter > length(sChainLikelihood)) {
   StartIter = 0;
 }
 int BetaHybridLevel = GetFirstInteger(sBetaHybridLevel);
 int CrossModel = GetFirstInteger(sCrossModel); 
 int numj = GetFirstInteger(snumj);
 if (CrossModel == 3 || CrossModel == 4 || CrossModel == 6 || CrossModel == 7 ||
     CrossModel == 9 || CrossModel == 10) {
   error("Error: Cannot Currently in C code deal with CrossModels in (3,4,6,7,9,10)");  
 }
 
 int NumIters = INTEGER(GET_DIM(sCodaChain))[0];
 int iIter = 0;
 int nBeta = length(sBeta);
 int ntau = length(stau);
 int ntauCrosses = 0;
 if (Rf_isNull(stauCrosses)) {
   if (Verbose > 1) {
     Rprintf("stauCrosses is NULL!, numj = \n", numj); R_FlushConsole();
   }
 } else {
   if (Verbose > 1) {
     Rprintf("stauCrosses is Not Null\n"); R_FlushConsole();
     ntauCrosses = length(stauCrosses);
   }
 }
 
 int One = 1;
 int TotPrintChains = INTEGER(GET_DIM(sCodaChain))[1];
 if (Verbose > 1) {
   Rprintf("Total Number of Chains to Print = %d\n ", TotPrintChains);
   R_FlushConsole();
 }

 SEXP Osig;
 if (Rf_isNull(OldBeta) || OldBeta == NULL || !Rf_isReal(OldBeta)) {
   OldBeta = R_NilValue;
   Convergence = R_NilValue;
 }
 if (!Rf_isNull(OldBeta) && Rf_isReal(OldBeta) && Rf_length(OldBeta) == nBeta) {
   F77_CALL(dcopy)(&nBeta, REAL(sBeta), &One, REAL(OldBeta), &One);
   ProtectedNum++;
   Osig = Rf_allocVector(REALSXP,1);  REAL(Osig)[0] = 0.0;
 } else {
   GetRNGstate();  OldBeta = R_NilValue;  Osig = R_NilValue;
 }
 ///////////////////////////////////////////
 // Warning, Reweighting Coming Here
 int IfWeight = 0;
 double dfTNoise = -1;
 if (!Rf_isNull(sdfTNoise) && REAL(sdfTNoise)[0] > 0) {
   IfWeight = 1;
   dfTNoise = REAL(sdfTNoise)[0];
   if (length(sfW) < length(sY)) {
     error(" Sorry, sfW too short to do T weighted Noise \n");
   }
 }
 if (dfTNoise < 0) {
   sVecOWeights = R_NilValue;
 }
 StructDpBeta *StDpBeta = MakeStructDpBeta(sDpBeta);
 
 if (Verbose > 0) {
  Rprintf("About to Start Algorithm\n"); R_FlushConsole();
 }
 int CountToPrint = 0;
 int IfImputeG = 0;
 for (iIter = StartIter; iIter < NumIters; iIter++) {
   if (Verbose > 1) {
     Rprintf("  %d: SampleTau\n", iIter); R_FlushConsole();
   }
   if (isnan(REAL(sXtX)[4])) {
     Rprintf("Hey, RunAlgorithm[iIter=%d], at start of loop we have sXtX[4] is nan!\n", iIter);
     R_FlushConsole();
     REAL(sSigmaSq)[0] = -1.0;
     return(sSigmaSq);  
   }
   int SampleT = SampleTau(sBeta, stau, sTauFixed, StDpBeta, mtau, dftau, OldBeta, Convergence);
   if (SampleT == -1) {
     Rprintf("Error after run SampleTau!"); REAL(sSigmaSq)[0] = -1;
     return(sSigmaSq);
   }

   if (Verbose > 1) {
     Rprintf("  %d: FillDiag\n", iIter); R_FlushConsole();
   }   
   int FMD = FillMyWantDiag(sMyWantDiag, stau, sTauFixed, CrossModel,
     BetaHybridLevel, stauCrosses, StDpBeta, sQ);
   if (FMD == -1) {
     Rprintf("Hey we have FillMyWantDiag Error!\n");
     REAL(sSigmaSq)[0] = -1.0;
     return(sSigmaSq);
   }
   if (isnan(REAL(sXtX)[4])) {
     Rprintf("Hey, RunAlgorithm[iIter=%d], after FillMyWantdiag we have sXtX[4] is nan!\n", iIter);
     R_FlushConsole();
     REAL(sSigmaSq)[0] = -1.0;
     return(sSigmaSq);  
   } 
   // Fill Q = (XtX + D_MyDiag) which is filled diagonal
   if (Verbose > 1) {
     Rprintf("  %d: FillQ\n", iIter); R_FlushConsole();
   }  
   if (REAL(sSigmaSq)[0] <= 0) {
     Rprintf("Hey, before FillSQ we have a -1.0 SigmaSq = %f!  Iter = %d, StartIter = %d\n",
       REAL(sSigmaSq)[0], iIter, StartIter);
     REAL(sSigmaSq)[0] = -1.0;
     return(sSigmaSq);
   }
   int FsQ = FillsQ(sQ, sXtX, IfWeight, IfImputeG, sMyWantDiag, sSigmaSq);
   if (FsQ == -1) {
     Rprintf("Hey, FillSQ ended with an Error!\n");
     REAL(sSigmaSq)[0] = -1.0;
     return(sSigmaSq);
   }
   if (isnan(REAL(sXtX)[4])) {
     Rprintf("Hey, RunAlgorithm[iIter=%d], after FillSQ we have sXtX[4] is nan!\n", iIter);
     R_FlushConsole();
     REAL(sSigmaSq)[0] = -1.0;
     return(sSigmaSq);  
   }
   
   //////////////////////////////////////////////////////////
   // Draw a Bayes Regression draws new Beta given sQ, sXtY
   //
   //  Optimal solution is
   //        Q^-1 %*% XtY + sigma * Q^-.5 * Z
   //   where Z is standard normal vec
   //
   //  However, it is not always possible to take square root of matrix
   //  In DiallelMatrixHelp, CalculateCholAndInverse() gets the necessary
   //   functions;  
   if (Verbose > 1) {
     Rprintf("  %d: DrawBayes\n", iIter); R_FlushConsole();
   }
   int DABR = 0;
   if (Rf_isNull(OldBeta)) {
   if (Rf_isNull(sXtResid)) {
     DABR = DrawABayesRegression(sQ, sXtY, sSigmaSq,
       sInvSqQ, sInvQ, sBeta);
   } else {
      DABR = DrawABayesRegression(sXtX, sQ, sXtY, sSigmaSq,
       sXtResid, sInvSqQ, sInvQ, sBeta, sUseBeta, sStartBeta);   
   }
   } else {
   if (Rf_isNull(sXtResid)) {
     DABR = DrawABayesRegression(sQ, sXtY, Osig,
       sInvSqQ, sInvQ, sBeta);
   } else {
    DABR = DrawABayesRegression(sXtX, sQ, sXtY, Osig,
       sXtResid, sInvSqQ, sInvQ, sBeta, sUseBeta, sStartBeta);   
   }   
   }
   if (DABR == -1) {
     Rprintf("Error found after DrawBayesRegression!\n"); R_FlushConsole();
     REAL(sSigmaSq)[0] = -1;
     return(sSigmaSq);
   }
   for (int www = 0; www < Rf_length(sBeta); www++) {
     if (isnan(REAL(sBeta)[www])) {
       Rprintf("nan-Check for sBeta, after DrawABayesRegression we have that element www = %d/%d is nan.\n",
         www, Rf_length(sBeta));
       Rprintf("Heres your tau: \n");
       for (int tt3 = 0; tt3 < Rf_length(stau); tt3++) {
         Rprintf("%f", REAL(stau)[tt3]);
         if (tt3 == Rf_length(stau)-1) {
           Rprintf(".\n"); R_FlushConsole();
         } else {
           Rprintf(", "); R_FlushConsole();
         }
       }
       REAL(sSigmaSq)[0] = -1;
       return(sSigmaSq);
     }
   }
   
   
   
   if (Verbose > 1) {
     Rprintf("  %d: UpdateSigma\n", iIter); R_FlushConsole();
   }   
   int SigmaRet = UpdateSigma(sSigmaSq, sY, sBeta, sXtX, sXtY, sfW, sSumYSq,
       smSigma, sdfSigma, sLikelihood, OldBeta, Convergence);
   if (SigmaRet == -1) {
     Rprintf("We discovered an Error after UpdateSigma = %f, after iIter = %d\n", REAL(sSigmaSq)[0], iIter); R_FlushConsole();
     Rprintf("sSumYSq we were given is %f\n", REAL(sSumYSq)[0]);
     double ADo = 0.0;
     if (!Rf_isNull(sVecOWeights)) {
       for (int iii = 0; iii < Rf_length(sY); iii++) {
         ADo += REAL(sVecOWeights)[iii] * REAL(sY)[iii] * REAL(sY)[iii];
       }
     } else {
       for (int iii = 0; iii < Rf_length(sY); iii++) {
         ADo +=  REAL(sY)[iii] * REAL(sY)[iii];
       }     
     }
     Rprintf("But we got %f instead!\n", ADo);
     int One = 1;  int NL = Rf_length(sXtY);
     Rprintf("Also, ddOtting sBeta by XtY gets %f\n",
       F77_CALL(ddot)(&NL, REAL(sXtY), &One, REAL(sBeta), &One));
     ADo = 0.0;
     if (Rf_isNull(sVecOWeights)) {
       for (int iii = 0; iii < Rf_length(sY); iii++) {
         for (int jjj = 0; jjj < INTEGER(GET_DIM(sX))[1]; jjj++) {
           ADo += REAL(sVecOWeights)[iii] * REAL(sY)[iii] *
             REAL(sX)[iii + jjj * Rf_length(sY)];
         }
       }
     } else {
        for (int iii = 0; iii < Rf_length(sY); iii++) {
         for (int jjj = 0; jjj < INTEGER(GET_DIM(sX))[1]; jjj++) {
           ADo +=  REAL(sY)[iii] *
             REAL(sX)[iii + jjj * Rf_length(sY)];
         }
       }    
     }
     Rprintf("But we got %f instead \n", (double) ADo); R_FlushConsole();
     REAL(sSigmaSq)[0] = -1;
     return(sSigmaSq);
   }
   
   if (dfTNoise > 0) {
     // Update TNoise updates "VecOWeights" and reweights XtX, XtY if necessary
     if (Verbose > 1) {
       Rprintf("  %d: UpdateTNoise\n", iIter); R_FlushConsole();
     }
     //Rprintf("Holy No, TNoise Update\n"); R_FlushConsole();
     if (Rf_isNull(sVecOWeights) || Rf_length(sVecOWeights) != Rf_length(sY)) {
       Rf_error("Can't update dfTNoise with faulty weights!");
     }
    int ATUp = UpdateTNoise(sSigmaSq, sBeta, sX, sY, sXtX, sXtY, sSumYSq, 
       sfW, sVecOWeights, dfTNoise, sLikelihood, sMeanWeights, 
       OldBeta, Convergence);
    if (ATUp < 0) {
      Rprintf("RunAlgorithm NoNet, nan flaw discovered after UpdateTNoise"); R_FlushConsole();
      REAL(sSigmaSq)[0] = -1.0;
      return(sSigmaSq);
    }
     if (!Rf_isNull(sAllWeights) && isReal(sAllWeights) && 
       length(sAllWeights) >= length(sVecOWeights) * iIter) {
       int nLen = length(sVecOWeights); int One = 1;
       int LenAllWeights = (int) 
         round(length(sAllWeights) / length(sVecOWeights) );
       F77_CALL(dcopy)(&nLen, REAL(sVecOWeights), &One,
         REAL(sAllWeights) + iIter, &LenAllWeights);
     }
   }
   if (!Rf_isNull(ListUnknownGender)
     && !Rf_isNull(ImputedGender) && !Rf_isNull(PriorGender)) {
     if (Verbose > 2) {
       Rprintf("I Guess I should impute the gender, doh\n"); R_FlushConsole();
     }
     int ReplayG = ReplayGender(sY, sX, GXX, ListUnknownGender,
       ImputedGender, PriorGender, sSigmaSq, sVecOWeights,
       sBeta, sXtX, sXtY, sVecOWeights, iIter); 
     if (ReplayG == -1) {
       Rprintf("Error after ReplayG, we got a negative return!\n"); R_FlushConsole();
       REAL(sSigmaSq)[0] = -1;
       return(sSigmaSq);
     }  
     IfImputeG = 1;
     //if (dfTNoise > 0) {
     //
     //} else {
       //char Trans = 'T'; double ZeroD = 0.0;  double OneD = 1.0;
       //int LDA = INTEGER(GET_DIM(sX))[0];  int ap = INTEGER(GET_DIM(sX))[1];
       //for (int kt1 = 0; kt1 < INTEGER(GET_DIM(sX))[1]; kt1++) {
     //    F77_CALL(dgemv)(&Trans, INTEGER(GET_DIM(sX)), 
     //      INTEGER(GET_DIM(sX))+1, &OneD, REAL(sX), INTEGER(GET_DIM(sX)),
     //      REAL(sX) + INTEGER(GET_DIM(sX))[0] * kt1, &One, &ZeroD,
     //      REAL(sXtX) + INTEGER(GET_DIM(sXtX))[0] * kt1, &One);
     //  }
     //}
   }
     
   // Fill In the Chains
   if (Verbose > 1) {
     Rprintf("  %d: PrintResult\n", iIter); R_FlushConsole();
   }    
   int OnPrint = 0;  int NumPrint = 0; 
   //if (iIter==NumIters-1) {
   //  Rprintf("Last Print, Printing Beta from %d to %d\n",
   //   iIter, numIters * nBeta); R_FlushConsole();
   //}
   
   if (!Rf_isNull(MissingYIndices) && Rf_length(MissingYIndices) > 0) {
     if (!Rf_isReal(MissingYIndices) && !Rf_isInteger(MissingYIndices)) {
       Rf_error("Error: MissingYIndices is Freaky, neither real nor integer!\n");
     }
     if (ANINT(MissingYIndices, 0) >= 0) {
       int IMissingY = ImputeMissingY(MissingYIndices,  sY, sXtY,
        sSumYSq, sX, sBeta, sSigmaSq, sdfTNoise, sVecOWeights,
        sLowCensorBound, sUpCensorBound, iIter, ImputedYChain, Verbose);
       if (IMissingY == -1) {
         Rprintf("Error: ImputeMissingY gave us an error!");
         REAL(sSigmaSq)[0] = -1;
         return(sSigmaSq);
       }
     }
   }
   if (Rf_isNull(Wanted) && Rf_isNull(Extractor)) {
     if (NumPrint + iIter + nBeta * NumIters >= length(sCodaChain)) {
       Rprintf("Error: Numprint = %d, iIter = %d, nBeta = %d, NumIters = %d, Chain Length = %d\n",
       NumPrint, iIter, nBeta, NumIters, Rf_length(sCodaChain));
       error("Trying to print to %d in sCodaChain, Beta Error\n",
        NumPrint+iIter);
     }  
     F77_CALL(dcopy)(&nBeta, 
       REAL(sBeta), &One, 
       REAL(sCodaChain) + iIter, &NumIters);
     OnPrint += nBeta;  NumPrint += nBeta * NumIters;
     //if (iIter==NumIters-1) {
     //  Rprintf("Last Print, Printing Beta from %d to %d\n",
     //   iIter + NumPrint, NumPrint + iIter + numIters * nBeta); R_FlushConsole();
     //}
     if (NumPrint + iIter + ntau * NumIters >= length(sCodaChain)) {
       error("Trying to print to %d in sCodaChain, tau Error\n",
         NumPrint+iIter);
     }    
     F77_CALL(dcopy)(&ntau, REAL(stau), &One,
       REAL(sCodaChain) + iIter + NumPrint, &NumIters);

     OnPrint += ntau; NumPrint += ntau * NumIters; 
     if (ntauCrosses > 0) {
       F77_CALL(dcopy)(&ntauCrosses, REAL(stauCrosses), &One, 
         REAL(sCodaChain) + iIter + NumPrint, &NumIters);
       OnPrint+=ntauCrosses;  NumPrint += ntauCrosses * NumIters;
     }
     if (iIter >= length(sChainLikelihood)) {
       error("Trying to print to %d in sChainLikelihood\n",
         iIter);
     }
     if (NumPrint + iIter >= length(sCodaChain)) {
       Rf_error("Trying to print to %d in sCodaChain, Sigma Error\n",
        NumPrint+iIter);
     }
     REAL(sCodaChain)[NumPrint + iIter] = REAL(sSigmaSq)[0];
   } else if (!Rf_isNull(Wanted)) {
     int itti;
     for (itti = 0; itti < Rf_length(Wanted); itti++) {
        if (ANINT(Wanted,itti) < 0) {
          Rf_error("Error, A Wanted = %d \n", ANINT(Wanted, itti));
        } else if (ANINT(Wanted, itti) < Rf_length(sBeta)) {
           REAL(sCodaChain)[NumPrint * NumIters + iIter] = 
             REAL(sBeta)[ANINT(Wanted, itti)];
        } else if (ANINT(Wanted, itti) < Rf_length(stau)+ Rf_length(sBeta)) {
           REAL(sCodaChain)[NumPrint * NumIters + iIter] = 
             REAL(stau)[ANINT(Wanted, itti) - Rf_length(sBeta)];       
        } else if (ANINT(Wanted, itti) < Rf_length(stau)+ Rf_length(sBeta) + Rf_length(sSigmaSq)) {
           REAL(sCodaChain)[NumPrint * NumIters + iIter] = 
             REAL(sSigmaSq)[0];       
        } else if (ANINT(Wanted, itti) < Rf_length(stau)+ Rf_length(sBeta) + 
          Rf_length(sSigmaSq) + Rf_length(sVecOWeights)) {
           REAL(sCodaChain)[NumPrint * NumIters + iIter] = 
             REAL(sVecOWeights)[ANINT(Wanted, itti) - Rf_length(sBeta) - 1
               - Rf_length(stau)];       
        } else {
          Rf_error("Hey, we tried to use Wanted but it is in error!");
          NumPrint--;
        }
        NumPrint++;
     }
   } else if (Rf_isNull(sState)) {
     Rf_error("Hey, State is Null but you wanted us to use Extractor ");
   } else {
     int LengthWant = Rf_length(stau) + Rf_length(sBeta) + 
       Rf_length(sSigmaSq);
     if (!Rf_isNull(sVecOWeights)) {
       LengthWant += Rf_length(sVecOWeights);
     }
     if (Rf_length(sState) < LengthWant) {
       Rprintf("Error: sState has length %d, LW = %d\n, t=%d,B=%d,sig=%d,V=%d\n",
         Rf_length(sState), LengthWant,Rf_length(stau), Rf_length(sBeta), 
       Rf_length(sSigmaSq), Rf_length(sVecOWeights));
       Rf_error("Hey State is too short to use Extractor!");  
     }
     if (Rf_isNull(NamesSpace)) {
       Rf_error("Hey, can't use Extractor with Null NamesSpace");
     }
     int LL = Rf_length(sBeta);
     F77_CALL(dcopy)( &LL, REAL(sBeta), &One, REAL(sState), &One);
     LL = Rf_length(stau);
     F77_CALL(dcopy)( &LL, REAL(stau), &One, REAL(sState) + Rf_length(sBeta), &One);
     LL = Rf_length(sSigmaSq);
     F77_CALL(dcopy)(&LL, REAL(sSigmaSq), &One, REAL(sState) + Rf_length(sBeta) +
       Rf_length(stau), &One);
     if (!Rf_isNull(sVecOWeights) && Rf_length(sVecOWeights) > 0) {
       LL = Rf_length(sVecOWeights);
       F77_CALL(dcopy)(&LL, REAL(sVecOWeights), &One, REAL(sState) +
         Rf_length(sBeta) + Rf_length(stau) + Rf_length(sSigmaSq),
         &One);
     }
     SEXP rCAll = R_NilValue; SEXP RTM2;
     //Rprintf("Calling Extractor\n"); R_FlushConsole();
     Rf_protect(rCAll = Rf_lcons(Extractor, Rf_cons(sState, R_NilValue)));
     Rf_protect(RTM2 = Rf_eval(rCAll, NamesSpace));
     //Rprintf("Writing Extractor to CodaChains!\n"); R_FlushConsole();
     int NC = INTEGER(GET_DIM(sCodaChain))[0];
     int CC = Rf_length(RTM2);
     if (CC <= 0) {
       Rf_error("Error: Call to Extractor Function failed!");
     }
     F77_CALL(dcopy)(&CC, REAL(RTM2), &One, REAL(sCodaChain) + iIter, &NC);
     Rf_unprotect(2);
   }
   if (!Rf_isNull(ImputedGender) &&
     !Rf_isNull(ImputeGenderChains) && Rf_length(ImputeGenderChains) >=
     (iIter+1) * Rf_length(ImputedGender)) {
      int aOne = 1;
      int lC = Rf_length(ImputedGender);
     if (Rf_isReal(ImputedGender) && Rf_isReal(ImputeGenderChains)) { 
        if (!Rf_isNull(GET_DIM(ImputeGenderChains)) &&
          INTEGER(GET_DIM(ImputeGenderChains))[0] > 0) {
          int nA = INTEGER(GET_DIM(ImputeGenderChains))[0];    
          F77_CALL(dcopy)(&lC, REAL(ImputedGender), &aOne, 
            REAL(ImputeGenderChains) + iIter, &nA); 
        } else {
          F77_CALL(dcopy)(&lC, REAL(ImputedGender), &aOne,
            REAL(ImputeGenderChains) + iIter * lC, &aOne);
        }
     } else if (Rf_isInteger(ImputeGenderChains)) {
      if (!Rf_isNull(GET_DIM(ImputeGenderChains)) &&
          INTEGER(GET_DIM(ImputeGenderChains))[0] > 0) {
          if (Rf_isInteger(ImputedGender)) {
            for (int jti = 0; jti < lC; jti++) {
              INTEGER(ImputeGenderChains)[iIter + jti * 
                INTEGER(GET_DIM(ImputeGenderChains))[0]] =
              INTEGER(ImputedGender)[jti];
            }
          } else if (Rf_isReal(ImputedGender)) {
            for (int jti = 0; jti < lC; jti++) {
              INTEGER(ImputeGenderChains)[iIter + jti * 
                INTEGER(GET_DIM(ImputeGenderChains))[0]] =
              (int) REAL(ImputedGender)[jti];
            }          
          }
        } else {
          if (Rf_isInteger(ImputedGender)) {
            for (int jti = 0; jti < lC; jti++) {
              INTEGER(ImputeGenderChains)[iIter * Rf_length(ImputedGender)
                 + jti ] =
              INTEGER(ImputedGender)[jti];
            }
          } else if (Rf_isReal(ImputedGender)) {
            for (int jti = 0; jti < lC; jti++) {
              INTEGER(ImputeGenderChains)[iIter * Rf_length(ImputedGender)
                 + jti ]  =
              (int) REAL(ImputedGender)[jti];
            }          
          }
        }
     } 
   }
   REAL(sChainLikelihood)[iIter] = REAL(sLikelihood)[0];
   if (CountToPrint >= 999) {
     if (Verbose > 1) {
       Rprintf("Hit Iter = %d\n", iIter+1); R_FlushConsole();
     }
     CountToPrint = 0;
   } else {
     CountToPrint++;
   }
   if(GetFirstInteger(sCheckNANINF)  > 0) {
     for (int ii = 0; ii  < nBeta; ii++) {
       if(isnan(REAL(sBeta)[ii])|| !R_finite(REAL(sBeta)[ii]) ||
          REAL(sBeta)[ii] == NA_REAL) {
          REAL(sBeta)[ii] = 0;
       }
     }
     for (int ii = 0; ii  < ntau; ii++) {
       if(isnan(REAL(stau)[ii])|| !R_finite(REAL(stau)[ii])||
          REAL(stau)[ii] == NA_REAL) {
          REAL(stau)[ii] = 1.0;
       }
     }
     if (ntauCrosses> 0) {
       for (int ii = 0; ii  < ntauCrosses; ii++) {
         if(isnan(REAL(stauCrosses)[ii])|| !R_finite(REAL(stauCrosses)[ii])||
           REAL(stauCrosses)[ii] == NA_REAL) {
            REAL(stauCrosses)[ii] = 1.0;
         }
       }
     }
     if (isnan(REAL(sSigmaSq)[0]) || !R_finite(REAL(sSigmaSq)[0]) ||
       REAL(sSigmaSq)[0] == NA_REAL) {
       REAL(sSigmaSq)[0] = 1.0;
     }
     if (dfTNoise > 0) {
       for (int ii = 0; ii  < length(sVecOWeights); ii++) {
         if(isnan(REAL(sVecOWeights)[ii])|| !R_finite(REAL(sVecOWeights)[ii]) ||
           REAL(sVecOWeights)[ii] == NA_REAL) {
           REAL(sVecOWeights)[ii] = 1.0;
         }
       }     
     }
   }   
   if (InformEvery > 0) {
     if (iIter > 0 && iIter % InformEvery == 0) {
       Rprintf("Run Algorithm: Finished Iter iIter = %d", iIter);
       int sPChain = 0;
       if (Rf_length(sInformEvery) > 1) {
         if (Rf_isReal(sInformEvery)) {
           sPChain = (int) REAL(sInformEvery)[1];
         } else { sPChain = INTEGER(sInformEvery)[1];}
         Rprintf(" of Chain \n", sPChain); R_FlushConsole();
       } else {
         Rprintf(" \n "); R_FlushConsole();
       }
     }
   }  
   if (!Rf_isNull(OldBeta) && Rf_isReal(OldBeta) && Rf_length(OldBeta) == nBeta) {
     double diff = 0.0;
     for (int jj = 0; jj < nBeta; jj++) {
       diff+= fabs(REAL(OldBeta)[jj]- REAL(sBeta)[jj]);
     }
     int One = 1;  
     F77_CALL(dcopy)(&nBeta, REAL(sBeta), &One, REAL(OldBeta), &One);
     if (!Rf_isNull(Convergence)  && Rf_isReal(Convergence) && REAL(Convergence)[0] > diff) {
       REAL(Convergence)[0] = diff;
       return(Convergence);
     }
   }
 }
 deleteStDpBeta(StDpBeta); StDpBeta = NULL;
 if (!Rf_isNull(OldBeta)) {
   PutRNGstate();
 }
 if (ProtectedNum > 0) { Rf_unprotect(ProtectedNum); }
 return(sBeta);
}

SEXP GiveRandomGamma(SEXP StoreGamma, SEXP alphaGamma, SEXP betaGamma) {
 int Len = length(StoreGamma);
 GetRNGstate();
 for (int ii = 0; ii < Len; ii++) {
   REAL(StoreGamma)[ii] = rgamma(REAL(alphaGamma)[0], REAL(betaGamma)[0]);
 }
 PutRNGstate();
 return(StoreGamma);
}

/*
SEXP CCalculateDIC(SEXP sCodaChains, SEXP sCodaOuts,
  SEXP sStart, SEXP sEnd, 
  SEXP sQuantCov)  {
 int jj = 0; 
 int Start = GetfirstInteger(sStart); int End = GetFirstInteger(sEnd);
 SEXP sOnCodaChain = VECTOR_ELT(sCodaChains,0);
  int dim1 = INTEGER(GET_DIM(sOnCodaChain))[0];
  int dim2 = INTEGER(GET_DIM(sOnCodaChain))[1];
  
  int dim3 = INTEGER(GET_DIM(sCodaOuts)[0];
  if (dim3 != dim2) {
    error("sCodaOuts %d, %d, Not compatible with OnCodaChain, %d, %d\n",
     dim3, dim4, dim1, dim2);
  }
  
  double QuantCov = REAL(sQuantCov)[0];
  double FirstQ = .5 - QuantCov*.5;
  double SecondQ = .5 + QuantCov * .5;
  if (Start > 0 && Start <= dim1 && End >= 0 && End > Start && End <= dim1) {
  
  } else {
    Start =1; End = dim1;
    error("Bad Start and End Inputs!\n");
  }
  int ii;
  
  int NLen = length(sCodaOuts); double ZeroD = 0.0;  int One = 1;
  F77_CALL(dscal)(&NLen, &ZeroD, REAL(sCodaOuts), &One);
  
  for (jj = 0; jj < length(sCodaChains); jj++) {
    sOnCodaChain = VECTOR_ELT(sCodaChains,jj);
    if (TYPEOF(sOnCodaChain) == REALSXP) {   
      for (ii = 0; ii < dim3;ii++) {
        nn = dim1 * ii + Start-1;
        for (tt = Start-1; tt < End; tt++) {
          REAL(sCodaOuts)[ii] += REAL(sOnCodaChain)[nn]; nn++;
        }
      }
    }   
  }
  double divisor = 1.0 / ( (End - Start+1) * length(sCodaChains));
  F77_CALL(dscal)(&dim3, &divisor, REAL(sCodaChains), &One);

  int NumChains = length(sCodaChains);
  int *CountBelow = (int*)Calloc(length(sCodaChains), &One);
  
  
  //Rprintf("Meaning smeanBeta, %d \n", TYPEOF(smeanBeta)); R_FlushConsole();
  Free(CountBelow);
}                                     */

SEXP CCalculateDIC(SEXP sCodaChains, SEXP smeanBeta, SEXP smeanSigma,
  SEXP sStart, SEXP sEnd, SEXP sLikelihoodChains, SEXP sLikelihoodMean,
  SEXP sCheckNANINF) {
  int jj = 0; //int Total;
  int Start = GetFirstInteger(sStart); int End = GetFirstInteger(sEnd);
  
  SEXP sOnCodaChain = VECTOR_ELT(sCodaChains,0);
  int dim1 = INTEGER(GET_DIM(sOnCodaChain))[0];
  int dim2 = INTEGER(GET_DIM(sOnCodaChain))[1];
  if (length(smeanBeta) > dim2) {
    error("meanBeta is Too Long, Cant CalculateDIC\n");
  }
  //Rprintf("dim1 = %d, dim2 = %d\n", dim1, dim2); R_FlushConsole();
  //Rprintf("Type of sCodaChains =%d, Type = sOnCodaChain=%d\n",
  //  TYPEOF(sCodaChains), TYPEOF(sOnCodaChain)); R_FlushConsole();
  
  if (Start > 0 && Start <= dim1 && End >= 0 && End > Start && End <= dim1) {
  
  } else {
    Start =1; End = dim1;
    error("Bad Start and End Inputs!\n");
  }
  int ii;
  //Rprintf("Meaning smeanBeta, %d \n", TYPEOF(smeanBeta)); R_FlushConsole();
  
  for (ii = 0; ii < length(smeanBeta);ii++) {
    REAL(smeanBeta)[ii] = 0;
  }
  //Rprintf("Now Taking the means of All Betas\n");
  int tt = 0;
  int nn = 0;
  double divisor;
  if (GetFirstInteger(sCheckNANINF) > 0) {
    int CountNonNa = 0;
    for (ii = 0; ii < length(smeanBeta);ii++) {
      for (jj = 0; jj < length(sCodaChains); jj++) {
        sOnCodaChain = VECTOR_ELT(sCodaChains, jj);
        if (TYPEOF(sOnCodaChain) == REALSXP) {
          nn = dim1 * ii + Start - 1;
          for (tt = Start-1; tt < End; tt++) {
            if (!isnan(REAL(sOnCodaChain)[nn]) && 
              R_finite(REAL(sOnCodaChain)[nn]) &&
              REAL(sOnCodaChain)[nn] != NA_REAL) {
              REAL(smeanBeta)[ii] += REAL(sOnCodaChain)[nn]; CountNonNa++;    
            }
            nn++;
          }
        }
      }
      REAL(smeanBeta)[ii] = ((double) REAL(smeanBeta)[ii]) /(
        (double) CountNonNa);
    }
  } else {
    for (jj = 0; jj < length(sCodaChains); jj++) {
      sOnCodaChain = VECTOR_ELT(sCodaChains,jj);
      if (TYPEOF(sOnCodaChain) == REALSXP) {   
        for (ii = 0; ii < length(smeanBeta);ii++) {
          nn = dim1 * ii + Start-1;
          for (tt = Start-1; tt < End; tt++) {
            REAL(smeanBeta)[ii] += REAL(sOnCodaChain)[nn]; nn++;
          }
        }
      }
    } 
    divisor = 1.0 / ( (End - Start+1) * length(sCodaChains));
    for (ii = 0; ii < length(smeanBeta); ii++) {
      REAL(smeanBeta)[ii]  = REAL(smeanBeta)[ii] * divisor;
    } 
  }


  
  REAL(smeanSigma)[0] = 0;
  if (GetFirstInteger(sCheckNANINF) > 0) {
    int CountAll = 0;
    for (jj = 0; jj < length(sCodaChains); jj++ ) {
      sOnCodaChain = VECTOR_ELT(sCodaChains,jj);
      nn = (dim2-1) *  dim1 + Start - 1;
      for (tt = Start-1; tt < End; tt++) {
        if (!isnan(REAL(sOnCodaChain)[nn]) && 
          R_finite(REAL(sOnCodaChain)[nn]) &&
          REAL(sOnCodaChain)[nn] == NA_REAL) {
          REAL(smeanSigma)[0] += REAL(sOnCodaChain)[nn]; nn++;
          CountAll++;
        }
      }
    } 
    REAL(smeanSigma)[0] = REAL(smeanSigma)[0] / ((double) CountAll);
  }  else {
    for (jj = 0; jj < length(sCodaChains); jj++ ) {
      sOnCodaChain = VECTOR_ELT(sCodaChains,jj);
      nn = (dim2-1) *  dim1 + Start - 1;
      for (tt = Start-1; tt < End; tt++) {
        REAL(smeanSigma)[0] += REAL(sOnCodaChain)[nn]; nn++;
      }
    }
    divisor = 1.0 / ( (End - Start+1) * length(sCodaChains));
    REAL(smeanSigma)[0] = REAL(smeanSigma)[0] * divisor;
  }
  
  REAL(sLikelihoodMean)[0] = 0;
  if (GetFirstInteger(sCheckNANINF) > 0) {
    int CountAll = 0;
    for (jj = 0; jj < length(sLikelihoodChains); jj++ ) {
      sOnCodaChain = VECTOR_ELT(sLikelihoodChains,jj);
      nn = Start - 1;
      for (tt = Start-1; tt < End; tt++) {
        if (!isnan(REAL(sOnCodaChain)[nn]) && 
          R_finite(REAL(sOnCodaChain)[nn]) &&
          REAL(sOnCodaChain)[nn] == NA_REAL) {
          REAL(sLikelihoodMean)[0] += REAL(sOnCodaChain)[nn]; nn++;
          CountAll++;
        }
      }
    } 
    REAL(sLikelihoodMean)[0] = REAL(sLikelihoodMean)[0] / ((double) CountAll);
  } else {
    for (jj = 0; jj < length(sLikelihoodChains); jj++ ) {
      sOnCodaChain = VECTOR_ELT(sLikelihoodChains,jj);
      nn = Start-1;
      for (tt = Start-1; tt < End; tt++) {
        REAL(sLikelihoodMean)[0] += REAL(sOnCodaChain)[nn]; nn++;
      }
    }
    divisor = 1.0 / ( (End - Start+1) * length(sCodaChains));
    REAL(sLikelihoodMean)[0] = REAL(sLikelihoodMean)[0] * divisor;  
  }
  return(smeanBeta);
}
}
 
 int FillsQ(SEXP sQ, SEXP sXtX, int IfWeight, int IfImputeG, SEXP sMyWantDiag, SEXP sSigma) {
   int nBeta = INTEGER(GET_DIM(sQ))[0];
   if (nBeta <= 0) {
     Rprintf("FillSq Error, dimension of SQ is zero!\n");
     return(-1);
   }
   if (INTEGER(GET_DIM(sXtX))[0] != nBeta) {
     Rprintf("FillSqError, dimension of sXtX[%d,%d] is not compatible with sQ[%d,%d]\n",
       INTEGER(GET_DIM(sXtX))[0], INTEGER(GET_DIM(sXtX))[1],
       INTEGER(GET_DIM(sQ))[0], INTEGER(GET_DIM(sQ))[1]);
     R_FlushConsole(); return(-1);
   }
   int One = 1; int ii,jj=0;
   if (IfWeight == 1 || IfImputeG == 1) {
     int nBetaSq = nBeta * nBeta;
     F77_CALL(dcopy)(&nBetaSq, REAL(sXtX), &One, REAL(sQ), &One);
   } else {
     for (ii = 0; ii < nBeta; ii++) {
        REAL(sQ)[jj] = REAL(sXtX)[jj];
        jj += nBeta + 1;
     }
   }
   jj=0;
   //Rprintf("nBeta = %d \n", nBeta);
   if (REAL(sSigma)[0] <= 0) {
     Rprintf("FillSq Error, Error, you have us REAL(sSigma)[0] = %f\n", REAL(sSigma)[0]);
     return(-1);
   }
   F77_CALL(dscal)(&nBeta, REAL(sSigma), REAL(sMyWantDiag), &One); 
   //for (ii = 0; ii < nBeta; ii++) {
   //   REAL(sMyWantDiag)[ii] *= REAL(sSigma)[0];
   //}
   for (ii = 0; ii < nBeta; ii++) {
     if (REAL(sMyWantDiag)[ii] < 0) {
       Rprintf("FillSqError, fishy, REAL(sMyWantDiag)[%d] < 0 = %f\n", ii, REAL(sMyWantDiag)[ii]);
       R_FlushConsole();  return(-1);
     }
     REAL(sQ)[jj] +=  REAL(sMyWantDiag)[ii];
     jj += nBeta + 1;
   }   
   return(1);
 }
 
 int SampleTau(SEXP OnBeta, SEXP stau, SEXP sTauFixed, StructDpBeta *StDpBeta, 
               SEXP mtau, SEXP dftau, SEXP OldBeta, SEXP Convergence) {
   double OnTotalSq = 0; int idi;
   int jj = length(sTauFixed);
   int ii = 0;
   unsigned short int *OnList = NULL;
   for (ii = 0; ii < length(stau); ii++) {
      OnTotalSq = 0;
      OnList = GetListX(StDpBeta,jj);
      for (idi = 0; idi < GetLenX(StDpBeta,jj);idi++) {
        OnTotalSq += Sq( (REAL(OnBeta)[OnList[idi]]) );
      }

      if (!Rf_isNull(OldBeta)) {
        if (!Rf_isNull(Convergence) && Rf_length(Convergence) >= 2) {
          REAL(stau)[ii] = (REAL(mtau)[ii] + .5 * OnTotalSq) /
                        ( REAL(dftau)[ii] + (double) GetLenX(StDpBeta,jj) * .5+1.0);         
        } else {
          REAL(stau)[ii] = (REAL(mtau)[ii] + .5 * OnTotalSq) /
                        ( REAL(dftau)[ii] + (double) GetLenX(StDpBeta,jj) * .5-1.0); 
        }     
      } else {
        REAL(stau)[ii] = (REAL(mtau)[ii] + .5 * OnTotalSq) /
                        ( rgamma(REAL(dftau)[ii] + (double) GetLenX(StDpBeta,jj) * .5, 1.0));
      }
      if (isnan(REAL(stau)[ii])) {
        Rprintf("Samplestau, We observe a nan tau at position %d, though mtau = %f, OnTotalSq = %f\n", ii,
          REAL(mtau)[0], OnTotalSq);
        Rprintf("Fix it!");
        return(-1);
      }
      if (REAL(stau)[ii] <= 0) {
        Rprintf("Samplestau, We observe a negative tau at position %d, though mtau = %f, OnTotalSq = %f, GetLenX(StDpBeta,jj) = %f\n", ii,
          REAL(mtau)[0], OnTotalSq, (double) GetLenX(StDpBeta,jj));
        Rprintf("Fix it!");
        return(-1);
      }
      //Rprintf(" On jj = %d, ii = %d, OnTotalSq = %f, new stau = %f, m %f, d %f\n",
      //   jj, ii, OnTotalSq, REAL(stau)[ii], REAL(mtau)[ii], REAL(dftau)[ii]);
      //R_FlushConsole();   
      jj++;
   }            
   return(1);            
 }
 int FillMyWantDiag(SEXP sMyWantDiag, SEXP stau, SEXP sTauFixed,
                    int CrossModel, int BetaHybridLevel, SEXP stauCrosses,
                    StructDpBeta *StDpBeta, SEXP sQ) {                
                    
    int ii;
    
    for (ii = 0; ii < length(sTauFixed); ii++) {
       REAL(sMyWantDiag)[ii] = 1.0 / REAL(sTauFixed)[ii];
       if (REAL(sTauFixed)[ii] <= 0) {
         Rprintf("Hey, just to note sTauFixed[%d] is negative! = %f\n", ii, REAL(sTauFixed)[ii]);
         return(-1);
       }
    }
    int jj = length(sTauFixed);  int idi;
    double OnPrint = 0.0;
    unsigned short int *OnList;
    for (ii=0; ii < length(stau); ii++) {
       OnPrint = 1.0/REAL(stau)[ii];
       if (OnPrint <= 0) {
         Rprintf("Hey, just to note that 1/stau[%d] is negative = %f!\n", ii, OnPrint);
         return(-1);
       }
       OnList = GetListX(StDpBeta,jj);
       for (idi = 0; idi < GetLenX(StDpBeta,jj); idi++) {
          if (OnList[idi] > length(sMyWantDiag)) {
           error("Fill My WantDiag OnList fell out of Bounds!!\n");
          }
          REAL(sMyWantDiag)[OnList[idi]] = OnPrint;
       }
       jj++;
    }
    return(1);
 }
 
 
 //////////////////////////////////////////////////
 //  FillCrossWantDiag
 //
 //   Because not all Cross Models are created equal
 //    we have to deal differently with Asymmetric, Symmetric,
 //     Type (3,6), (4,7), 9, 10  depending on whether the diagonal is
 //    part of the model.
 int FillCrossWantDiag(int numj, int CrossLevel, int BetaHybridLevel, SEXP stau,
   SEXP stauCrossStarts, SEXP sAsymNotASym,
   SEXP stauCrosses, SEXP sjCrosses, SEXP sjCrossesO, SEXP skCrosses, SEXP skCrossesO) {
   
   int nPos; 
   int nDifftauCrosses  = length(stauCrossStarts);
   //int OnsCross = 0;
    int LastPos = 0; int OnPos = 0; 
   //int MorePos;
   for (int OntauCross = 0; OntauCross < nDifftauCrosses; OntauCross++) {
     nPos = 0;
     LastPos = (int) REAL(stauCrossStarts)[OntauCross];
     if ((CrossLevel == 3 || CrossLevel == 6)
         && BetaHybridLevel < 2 && REAL(sAsymNotASym)[OntauCross] == 1) {
       for (OnPos = 0; OnPos < length(sjCrosses); OnPos++) {
          REAL(stau)[OnPos + LastPos] =
            REAL(stauCrosses)[nPos + (int) REAL(sjCrosses)[OnPos]] *
            REAL(stauCrosses)[nPos + (int) REAL(skCrosses)[OnPos]];
       }
     } else if ((CrossLevel == 3 || CrossLevel == 6)) {
        for (OnPos = 0; OnPos < length(sjCrossesO); OnPos++) {
          REAL(stau)[OnPos + LastPos] =
            REAL(stauCrosses)[nPos + (int) REAL(sjCrossesO)[OnPos]] *
            REAL(stauCrosses)[nPos + (int) REAL(skCrossesO)[OnPos]];
        }    
     } else if ((CrossLevel == 4 || CrossLevel == 7)
         && BetaHybridLevel < 2 && REAL(sAsymNotASym)[OntauCross] == 1) {
       for (OnPos = 0; OnPos < length(sjCrosses); OnPos++) {
          REAL(stau)[OnPos + LastPos] =
            REAL(stauCrosses)[nPos + (int) REAL(sjCrosses)[OnPos]] +
            REAL(stauCrosses)[nPos + (int) REAL(skCrosses)[OnPos]];
       }
     } else if ((CrossLevel == 4 || CrossLevel == 7)) {
        for (OnPos = 0; OnPos < length(sjCrossesO); OnPos++) {
          REAL(stau)[OnPos + LastPos] =
            REAL(stauCrosses)[nPos + (int) REAL(sjCrossesO)[OnPos]] +
            REAL(stauCrosses)[nPos + (int) REAL(skCrossesO)[OnPos]];
        }    
     } else if ((CrossLevel == 9)
         && BetaHybridLevel < 2 && REAL(sAsymNotASym)[OntauCross] == 1) {
       int MorePos = 0;
       for (OnPos = 0; OnPos < length(sjCrosses); OnPos++) {
          REAL(stau)[OnPos + LastPos] =
            REAL(stauCrosses)[nPos + (int) REAL(sjCrosses)[OnPos]] *
            REAL(stauCrosses)[nPos + (int) REAL(skCrosses)[OnPos]];
       }
       MorePos = OnPos;
       for (OnPos = 0; OnPos < length(sjCrossesO); OnPos++) {
           REAL(stau)[MorePos + OnPos + LastPos] =
            REAL(stauCrosses)[nPos + (int) REAL(skCrossesO)[OnPos]] *
            REAL(stauCrosses)[nPos + (int) REAL(sjCrossesO)[OnPos]];        
       }
     } else if (CrossLevel == 9) {
       int MorePos = 0;
       for (OnPos = 0; OnPos < length(sjCrossesO); OnPos++) {
          REAL(stau)[OnPos + LastPos] =
            REAL(stauCrosses)[nPos + (int) REAL(sjCrossesO)[OnPos]] *
            REAL(stauCrosses)[nPos + (int) REAL(skCrossesO)[OnPos]];
       }
       MorePos = OnPos;
       for (OnPos = 0; OnPos < length(sjCrossesO); OnPos++) {
           REAL(stau)[MorePos + OnPos + LastPos] =
            REAL(stauCrosses)[nPos + (int) REAL(skCrossesO)[OnPos]] *
            REAL(stauCrosses)[nPos + (int) REAL(sjCrossesO)[OnPos]];        
       }
     } else if ((CrossLevel == 10)
         && BetaHybridLevel < 2 && REAL(sAsymNotASym)[OntauCross] == 1) {
       int MorePos = 0;
       for (OnPos = 0; OnPos < length(sjCrosses); OnPos++) {
          REAL(stau)[OnPos + LastPos] =
            REAL(stauCrosses)[nPos + (int) REAL(sjCrosses)[OnPos]] +
            REAL(stauCrosses)[nPos + (int) REAL(skCrosses)[OnPos]];
       }
       MorePos = OnPos;
       for (OnPos = 0; OnPos < length(sjCrossesO); OnPos++) {
           REAL(stau)[MorePos + OnPos + LastPos] =
            REAL(stauCrosses)[nPos + (int) REAL(skCrossesO)[OnPos]] +
            REAL(stauCrosses)[nPos + (int) REAL(sjCrossesO)[OnPos]];        
       }
     } else if (CrossLevel == 10) {
       int MorePos = 0;
       for (OnPos = 0; OnPos < length(sjCrossesO); OnPos++) {
          REAL(stau)[OnPos + LastPos] =
            REAL(stauCrosses)[nPos + (int) REAL(sjCrossesO)[OnPos]] +
            REAL(stauCrosses)[nPos + (int) REAL(skCrossesO)[OnPos]];
       }
       MorePos = OnPos;
       for (OnPos = 0; OnPos < length(sjCrossesO); OnPos++) {
           REAL(stau)[MorePos + OnPos + LastPos] =
            REAL(stauCrosses)[nPos + (int) REAL(skCrossesO)[OnPos]] +
            REAL(stauCrosses)[nPos + (int) REAL(sjCrossesO)[OnPos]];        
       }
     } 
   }
   return(1);
 }
 
 StructDpBeta *MakeStructDpBeta(SEXP sDpBeta) {
   StructDpBeta *StDpBeta = new(StructDpBeta);
   SEXP dimDpBeta = getAttrib(sDpBeta, R_DimSymbol);
   int ntau = INTEGER(dimDpBeta)[1];
   int nBeta = INTEGER(dimDpBeta)[0];
   
   int nni = 0;
   int TotBeta = 0;
   if (isInteger(sDpBeta)) {
     for (nni = 0; nni < length(sDpBeta); nni++) {
       TotBeta += INTEGER(sDpBeta)[nni];   
     }
   } else {
      for (nni = 0; nni < length(sDpBeta); nni++) {
       TotBeta += (int) REAL(sDpBeta)[nni];   
     }  
   }
   
   StDpBeta->TotLen = TotBeta;
   StDpBeta->ntau = ntau;
   StDpBeta->nBeta = nBeta;
   ;;
   // Okay
   StDpBeta->WhereIstauX = (unsigned short int *)
     calloc( ntau, sizeof(unsigned short int));
   StDpBeta->LengthOftauX = (unsigned short int *)
     calloc( ntau, sizeof(unsigned short int));
   StDpBeta->AllListOfXs = (unsigned short int *)
     calloc( TotBeta, sizeof(unsigned short int));
   
   int itau; int iBeta;
   int nLengthOntau = 0;
   int Totaltau = 0;
   nni = 0;
   if (isInteger(sDpBeta)) {
     for (itau = 0; itau < ntau; itau++) {
       nLengthOntau = 0;
       StDpBeta->WhereIstauX[itau] = Totaltau;
       for (iBeta = 0; iBeta < nBeta; iBeta++) {
         if(INTEGER(sDpBeta)[nni] == 1) {
            StDpBeta->AllListOfXs[Totaltau] = (unsigned short int) iBeta;
            Totaltau++; nLengthOntau++;
         }
         nni++;
       }
       StDpBeta->LengthOftauX[itau] = nLengthOntau;
     }
   } else {
      for (itau = 0; itau < ntau; itau++) {
       nLengthOntau = 0;
       StDpBeta->WhereIstauX[itau] = Totaltau;
       for (iBeta = 0; iBeta < nBeta; iBeta++) {
         if(REAL(sDpBeta)[nni] == 1) {
            StDpBeta->AllListOfXs[Totaltau] = (unsigned short int) iBeta;
            Totaltau++; nLengthOntau++;
         }
         nni++;
       }
       StDpBeta->LengthOftauX[itau] = nLengthOntau;
     }    
   }
   //Rprintf("Printing StDpBeta: \n");
   //unsigned short int *ListOfLocs = NULL;
   //for (itau = 0; itau < ntau; itau++) {
   //  ListOfLocs = GetListX(StDpBeta, itau);
   //  for (iBeta = 0; iBeta < GetLenX(StDpBeta, itau); iBeta++) {
   //    Rprintf(" %d ", ListOfLocs[iBeta]);
   //  }
   //  Rprintf(" \n"); R_FlushConsole();
   //}
   return(StDpBeta);
 }
 
 void deleteStDpBeta(StructDpBeta *StDpBeta) {
   free(StDpBeta->LengthOftauX);
   free(StDpBeta->WhereIstauX);
   free(StDpBeta->AllListOfXs);
   free(StDpBeta);
 }

/*
int CrossImpute36(int numj, double *Onstaus, double *OnstauCrosses, int UseDiag,
    double *BetaCrosses,
    SEXP sjCrosses, SEXP sjCrossesO, SEXP skCrosses, SEXP skCrossesO, double mtau, double dftau);
int CrossImpute9(int numj, double *Onstaus, double *OnstauCrosses, int UseDiag,
    double *BetaCrosses,
    SEXP sjCrosses, SEXP sjCrossesO, SEXP skCrosses, SEXP skCrossesO, double mtau, double dftau); 
int CrossImpute47(int numj, double *Onstaus, double *OnstauCrosses, int UseDiag,
    double *BetaCrosses,
    SEXP sjCrosses, SEXP sjCrossesO, SEXP skCrosses, SEXP skCrossesO, double mtau, double dftau);
int CrossImpute10(int numj, double *Onstaus, double *OnstauCrosses, int UseDiag,
    double *BetaCrosses,
    SEXP sjCrosses, SEXP sjCrossesO, SEXP skCrosses, SEXP skCrossesO, double mtau, double dftau);
    
    
int CrossImpute(int numj, int CrossModel, int BetaHybridLevel, SEXP stau,
   double *BetaCrosses,
   SEXP stauCrossStarts, SEXP sAsymNotASym, SEXP mtauCrosses, SEXP sdftauCrosses,
   SEXP stauCrosses, SEXP sjCrosses, SEXP sjCrossesO, SEXP skCrosses, SEXP skCrossesO) {
int OnCrossVals = 0;
int UseDiag = 0;  if (BetaHybridLevel < 2) {UseDiag = 1;}
for (OnCrossVals = 0; OnCrossVals < length(stauCrossStarts); OnCrossVals++) {
  if (CrossModel == 3 || CrossModel == 6) {
    CrossImpute36(numj, ((double*) (REAL(stau) + (int) REAL(stauCrossStarts)[OnCrossVals])),
    BetaCrosses,
    REAL(stauCrosses) + numj * OnCrossVals, UseDiag * (int) REAL(sAsymNotASym)[OnCrossVals],
    sjCrosses, sjCrossesO, skCrosses, skCrossesO,
    REAL(mtauCrosses)[OnCrossVals], REAL(sdftauCrosses)[OnCrossVals]);
  } else if (CrossModel == 4 || CrossModel == 7) {
     CrossImpute47(numj, REAL(stau) + ((int)REAL(stauCrossStarts)[OnCrossVals]),
    BetaCrosses,
    REAL(stauCrosses) + numj * OnCrossVals, UseDiag * (int) REAL(sAsymNotASym)[OnCrossVals],
    sjCrosses, sjCrossesO, skCrosses, skCrossesO,
    REAL(mtauCrosses)[OnCrossVals], REAL(sdftauCrosses)[OnCrossVals]); 
  } else if (CrossModel == 9) {
    CrossImpute9(numj, REAL(stau) + ((int) REAL(stauCrossStarts)[OnCrossVals]),
      BetaCrosses,
      REAL(stauCrosses) + numj * OnCrossVals, UseDiag * (int) REAL(sAsymNotASym)[OnCrossVals],
      sjCrosses, sjCrossesO, skCrosses, skCrossesO,
      REAL(mtauCrosses)[OnCrossVals], REAL(sdftauCrosses)[OnCrossVals]);
  } else if (CrossModel == 10) {
    CrossImpute10(numj, REAL(stau) ((int) REAL(stauCrossStarts)[OnCrossVals]),
      BetaCrosses,
      REAL(stauCrosses) + numj * OnCrossVals, UseDiag * (int) (REAL(sAsymNotASym)[OnCrossVals]),
      sjCrosses, sjCrossesO, skCrosses, skCrossesO,
      (double) REAL(mtauCrosses)[OnCrossVals], (double) (REAL(sdftauCrosses)[OnCrossVals]));  
  }
}


return(1);  
}
*/

int UpdateTNoise(SEXP sSigmaSq, SEXP sBeta, SEXP sX, SEXP sY, SEXP sXtX, SEXP sXtY,
   SEXP sSumYSq,
   SEXP sfW, SEXP sVecOWeights, double dfTNoise, SEXP sLikelihood,
   SEXP sMeanWeights, SEXP OldBeta, SEXP Convergence) {
  int ii;
  int nBeta = length(sBeta);  int nY = length(sY); int One = 1;
  double Resid = 0.0;
  REAL(sLikelihood)[0] = -.5 * log(REAL(sSigmaSq)[0]) * nY;
  double iSigmaSq = 1.0 / REAL(sSigmaSq)[0];
  if (Rf_isNull(OldBeta)) {
  for (ii = 0; ii < nY; ii++) {
    Resid = REAL(sY)[ii] -
      F77_CALL(ddot)(&nBeta, REAL(sX) + ii, &nY, REAL(sBeta), &One);
    Resid = Sq(Resid) * iSigmaSq;
    REAL(sVecOWeights)[ii] = rgamma( (dfTNoise + 1) * .5,1.0) / 
      (( Resid + dfTNoise ) * .5);  
    REAL(sLikelihood)[0] -= .5*(dfTNoise + 1) * log( 1 + Resid / dfTNoise);
  }
  } else {
    if (Rf_isNull(Convergence) || Rf_length(Convergence) < 2) {
      for (ii = 0; ii < nY; ii++) {
      Resid = REAL(sY)[ii] -
        F77_CALL(ddot)(&nBeta, REAL(sX) + ii, &nY, REAL(sBeta), &One);
      Resid = Sq(Resid) * iSigmaSq;
      REAL(sVecOWeights)[ii] =  (dfTNoise + 1) / 
        (( Resid + dfTNoise ) * .5);  
      REAL(sLikelihood)[0] -= .5*(dfTNoise + 1) * log( 1 + Resid / dfTNoise);
    }  
  } else {
    for (ii = 0; ii < nY; ii++) {
      Resid = REAL(sY)[ii] -
        F77_CALL(ddot)(&nBeta, REAL(sX) + ii, &nY, REAL(sBeta), &One);
      Resid = Sq(Resid) * iSigmaSq;
      REAL(sVecOWeights)[ii] =  (dfTNoise + 1) / 
        (( Resid + dfTNoise ) * .5 + 1.0);  
      REAL(sLikelihood)[0] -= .5*(dfTNoise + 1) * log( 1 + Resid / dfTNoise);
      if (isnan(REAL(sVecOWeights)[ii])) {
        Rprintf("UpdateTNoise, error, we had Resid = %f, dfTNoise = %f, but Updated VecOWeights[%d] = %f\n",
          Resid, dfTNoise, ii, REAL(sVecOWeights)[ii]);
        return(-1);
      }
    }    
  }
  }
  int WeightRet = CalculateWeightedXtXandXtY(sY, sX, sVecOWeights, sfW, 
       sXtY, sXtX, sSumYSq); 
  if (WeightRet == -1) {
    Rprintf("UpdateTNoise: WeightRet returns error, we apparently have NANs\n");
    return(-1);
  }
       
  if (!Rf_isNull(sMeanWeights) && isReal(sMeanWeights) && 
    length(sMeanWeights) >= length(sVecOWeights)) {
   int nLen = length(sVecOWeights); double OneD = 1.0; int One = 1; 
   F77_CALL(daxpy)(&nLen, &OneD, REAL(sVecOWeights), &One,
     REAL(sMeanWeights), &One);
  }
 
  return(1);
}

int CrossImpute36(int numj, double *Onstaus, double *OnstauCrosses, int UseDiag,
    double *BetaCrosses,
    SEXP sjCrosses, SEXP sjCrossesO, SEXP skCrosses, SEXP skCrossesO, double mtau, double dftau) {
    int ii = 0;
    for (ii = 0; ii < numj; ii++) {OnstauCrosses = 0;}
    int OnPos;
    int CountVals = numj;
    if (UseDiag == 1) {
      for (OnPos = 0; OnPos < length(sjCrosses); OnPos++) {
         OnstauCrosses[(int) REAL(skCrossesO)[OnPos]] +=
           Sq(BetaCrosses[(int) REAL(sjCrosses)[OnPos]]) /
            OnstauCrosses[(int) REAL(skCrosses)[OnPos]] +
           Sq(BetaCrosses[(int) REAL(skCrosses)[OnPos]]) /
            OnstauCrosses[(int) REAL(sjCrosses)[OnPos]];            
      }
    } else {
      CountVals = numj -1 ;
      for (OnPos = 0; OnPos < length(sjCrossesO); OnPos++) {
         OnstauCrosses[(int) REAL(skCrossesO)[OnPos]] +=
           Sq(BetaCrosses[(int) REAL(sjCrossesO)[OnPos]]) /
            OnstauCrosses[(int) REAL(skCrossesO)[OnPos]] +
           Sq(BetaCrosses[(int) REAL(skCrossesO)[OnPos]]) /
            OnstauCrosses[(int) REAL(sjCrossesO)[OnPos]];            
      }       
    }
    for (ii = 0; ii < numj; ii++) {
      OnstauCrosses[ii] = (mtau + OnstauCrosses[ii]) /
         (rgamma(dftau + .5 * CountVals,1.0));
    }
    return(1);
}
int CrossImpute9(int numj, double *Onstaus, double *OnstauCrosses, int UseDiag,
    double *BetaCrosses,
    SEXP sjCrosses, SEXP sjCrossesO, SEXP skCrosses, SEXP skCrossesO, double mtau, double dftau) {
    int ii = 0;
    for (ii = 0; ii < numj; ii++) {OnstauCrosses = 0;}
    int OnPos;
    int CountVals = numj * 2 - 1;
    int MorePos;
    if (UseDiag == 1) {
      for (OnPos = 0; OnPos < length(sjCrosses); OnPos++) {
         OnstauCrosses[(int) REAL(sjCrosses)[OnPos]] +=
           Sq(BetaCrosses[(int) REAL(sjCrosses)[OnPos]]) /
            OnstauCrosses[(int) REAL(skCrosses)[OnPos]];
         OnstauCrosses[(int) REAL(skCrosses)[OnPos]] +=
           Sq(BetaCrosses[(int) REAL(skCrosses)[OnPos]]) /
            OnstauCrosses[(int) REAL(sjCrosses)[OnPos]];            
      }
      MorePos = OnPos;
      for (OnPos = 0; OnPos < length(sjCrossesO); OnPos++) {
         OnstauCrosses[(int) REAL(skCrossesO)[OnPos]] +=
           Sq(BetaCrosses[MorePos+(int) REAL(sjCrossesO)[OnPos]]) /
            OnstauCrosses[(int) REAL(skCrossesO)[OnPos]] +
           Sq(BetaCrosses[MorePos+(int) REAL(skCrossesO)[OnPos]]) /
            OnstauCrosses[(int) REAL(sjCrossesO)[OnPos]];            
      }      
    } else {
      CountVals = numj -1 + numj -1;
      for (OnPos = 0; OnPos < length(sjCrossesO); OnPos++) {
         OnstauCrosses[(int) REAL(sjCrossesO)[OnPos]] +=
           Sq(BetaCrosses[(int) REAL(sjCrossesO)[OnPos]]) /
            OnstauCrosses[(int) REAL(skCrossesO)[OnPos]] +
           Sq(BetaCrosses[(int) REAL(skCrossesO)[OnPos]]) /
            OnstauCrosses[(int) REAL(sjCrossesO)[OnPos]];            
      }
      MorePos = OnPos;
      for (OnPos = 0; OnPos < length(sjCrossesO); OnPos++) {
         OnstauCrosses[(int) REAL(skCrossesO)[OnPos]] +=
           Sq(BetaCrosses[MorePos+ (int) REAL(sjCrossesO)[OnPos]]) /
            OnstauCrosses[(int) REAL(skCrossesO)[OnPos]] +
           Sq(BetaCrosses[(int) REAL(skCrossesO)[OnPos]]) /
            OnstauCrosses[(int) REAL(sjCrossesO)[OnPos]];            
      }        
    }
    for (ii = 0; ii < numj; ii++) {
      OnstauCrosses[ii] = (mtau + OnstauCrosses[ii]) /
         (rgamma(dftau + CountVals * .5,1.0));
    }
    return(1);
}

int CrossImpute47(int numj, double *Onstaus, double *OnstauCrosses, int UseDiag,
    double *BetaCrosses,
    SEXP sjCrosses, SEXP sjCrossesO, SEXP skCrosses, SEXP skCrossesO, double mtau, double dftau) {
    int ii = 0;
    for (ii = 0; ii < numj; ii++) {OnstauCrosses = 0;}
    int OnPos;
    int CountVals = numj;
    //double ConsiderBeta1; double ConsiderBeta2;
    double sqrtVariance = 0.0;
    if (UseDiag == 1) {
      for (OnPos = 0; OnPos < length(sjCrosses); OnPos++) {
         if (REAL(sjCrosses)[OnPos] == REAL(skCrosses)[OnPos]) {
           OnstauCrosses[(int) REAL(sjCrosses)[OnPos]] = 1;
         
         }
         sqrtVariance = OnstauCrosses[(int) REAL(sjCrosses)[OnPos]];
         OnstauCrosses[OnPos] +=
           Sq(BetaCrosses[(int) REAL(sjCrosses)[OnPos]]) /
            OnstauCrosses[(int) REAL(skCrosses)[OnPos]] +
           Sq(BetaCrosses[(int) REAL(skCrosses)[OnPos]]) /
            OnstauCrosses[(int) REAL(sjCrosses)[OnPos]];            
      }
    } else {
      CountVals = numj -1 ;
      for (OnPos = 0; OnPos < length(sjCrossesO); OnPos++) {
         OnstauCrosses[OnPos] +=
           Sq(BetaCrosses[(int) REAL(sjCrossesO)[OnPos]]) /
            OnstauCrosses[(int) REAL(skCrossesO)[OnPos]] +
           Sq(BetaCrosses[(int) REAL(skCrossesO)[OnPos]]) /
            OnstauCrosses[(int) REAL(sjCrossesO)[OnPos]];            
      }       
    }
    for (ii = 0; ii < numj; ii++) {
      OnstauCrosses[ii] = (mtau + OnstauCrosses[ii]) /
         (rgamma(dftau + CountVals * .5,1.0));
    }
    return(1);
}

int UpdateSigma(SEXP sSigmaSq, SEXP sY, SEXP sBeta, SEXP sXtX, SEXP sXtY, 
                 SEXP sfW, SEXP sSumYSq,
                 SEXP smSigma, SEXP sdfSigma, SEXP sLikelihood,
                 SEXP OldBeta, SEXP Convergence) {
 int nY = length(sY);               
 int nBeta = INTEGER(GET_DIM(sXtX))[0];
 double OneD = 1.0; int One = 1;  double ZeroD = 0.0;
 double CurTot = 0;
 char MyUpperLoc = UpLo;
 double BetaXtX = 0.0;
 
 F77_CALL(dsymv)(&MyUpperLoc, &nBeta, &OneD,
		REAL(sXtX), &nBeta,
		REAL(sBeta), &One, &ZeroD, REAL(sfW), &One);
 CurTot = F77_CALL(ddot)(&nBeta, REAL(sBeta), &One, REAL(sfW), &One); 
 BetaXtX = CurTot;
 if (CurTot <= 0) {
   Rprintf("UpdateSigma, error, after first dot we have CurTot <= 0, not possible!\n",
     CurTot); R_FlushConsole();
   return(-1);
 }
 CurTot -= 2 * F77_CALL(ddot)(&nBeta, REAL(sBeta), &One, REAL(sXtY), &One);
 CurTot += REAL(sSumYSq)[0];
 if (REAL(sSumYSq)[0] <= 0) {
   Rprintf("Updatesigma Error, REAL(sSumYSq)[0] = %f < 0", REAL(sSumYSq)[0]);
   return(-1);
 }
  if (.5 * REAL(sdfSigma)[0] + nY * .5 <= 0) {
    Rprintf("UpdateSigma, wacky, we have that the gamma input is negative, %f, %f\n",
      REAL(sdfSigma)[0], nY);    R_FlushConsole();
    return(-1);
  }
  if ( REAL(smSigma)[0] + CurTot <= 0) {
    Rprintf("UpdateSigma, wacky, we have that numerical in sSigmaSq < 0, CurTot = %f, smSigma = %f\n",
      CurTot, REAL(smSigma)); R_FlushConsole();
    Rprintf("Notted that Beta XtY = %f\n", F77_CALL(ddot)(&nBeta, REAL(sBeta), &One, REAL(sXtY), &One),
    BetaXtX); R_FlushConsole();
    return(-1);  
  }
 
 if (Rf_isNull(OldBeta)) {
  
   REAL(sSigmaSq)[0] =  (CurTot*.5 + .5 * REAL(smSigma)[0]) / 
      (rgamma(.5 *REAL(sdfSigma)[0] + nY *.5, 1.0));
 } else {
   if (Rf_isNull(Convergence) || Rf_length(Convergence) < 2) {
     REAL(sSigmaSq)[0] = (CurTot*.5 + .5 * REAL(smSigma)[0]) /
       (.5 *REAL(sdfSigma)[0] + nY *.5-1.0);
   } else {
     REAL(sSigmaSq)[0] = (CurTot + REAL(smSigma)[0]) /
       (REAL(sdfSigma)[0] + nY + 1.0);   
   }
 }
 if (CurTot <= 0) {
   Rprintf("UpdateSigmaSq Error: CurTot = %f\n", CurTot); R_FlushConsole();
   return(-1);
 }
 if (REAL(sSigmaSq)[0] <= 0) {
   Rprintf("UpdateSigmaSq Error: Inexplicably, sSigma = %f\n", REAL(sSigmaSq)[0]);
   R_FlushConsole();
   return(-1);
 }
// REAL(sSigmaSq)[0] = (CurTot *.5 + .5 * REAL(smSigma)[0]) /
//                  ( .5 * REAL(sdfSigma)[0] + nY * .5);
// Rprintf("CurTot was %f, Sigma = %d, %f, %f, %f\n", CurTot, REAL(sSigmaSq)[0],
//   F77_CALL(ddot)(&nBeta, REAL(sBeta), &One, REAL(sfW), &One),
//   F77_CALL(ddot)(&nBeta, REAL(sBeta), &One, REAL(sXtY), &One),
//   REAL(sSumYSq)[0]);
//   R_FlushConsole();
 REAL(sLikelihood)[0] = - .5 * nY * log(REAL(sSigmaSq)[0])
                        - .5 * CurTot / REAL(sSigmaSq)[0]; 
 if (isnan(REAL(sSigmaSq)[0])) {
   Rprintf("UpdateSigmaSq Error: we had CurTot = %f, smSigma=%f, but gog nan SigmaSq\n", CurTot, smSigma);
   return(-1);
 }
 return(1);             
}


  int  TestAlgorithmInputs(SEXP snumj, SEXP sX, SEXP sY, SEXP sXtX, SEXP sXtY,
   SEXP sSumYSq, SEXP sBeta, SEXP stau, SEXP sSigmaSq, SEXP sLikelihood,
   SEXP sCodaChain,
   SEXP sChainLikelihood,
   SEXP sQ, SEXP sInvQ, SEXP sInvSqQ,
   SEXP sDpBeta, SEXP sTauFixed, SEXP dftau, SEXP mtau,
   SEXP smSigma, SEXP sdfSigma,
   SEXP sMyWantDiag,
   SEXP sCrossModel, SEXP sBetaHybridLevel,
   SEXP stauCrosses, SEXP sAsymNotASym,
   SEXP jCross, SEXP kCross, SEXP jCrossO, SEXP kCrossO,
   SEXP sVecOWeights, SEXP sfW, SEXP sdfTNoise, 
   SEXP stauHybridNoise, SEXP stoggleHybrid, SEXP sSigmaDeltaHybrid,
   SEXP sVerbose, SEXP sMeanWeights, SEXP sAllWeights, SEXP sCheckNANINF,
   SEXP sStartIter,    SEXP sInformEvery,
   SEXP ListUnknownGender, SEXP GXX, 
   SEXP ImputedGender, SEXP PriorGender,
   SEXP ImputeGenderChains,
   SEXP Wanted, SEXP Extractor, SEXP sState, SEXP NamesSpace, SEXP OldBeta, SEXP Convergence){
   if (!isInteger(snumj) && !isReal(snumj)) {
     error("snumj Is Wrong");
   }
   int numj = (int) GetFirstInteger(snumj);
   int dimX1 = INTEGER(GET_DIM(sX))[0]; int dimX2 = INTEGER(GET_DIM(sX))[1];
   int dimY = length(sY);  
   
   int Verbose = -1;
   if (!Rf_isNull(sVerbose)) {
     Verbose = GetFirstInteger(sVerbose);
   }
   Verbose =-1;
   if (isNull(sStartIter)) {
     error("sStartIter is NULL!");
   } else if (!isInteger(sStartIter) && !isReal(sStartIter)) {
     error("sStartIter isn't integer or real!");
   }  
   if (Verbose > 1) {
      Rprintf("Testing sCrossModel!"); R_FlushConsole();
   }
   if (Rf_isNull(sCrossModel) || (!isInteger(sCrossModel) && !isReal(sCrossModel))) {
     error("sCrossModel Is Wrong");
   }
   if (!isInteger(sBetaHybridLevel) && !isReal(sBetaHybridLevel)) {
     error("sBetaHybridLevel Is Wrong");
   }
   if (!isReal(sLikelihood)) {
     error("sLikelihood isn't Real, can't input!");
   }
   if (!isReal(sSumYSq)) {
     error("sSumYSq isn't Real, can't input!");
   }
   if (length(smSigma) < 1) {
     error("No Good information on smSigma!");
   }
   if (isReal(sdfTNoise) && REAL(sdfTNoise)[0] > 0) {
     if (length(sVecOWeights) != length(sY)) {
       error("Despite tnoise, the VecOWeights is not long enough");
     }
     if (length(sfW) < dimX2  || length(sfW) < length(sY)) {
       error("Despite tnoise, the sfW is not long enough");
     }   
   }
   if (length(dftau) != length(stau)) {
     error("dftau = %d length not comparable to stau = %d",
       length(dftau), length(stau));
   }
   if (length(mtau) != length(stau)) {
     error("mtau = %d length not comparable to stau = %d",
       length(mtau), length(stau));
   }   
  
   if (Verbose > 2) {
     Rprintf("Testing sTauCrosses!\n "); R_FlushConsole();
   }
   if (!Rf_isNull(stauCrosses) && length(sAsymNotASym) * numj != length(stauCrosses)) {
     error("sAsymNotASym not compatible with stauCrosses\n");
   }
   
   if (Verbose > 2) {
     Rprintf("Testing DpBeta!\n "); R_FlushConsole();
   }
   if (INTEGER(GET_DIM(sDpBeta))[0] != dimX2) {
     Rprintf("length(Beta) = %d, dimX2 = %d, dimX1 = %d", length(sBeta),
      dimX2, dimX1);
     Rprintf(",  But Dim(sDpBeta) == c(%d,%d) \n",
      INTEGER(GET_DIM(sDpBeta))[0], INTEGER(GET_DIM(sDpBeta))[1]);
     R_FlushConsole();
     error("sDpBeta not enough dimensions for Beta");   
   }
   if (INTEGER(GET_DIM(sDpBeta))[1] - length(sTauFixed) != length(stau)) {
     Rprintf("DpBeta Dimension is %d, %d, but TsauFixed = %d, stau = %d\n",
       INTEGER(GET_DIM(sDpBeta))[0] , INTEGER(GET_DIM(sDpBeta))[1] ,
       length(sTauFixed), length(stau)); R_FlushConsole();
     error("sDpBeta not enough dimensions for tau");   
   }
   if (length(sBeta) != dimX2) {
     error("sBeta =%d, is not long enough compared to dimX2 = %d",
       length(sBeta), dimX2);
   }
   if (length(sMyWantDiag) != dimX2) {
     error("MyWantDiag =%d, is not long enough compared to dimX2 = %d",
       length(sMyWantDiag), dimX2);   
   }
   if (dimY != dimX1) {
     error("sX and sY do not have same length, bad lengths");   
   }
   if (length(sChainLikelihood) != INTEGER(GET_DIM(sCodaChain))[0]) {
     error("CodaChain and sChainLikelihood not of same length");   
   }
   if (INTEGER(GET_DIM(sXtX))[0] != dimX2 ||
       INTEGER(GET_DIM(sXtX))[1] != dimX2 
      ) {
     error("sXtX does not have right dimensions to work as hat matrix"); 
   }
   if (length(sXtY) != INTEGER(GET_DIM(sXtX))[0]) {
    error("DrawABayesRegression: sXtY is not right Length = %d!\n",
      length(sXtY));
   }    
   if (INTEGER(GET_DIM(sQ))[0] != dimX2 ||
       INTEGER(GET_DIM(sQ))[1] != dimX2 
      ) {
     error("sQ does not have right dimensions to work as hat matrix"); 
   }
   if (INTEGER(GET_DIM(sInvQ))[0] != INTEGER(GET_DIM(sInvQ))[1] ||
       INTEGER(GET_DIM(sInvQ))[1] != INTEGER(GET_DIM(sInvSqQ))[1] ||
       INTEGER(GET_DIM(sInvSqQ))[1] != INTEGER(GET_DIM(sInvSqQ))[0] ||
       INTEGER(GET_DIM(sInvQ))[0] > dimX2
      ) {
     error("sInvQ or sInvSqQ do not have right dimensions to work for fractional simulation"); 
   }
   if (Verbose > 2) {
     Rprintf("Testing jCross, kCross!\n "); R_FlushConsole();
   }
   if (length(jCross) != numj * (numj+1) /2) {
     error("jCross Given is Of wrong Length!");
   }
   if (length(kCross) != numj * (numj+1) /2) {
     error("kCross Given is Of wrong Length!");
   }
   if (length(jCrossO) != numj * (numj-1) /2) {
     error("jCrossO Given is Of wrong Length! = %d not %d",
       length(jCrossO), numj * (numj-1)/2);
   }
   if (length(kCrossO) != numj * (numj-1) /2) {
     error("kCrossO Given is Of wrong Length!");
   }
   if (Verbose > 2) {
     Rprintf("Testing dimX!\n "); R_FlushConsole();
   }
   if (length(sfW) < dimX2) {
     error("sfW length = %d, not long enough for Sigma \n",
      length(sfW));
   }
   
   if (!Rf_isNull(OldBeta)) {
     if (!Rf_isReal(OldBeta)) {
       Rf_error("Hey, Test inputs got an invalid OldBeta! its not null but not real"); 
     }
     if (Rf_length(OldBeta)  != Rf_length(sBeta)) {
       Rf_error("Hey, Test inputs got an invalid OldBeta! its length is %d, not the same as Beta!"); 
     }
   }
   if (Verbose > 1) {
     PrintFeatures(sInformEvery, (char*) "InformEvery");
     PrintFeatures(ListUnknownGender, (char*)"ListUnknownGender");
     PrintFeatures(GXX, (char*)"GXX");
     PrintFeatures(ImputedGender, (char*)"ImputedGender");
     PrintFeatures(PriorGender, (char*)"PriorGender");
     PrintFeatures(ImputeGenderChains, (char*)"ImputeGenderChains");
     PrintFeatures(Wanted, (char*)"Wanted");
     PrintFeatures(Extractor, (char*)"Extractor");
     PrintFeatures(sState, (char*)"sState");
     PrintFeatures(NamesSpace, (char*)"NamesSpace");    
   }
   return(1);
 }

 int ReplayGender(SEXP AllY, SEXP AllX, SEXP GXX, SEXP ListUnknownGender,
   SEXP ImputedGender, SEXP PriorGender, SEXP OnSigmaSq, SEXP OnWeights,
   SEXP OnBeta, SEXP sXtX, SEXP sXtY, SEXP sVecOWeights, int iIter
   ) {
   if (Rf_isNull(ListUnknownGender) || Rf_length(ListUnknownGender) == 0) {
     Rprintf("ReplayGender: Error, ListUnknownGender is NULL \n"); R_FlushConsole();
     Rf_error("ReplayGender: Give ListUnknownGender");
   }
   if (Rf_isNull(ImputedGender) || Rf_length(ImputedGender) == 0 ||
     Rf_length(ListUnknownGender) != Rf_length(ImputedGender)) {
     Rprintf("ReplayGender: Error, ImputedGender is wrong \n"); R_FlushConsole();
     Rf_error("ReplayGender: Give ImputedGender");
   }
   int jj;  double PriorG = 0.0;
   int OnUnknown = 0;
   double GEffect; double  MM = 0.0;  double Val = 0.0;  double MV= 0.0;
   for (jj = 0; jj < Rf_length(ListUnknownGender); jj++) {
    
     GEffect = (REAL(AllX)[ ANINT(ListUnknownGender,jj) + INTEGER(GET_DIM(AllX))[0]]);
     MM = ANINT(ImputedGender,jj) * 2.0 - 1.0;
     if (fabs(GEffect -MM * .5) > .01) {
       Rf_error("Error, iter = %d, before Refresh Mommy, jj = %d, OnUnknown = %d,  Imputed = %f, But AllX[jj,2] = %f, MM = %f, diff = %f\n",
         iIter, jj,  ANINT(ListUnknownGender,jj), (double) (ANINT(ImputedGender,jj)),
         GEffect, MM, fabs(GEffect-MM*.5));
     }
   }   
   SEXP DimX =  Rf_getAttrib(AllX, R_DimSymbol);
   if (Rf_isNull(DimX)) {
     Rf_error("ReplayGender: Error iter = %d, DimX is NULL! \n", iIter);
   }
   int p = INTEGER(DimX)[1];
   int n = INTEGER(DimX)[0];
   if (INTEGER(GET_DIM(GXX))[1] != p) {
     Rf_error("ReplayGender: Error, GXX does not have p=%d as wide dimension! instead %d",p,
     INTEGER(GET_DIM(GXX))[1]);
   }
   int p2 = INTEGER(GET_DIM(sXtX))[0];
   int p3 = INTEGER(GET_DIM(sXtX))[1];
   if (p2 != p3) {
     Rf_error("Error, sXtX is not symmetric! %d,%d",p2,p3);
   }
   if (p != p2) {
     Rf_error("Error, AllX has a different p = %d, but sXtX is %d,%d",p,p2,p3);
   }
  
   int One = 1;
   if (Rf_length(OnBeta) != p) {
     Rf_error("ReplayGender: iter = %d, Give Decent OnBeta", iIter);
   }
   double ImputedYNull, ImputedY1, ImputedY0; double YDiff = 0.0;
   int NumUnknowns = Rf_length(ListUnknownGender);
   SEXP DimGXX = Rf_getAttrib(GXX, R_DimSymbol);
   if (Rf_isNull(DimGXX)) {
     Rf_error("ReplayGender: iter = %d, Supply Dimensions to GXX!", iIter);
   } else if (INTEGER(DimGXX)[1] != p) {
     Rf_error("ReplayGender: Dim of GXX is wrong!");
   } else if (INTEGER(DimGXX)[0] != NumUnknowns) {
     Rf_error("ReplayGender: DimGXX[%d,%d] and NumUnknowns[%d] disagree!",
       INTEGER(DimGXX)[0], INTEGER(DimGXX)[1], NumUnknowns);
   }
   if (Rf_isNull(OnSigmaSq) || !Rf_isReal(OnSigmaSq)) {
     Rf_error("ReplayGender: Error, OnSigma Must be supplied!");
   }
   double iOnSigma = 1.0 / REAL(OnSigmaSq)[0];
   double logOdds, logOddsPost,  Post;
   char MyUpperLo = UpLo;   //char Trans = 'N'; double OneD = 1.0;
   int GotAChange = 0;
   for (jj = 0; jj < Rf_length(ListUnknownGender); jj++) {
     OnUnknown = (int) ANINT(ListUnknownGender, jj);
     if (OnUnknown >= Rf_length(AllY) || OnUnknown < 0) {
       Rf_error("ReplayGender: Error iter = %d, bad OnUnkwown = %d, n = %d\n",
         iIter, OnUnknown, Rf_length(AllY));
     }
     if (Rf_isNull(PriorGender) || Rf_length(PriorGender) == 0) {
       PriorG = 0.0;
     } else if (Rf_length(PriorGender) == 1) {
       PriorG = REAL(PriorGender)[0];
       PriorG = log(PriorG) - log(1.0-PriorG);
     } else if (Rf_length(PriorGender) == Rf_length(ListUnknownGender)) {
       PriorG = REAL(PriorGender)[jj];
       PriorG = log(PriorG) - log(1.0-PriorG);
     } else if (Rf_length(PriorGender) == Rf_length(ListUnknownGender)) {
       PriorG = REAL(PriorGender)[ANINT(ListUnknownGender, jj)];
       PriorG = log(PriorG) - log(1.0-PriorG);
     }
     double OnGender = (double) ANINT(ImputedGender, jj);
     double ReverseGender = OnGender * -2 + 1.0;
     if (REAL(AllX)[INTEGER(GET_DIM(AllX))[0] + OnUnknown] != -1.0 * ReverseGender * .5) {
      Rf_error("Error, iter = %d, AllX[%d,%d] = %f, but OnGender = %f, ReverseGender = %f\n",
        iIter, OnUnknown, 1, OnGender, ReverseGender);
     }
     F77_CALL(daxpy)(&p, &ReverseGender, 
       REAL(GXX)+jj, &NumUnknowns,
       REAL(AllX) + OnUnknown, &n );
     //Rf_error("Okay we just blanked out AllX OnUnknown = %d, with GXX[jj=%d], Reverse = %f\n",
     //  OnUnknown, jj, ReverseGender);
     ImputedYNull = F77_CALL(ddot)(&p,
       REAL(AllX) + OnUnknown, &n,
       REAL(OnBeta), &One);
     YDiff = F77_CALL(ddot)(&p, 
       REAL(GXX) + jj, &NumUnknowns,
       REAL(OnBeta), &One);
     ImputedY1 = ImputedYNull + YDiff;
     ImputedY0 = ImputedYNull - YDiff;
     logOdds = -.5 * Sq( (ImputedY1 - REAL(AllY)[OnUnknown]) ) +
       .5 * Sq( (ImputedY0 - REAL(AllY)[OnUnknown]) );
     logOdds *= iOnSigma;
     if (!Rf_isNull(OnWeights) && Rf_isReal(OnWeights) &&
       Rf_length(OnWeights) > OnUnknown) {
       logOdds *= REAL(OnWeights)[OnUnknown]; 
     }
     logOddsPost = logOdds + PriorG;
     if (logOddsPost < -15) {
       Post = exp(logOddsPost);
     } else if (logOddsPost > 10) {
       Post = 1.0 - exp(-logOddsPost);
     } else {
       Post = exp(logOddsPost);
       Post = Post / (1.0 + Post);
     }
     double OldXtY = REAL(sXtY)[1];
     if (Rf_runif(0.0,1.0) < Post) {
       if (Rf_isInteger(ImputedGender)) {
         INTEGER(ImputedGender)[jj] = 1;
       } else { REAL(ImputedGender)[jj] = 1.0; }
       ReverseGender = 1.0;
       if ((double) OnGender != 1.0) {
         Val = 2.0;
           if (!Rf_isNull(sVecOWeights) && Rf_isReal(sVecOWeights) && Rf_length(sVecOWeights) == n) {
             Val = Val * REAL(sVecOWeights)[OnUnknown];
           }
	         for (int kk = 0; kk < INTEGER(GET_DIM(AllX))[1]; kk++) {
             if (REAL(AllX)[kk * INTEGER(GET_DIM(AllX))[0] + OnUnknown] != 0.0
               && REAL(GXX)[kk * INTEGER(GET_DIM(GXX))[0] + jj] != 0.0) {
              Rf_error("Error, want to impute iter = %d, on jj = %d, OnUnknown = %d, but we get a cross zero!",
                iIter, jj, OnUnknown); 
             }
           }
           double DDotProd1 = 0.0;
           if (!Rf_isNull(sVecOWeights) && Rf_isReal(sVecOWeights) &&
             Rf_length(sVecOWeights) == n) {
             for (int gg = 0; gg < n; gg++) {
               DDotProd1 += Sq(REAL(AllX)[INTEGER(GET_DIM(AllX))[0] + gg])*
                 REAL(sVecOWeights)[gg];
             }
            DDotProd1 +=   
             Sq(REAL(GXX)[INTEGER(GET_DIM(GXX))[0] + jj]) *
             REAL(sVecOWeights)[OnUnknown];  
          } else { 
            DDotProd1 = F77_CALL(ddot)(&n,
             REAL(AllX) + INTEGER(GET_DIM(AllX))[0], &One,
             REAL(AllX) + INTEGER(GET_DIM(AllX))[0], &One) + 
             Sq(REAL(GXX)[INTEGER(GET_DIM(GXX))[0] + jj]); 
          }
           if (fabs(DDotProd1 - REAL(sXtX)[1 +INTEGER(GET_DIM(sXtX))[0]]) > .1) {
             Rprintf("Error, before making positive error change but before multiplication ");
             Rprintf("on iter = %d, well, we dot proded 2,2 on jj = %d, \n", iIter, jj); 
             Rf_error(" but OnUnknown = %d, to get %f, but we're at %f \n",
               OnUnknown, DDotProd1, REAL(sXtX)[1 +INTEGER(GET_DIM(sXtX))[0]]); 
           }
           MV = (double) Val * (double) REAL(AllY)[OnUnknown];
           //if (MV == 0.0) {
           //  Rf_error("Hey, why is MV zero for 0-1 transition, Val = %f, Y[%d] = %f\n",
           //    Val, OnUnknown, REAL(AllY)[OnUnknown]);
           //}
           F77_CALL(daxpy)(&p, &MV, REAL(GXX) + jj, &NumUnknowns, REAL(sXtY), &One);
           F77_CALL(dsyr2)(&MyUpperLo,
             &p,  &Val,
             REAL(AllX) + OnUnknown, &n, 
             REAL(GXX) + jj, &NumUnknowns, REAL(sXtX), &p
             );
       //double NewGS2 = F77_CALL(ddot)(&n,REAL(AllX)+n, &One, REAL(AllY), &One);
       //if (NewGS2 != REAL(sXtY)[1]) {
       //  Rprintf("Error, Gender change 0 to 1 on jj = %d, OnUnknown = %d right after this move", jj, OnUnknown);
       //  Rprintf("Val = %f, MV = %f, Y[%d] = %f, NumUnknowns = %d \n", Val, MV, OnUnknown, REAL(AllY)[OnUnknown], NumUnknowns);
       //  Rf_error(" you screwed up new input into XtY, XtY now %f, was %f, should be %f\n",
       //    REAL(sXtY)[1], OldXtY,NewGS2);
        // }
          /*   
           double DDotProd = F77_CALL(ddot)(&n,
             REAL(AllX) + n, &One,
             REAL(AllX) + n, &One)+
             Sq(REAL(GXX)[NumUnknowns + jj]); 
           if (fabs(DDotProd - REAL(sXtX)[1 +INTEGER(GET_DIM(sXtX))[0]]) > .1) {
             Rprintf("Error, after positive error change after multiplication ");
             Rprintf(" and copy, on iter = %d, on jj = %d, OnUnknown = %d,\n ",
               iIter, jj, OnUnknown);
             Rf_error("well, we dot proded 2,2 to get %f, but we're at %f \n",
                DDotProd, REAL(sXtX)[1 +INTEGER(GET_DIM(sXtX))[0]]); 
           }
           */
             GotAChange = 1;
       } else {Val = 0.0;  MV = 0.0;}

       F77_CALL(daxpy)(&p, 
         &ReverseGender, REAL(GXX) + jj, &NumUnknowns,
         REAL(AllX) + OnUnknown, &n);
       if (REAL(AllX)[OnUnknown + INTEGER(GET_DIM(AllX))[0]] > .51 ||
        REAL(AllX)[OnUnknown + INTEGER(GET_DIM(AllX))[0]] < .49 ) {
         Rf_error("Error iter = %d, on jj = %d, OnUnknown = %d, \n we choose 1 for reverse gender but get fake!",
           iIter, jj, OnUnknown);
       }
       //double NewGS = F77_CALL(ddot)(&n,REAL(AllX)+n, &One, REAL(AllY), &One);
       //if (fabs(NewGS - REAL(sXtY)[1]) > .1) {
       //  Rprintf("Error, Gender change 0 to 1 on jj = %d, OnUnknown = %d \n", jj, OnUnknown);
       //  Rprintf("Val = %f, MV = %f, Y[%d] = %f, NumUnknowns = %d \n", Val, MV, OnUnknown, REAL(AllY)[OnUnknown], NumUnknowns);
       //  Rf_error(" you screwed up new input into XtY, XtY now %f, was %f, should be %f\n",
       //    REAL(sXtY)[1], OldXtY,NewGS);
       //}
       //if (OnGender != 1.0) {
       //  Rf_error("Check, iter = %d, we just changed coordinate %d to gender %f, jj = %d\n",
       //  iIter, OnUnknown, 1.0, jj);
       //}
     } else {
       if (Rf_isInteger(ImputedGender)) { INTEGER(ImputedGender)[jj] = 0;
       } else {REAL(ImputedGender)[jj] = 0.0; }
       if (OnGender != 0.0) {
         Val = -2.0;
           if (!Rf_isNull(sVecOWeights) && Rf_isReal(sVecOWeights) && Rf_length(sVecOWeights) == n) {
             Val = Val * REAL(sVecOWeights)[OnUnknown];
           }
  //F77_NAME(dspr2)(const char *uplo, const int *n, const double *alpha,
  //		const double *x, const int *incx,
	//	const double *y, const int *incy, double *ap);
	         /*
           for (int kk = 0; kk < INTEGER(GET_DIM(AllX))[1]; kk++) {
             if (REAL(AllX)[kk * INTEGER(GET_DIM(AllX))[0] + OnUnknown] != 0.0
               && REAL(GXX)[kk * INTEGER(GET_DIM(GXX))[0] + jj] != 0.0) {
              Rf_error("Error, want to impute iter = %d, on jj = %d, OnUnknown = %d, but we get a cross zero!",
                iIter, jj, OnUnknown); 
             }
           }
           double DDotProd1 = F77_CALL(ddot)(&n,
             REAL(AllX) + n, &One,
             REAL(AllX) + n, &One)+
             Sq(REAL(GXX)[NumUnknowns + jj]); 
           if (fabs(DDotProd1 - REAL(sXtX)[1 +INTEGER(GET_DIM(sXtX))[0]]) > .1) {
             Rf_error("Error, before negative gender change and copy , on iter = %d,  on jj = %d, OnUnknown = %d, well, we dot proded 2,2 to get %f, but we're at %f \n",
               iIter, jj, OnUnknown, DDotProd1, REAL(sXtX)[1 +INTEGER(GET_DIM(sXtX))[0]]); 
           } */

           double ScoreUpLow = REAL(sXtX)[INTEGER(GET_DIM(sXtX))[0] + 1];
           if (fabs(REAL(AllX)[OnUnknown + n])  > 0.0001) {
             Rf_error("Error, AllX before dspr2 does not have zero at goal position!");
           }                                        
           //int pp = INTEGER(GET_DIM(AllX))[1];
           //int nn = INTEGER(GET_DIM(AllX))[0];
           //int TUnknown = INTEGER(GET_DIM(GXX))[0];
           //DSYR2(UPLO,N,ALPHA,X,INCX,Y,INCY,A,LDA)
           F77_CALL(dsyr2)(&MyUpperLo, 
             &p, &Val,
             REAL(AllX) + OnUnknown, &n, 
             REAL(GXX) + jj, &NumUnknowns,  REAL(sXtX), &p);
             
           MV = Val * REAL(AllY)[OnUnknown];
           //if (MV == 0.0) {
           //  Rf_error("Hey, why is MV zero for 1-0 transition, Val = %f, Y[%d] = %f\n",
           //    Val, OnUnknown, REAL(AllY)[OnUnknown]);
           //}     
           F77_CALL(daxpy)(&p, &MV, REAL(GXX) + jj, &NumUnknowns, REAL(sXtY), &One);   
        double NewGS2 = F77_CALL(ddot)(&n,REAL(AllX)+n, &One, REAL(AllY), &One);
       //if (NewGS2 != REAL(sXtY)[1]) {
       //  Rprintf("Error, Gender change 1 to 0 on jj = %d, OnUnknown = %d right after this move", jj, OnUnknown);
       //  Rprintf("Val = %f, MV = %f, Y[%d] = %f, NumUnknowns = %d \n", Val, MV, OnUnknown, REAL(AllY)[OnUnknown], NumUnknowns);
       //  Rf_error(" you screwed up new input into XtY, XtY now %f, was %f, should be %f\n",
       //    REAL(sXtY)[1], OldXtY,NewGS2);
       // }
          if (fabs(ScoreUpLow -REAL(sXtX)[p + 1]) > .1) {
            Rprintf("Error, Score Up low fail on negative gender change and copy \n");
            Rprintf(" on iter = %d,  on jj = %d, OnUnknown = %d, \n",
              iIter, jj, OnUnknown);
            Rf_error(" well, ScoreUpLow = %f, but we're at %f \n",
              ScoreUpLow, REAL(sXtX)[1 +INTEGER(GET_DIM(sXtX))[0]]);           
          }
          /*
           double DDotProd = F77_CALL(ddot)(&n,
             REAL(AllX) + INTEGER(GET_DIM(AllX))[0], &One,
             REAL(AllX) + INTEGER(GET_DIM(AllX))[0], &One)+
             Sq(REAL(GXX)[INTEGER(GET_DIM(GXX))[0] + jj]); 
           if (fabs(DDotProd - REAL(sXtX)[1 +INTEGER(GET_DIM(sXtX))[0]]) > .1) {
             Rf_error("Error, After negative gender change and copy , on iter = %d,  on jj = %d, OnUnknown = %d, well, we dot proded 2,2 to get %f, but we're at %f \n",
               iIter, jj, OnUnknown, DDotProd, REAL(sXtX)[1 +INTEGER(GET_DIM(sXtX))[0]]); 
           }
           */
          GotAChange = 1;
       } else {
         MV = 0.0;  Val = 0.0;
       }
       ReverseGender = -1.0;
         F77_CALL(daxpy)(&p, &ReverseGender, 
         REAL(GXX) + jj, &NumUnknowns,
         REAL(AllX) + OnUnknown, &n);
       if (REAL(AllX)[OnUnknown + INTEGER(GET_DIM(AllX))[0]] < -.51 ||
        REAL(AllX)[OnUnknown + INTEGER(GET_DIM(AllX))[0]] > -.49 ) {
         Rf_error("Error, iter = %d, on jj = %d, OnUnknown = %d, we choose -1 for reverse gender but get fake!",
           iIter, jj, OnUnknown);
       }    
       //double NewGS = F77_CALL(ddot)(&n,REAL(AllX)+n, &One, REAL(AllY), &One);
       //if (fabs(NewGS - REAL(sXtY)[1]) > .1) {
       //  Rprintf("Error, Gender change 1 to 0 on jj = %d, OnUnknown = %d \n", jj, OnUnknown);
       //  Rprintf("Val = %f, MV = %f, Y[%d] = %f, NumUnknowns = %d \n", Val, MV, OnUnknown, REAL(AllY)[OnUnknown], NumUnknowns);
       //  Rf_error(" you screwed up new input into XtY, XtY now %f, was %f, should be %f\n",
       //    REAL(sXtY)[1], OldXtY,NewGS);
       //}
       //if (OnGender != 0.0) {
       //  Rf_error("Check, iter = %d, we just changed coordinate %d to gender %f, jj = %d\n",
       //    iIter, OnUnknown, -1.0, jj);
       //}
     }
   
   }

   if (GotAChange > 0) {
   int i1, i2;
   for (i1 = 0; i1 < INTEGER(GET_DIM(sXtX))[0]-1; i1++) {
     for (i2 = i1+1; i2 < INTEGER(GET_DIM(sXtX))[1]; i2++) {
        REAL(sXtX)[i2 * INTEGER(GET_DIM(sXtX))[0] + i1] = 
          REAL(sXtX)[i1 * INTEGER(GET_DIM(sXtX))[0] + i2];
     }
   }}
   
   /*
   double DDotProd = F77_CALL(ddot)(&n,
     REAL(AllX) + INTEGER(GET_DIM(AllX))[0], &One,
     REAL(AllX) + INTEGER(GET_DIM(AllX))[0], &One); 
   if (fabs(DDotProd - REAL(sXtX)[1 +INTEGER(GET_DIM(sXtX))[0]]) > .1) {
     Rf_error("Error, on iter = %d, well, we dot proded 2,2 to get %f, but we're at %f \n",
       iIter, DDotProd, REAL(sXtX)[1 +INTEGER(GET_DIM(sXtX))[0]]); 
   }
   */
   MM = 0.0;
   /*for (jj = 0; jj < Rf_length(ListUnknownGender); jj++) {
    
     GEffect = (REAL(AllX)[ ANINT(ListUnknownGender,jj) + INTEGER(GET_DIM(AllX))[0]]);
     MM = ANINT(ImputedGender,jj) * 2.0 - 1.0;
     if (fabs(GEffect -MM * .5) > .01) {
       Rf_error("Error ALL AFTER Refresh Mommy, iter = %d, jj = %d, OnUnknown = %d,  Imputed = %f, But AllX[jj,2] = %f, , MM = %f, diff = %f\n",
         iIter, jj,  ANINT(ListUnknownGender,jj), (double) ANINT(ImputedGender,jj),
         GEffect, MM, fabs(GEffect-MM *.5));
     }
   }
   */
   return(1);
 }

int ImputeMissingY(SEXP MissingYIndices, SEXP sY, SEXP sXtY,
  SEXP sSumYSq, SEXP sX, SEXP sBeta, SEXP sOnSigma, SEXP dfTNoise, SEXP sVecOWeights,
  SEXP sLowCensorBound, SEXP sUpCensorBound, int iOnIter, SEXP sImputedYChain,
  int Verbose) {
  int One = 1;  int n = Rf_length(sY);
  int p = INTEGER(GET_DIM(sX))[1];
  double Expected = 0.0;
  int OnMissingii;
  //Verbose = 4;
  if (Verbose > 2) {
    Rprintf("ImputeMissingY: Starting now .\n");   R_FlushConsole();
  }
  if (Verbose > 2) {
    Rprintf("ImputeMissingY we're starting \n");
    if (!Rf_isNull(sLowCensorBound) && Rf_isReal(sLowCensorBound) && Rf_length(sLowCensorBound) > 0) {
      Rprintf("LowCensorBound = %f\n", REAL(sLowCensorBound)[0]); R_FlushConsole();
    } else {
      Rprintf("LowCensorBound is NULL!");  R_FlushConsole();
    }
    if (!Rf_isNull(sUpCensorBound) && Rf_isReal(sUpCensorBound) && Rf_length(sUpCensorBound) > 0) {
      Rprintf("UpCensorBound = %f\n", REAL(sUpCensorBound)[0]);  R_FlushConsole();
    } else {
      Rprintf("UpCensorBound is NULL!");   R_FlushConsole();
    }
    Rprintf("MissingYIndices = "); R_FlushConsole();
    if (Rf_isNull(MissingYIndices)) {
      Rf_error("ImputeMissingY: Hey, missingYIndices is null, it don't work!\n");
    } else {
      for (int jj = 0; jj < Rf_length(MissingYIndices); jj++) {
        Rprintf("%d", ANINT(MissingYIndices,jj));
        if (jj < Rf_length(MissingYIndices)-1) {
          Rprintf(","); R_FlushConsole();
        }
      }
      Rprintf("\n"); R_FlushConsole();
    }
  }
  if (!Rf_isNull(dfTNoise) && Rf_isReal(dfTNoise) && Rf_length(dfTNoise) >= 1) {
    if (Verbose >2) {
      Rprintf("ImputeY:  Well dfTNoise = %f\n", REAL(dfTNoise)[0]);
      R_FlushConsole();
    }
  }
  if (Rf_isNull(sSumYSq) || !Rf_isReal(sSumYSq) ) {
    Rf_error("Error, ImputeMissingY, sSumYSq is NULL or not Real cannot use!");
  }
  if (Rf_isNull(sOnSigma) || !Rf_isReal(sOnSigma)) {
    Rf_error("Error: ImputeMissingY, sOnsigma is a not Real\n");
  }
  
  if ((!Rf_isNull(dfTNoise) && Rf_isReal(dfTNoise)  && REAL(dfTNoise)[0] > 0.0) &&
    (Rf_isNull(sVecOWeights) || !Rf_isReal(sVecOWeights) ||
      Rf_length(sVecOWeights) != Rf_length(sY))) {
    Rprintf("Error: ImputeMissingY, sVecOWeights not of right length!\n");
    Rf_error("length(sVecOWeights) == %d, length(sY) == %d\n", 
      Rf_length(sVecOWeights), Rf_length(sY));    
  }
  if (Rf_isNull(sY) || !Rf_isReal(sY)) {
    Rf_error("Error, ImputeMissingY, Y is not Real!");
  }
  if (Rf_isNull(sX) || !Rf_isReal(sX)) {
    Rf_error("Error, ImputeMissingY, X is Not Real!");
  }
  if (Rf_isNull(sXtY) || !Rf_isReal(sXtY)) {
    Rf_error("Error, ImputeMissingY, XtY is Not Real!");
  }
  if (INTEGER(GET_DIM(sX))[1] != Rf_length(sXtY)) {
    Rf_error("Error, ImputeMissingY, dim(X) == (%d,%d), but length sXtY = %d\n",
      INTEGER(GET_DIM(sX))[0], INTEGER(GET_DIM(sX))[1], Rf_length(sXtY));
  }
  if (Rf_isNull(sBeta) || !Rf_isReal(sBeta)) {
    Rf_error("Error, sBeta is Not Real!");
  }
  if (Rf_isNull(MissingYIndices)  || (!Rf_isReal(MissingYIndices) &&
    !Rf_isInteger(MissingYIndices))) {
    Rf_error("Error, there are no MissingYIndices to make use of!\n");  
  }

  double iOSigma = 1.0 / sqrt(REAL(sOnSigma)[0]);
  double OldY = 0.0;
  double NewY = 0.0;
  double sqSigma = sqrt(REAL(sOnSigma)[0]);
  double Move = 0.0;
  for (int jj = 0; jj < Rf_length(MissingYIndices); jj++) {
    OnMissingii = ANINT(MissingYIndices, jj);
    if (OnMissingii < 0 || OnMissingii >= n) {
      Rf_error("Error: ImputeMissingY, OnMissingii = %d, but n = %d.\n",
        OnMissingii, n);
    }
    Expected = F77_CALL(ddot)(&p, REAL(sX)+OnMissingii, &n, REAL(sBeta), &One);
    OldY = REAL(sY)[OnMissingii];
    if (Rf_isNull(dfTNoise) || REAL(dfTNoise)[0] <= 0) {
       //  Y = trNormExpected(0,(L-Expected)/Sigma,(U-Expected)/Sigma  
       if (!Rf_isNull(sLowCensorBound) && Rf_isReal(sLowCensorBound) &&
         Rf_length(sLowCensorBound) >= 1 && 
         !Rf_isNull(sUpCensorBound)  && Rf_isReal(sUpCensorBound)
         && Rf_length(sUpCensorBound) >= 1) {
         NewY = Expected +sqSigma* rTruncNorm2( (REAL(sLowCensorBound)[0]-Expected) * iOSigma,
           (REAL(sUpCensorBound)[0] - Expected) * iOSigma);
       }  else if (!Rf_isNull(sLowCensorBound) && Rf_isReal(sLowCensorBound) &&
         Rf_length(sLowCensorBound)>= 1) {
         NewY = Expected +sqSigma* rTruncNorm2( (REAL(sLowCensorBound)[0]-Expected) * iOSigma,
           100.0);
       } else if (!Rf_isNull(sUpCensorBound) && Rf_isReal(sUpCensorBound)  &&
         Rf_length(sUpCensorBound)>= 1) {
          NewY= Expected +sqSigma* rTruncNorm2( -100.0,
           (REAL(sUpCensorBound)[0] - Expected) * iOSigma);
       }  else  {
          NewY= Expected +sqSigma* rTruncNorm2( -100.0,
           100.0); 
       }
       Move = NewY - OldY;
       F77_CALL(daxpy)(&p, &Move, REAL(sX) + OnMissingii, &n, REAL(sXtY), &One);
       REAL(sSumYSq)[0] +=  Sq(NewY) - Sq(OldY);
       REAL(sY)[OnMissingii] = NewY; 
    }  else {
        if (!Rf_isNull(sLowCensorBound) && Rf_isReal(sLowCensorBound)  &&
         Rf_length(sLowCensorBound)>= 1 &&
         !Rf_isNull(sUpCensorBound)  && Rf_isReal(sUpCensorBound)  &&
         Rf_length(sUpCensorBound)>= 1) {
         NewY = Expected +sqSigma* rTruncT2( REAL(dfTNoise)[0], (REAL(sLowCensorBound)[0]-Expected) * iOSigma,
           (REAL(sUpCensorBound)[0] - Expected) * iOSigma);
       }  else if (!Rf_isNull(sLowCensorBound) && Rf_isReal(sLowCensorBound) &&
         Rf_length(sLowCensorBound)>= 1 ) {
         NewY = Expected +sqSigma* rTruncT2( REAL(dfTNoise)[0],(REAL(sLowCensorBound)[0]-Expected) * iOSigma,
           1000000.0);
       } else if (!Rf_isNull(sUpCensorBound) && Rf_isReal(sUpCensorBound)  &&
         Rf_length(sUpCensorBound)>= 1) {
          NewY= Expected +sqSigma*rTruncT2( REAL(dfTNoise)[0], -1000000.0,
           (REAL(sUpCensorBound)[0] - Expected) * iOSigma);
       } else {
          NewY= Expected +sqSigma*rTruncT2(REAL(dfTNoise)[0], -100000.0, 100000.0);
       }       
       Move = (NewY - OldY) * REAL(sVecOWeights)[OnMissingii];
       F77_CALL(daxpy)(&p, &Move, REAL(sX) + OnMissingii, &n, REAL(sXtY), &One);
       REAL(sSumYSq)[0] +=  (Sq(NewY) - Sq(OldY)) * REAL(sVecOWeights)[OnMissingii];
       REAL(sY)[OnMissingii] = NewY; 
       if (isnan(REAL(sY)[OnMissingii])) {
         Rprintf("Error on ImputedYChain, we have OnMissingii = %d, while NewY = %f", OnMissingii, NewY);
         return(-1);
       }
    }
    if (!Rf_isNull(sImputedYChain) && Rf_isReal(sImputedYChain) &&
      INTEGER(GET_DIM(sImputedYChain))[0] >iOnIter  &&
      INTEGER(GET_DIM(sImputedYChain))[1] > jj) {
      REAL(sImputedYChain)[ iOnIter +
        INTEGER(GET_DIM(sImputedYChain))[0]*jj] = NewY;   
      
    }  
  
  }
  if (Verbose > 4) {
    Rprintf("ImputeMissingY: Done iter %d.\n", iOnIter); R_FlushConsole();
  }
  return(1);  
}
 
 
 
 
