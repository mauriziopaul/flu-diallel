/* ========================================================================== */
/*                                                                            */
/*   DoMeaMatrixMact.c                                                               */
/*   (c) 2001 Author                                                          */
/*                                                                            */
/*   Description                                                              */
/*                                                                            */
/* ========================================================================== */
#ifndef RNeeds 
 #include <R.h>
 #include <Rmath.h>
 #include <Rinternals.h>
 #include <R_ext/BLAS.h>
 #include <R_ext/Lapack.h>
 #include <Rdefines.h>
 #define RNeeds 0
#endif 

extern "C" {
 
SEXP DoMeAMatrixMatch(SEXP aX, SEXP bX) {
  SEXP MyMatchL = R_NilValue;
  SEXP Dim1 = GET_DIM(aX);
  if (Rf_isNull(Dim1)) {
    Rf_error("DoMeAMatrixMatch: no, aX has null dimension!\n"); R_FlushConsole();
  }
  SEXP Dim2 = GET_DIM(bX);
  if (Rf_isNull(Dim2)) {
    Rf_error("DoMeAMatrixMatch: no, bX has null dimension!\n"); R_FlushConsole();
  }
  if (Rf_length(Dim1) != 2) {
    Rf_error("DoMeAMatrixMatch: no, aX has dimension length %d\n", 
    Rf_length(Dim1)); R_FlushConsole();
  }
  if (Rf_length(Dim2) != 2) {
    Rf_error("DoMeAMatrixMatch: no, bX has dimension length %d\n", 
    Rf_length(Dim2)); R_FlushConsole();
  }
  if (INTEGER(Dim1)[1] != INTEGER(Dim2)[1]) {
    Rf_error("DoMeAMatrixMatch: no, aX has col length %d, bX has col length %d\n", 
    INTEGER(Dim1)[1], INTEGER(Dim2)[1]); R_FlushConsole();
  }
  Rf_protect(MyMatchL = Rf_allocVector(INTSXP, INTEGER(Dim1)[0]));
  int ii; int jj; int tt; int Oo1 = 0, Oo2 = 0;   int ItFit = 0;
  if (Rf_isReal(aX) && Rf_isReal(bX)) {
  for (ii = 0; ii < Rf_length(MyMatchL); ii++) {
    INTEGER(MyMatchL)[ii] = -1;
    tt = 0;
    for (jj = ii; jj < INTEGER(Dim2)[0]; jj++) {
      ItFit = 1;
      Oo1 = ii;  Oo2 = jj;
      for (tt = 0; tt < INTEGER(Dim2)[1]; tt++) {
        if (REAL(aX)[Oo1] != REAL(bX)[Oo2]) {
          ItFit = 0;
          break;
        }
        Oo1 += INTEGER(Dim1)[0];  Oo2 += INTEGER(Dim2)[0];
      }
      if (ItFit == 1) {
        INTEGER(MyMatchL)[ii] = jj+1;
        break;
      }
    }
  }  
  } else if (Rf_isInteger(aX) && Rf_isInteger(bX)) {
  for (ii = 0; ii < Rf_length(MyMatchL); ii++) {
    INTEGER(MyMatchL)[ii] = -1;
    tt = 0;
    for (jj = 0; jj < INTEGER(Dim2)[0]; jj++) {
      ItFit = 1;
      Oo1 = ii;  Oo2 = jj;
      for (tt = 0; tt < INTEGER(Dim2)[1]; tt++) {
        if (INTEGER(aX)[Oo1] != INTEGER(bX)[Oo2]) {
          ItFit = 0;
          break;
        }
        Oo1 += INTEGER(Dim1)[0];  Oo2 += INTEGER(Dim2)[0];
      }
      if (ItFit == 1) {
        INTEGER(MyMatchL)[ii] = jj+1;
        break;
      }
    }
  }    
  } else {
    Rf_error("Hey, aX and bX are either not real or different type, unlikely they match! \n"); 
  }
  Rf_unprotect(1);
  return(MyMatchL);
}

}
