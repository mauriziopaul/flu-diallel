/* ========================================================================== */
/*                                                                            */
/*   DiallelMatrixHelp.h                                                      */
/*   (c) 2010 Alan Lenarcic                                                   */
/*                                                                            */
/*   Functions to help understanding needs of Diallele mixed model            */
/*                                                                            */
/* ========================================================================== */
#define UpLo 'L'
#define TransWant 'N'
#ifndef RNeeds 
 #include <R.h>
 #include <Rmath.h>
 #include <Rinternals.h>
 #include <R_ext/BLAS.h>
 #include <R_ext/Lapack.h>
 #include <Rdefines.h>
 #define RNeeds 0
#endif

#define PRMATRIX 0

#define UpLo 'L'
#define TransWant 'N'

#define GetFirstInteger(x) isInteger(x) ? INTEGER(x)[0] : REAL(x)[0]

int CalculateWeightedXtXandXtY(SEXP sY, SEXP sX, SEXP sW, SEXP sfW, 
       SEXP sXtWY, SEXP sXtWX, SEXP sSumYSq);
int CalculateCholAndInverse(SEXP sQ, SEXP sOutiChol, SEXP sI);
int DrawABayesRegression(SEXP sQ, SEXP sXtY, SEXP sSigmaSq,
//  SEXP sOutiChol, SEXP sI, SEXP sGiveBeta, int iIter, SEXP sTestDraws);  
    SEXP sOutiChol, SEXP sI, SEXP sGiveBeta);    
  
void PrintRMatrix(double *Mat, int NR, int NC);
void PrintVector(int *Vec, int Len);     


int DrawABayesRegression(SEXP sXtX, SEXP sQ, SEXP sXtY, SEXP sSigmaSq,
//  SEXP sOutiChol, SEXP sI, SEXP sGiveBeta, int iIter, SEXP sTestDraws) {
    SEXP sXtResid, SEXP sMiniOutiChol, SEXP sMiniI, SEXP sGiveBeta,
    SEXP sUseBeta, SEXP sStartBeta);
int CalculateCholAndInverse(SEXP sQ, SEXP sOutiChol, SEXP sI, SEXP sUseBeta,
  SEXP sStartBeta);
