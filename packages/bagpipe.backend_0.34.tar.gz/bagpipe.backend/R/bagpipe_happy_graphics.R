

happy.get.genome.location <- function(h, markers=NULL, chr=NULL, bp=0,
        pretty       = TRUE,
        pad.bp       = ifelse(pretty, 2e7, 0),
        pad.position = ifelse(pretty, 10, 0))
{
    # calculate chromosome offsets
    all.markers <- happy.get.markers(h)
    all.chroms  <- happy.get.chromosome(h, all.markers)
    all.pos     <- happy.get.position(h, all.markers)
    all.bp      <- happy.get.bp(h, all.markers)

    chroms <- happy.list.chromosomes(h)
    last.pos <- 0
    last.bp  <- 0
    chrom2add <- data.frame(
            rownames=chroms,
            pos=rep(0, length(chroms)),
            bp=rep(0, length(chroms)))

    chrom2addpos <- list()
    chrom2addbp  <- list()

    first.marker <- happy.get.markers(h, chr=chroms[1])[1]

    chrom2addpos[[chroms[1]]] <- - happy.get.position(h, first.marker)
    chrom2addbp[[chroms[1]]]  <- - happy.get.bp(h, first.marker)

    for (i in 2:length(chroms))
    {
        first.marker <- happy.get.markers(h, chr=chroms[i])[1]

        prev.chr.length <- happy.get.chromosome.length(h, chroms[i-1],
                scale="cM",
                subtract.offset=FALSE)
        curr.offset <- happy.get.position(h, first.marker)
        chrom2addpos[[chroms[i]]]<- chrom2addpos[[chroms[i-1]]] +
                prev.chr.length - curr.offset + pad.position

        prev.chr.length <- happy.get.chromosome.length(h, chroms[i-1],
                scale="bp", subtract.offset=FALSE)
        curr.offset <- happy.get.bp(h, first.marker)
        chrom2addbp[[chroms[i]]]<- chrom2addbp[[chroms[i-1]]] +
                prev.chr.length - curr.offset + pad.bp
    }

    #

    if (!is.null(markers))
    {
        marker.chr <- happy.get.chromosome(h, markers)
        marker.pos <- happy.get.position(h, markers) + as.numeric(chrom2addpos[marker.chr])
        marker.bp  <- happy.get.bp(h, markers) + as.numeric(chrom2addbp[marker.chr])

        return (data.frame(position=marker.pos, bp=marker.bp, marker=as.character(markers)))
    }
    else if (!is.null(bp) & !is.null(chr))
    {
        chr <- as.character(chr)
        if (length(chr)!=length(bp))
        {
            if (1==length(chr) & 1 < length(bp)) chr <- rep(chr, length(bp))
            else if (1<length(chr) & 1==length(bp)) bp <- rep(bp, length(chr))
            else
            {
                stop("Incompatible bp and chr arguments: chr(",
                        paste(collapse=",", chr), "), bp(",
                        paste(collapse=",", bp), ")")
            }
        }
        return (as.numeric(chrom2addbp[chr]) + bp)
    }
}

happy.make.genome.location <- function(h,
        markers = NULL,
        chr     = NULL,
        x       = NULL,
        pretty  = TRUE,
        scale   = "cM",
        pad     = switch(scale,
                cM = ifelse(pretty, 10, 0),
                bp = ifelse(pretty, 2e7, 0),
                Mb = ifelse(pretty, 20, 0)
                )
        )
{
    # calculate chromosome offsets
    chroms        <- happy.list.chromosomes(h)
    first.markers <- happy.get.first.marker(h, chroms)
    chrom.offset  <- rep(0, length(chroms))
    chrom.offset[1] <- happy.get.location(h, first.markers[1], scale=scale)

    for (i in 2:length(chroms))
    {
        prev.chr.length <- happy.get.chromosome.length(h, chroms[i-1],
                scale=scale,
                subtract.offset=FALSE)
        offset <- happy.get.location(h, first.markers[i], scale=scale)
        cat("Chr ", i, "offset", offset, "\n")
        chrom.offset[i] <- chrom.offset[i-1] + prev.chr.length - offset + pad
    }

    chrmap = data.frame(
            chr       = I(chroms),
            offset    = chrom.offset)
    chrmap$start <- chrom.offset + happy.get.location(h, first.markers, scale=scale)
    chrmap$end   <- chrom.offset + happy.get.chromosome.length(h, chroms, scale=scale)
    chrmap$midpoint <- 0.5 * (chrmap$start + chrmap$end)

    retval <- list(chr.limits=chrmap)

    # calculate specific positions
    if (!is.null(x) & !is.null(chr))
    {
        stopifnot(length(x)==length(chr))
        x <- x + chrmap$offset[match(chr, chrmap$chr)]
        retval$x <- x
    }
    if (!is.null(markers))
    {
        marker.chr <- happy.get.chromosome(h, markers)
        i <- match(marker.chr, chrmap$chr)
        z <- happy.get.location(h, markers, scale=scale)
        z <- z + chrmap$offset[i]

        retval$marker <- markers
        retval$genome.location <- z
        retval$scale <- scale
    }
    retval
}



load.gscan <- function(files=NULL, pattern=NULL, dir="./HAPPY/BOTH/", verbose=TRUE)
{
    if (is.nullOrEmpty(files))
    {
        files <- grep(pattern, value=TRUE, list.files(dir))
        if (0==length(files))
        {
            stop("Could not find files matching pattern ", pattern,
                    " in directory ", dir, "\n")
        }
        files <- paste(sep="/", dir, files)
    }
    if (verbose) cat("Loading scan files\n", paste(files, collapse="\n"), "\n")

    retval <- list(phenotype=NULL, genome=NULL, chromosomes=list())

    for (file in files)
    {
        c.scan <- read.scan.file(file)
        c.name <- c.scan$chromosome
        retval$chromosomes[[c.name]] <- c.scan$scan.data
        if (is.null(retval$phenotype))
        {
            retval$phenotype <- c.scan$phenotype
        }
        else if (retval$phenotype!=c.scan$phenotype)
        {
            stop("Scan files must contain the same phenotype. Files:\n",
                    paste("\t",collapse="\n", files), "\nphenotypes:\n",
                    retval$phenotype, "\n", c.scan$phenotype,"\n")
        }

        retval$genome <- rbind(retval$genome, c.scan$scan.data)
    }
    retval
}


make.step.data <- function(x, y, last.x=NULL, jitter.factor=10000)
{
    d <- x[2:length(x)] - x[1:(length(x)-1)]
    tiny <- min(d, na.rm=TRUE)/jitter.factor

    new.x <- rep(NA, 2*length(x)-1)
    new.x[2*(1:length(x))-1] <- x
    new.x[2*(1:(length(x)-1))] <- x[-length(x)] + d - tiny
    new.y <- as.numeric(y %x% c(1,1))
    new.y <- new.y[-length(new.y)]

    if (!is.null(last.x))
    {
        new.x <- c(new.x, last.x)
        new.y <- c(new.y, new.y[length(new.y)])
    }

    data.frame(x=new.x, y=new.y)
}

polygonh <- function(xrange, ypos, yheight, ...)
{
    polygon( xrange[c(1,1,2,2)], c(ypos, rep(ypos+yheight,2), ypos), ...)
}

happy.plot.ladder <- function(h,
        chr.list,          # list("1"=matrix(ncol=2+,nrow=nloci, ...)
        scale,

        add               = FALSE,

        ## ladder plot
        chr.xaxis.col     = "gray50",
        chr.yaxis.cex     = 0.8,
        yspace            = diff(ylim)*0.1,

        ## individual chromosome plots
        col   = "black",
        draw.edge.support = FALSE,
        fill  = FALSE,
        lty   = 1,
        type  = "l",
        ylim  = c(0,1),
        ...)  # other arguments to happy.plot.intervals
{
    chr.names <- names(chr.list)
    longest.chr <- chr.names[which.max(
            happy.get.chromosome.length(h, chr.names, scale=scale))]

    yrange    <- diff(ylim)
    true.ylim <- c(ylim[1], ylim[1] + (yrange+yspace)*length(chr.list)-yspace)
    y.offset  <- rev(ylim[1] + ((1:length(chr.list))-1)*(yrange+yspace))

    if (!add)
    {
        happy.plot.intervals(h, chr=longest.chr, ylim=true.ylim, type="n",
                scale=scale, axis.y=FALSE, ...)
        ## annotate ylim for top chromosome only
        pretty.ylim.value <- round(ylim,0)
        pretty.ylim.pos <- pretty.ylim.value+y.offset[1]
        mtext(pretty.ylim.value, at=pretty.ylim.pos, side=2,
                col=chr.xaxis.col, las=1, line=-1, cex=chr.yaxis.cex)

        ## draw chr axes, chr names and a representative ylim
        for (ic in 1:length(chr.list))
        {
            chr <- chr.names[ic]
            chr.y.offset <- y.offset[ic]
            chr.ylim <- c(chr.y.offset, chr.y.offset+yrange)
			chr.xlim <- c(
					happy.get.interval.range(h, happy.get.first.marker(h, chr=chr), scale=scale)[1],
					happy.get.interval.range(h, happy.get.last.marker(h, chr=chr), scale=scale)[2])
			lines(chr.xlim, rep(chr.y.offset[1],2), col=chr.xaxis.col)

            #happy.plot.intervals(add=TRUE, h, chr=chr, y=chr.y.offset,
            #        draw.edge.support=FALSE, col=chr.xaxis.col, scale=scale)

            mtext(chr, side=2, at=mean(chr.ylim), las=1)
        }
    }

    for (ic in 1:length(chr.list))
    {
        chr <- chr.names[ic]
        chr.y.offset <- y.offset[ic]
        chr.ylim <- c(chr.y.offset, chr.y.offset+yrange)

        if (!force.logical(2<=ncol(chr.list[[ic]]))) next
        data <- chr.list[[ic]]
        if (0==nrow(data)) next

        ny   <- ncol(data)-1
        for (iy in 1:ny)
        {
   #         if (any(is.na(data[,iy+1]))) next
            happy.plot.intervals(add=TRUE, h, chr=chr,
                    loci = data[,1],
                    y    = data[,iy+1]+chr.y.offset,
                    ylim = chr.ylim,
                    col=ifelse(ny==length(col), col[iy], col),
                    draw.edge.support = ifelse(
                            ny==length(draw.edge.support),
                            draw.edge.support[iy],
                            draw.edge.support),
                    fill = ifelse(ny==length(fill), fill[iy], fill),
                    lty=ifelse(ny==length(lty), lty[iy], lty),
                    type=type,
                    scale = scale,
                    ...)
        }
    }
}

happy.plot.ladder.chr.list <- function(chr.names, data,
        chr.col="chr", wanted.cols="locus", constant.cols=list())
# to help with input for happy.plot.ladder()
{
    chr.list <- list()
    for (chr in chr.names)
    {
        i <- data[,chr.col]==as.character(chr)
        d <- data[i,wanted.cols]
        for (nam in names(constant.cols))
        {
            d[,nam] <- constant.cols[[nam]]
        }
        chr.list[[chr]] <- d
    }
    chr.list
}



happy.plot.intervals <- function(h,
        loci               = NULL,
        y                  = NULL,
        chr                = NULL,
        scale              = "cM",
        loci.lim           = NULL,
        ylim               = c(0,1),
        add                = FALSE,

        axes               = !add,
        axis.x             = axes,
        axis.y             = axes,
        axis.x.extend      = NULL,

        type               = "l",
        lty                = 1,
        na.edge.lty        = 2,
        fill               = NULL,
        na.edge.density    = NA,
        missing.y          = NA,
        draw.edge.support  = FALSE,

		    flag.missing.y.line = function(x,...){},

        ## pass through
        xlab = scale,
        ylab = "",
        ...)
{
  ##-----------------
  ## Check arguments
  ##-----------------
  ## Non -cM scale relies on base pairs being defined 
  if (scale!="cM")
  {
      happy.check.bp(h)
  }

  ## establish which chromosomes and loci are to be plotted
  if (!all(force.logical(chr)) & !all(force.logical(loci)))
  {
      stop("One or both of chr or loci must be completely defined in happy.plot.intervals\n")
  }
  ## establish y data
  if (is.null(y))
  {
      y <- rep(0, length(loci))
  }
  else if (1==length(y) & 1<length(loci))
  {
      y <- rep(y, length(loci))
  }
  else if (length(y) != length(loci))
  {
      stop("Length of x and y differ: ",length(loci), " loci and ",
          length(y), " y values\n") 
  }

  if (!all(force.logical(chr)))
  {
	  chr <- happy.get.chromosome(h, loci)
  }

  chr=unique(chr) # ????? Doing this here (rather than uniqing multiple times) may have hidden consequences - but not sure what they are ??
	all.chr <- happy.list.chromosomes(h)[happy.list.chromosomes(h) %in% unique(chr)]
	is.multiple.chroms <- 1<length(unique(chr))
	pad.loci <- NULL
	xlim     <- NULL
	if (!is.multiple.chroms)
	{
    ## locus range
    if (is.null(loci.lim)) {
      loci.lim <- ifow(add,
         c(loci[1], loci[length(loci)]),
         c(happy.get.first.marker(h, chr=chr), happy.get.last.marker(h, chr=chr)))
    }
    else if (2!=length(loci.lim))
    {
      stop("loci.lim must specify two markers\n")
    }
		if (0>diff(happy.get.location(h, loci.lim, scale=scale)))
		{
			loci.lim <- rev(loci.lim)
		}
    pad.loci <- happy.get.markers.between(h,
            from = loci.lim[1],
            to   = loci.lim[2])
    xmat <- as.matrix(happy.get.interval.range(h, pad.loci,scale=scale))
    xlim <- c(xmat[1,1], tail(xmat,1)[1,2])

		if (!add)
		{
      plot(xlim, ylim, type="n", axes=FALSE, xlab=xlab, ylab=ylab,
              ylim=ylim, ...)
	    if (axis.y) axis(2, las=1)
			if (axis.x)
			{
			  alim=range(axis(1))
			  if (!is.null(axis.x.extend))
			  # experimental -- unclear whether this is desireable
			  {
  			  axdiff=abs(xlim-alim)/diff(xlim)
  			  if (axdiff[1] > axis.x.extend)
  			  {
  			    #axis(1, at=xlim[1], labels="")
    			  axis(1, at=c(xlim[1],alim[1]), labels=rep("",2), tcl=0)
  			  }
  			  if (axdiff[2] > axis.x.extend)
  			  {
    			  #axis(1, at=xlim[2], labels="")
    			  axis(1, at=c(alim[2],xlim[2]), labels=rep("",2), tcl=0)
          }
        }
			}
		}		
	}
	else # multiple chromosomes
	{
		pad.loci  <- happy.get.markers(h, chr=all.chr)
		gloc.list <- happy.make.genome.location(h, markers=pad.loci, scale=scale)
		locus.begin <- gloc.list$genome.location
		locus.end   <- locus.begin +
		    happy.get.interval.length(h, pad.loci, scale=scale)
		xmat <- cbind(locus.begin, locus.end)
	  xlim <- c(xmat[1,1], tail(xmat,1)[1,2])

		if (!add)
		{
      plot(xlim, ylim, type="n", axes=FALSE, xlab=xlab, ylab=ylab,
              ylim=ylim, ...)
	    if (axis.y) axis(2, las=1)
			if (axis.x)
			{
				chr.limits <- gloc.list$chr.limits
				for (ic in 1:nrow(chr.limits))
				{
					axis(1, at=chr.limits[ic,c("start", "end")], labels=c("",""))
					axis(1, at=chr.limits$midpoint[ic], labels=chr.limits$chr[ic], lty=0)
				}
			}
		}		
  }
    
  ## pad y with NAs where necessary
  if (!is.null(loci))
  {
    pad.y <- rep(missing.y, length(pad.loci))
    pad.y[match(loci, pad.loci)] <- y
    y    <- pad.y
    loci <- pad.loci
  }

  ## fill
  if (force.logical(fill[1]))
  {
    if (length(loci) != length(fill)) {
      if (1 == length(fill)) {
    		fill <- rep(fill, length.out=length(loci))
    	} else {
        stop("Bad \"fill\" specification: cannot use ", length(fill),
            " colors to draw polygons for ", length(loci), " loci.\n")
      }
    }
    for (i in 1:length(loci))
    {
      if (is.na(y[i])) next

      if (1==i | length(loci)==i | any(is.na(y[i-1])) | is.na(y[i+1]) )
      {
        polygonh(xmat[i,1:2], ylim[1], y[i]-ylim[1], col=fill[i],
                density=na.edge.density)
      }
      else if (y[i]!=ylim[1])
      {
        polygonh(xmat[i,1:2], ylim[1], y[i]-ylim[1], col=fill[i],
                density=NA)
      }
    }
  }

  ## lines
  if ("n"!=type)
  {
  	# make sure loci and y are in order
    #	oi <- order(happy.get.location(h, loci, scale=scale))
    #	y    <- y[oi]
    #	loci <- loci[oi]

		max.coords <- 2*length(loci)+1
		from.x <- numeric(max.coords)
		from.y <- numeric(max.coords)
		to.x   <- numeric(max.coords)
		to.y   <- numeric(max.coords)
		
		k <- 1
    for (i in 1:length(loci))
    {
      if (is.na(y[i]))
 			{
				flag.missing.y.line(xmat[i,c(1,2)], locus=loci[i], ylim=ylim)
				next
			}

			# top lines
			from.x[k] <- xmat[i,1]
			from.y[k] <- y[i]
			to.x[k]   <- xmat[i,2]
			to.y[k]   <- y[i]
			k <- k+1

      ## draw left support
      if (1<i)
      {
        if (is.finite(y[i-1]) | force.logical(y[i-1]!=y[i], na=FALSE))
        {
					from.x[k] <- xmat[i,1]
					from.y[k] <- y[i-1]
					to.x[k]   <- xmat[i,1]
					to.y[k]   <- y[i]
					k <- k+1
        }
        else if (draw.edge.support)
        {
            lines(rep(xmat[i,1], 2), c(ylim[1], y[i]), type=type,
                lty=na.edge.lty, ...)
        }
      }
      ## draw right support
      if (length(loci)==i | is.na(y[i+1])) ## if at the end of the graph
      {
        if (draw.edge.support)
        {
          lines(rep(xmat[i,2], 2), c(ylim[1], y[i]), type=type,
              lty=na.edge.lty, ...)
        }
      }
    }
		segments(from.x, from.y, to.x, to.y, lty=lty, ...)
  }
  invisible()
}


