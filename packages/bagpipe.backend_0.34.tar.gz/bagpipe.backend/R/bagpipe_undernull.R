apply.permutation.matrix <- function(original.response, perm.matrix){
	responses.list <- list()
	for (i in 1:ncol(perm.matrix)){
		if (is.data.frame(original.response))	{
			responses.list[[i]] <- original.response[perm.matrix[,i],]
		}
		else{
			responses.list[[i]] <- original.response[perm.matrix[,i]]
		}
	}
	responses.list  
}


make.permuted.responses <- function(h, 
		null.formula,
		num.perms,
		data,
		seed)
{
  perm.matrix <- permutation.matrix(
            num.perms = num.perms,
            data      = data,
            seed      = seed)
	response.vars <- split.formula(null.formula)$response.vars
  original.response <- data[,response.vars]
	list(SUBJECT.NAME=data$SUBJECT.NAME, 
    apply.permutation.matrix(original.response, perm.matrix))
}

#' Simulates phenotypes under a null model using parametric bootstrapping.
#' 
#' First fits the null model, then simulates \code{num.responses} independent realizations of the phenotype. In order to accommodate ydim dimensional phenotypes (eg, survival outcomes, etc), each realization is provided as an nrow(data) by ydim data.frame.
#' 
#' @param data is assumed to be non-missing for all variables in \code{null.formula}.
#' 
#' @return A length list of \code{num.responses} data frames where each data frame contains n rows and ydim columns.
make.parboot.responses <- function(h,
		null.formula,
		num.responses,
		data,
		seed,
		model.type,
		model.args)
{
  set.seed(seed)
  response.vars <- split.formula(null.formula)$response.vars
  if (1!=length(response.vars)){
    stop("Can currently handle only univariate nullsims\n")
  }
  if (bagpipe.formula.has.abstract.loci(null.formula)) {
    bagpipe.input.error("Cannot currently perform null simulations that include THE.LOCUS\n")
  }
  fit <- unify.fit(null.formula, data=data, model.type=model.type, args=model.args)
  responses.list <- list()
  for (i in 1:num.responses){
    responses.list[[i]] <- unify.simulate(fit)
  }
  list(SUBJECT.NAME=data$SUBJECT.NAME, responses.list=responses.list)
}

make.parboot.permuted.responses <- function(h,
		null.formula,
		num.responses,
		data,
		seed,
		model.type,
		model.args)
{
  stop("Function needs update")
  perm.matrix <- make.parboot.permutation.matrix(
      null.formula,
      num.responses, 
      data=data,
      seed=seed,
      model.type=model.type,
      model.args=model.args)
	response.vars <- split.formula(null.formula)$response.vars
  original.response <- data[,response.vars]
	list(SUBJECT.NAME=data$SUBJECT.NAME, responses.list=apply.permutation.matrix(original.response, perm.matrix))
}


make.parboot.permutation.matrix <- function(
    null.formula,
    num.responses,
    data,
    seed,
    model.type,
    model.args)
{
  set.seed(seed)
  response.vars=split.formula(null.formula)$response.vars
  if (1!=length(response.vars)){
    stop("Can currently handle only univariate nullsimperms\n")
  }
  if (bagpipe.formula.has.abstract.loci(null.formula)){
    bagpipe.input.error("Cannot currently perform null simulations that include THE.LOCUS\n")
  }
  
  y=data[,response.vars]
  
  fake.response.name="FAKE.Z"
  perm.matrix=matrix(nrow=length(y), ncol=num.responses)
  for (i in 1:num.responses)
  {
    # generate new response
    r=rank(y, ties="random")
    rank2yindex=order(r)
    
    z=r # question about whether to use non-identity z <- f(r)

    # fit model to z
    data[,fake.response.name]=z
    zform=paste(fake.response.name, "~", split.formula(null.formula)$predictor.string)  
    fit=unify.fit(zform, data=data, model.type=model.type, args=model.args)
    zstar=as.numeric(unify.simulate(fit))
    
    # generate new ranks
    rstar=rank(zstar, ties="random")
    # generate implied permutation
    yistar=rank2yindex[rstar]

    perm.matrix[,i]=yistar
  }
  perm.matrix
}

#' Read a file of fake or null phenotype data that will be used to judge significance thresholds
#' 
#' @return A list with two components:
#'    SUBJECT.NAME, a vector of the subject names for which phenotype values are provided
#'    responses.list, a list of data frames, one for each realization of the fake phenotype. Each data.frame should contain all response variables (ie, one column if univariate, ydim columns if ydim-multivariate).
read.nullphenotype.file <- function(file, ref.data, num.required){
  bagpipe.proc.message("Reading null phenotype file ", file, ".")
  fake.phenotypes <- NULL
  if (igrep("\\.csv$", file)){
    null.data <- read.csv(file, stringsAsFactors=FALSE)
    if ("SUBJECT.NAME"!=colnames(null.data)[1]){
      bagpipe.input.error("In nullphenotype.file ", file, ", first column must be SUBJECT.NAME\n")
    }
    if (num.required + 1 > ncol(null.data)){
      bagpipe.input.error("In nullphenotype.file ", file, ", need at least ", num.required, " columns (excluding the SUBJECT.NAME column) but only got ", ncol(null.data)-1, ".")
    }
    # check mapped subjects are 
    si <- match(ref.data$SUBJECT.NAME, null.data$SUBJECT.NAME)
    if (any(is.na(si))){
      browser()
      bagpipe.input.error("In nullphenotype.file ", file, " phenotype values are missing for ",
        sum(is.na(si)), " members of the mapping population.")
    }
    responses.list <- list()
    for (r in 1:num.required){
      responses.list[[r]] <- as.data.frame(null.data[si, r+1])
    }
    fake.phenotypes <- list(
      SUBJECT.NAME=null.data$SUBJECT.NAME[si],
      responses.list=responses.list)
  }
  if (igrep("\\.RDS$", file)){
    fake.phenotypes <- readRDS(file)
    if (any(ref.data$SUBJECT.NAME!=fake.phenotypes$SUBJECT.NAME)){
      bagpipe.input.error("In nullphenotype.file ", file, ", subjects are mismatched.")
    }
    if (length(fake.phenotypes$responses.list) < num.required){
      bagpipe.input.error("In nullphenotype.file ", file, ", need at least ", num.required, " phenotype realizations but only got ", length(fake.phenotypes$responses.list))
    }
  }
  fake.phenotypes
}


fit.gev <- function( data, thresholds ){
  require(evd)
  model.gev <- fgev(data)
  gev.df <- data.frame(
    loc        = model.gev$estimate[1],
    loc.se     = model.gev$std.err[1],
    scale      = model.gev$estimate[2],
    scale.se   = model.gev$std.err[2],
    shape      = model.gev$estimate[3],
    shape.se   = model.gev$estimate[3]
    )
  gev.thresholds.df <- data.frame(
          upper.tail.prob=thresholds,
          quantile = qgev(thresholds,
                  loc   = gev.df$loc,
                  scale = gev.df$scale,
                  shape = gev.df$shape,
                  lower.tail=FALSE)
          )
  return (list(thresholds=gev.thresholds.df, gev=gev.df))
}

permutation.matrix <- function(num.perms,
        data,
        seed   = NULL)
# make matrix of permuted indices
{
  if (!is.null(seed)) set.seed(seed)
  if (0 >= num.perms)
  {
    stop("Cannot permute 0 or fewer times\n")
  }
  mat <- matrix(integer(0), nrow=nrow(data), ncol=num.perms )
  id  <- 1:nrow(data)
  for( p in 1:num.perms)
  {
      mat[,p] <- sample(id, replace=FALSE)
  }
  return(mat)
}
