
hasS3method <- function(f, x)
# checks whether there is an S3 method f for class or object x
{
    if(is.object(x)) x <- oldClass(x)
    !is.null(getS3method(f, x, optional=TRUE))
}

hasS4method <- function(f, x)
# checks whether there is an S4 method f for class or object x
{
    if (is.object(x)) x <- class(x)
    for (cl in x)
    {
        m <- selectMethod(f, optional=TRUE, signature=signature(object=cl))
        if (!is.null(m)) return (TRUE)
    }
    FALSE
}


unify.aic <- function(object)
{
	2 * unify.num.params(object) - 2* unify.logLik(object) 
}

# promises to return a data frame with at least the following columns
#   predictor
#   pvalue
#   logP
#   pctvar
unify.anova <- function(object, test=NULL, ...){
  retval <- NULL
  make.dummy.anova <- function(object)
  {
      predictors <- c("NULL", colnames(attr(terms(object), "factors")))
      data.frame(
              predictors = predictors,
              pvalue     = rep(NA, length(predictors)),
              logP       = rep(NA, length(predictors)),
              pctvar     = rep(NA, length(predictors)))
  }
  
  if (inherits(object, "glm"))
  {
      if (is.null(test)) test <- "Chisq"
      an <- anova(object, test=test)
      add <- data.frame(predictor=rownames(an), pvalue=an$"P(>|Chi|)")
      add$logP <- -log10(add$pvalue)
      add$pctvar <- NA
      retval <- cbind(an, add)
  }
  else if (inherits(object, "lm"))
  {
      if (is.null(test)) test  <- "F"
      pname <- switch(test, F="Pr(>F)", NA)
      if (is.na(test)) test <- NULL

      an <- anova(object, test=test)
      add <- data.frame(predictor=rownames(an), pvalue=an[,pname])
      add$logP <- -log10(add$pvalue)

      # pctvar calculation
      tss <- SS(fitted(object)+residuals(object))
      add$pctvar <- an$"Sum Sq"/tss * 100

      retval <- cbind(an, add)
  }
  else if (inherits(object, "survreg")
          | inherits(object, "coxph")
          | inherits(object, "polr")
          | inherits(object, "lmer")
          | inherits(object, "glmer")
          | inherits(object, "mer")
           )
  {
      retval <- make.dummy.anova(object)
  }
  else
  {
      stop("No unify.anova() for objects of class ",
              paste(class(object), collapse="/"), "\n")
  }
  retval
}

# promises to return a data frame with at least the following columns
#   formula
#   df.residual
#   residual.deviance
#   df
#   delta.deviance
#   test
#   pvalue
#   logP
unify.anova.list <- function(..., test=NULL)
{
  unify.anova.list.lrt <- function(x, sort=FALSE)
  {
      if (sort)
      {
          x <- x[order(x$df),]
      }

      x$delta.deviance <- c(NA, diff(-x$residual.deviance))
      x$test           <- c(NA,rep("Chisq",nrow(x)-1))
      x$pvalue  <- c(NA, pchisq(x$delta.deviance[-1], df = diff(x$df),
              lower.tail = FALSE))
      x$logP <- -log10(x$pvalue)
      x
  }

  ## main function
  objects <- list(...)
  retval <- NULL
  if (inherits(objects[[1]], "negbin"))
  {
      retval <- as.data.frame(anova(...))
      formulae <- sapply(objects,
              function(x){ formula.as.string(x$terms) }, simplify=TRUE)
      retval$formula           <- formulae
      retval$df.residual       <- retval$"Resid. df" - 1
      retval$residual.deviance <- - retval$"   2 x log-lik."
      nobs <- sapply(objects, function(x){ length(resid(x)) }, simplify=TRUE)
      retval$df                <- nobs - retval$df.residual
      retval                   <- unify.anova.list.lrt(retval)
  }
  else if (inherits(objects[[1]], "glm"))
  {
      retval <- as.data.frame(anova(...))
      formulae <- sapply(objects,
              function(x){ formula.as.string(x$terms) }, simplify=TRUE)
      retval$formula           <- formulae
      retval$df.residual       <- retval$"Resid. Df"
      retval$residual.deviance <- retval$"Resid. Dev"
      nobs <- sapply(objects, function(x){ length(resid(x)) }, simplify=TRUE)
      retval$df                <- nobs - retval$df.residual
      retval <- unify.anova.list.lrt(retval)
  }
  else if (inherits(objects[[1]], "lm"))
  {
      retval <- as.data.frame(anova(...))
      formulae <- sapply(objects,
              function(x){ formula.as.string(x$terms) }, simplify=TRUE)
      retval$formula           <- formulae
      retval$df.residual       <- retval$Res.Df
      retval$residual.deviance <- retval$RSS     # deviance == RSS, p141 V&R
      nobs <- sapply(objects, function(x){ length(resid(x)) }, simplify=TRUE)
      retval$df                <- nobs - retval$df.residual
      retval$delta.deviance    <- retval$"Sum of Sq"
      retval$test              <- "F"
      retval$pvalue            <- retval$"Pr(>F)"
      retval$logP              <- -log10(retval$pvalue)
  }
  else if (inherits(objects[[1]], "survreg"))
  {
      for (k in 1:length(objects))
      {
          obj <- objects[[k]]
          add <- data.frame(
              formula           = formula.as.string(as.formula(obj$terms)),
              residual.deviance = unify.deviance(obj),
              df.residual       = obj$df.residual,
              df                = obj$df)
          retval <- rbind(retval, add)
      }
      retval <- unify.anova.list.lrt(retval)
  }
  else if (inherits(objects[[1]], "coxph"))
  {
      for (k in 1:length(objects))
      {
          obj <- objects[[k]]
          add <- data.frame(
              formula           = formula.as.string(as.formula(obj$terms)),
              residual.deviance = unify.deviance(obj),
              df.residual       = obj$n - sum(!is.na(coef(obj))), # not quite right!
              df                = sum(!is.na(coef(obj))))         # not quite right!
          retval <- rbind(retval, add)
      }
      retval <- unify.anova.list.lrt(retval)
  }
  else if (inherits(objects[[1]], "polr"))
  {
      for (k in 1:length(objects))
      {
          obj <- objects[[k]]
          add <- data.frame(
              formula           = formula.as.string(as.formula(obj$terms)),
              residual.deviance = unify.deviance(obj),
              df.residual       = obj$df.residual,
              df                = obj$edf)
          retval <- rbind(retval, add)
      }
      retval <- unify.anova.list.lrt(retval)
  }
  else if (inherits(objects[[1]], "merMod")){
      retval <- as.data.frame(anova(...))
      formulae <- sapply(objects,
              function(x){ formula.as.string(attr(x@frame, "formula")) }, simplify=TRUE)
      retval$formula           <- formulae
      retval$df.residual       <- NA
      retval$residual.deviance <- sapply(objects, unify.deviance)
      retval$df                <- retval$Df
      retval$delta.deviance    <- retval$Chisq
      retval$test              <- "Chisq"
      retval$pvalue            <- retval$"Pr(>Chisq)"
      retval$logP              <- -log10(retval$pvalue)
  }
  else if (inherits(objects[[1]], "glmer"))
  {
      retval <- as.data.frame(anova(...))
      formulae <- sapply(objects,
              function(x){ formula.as.string(x@terms) }, simplify=TRUE)
      retval$formula           <- formulae
      retval$df.residual       <- NA
      retval$residual.deviance <- sapply(objects, unify.deviance)
      retval$df                <- retval$Df
      retval$delta.deviance    <- retval$Chisq
      retval$test              <- "Chisq"
      retval$pvalue            <- retval$"Pr(>Chisq)"
      retval$logP              <- -log10(retval$pvalue)
  }
  else if (inherits(objects[[1]], "mer"))
  {
      retval <- as.data.frame(anova(...))
      formulae <- sapply(objects,function(x){ formula.as.string(terms(x)) }, simplify=TRUE)
      retval$df.residual       <- NA
      retval$residual.deviance <- sapply(objects, unify.deviance)
      retval$df                <- retval$Df
      retval$delta.deviance    <- retval$Chisq
      retval$test              <- "Chisq"
      retval$pvalue            <- retval$Pr
      retval$logP              <- -log10(retval$pvalue)
  }
  else if (inherits(objects[[1]], "lmer"))
  {
      retval <- as.data.frame(anova(...))
      formulae <- sapply(objects,function(x){ formula.as.string(terms(x)) }, simplify=TRUE)
      retval$df.residual       <- NA
      retval$residual.deviance <- sapply(objects, unify.deviance)
      retval$df                <- retval$Df
      retval$delta.deviance    <- retval$Chisq
      retval$test              <- "Chisq"
      retval$pvalue            <- retval$Pr
      retval$logP              <- -log10(retval$pvalue)
  }
  else
  {
		warning("Unrecognized class ", class(objects[[1]]), "in unify anova list\n")
      retval <- anova(...)
  }
  rownames(retval) <- 1:nrow(retval)

  # set same vs same fit comparisons to p=1
  zeros <- which(0==retval$delta.deviance & !is.finite(retval$pvalue))
  retval$pvalue[zeros] <- 1
  retval$logP[zeros]   <- 0
  
  retval
}

unify.bic <- function(object, k=unify.num.params(object))
{
	k * log(unify.num.obs(object)) - 2* unify.logLik(object) 
}

unify.deviance <- function(object)
# promises to return the deviance, either via deviance() or
# from the log liklihood
{
	if (inherits(object, "mer"))
	{
		return (deviance(object, REML=FALSE))
	}
    else if (hasS3method("deviance", object) | hasS4method("deviance", object))
    {
        return (deviance(object))
    }
    -2*unify.logLik(object)
}

unify.logLik <- function(object){
  retval <- NULL
  if (inherits(object, "survreg") | inherits(object, "coxph")){
      retval <- object$loglik[2]
  }
	else if (inherits(object, "mer") | inherits(object, "merMod")){
		retval <- as.numeric(logLik(object, REML=FALSE))
	}
  else{
      retval <- as.numeric(logLik(object))
  }
  retval
}

unify.generic.model.type <- function(x)
{
	lookup <- unify.model.types()
	unlist(lookup)[match(x, names(lookup))]
}

unify.has.model.type <- function(x)
# returns TRUE for model types that the unify functions know about
{
    x %in% names(unify.model.types())
}


unify.is.multilevel.formula <- function(form)
# returns TRUE if formula contains lmer-style conditioning symbol "|"
{
	if (is.null(form)) return (FALSE)
	if (1<length(form))
	{
		return ( apply(as.array(form), 1, unify.is.multilevel.formula) )
	}
	
	if (!is.formula(form)) { if (is.na(form)) return (FALSE) }
	return ( 0<length(grep(pattern="\\|", formula.as.string(form))) )
}

unify.model.types <- function()
# list model types and generic names for models that the unify
# functions know about
{
    synonyms <- list(
            binary       = "binomial",
            binomial     = "binomial",
            coxph        = "coxph",
            Gamma        = "Gamma",
            gamma        = "Gamma",
            gaussian     = "gaussian",
            linear       = "gaussian",
            negative.binomial     = "negative.binomial",
            negbin                = "negative.binomial",
            ordinal      = "polr",
            overdispersed.poisson = "negative.binomial",
            poisson      = "poisson",
            polr         = "polr",
            quasipoisson = "quasipoisson",
            survival     = "survreg",
            survreg      = "survreg")
}

unify.num.obs <- function(object)
{
	ll <- logLik(object)
	as.numeric(attr(ll, "nobs"))
}

unify.num.params <- function(object)
{
	ll <- logLik(object)
	as.numeric(attr(ll, "df"))
}

# unify different model fitting procedures
unify.fit <- function(formula, data, model.type="linear", args=list())
{
  form <- as.formula(formula)

  is.multilevel <- 0<length(grep(pattern="\\|", formula.as.string(form)))

  type <- unify.model.types()[[model.type]]
  if (is.null(type)){
    stop("Cannot currently fit models of type ", model.type ,"\n")
  }

  fit <- NULL
  if (!is.multilevel) {
    args$formula <- formula
    args$data    <- quote(data)
    if ("gaussian"==type) {
        fit <- do.call("lm", args=args)
    }
    else if (type %in% c("binomial", "Gamma", "poisson", "quasipoisson")) {
        args$family <- type
        fit <- do.call("glm", args=args)
    }
    else if ("negative.binomial"==type) {
        fit <- do.call("glm.nb", args=args)
    }
    else if ("survreg"==type) {
        fit <- do.call("survreg", args=args)
    }
    else if ("coxph"==type) {
        fit <- do.call("coxph", args=args)
    }
    else if ("polr"==type) {
        fit <- do.call("polr", args=args)
    }
    else {
        stop("Cannot fit unilevel model.type ", model.type, "\n")
    }
  }
  else {
    require(lme4)
    args$formula <- formula
    args$data    <- quote(data)
    args$REML    <- FALSE # 2015-05-19
    if ("gaussian"==type) {
        fit <- do.call("lmer", args=args)
    }
    else if (type %in% c("binomial", "Gamma", "poisson", "quasipoisson")) {
        args$family <- type
        fit <- do.call("lmer", args=args)
    }
    else {
        stop("Cannot fit multilevel model.type ", model.type, "\n")
    }
  }
  fit
}

unify.simulate <- function(object, ...){
	if (inherits(object, "mer")|inherits(object, "merMod")){
		return  ( unify.simulate.lmer(object, ...) )
  }
  else if (inherits(object, "glm")){
    type <- attr(object, "family")$family
    if (type %in% c("binomial", "poisson")) {
      return (simulate(object, ...))
    }
    else {
      stop("Cannot currently simulate from ", type, " glm model\n")
    }
  }
  else if (inherits(object, "lm")){
    return (simulate(object, ...))
  }
  else{
    stop("Cannot currently simulate from model of type ",
            class(object), "\n")
  }
}

unify.simulate.lmer <- function(object, ...){
	return ( simulate(object, ...) )
	
  # IN PROGRESS!!!!
  #type <- attr(object, "family")$family
  if ("binomial"==type) {
      out <- simulate(object, ...)
#            if (!is.null(attr(object, "weights")))
#            # simulate binomial proportions
#            {
#                out <- out / attr(object, "weights")
#            }
    return (out)
  }
  if ("poisson"==type) {
      return (simulate(object, ...))
  }
  else {
      stop("Cannot currently simulate from ", type, " glmer model\n")
  }
}
