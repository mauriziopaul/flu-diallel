bagpipe.define.posboot.loci <- function(h, locus.range){
  if (2!=length(locus.range)){
    bagpipe.input.error("Must specify exactly two markers for positional bootstrap")
  }
  if (!all(happy.has.markers(h, locus.range))){
  	bagpipe.input.error("Unknown markers:",
  			paste(locus.range[!happy.has.markers(h, locus.range)],collapse=","))
  }
  if (1!=length(unique(happy.get.chromosome(h, locus.range)))){
  	bagpipe.input.error(paste(sep="",
  			"Cannot bootstrap between unlinked markers ", locus.range[1], " (chr ",
  			happy.get.chromosome(h, locus.range[1])),") and ", locus.range[2],
  			" (chr ", happy.get.chromosome(h, locus.range[2]), ")")
  }
  if (0 > diff(happy.get.location(h, locus.range, scale="cM"))){
  	bagpipe.input.error("Markers for positional bootstrap must in given in chromosome order")
  }
  happy.get.markers.between(h, from=locus.range[1], to=locus.range[2])
}

bagpipe.init.posboot.file=function(file, loci)
{
  boot.cols=c(paste(loci, ".LOD", sep=""), paste(loci, ".modelcmp", sep=""))
  if (file.exists(file))
  {
  	results <- read.delim(file)
  	format.error <- function(){bagpipe.input.error(
  			"Cannot add bootstraps to incompatible boot file ",
  			file, "; must delete or rename")}
  	if (length(boot.cols)!=ncol(results))
  	{
  		format.error()
  	}
  	if (!all(boot.cols==colnames(results)))
  	{
  		format.error()
  	}
  	return (results)
  }
  as.data.frame(matrix(nrow=0, ncol=length(boot.cols), dimnames=list(c(),boot.cols)))
} 

bagpipe.posboot.scan <- function(h, loci, num.boots, results.file,
  save.every=10,
  method="multinom"){
  
  boot.results <- bagpipe.init.posboot.file(results.file, loci)
  
  d <- get.phenotype.data(h, config=config)
  
  pdata <- d$pdata
  first.boot=nrow(boot.results)+1
  if (first.boot > num.boots){
    return (boot.results)
  }
  cat("Bootstraps ", first.boot, " to ", num.boots, ":", sep="")
  
  num.obs <- nrow(pdata)
  obs.probs <- rep(1/num.obs, num.obs)
  if (is.null(d$scan.options$weights.factor)){
    d$scan.options$weights.factor <- rep(1, num.obs)
  }
  orig.weights <- d$scan.options$weights.factor
  for (b in first.boot:num.boots){
    if ("multinom"==method){
      boot.weights <- c(rmultinom(1, size=num.obs, prob=obs.probs))
    } else if ("dirichlet"==method){
      w <- runif(num.obs)
      boot.weights <- w*length(w)/sum(w)
    }
    d$scan.options$weights.factor <- orig.weights*boot.weights
    scan.result <- scan.phenotype(h, config, markers=loci, scan.type="scan", verbose=FALSE, data.object=d)
    boot.results[b,] <- c(scan.result$table$LOD, scan.result$table$modelcmp)
    if (b-first.boot %% save.every != 0 | b==num.boots){
      write.delim(boot.results, file=results.file)
    }
    cat("[",sep="",b,"]")
  }
  cat("\n")
  boot.results
}

make.posboot.summary <- function(h, loci, boot.results){
  boot.summary=data.frame(
      locus=loci,
      chr=happy.get.chromosome(h, loci),
      cM.start=happy.get.interval.range(h, loci, scale="cM")[,1],
      cM.end=happy.get.interval.range(h, loci, scale="cM")[,2],
      Mb.start=happy.get.interval.range(h, loci, scale="Mb")[,1],
      Mb.end=happy.get.interval.range(h, loci, scale="Mb")[,2],
      times.max.LOD=rep(0, length(loci)),
      times.max.modelcmp=rep(0, length(loci)))

  lods=as.matrix(boot.results[,1:length(loci)])
  lods.max=table(apply(lods, 1, which.max))
  boot.summary$times.max.LOD[as.integer(names(lods.max))] = lods.max
  boot.summary$cumfrac.max.LOD=cumsum(boot.summary$times.max.LOD)/num.boots

  cmps=as.matrix(boot.results[,-c(1:length(loci))])
  cmps.max=table(apply(cmps, 1, which.max))
  boot.summary$times.max.modelcmp[as.integer(names(cmps.max))] = cmps.max
  boot.summary$cumfrac.max.modelcmp=cumsum(boot.summary$times.max.modelcmp)/num.boots
  boot.summary
}

make.posboot.summary.ci=function(h, boot.summary, prob=0.95, score="LOD")
{
  score.col=paste("times.max.",sep="",score)
  ci=which.wide.ci(boot.summary[,score.col], prob=prob)
  data.frame(
      score=score,
      ci=prob,
      idx.start=ci[1],
      idx.end=ci[2],
      first.marker.interval=boot.summary$locus[ci[1]],
      last.marker.interval=boot.summary$locus[ci[2]],
      marker.start=boot.summary$locus[ci[1]],
      marker.end=happy.get.next.marker(h, boot.summary$locus[ci[2]], as.intervals=FALSE, within.chr=TRUE),
      cM.start=boot.summary$cM.start[ci[1]],
      cM.end=boot.summary$cM.end[ci[2]],
      Mb.start=boot.summary$Mb.start[ci[1]],
      Mb.end=boot.summary$Mb.end[ci[2]])
}

which.wide.ci=function(counts, prob)
{
  cumfrac=cumsum(counts)/sum(counts)
  tailfrac=ifelse(cumfrac > 0.5, 1-cumfrac, cumfrac)
  tailfrac.target=(1-prob)/2
  delta=tailfrac-tailfrac.target
  
  ge0 = 0<=delta
  first.ge0=which(ge0)[1]
  lower.q=first.ge0
  if (0!=delta[first.ge0] & 1!=first.ge0)
  {
    lower.q=which(delta==delta[first.ge0-1])[1]
  }

  last.ge0=rev(which(ge0))[1]
  upper.q=last.ge0
  if (0!=delta[last.ge0] & length(counts)!=last.ge0)
  {
    upper.q=rev(which(delta==delta[last.ge0+1]))[1]
  }
  c(lower.q, upper.q)
}


 
  
  
  
