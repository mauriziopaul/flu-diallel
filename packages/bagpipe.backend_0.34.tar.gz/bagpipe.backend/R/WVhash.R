# Valdar's environment-based hashtable.

new.hash <- function()
{
	new.env(hash=TRUE)
}

hash.has <- function(hash, key)
{
	exists(as.character(key), envir=hash, inherits=FALSE)
}

hash.get <- function(hash, key)
{
	get(as.character(key), envir=hash, inherits=FALSE)
}

hash.put <- function(hash, key, value)
{
	assign(as.character(key), envir=hash, value=value)
}

hash.keys <- function(hash)
{
	ls(envir=hash)
}

hash.memory.usage <- function(hash)
{
	total <- 0
	for (k in hash.keys(hash))
	{
		total <- total + object.size(hash.get(hash, k))
	}
	total
}

hash.remove <- function(hash, key)
{
	rm(envir=hash, list=key)
}
