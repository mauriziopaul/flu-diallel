bagpipe.devel.mode <- function(){
  detach("package:bagpipe.backend")
  dirs <- file.path(c(
      ENV("$CODE/R/packages/RWVmisc/WVmisc"),
      ENV("$CODE/R/packages/RWVhash/WVhash"),
      ENV("$CODE/R/packages/Rcmdline/cmdline"),
      ENV("$CODE/R/packages/Rconfigfile/configfile"),
      ENV("$CODE/R/packages/Rread.happy/read.happy"),
      ENV("$CODE/R/packages/Rbagpipe/bagpipe"),
      ENV("$CODE/R/packages/RDiploprobReader/DiploprobReader")
      ), "R")
  files <- list.files(path=dirs, pattern="*.R$", full.names=TRUE)
  invisible(mapply(source, files))
}

apply.transform <- function(formula, data)
{
    if (!is.character(formula))
    {
        formula <- as.character(deparse(formula))
    }
    response <- sub("~.*", "", formula)
    eval(parse(text=response), env=data)
}

is.informative.predictor <- function(x)
# returns true iff there is more than one unique combination
# of values in x
{
    x <- as.data.frame(x)

    # remove missing data
    ok <- complete.cases(x)
    if ( !all(ok) )
    x <- as.data.frame(x[ok,])

    # look for heterogeneity by column
    for (i in 1:ncol(x))
    {
        if (1 < length(unique(x[,i])))
        {
            return (T)
        }
    }

    # look for heterogeneity among combinations
    return ( 1 < length(unique(x)) )
}


cols.as <- function(df, convert=list(), pattern=NULL, Class=NULL,
        character=NULL, integer=NULL, numeric=NULL, factor=NULL)
# returns input (a dataframe) with specified columns converted to
# specified data type, all other columns are returned untouched.
#
# Arguments:
#       df:  data frame input
#
#  convert:  list specifying conversion with keys being column names
#            and values being either the name of the data type,
#            eg, "integer", or a character vector specifying the order of
#            levels in a factor, eg, c("spring", "summer", "autumn", "winter")
#
#  pattern: optional pattern to match against
#
#  Class:   Class to assign to columns matching the pattern
#
# Details:
#            For every type name specified there must be a corresponding
#            as.type function, eg, integer requires there to be as.integer()
#
# Examples:
#
#   data <- cols.as(read.delim("phenotype.txt"), list(
#           SUBJECT.NAME="character",
#           Date.Month="factor",
#           Date.Season=c("summer", "autumn", "winter", "spring"))
#           )
{
    require(methods) # for as()

    if (!is.null(pattern) & !is.null(Class))
    {
        matching.cols <- grep(pattern, value=TRUE, colnames(df))
        conv <- list()
        conv[matching.cols] <- Class
        convert <- c(convert, conv)
    }
    if (!is.null(character)) convert[character] <- "character"
    if (!is.null(integer))   convert[integer]   <- "integer"
    if (!is.null(numeric))   convert[numeric]   <- "numeric"
    if (!is.null(factor))    convert[factor]    <- "factor"

    for (name in names(convert))
    {
        if (1==length(convert[[name]]))
        {
            func <- paste("as.",convert[[name]],sep="")
            df[,name] <- as(df[,name], convert[[name]])
        }
        else
        {
            df[,name] <- factor(as.character(df[,name]), levels=convert[[name]])
        }
    }
    df
}

drop.formula.vars <- function(formulae, patterns)
# removes all rhs terms that include variables matching in patterns
# eg, drop.formula.vars("y ~ alpha + beta + gamma + gamma*beta", "beta")
# would return "y~alpha + gamma"
{
  formulae <- formula.as.string(formulae)
  for (patt in patterns)
  {
    for (i in grep(patt, formulae))
    {
        form <- formulae[i]
        spf <- split.formula(form)
        terms <- spf$predictors
        unwanted <- grep(patt, terms)
        form <- paste(spf$response, sep=" ~ ",
                paste(terms[-unwanted], collapse=" + "))
        formulae[i] <- form
    }
  }
  formulae
}

is.nullOrEmpty <- function(x)
# Returns TRUE if x is null or contains no elements
# Purpose: deals with a common scenario arising in R. Statements like
#      if (is.null(x) | 0==nrow(x)) {
# won't work because all K components of a logical statement in R are
# evaluated before the statement returns a value, even though only
# the first k < K may need to be evaluated to determine the result (ie,
# in contrast to Perl).
{
    if (is.null(x))
    {
        return (TRUE)
    }
    if (0==length(x)) return (TRUE)
    if (0==prod(dim(x))) return (TRUE)
    FALSE
}

find.peaks <- function(series, span=3, ends=FALSE)
# returns indices of all peaks in a series,
# where peak is defined as a point higher than any of the span % 2
# (ie, default 1) point(s) either side
# If ends==TRUE then terminii are included
{
	if (0==span %% 2)
	{
		span <- span + 1
		warning("span should be an odd number in find.peaks(): ", span-1, ".",
				" Forcing span = ", span,"\n")
	}
    z          <- embed(series, span)
	col.radius <- span %/% 2
	mid.col    <- col.radius + 1 
    result 	   <- max.col(z) == mid.col 
    retval 	   <- which(result) + col.radius
    if (ends & 3==span)
    {
        if( series[1] > series[2] )
        {
            retval <- c(0, retval)
        }
        if (series[length(series)] > series[length(series)-1])
        {
            retval[length(retval)+1] <- length(series)
        }
    }
    retval
}

find.windowed.peaks <- function(x, y, radius, above=min(y), ...)
# returns indices of windowed peaks,
# where windowed peaks are defined as the highest peaks separated by
# more than $radius x units.
# $above specifies a y threshold below which peaks are ignored.
#
# Details: x must be ordered.
# Value: indices in x order
#
{
    d <- data.frame(x=x, y=y, index=1:length(y))
    d$peak <- FALSE
    d$windowed.peak <- FALSE
    d$peak[find.peaks(y, ...)] <- TRUE
    d$peak[d$y <= above] <- FALSE
    d <- d[order(-d$y),]

    for (i in which(d$peak))
    {
        if (d$peak[i]==FALSE) next
        d$windowed.peak[i] <- TRUE
        d$peak[abs(d$x[i] - d$x)<= radius] <- FALSE
    }
    sort(d$index[d$windowed.peak])
}


freeman.tukey <- function(x)
# Freeman-Tukey transform for Poisson count data
{
    0.5 * (sqrt(x) + sqrt(x+1))
}


reduce.dim <- function(x, sdev.cutoff=0.01,
	 	cor=FALSE, scale=TRUE, center=TRUE)
# reduces the dimensionality of a matrix by choosing
{
    x <- as.matrix(x)
    prc <- prcomp(x, cor=cor, scale=scale, center=center)
    return ( x %*% prc$rotation[,which(prc$sdev > sdev.cutoff)] )
}

