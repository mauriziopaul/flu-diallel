#----------------------------------------------
# configfile -- access methods for config files

configfile.get <- function(config, keys, default=NULL, stop.on.fail=TRUE)
{
    if (!mdlist.has(config, keys))
    {
		if ( !stop.on.fail | (missing(stop.on.fail) & !missing(default)))
		{
			return (default)
		}
        stop("Cannot find parameters ", keys, " in configfile\n")
    }
    return(mdlist.get(config, keys))
}

configfile.has <- function(config, keys)
{
	mdlist.has(config, keys)
}

configfile.integer <- function(config, keys, ...)
{
    as.integer(configfile.get(config, keys, ...))
}

configfile.integers <- function(config, key, ...)
{
    as.integer(configfile.strings(config, key, ...))
}

configfile.logical <- function(config, keys, ...)
{
    as.logical(configfile.get(config, keys, ...))
}

configfile.numeric <- function(config, keys, ...)
{
    as.numeric(configfile.get(config, keys, ...))
}

configfile.numerics <- function(config, key, ...)
{
    as.numeric(configfile.strings(config, key, ...))
}

configfile.string <- configfile.get

configfile.strings <- function(config, key, delim="[\\s,]+", ...)
{
    if (1!=length(key))
    {
        stop("Must pass only one key at a time to method\n")
    }
    string <- configfile.get(config, key, ...)
    if (is.null(string)) return (NULL)
    unlist(strsplit(string, split=delim, perl=TRUE))
}

read.configfile <- function(file)
{
    line.list <- scan(
            file=file,
            sep="\n",
            strip.white=TRUE,
            what=character(0))
    line.vect <- as.character(line.list)
    config <- list()
    for (line in line.vect)
    {
        x <- strsplit(line, split="[[:space:]]+")[[1]]
        key <- pop.front(x)
        value <- paste(x, collapse=" ")
        config <- mdlist.put(config, key, value)
    }
    return(config)
}

write.configfile <- function(config, file)
{
    string <- paste(names(config), sep="\t",
            as.character(unlist(config)), collapse="\n")

    cat(string, "\n", file=file)
}
