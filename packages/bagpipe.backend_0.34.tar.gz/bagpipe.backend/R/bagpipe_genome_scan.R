DEFAULT.REDUCE.DMAT.CUTOFF <- 0.01

as.DiploprobReader <- function(h){
  if (inherits(h, "happy.genome")){
    return (DiploprobReader$new(h))
  } else if (inherits(h, "DiploprobReader")) {
    return (h)
  } else {
    stop("as.DiploprobReader conversion failed for object of class ", paste("{", paste(collapse=",", class(h)), "}"))
  }
}

bagpipe.extract.loci <- function(h, locus.group.id){
  h <- as.DiploprobReader(h)
  loci <- NULL
	if (locus.group.id %in% h$getChromList())	{
		loci <- h$getLoci(chrom=locus.group.id)
	} else if (file.exists(locus.group.id)){
  	loci <- scan(locus.group.id, comment.char="#", blank.lines.skip=TRUE, what="character")
  	if (!all(h$hasLoci(loci))){
  		bagpipe.input.error("Input error: could not find loci ", paste(sep=",", loci[!has.loci]), "listed in file", locus.group.id, "\n")
  	}
  } else {
    bagpipe.input.error("Config field ", locus.group.id, " must correspond to either a chromosome or a filename.")   
  }
	loci
}

bagpipe.extract.subjects <- function(h, subjects.spec){
  MIN.NUM.SUBJECTS <- 10
  h <- as.DiploprobReader(h)
  if (1!=length(subjects.spec)){
    bagpipe.input.error("Not implemented yet: multiple arguments for subjects in config.")
  }

  subjects <- NULL
  if ("ALL"==subjects.spec){
    subjects <- h$getSubjects()
  } else if (file.exists(subjects.spec)){
    subjects <- scan(subjects.spec, comment.char="#", blank.lines.skip=TRUE, what="character")
    subjects <- intersect(subjects, h$getSubjects())
    if (MIN.NUM.SUBJECTS>=length(subjects)){
      bagpipe.input.error("Input error: fewer than ", MIN.NUM.SUBJECTS, " subjects specified by config file have genotype information.")
    }
  } else {
    bagpipe.input.error("Unsupported subject specifcation: ", subjects.string)
  }
  subjects
}

bagpipe.read.configfile <- function(config.file){
  config <- read.configfile(config.file)
  for (filespec in c("genome.cache.dir", "phenotype.file")){
    if (!configfile.has(config, filespec)) next
    pathname <- configfile.string(config, filespec)
    config[[filespec]] <- interpolate.Sys.env(pathname)
  }
  config
}


make.reduce.dmat.fun <- function(config.string)
# Make function to reduce the dimensionality of the design matrix
{
	if ("FALSE"==config.string)
	{
		return (NULL)
	}
	
	cutoff <- NULL
	if ("TRUE"==config.string)
	{
		cutoff <- DEFAULT.REDUCE.DMAT.CUTOFF
	} 
	else
	{
		cutoff <- try(as.numeric(config.string))
		if (caught.error(cutoff))
		{
			bagpipe.input.error("reduce.dmat option must be TRUE, FALSE or a real positive number\n")
		}
		cutoff <- abs(cutoff)
	}
	return ( function(x) { reduce.dim(x, sdev.cutoff=cutoff ) } )
}

#--------------------------------------------------------------------------
# GENERAL SCAN FUNCTIONS
#

get.phenotype.data <- function(h, config, warn = 1)
{
  MIN.DATA.SIZE <- 5
  MIN.Y.RANGE   <- 0.01
  MAX.Y.RANGE   <- 1e7

  phenotype <- configfile.string(config, "analysis.id")
  subjects  <- bagpipe.extract.subjects(h, configfile.strings(config, "subjects", default="ALL"))

  #----------------------------
  # Set up phenotype data frame

  # read phenotype
  phenoFile <- configfile.string(config, "phenotype.file")
  if (!file.exists(phenoFile)) {
    bagpipe.input.error("Could not open ", phenoFile)
  }
  data <- read.delim(phenoFile)
  cat("Reading ", phenoFile, "\n")

  # get rid of purely null strings
  data[ data=="" ] <- NA

  # filter and sort to match happy subjects
  if (is.null(data$SUBJECT.NAME)) {
      bagpipe.input.error("Phenotype file must have column SUBJECT.NAME\n")
  }
  data <- data[match(subjects, data$SUBJECT.NAME),]

  # apply subsetting
  if (configfile.has(config, "data.subset")) {
    s <- configfile.get(config, "data.subset")
    i <- try(eval(parse(text=s), env=data))
    if (caught.error(i)) {
      bagpipe.input.error("Could not process data.subset argument:", i)
    }
    i <- force.logical(i, na=FALSE)
    if (MIN.DATA.SIZE > sum(i)){
        bagpipe.data.error("Data subset ", s, " contains only ",
                sum(i), " data points!\n")
    }
    data <- data[i,]
  }

  # formulae
  model.formulae <- list(
      scan.formula.null   = configfile.string(config, "scan.formula.null"),
      scan.formula.test   = configfile.string(config, "scan.formula.test"),
      nullsim.formula 	  = configfile.string(config, "nullsim.formula", 
          default=configfile.string(config, "scan.formula.null")),
		  rma.formula     	  = configfile.string(config, "rma.formula",
			default = configfile.string(config, "scan.formula.null"))
		)
	present.formulae <- which(!is.na(unlist(model.formulae)))

	# simplify 1D responses by transformation
	for (i in 1:length(model.formulae)) {
		if (is.na(model.formulae[[i]])) next
		
		spf <- split.formula(model.formulae[[i]])
		if (1!=length(spf$response)) next
		if (spf$response==spf$response.vars) next
		
		new.response.name <- paste("transformed.",sep="", make.names(spf$response))
		model.formulae[[i]] <- paste(new.response.name, sep=" ~ ", spf$predictor.string)
		if (new.response.name %in% colnames(data)) next
		
		data[,new.response.name] = apply.transform(spf$response, data)
    
    # Check range of data is within sensible limits
    y.range=diff(range(apply.transform(model.formulae[[i]], data=data), na.rm=TRUE))
    if (y.range < MIN.Y.RANGE || y.range > MAX.Y.RANGE) {
      bagpipe.input.error("Phenotype has bad range. Difference between mininum and maximum of (transformed) phenotype value must be with the range [", MIN.Y.RANGE, ", ", MAX.Y.RANGE, "], otherwise model fitting procedures can be unstable.")
    }
	}

	# model functions
	model.functions <- list(
			scan.function = unify.generic.model.type(configfile.string(
					config, "scan.function")),
			nullsim.function = unify.generic.model.type(configfile.string(
					config, "nullsim.function",
					default=configfile.string(config, "scan.function"))),
			rma.function = unify.generic.model.type(configfile.string(
					config, "rma.function",
					default=configfile.string(config, "scan.function")))
			)
		
	# survival data : TODO!!!
	if (any("survival" %in% unlist(model.functions)))
	{
		bagpipe.input.error("Cannot currently handle survival data\n")
	    # clean up survival data
	    if ("survival"==configfile.string(config, "scan.function"))
	    {
	        y <- apply.transform(split.formula(subformula)$response, data)
	        if ((nzero <- sum(y[,1] <= 0, na.rm=TRUE))>0)
	        {
	            browser()
	            stop("Time to event data must have all times > 0\n")
	        }
	    }
	}

	# define some quick closures to help parse model options
	quick.configfile.function.options <- function(key)
	{
		if (!configfile.has(config, key))
		{
			return (list(dmat=NULL, others=list()))
		}		
		arg.list <- eval(parse(text=paste("list(",
				configfile.string(config,key),")")) )
				#,
				#env=pdata)
		dmat <- NULL
		if (list.has(arg.list, "reduce.dmat"))
		{
			dmat <- make.reduce.dmat.fun(arg.list$reduce.dmat)
			arg.list$reduce.dmat <- NULL
		}		
		return (list(dmat=dmat, others=arg.list))
	}
	quick.get.dmat <- function(x){quick.configfile.function.options(x)$dmat}
	quick.get.args <- function(x){quick.configfile.function.options(x)$others}

  # incorporate any locus information
	if (!is.null(h))
  {	
    expanded <- bagpipe.expand.formula(
        h,
        formulae  = unlist(model.formulae)[present.formulae],
        subjects  = data$SUBJECT.NAME,
        dmat.transform.FUN = quick.get.dmat("scan.function.options"))
  	for (i in 1:length(present.formulae))
  	{
  		model.formulae[[present.formulae[i]]] <- expanded$formulae[i]
  	}
  	if (!is.null(expanded$locus.data))
  	{
  		data <- cbind(data, expanded$locus.data)
  	}
  }

  # subject weights
  weights.formula = configfile.get(config, "subject.weighting", default="~1")

	# collate model options
	scan.options <- list(
			null.formula   = model.formulae$scan.formula.null,
			test.formula   = model.formulae$scan.formula.test,
			fitting.family = model.functions$scan.function,
			fitting.args   = quick.get.args("scan.function.options"),
			reduce.dmat    = quick.get.dmat("scan.function.options"),
			weights.formula = weights.formula
			)
	nullsim.options <- list(
			null.formula     = model.formulae$nullsim.formula,
			fitting.family   = model.functions$nullsim.function,
			fitting.args     = quick.get.args("nullsim.model.function.options"),
			reduce.dmat      = quick.get.dmat("nullsim.model.function.options"),
			weights.formula = weights.formula
			)
	rma.options <- list(
			null.formula     = model.formulae$rma.formula.null,
			fitting.family   = model.functions$rma.model.function,
			fitting.args     = quick.get.args("rma.function.options"),
			reduce.dmat      = quick.get.dmat("rma.function.options"),
			weights.formula = weights.formula
			)		

  # prepare sub-data frame pdata with all covariates and responses
	all.responses <- unique(unlist(
			lapply( model.formulae,
					function(x){split.formula(unlist(x))$response.vars})
			))
	all.covariates <- unique(unlist(
			lapply( c(model.formulae, weights.formula),
					function(x){split.formula(unlist(x))$predictor.vars})
			))
	all.covariates <- setdiff(all.covariates,
	    bagpipe.formula.reserved.variables(h))

  all.cols  <- c( "SUBJECT.NAME", unique(c(all.covariates, all.responses)))
  if (!all(all.cols %in% colnames(data)))
  {
      bagpipe.input.error("Variables in model formulae for ", phenotype,
              " are missing from ", phenoFile, ": ",
              paste(setdiff(all.cols, colnames(data)), collapse=", "),
              "\n")
  }
  pdata <- data[,c("SUBJECT.NAME", all.responses, all.covariates)]
  pdata <- pdata[complete.cases(pdata),]
  if (0==nrow(pdata))
  {
      bagpipe.data.error("There are no complete cases for phenotype ",
              phenotype)
  }

	# compile return value
  retval <- list(
      file                  = phenoFile,
      all.data              = data,
      pdata                 = pdata,
      scan.options          = scan.options,	
      nullsim.options 	    = nullsim.options,
      rma.options     	    = rma.options,
      phenotype             = phenotype,
      response.names        = all.responses,
      covariates            = all.covariates
      )
  retval
}

general.scan <- function(h,
    null.formula,
    test.formula,
    markers,
    data,
    model.type,
    weights.formula,
    weights.factor = NULL,
    model.args  = list(),
    verbose     = TRUE,
    reduce.dmat = NULL,
    save.at.loci= NULL)
{
    if (bagpipe.formula.has.abstract.loci(null.formula)){
    # using constant null model works only if null model does not
    # contain THE.LOCUS
        constant.null.model = FALSE
    }

	  # set up data frame to hold the the results
    num.loci <- length(markers)
    results  <- data.frame(
        locus           = I(markers),
        chr             = happy.get.chromosome(h, markers),
        cM              = happy.get.location(h, markers, scale="cM"),
        bp				      = happy.get.location(h, markers, scale="bp"),
        num.obs         = rep(nrow(data), num.loci),
        null.logLik     = rep(NA, num.loci),
        null.num.params = rep(NA, num.loci),
        test.logLik		  = rep(NA, num.loci),
        test.num.params = rep(NA, num.loci),
        LOD				      = rep(NA, num.loci),
        modelcmp     	  = rep(NA, num.loci),
        comments        = rep(NA, num.loci)
			)

 	if (verbose) {cat("general.scan() of", num.loci, "markers:")}
 
  for( i in 1:num.loci){
    locus <- markers[i]
    if (verbose) {cat("[",i,"]",sep="")}

    #------------------------------------------------
    # expand formulae and extract locus specific data
    #------------------------------------------------
    expanded <- bagpipe.expand.formula(h,
            formulae      = c(null.formula,test.formula, weights.formula),
            THE.LOCUS     = locus,
            subjects    	= data$SUBJECT.NAME,
            dmat.transform.FUN = reduce.dmat)

    gdata <- cbind(data, expanded$locus.data)

    # interpret weights
    # TODO: weights should be in the definition of the PCs in expand.formula
    weights <- ifow(
      is.null(split.formula(weights.formula)$predictors),
      rep(1,nrow(gdata)),
      eval(parse(text=split.formula(expanded$formulae[3])$predictor.string), env=gdata))
    if (!is.null(weights.factor)){
      if (1==length(weights.factor) | length(weights)==length(weights.factor)){
        weights <- weights * weights.factor
      } else {
        stop("Incorrectly specified weights.factor:", weights.factor, "\n")
      }
    }
    # remove zero weight obs, because fitting functions can't handle this
    nonzero.weight.obs <- 0 < weights # could add a tolerance
    gdata <- gdata[nonzero.weight.obs, ]
    weights <- weights[nonzero.weight.obs]
    results$num.obs[i] = sum(weights)
    args=c(model.args, list(weights=weights))

    #---------------
    # fit models
    #---------------
		# ensure false convergences result in NA values
		oldwarn <- options("warn")
		options(warn=2)
		fit0 <- try(unify.fit(
                as.formula(expanded$formulae[1]),
                data       = gdata,
                model.type = model.type,
                args       = args))
		options(oldwarn)
		if (caught.error(fit0))
		{
			warning(paste("Warning: could not fit null model for ",locus),"\n")
			next
		}
		results$null.logLik[i] <- unify.logLik(fit0)
		results$null.num.params[i] <- unify.num.params(fit0)

		options(warn=2)
		fit1 <- try(unify.fit(
                as.formula(expanded$formulae[2]),
                data       = gdata,
                model.type = model.type,
                args       = args))
		options(oldwarn)
		if (caught.error(fit1))
		{
			warning(paste("Warning: could not fit alternative model for ",locus),"\n")
			next
		}
		
		results$test.logLik[i] <- unify.logLik(fit1)
		results$test.num.params[i] <- unify.num.params(fit1)

		options(oldwarn)
		#------------------------
		# save fits, if requested
		#------------------------
		if (!is.null(save.at.loci))
		{
		  if (locus %in% names(save.at.loci))
		  {
		    save(fit0, fit1, file=save.at.loci[[locus,exact=TRUE]])
		  }
		}
		    
    #---------------------
    # inference for models
    #---------------------

		results$LOD[i] <- (results$test.logLik[i] - results$null.logLik[i])/log(10)

    an <- unify.anova.list(fit0, fit1)
		if (!is.finite(an$logP[2]))
		{
		  an$logP[2] <- NA  # Inf is typically a mistake
		}
    results$modelcmp[i] <- an$logP[2]
	}
	if (verbose){cat("Done\n")}

  return(list(
      null.formula = null.formula,
			test.formulae = test.formula,
      table      = results,
      model      = model.type,
      anova      = NA,
			modelcmp.type = "logP"
            ))
}

Bagpipe.ReadScanFile <- function(file, update.bp=FALSE, dr=NULL){
  # gives scan file in a list
  text <- readLines(file)

  # read scan data
  start <- grep("^BEGIN_SCAN_DATA", text) + 1
  end   <- grep("^END_SCAN_DATA", text) - 1
  if (length(start)!=1 | length(end)!=1){
      stop("Cannot read scan file", file, "\n")
  }
  textCon <- textConnection(text[start:end])
  scan.data <- cols.as(read.delim(textCon),
          list(locus="character", chr="character"))
  close(textCon)
  if (update.bp){ # update bp info
    stopifnot(!is.null(dr) & inherits(dr, "DiploprobReader"))
    scan.data$bp <- dr$getMarkerLocation(scan.data$locus, scale="bp")
  }
  out <- list(scan.data=scan.data)

  # read anova data
  start <- grep("^BEGIN_ANOVA", text) + 1
  end   <- grep("^END_ANOVA", text) - 1
  if ((length(start)==1 | length(end)==1) & force.logical(end - start)){
      textCon <- textConnection(text[start:end])
      out$anova <- try(read.delim(textCon))
      close(textCon)
  }
  
  # get other stuff
  wanted <- c("phenotype", "build", "chromosome", "formula")
  for (w in wanted){
      pattern <- paste("^", toupper(w), sep="")
      out[[w]] <- string.trim(
              sub(pattern,"",grep(pattern, text, value=T)))
  }
  out
}  

read.scan.file <- function(file){
  Bagpipe.ReadScanFile(file)
}

scan.phenotype <- function(h,
    config,
    markers,
    scan.type,
    cpus        = 1,
    verbose     = FALSE,
		seed        = 1,
		data.object = NULL,
		save.at.loci= NULL)
{
  pheno <- configfile.string(config, "analysis.id")

  #---------------------------------
  # Get phenotype and covariate data
  #---------------------------------
  if (is.null(data.object)){
    d <- get.phenotype.data(h, config=config)
  } else {
    d <- data.object
  }
  
  #------
  # Scans
  #------
  result <- NULL
  if ("scan"==scan.type) {
    result <- general.scan(h,
        data               = d$pdata,
        markers            = markers,
        null.formula       = d$scan.options$null.formula,
        test.formula       = d$scan.options$test.formula,
        reduce.dmat        = d$scan.options$reduce.dmat,
        model.type         = d$scan.options$fitting.family,
        model.args         = d$scan.options$fitting.args,
        weights.formula    = d$scan.options$weights.formula,
        weights.factor     = d$scan.options$weights.factor,
        save.at.loci       = save.at.loci,
        verbose            = verbose)
	}
	else if (scan.type %in%
	  c("permute.scan", "nullsim.scan", "nullsimpermute.scan", "nullfile.scan"))	{
		num.nullscans <- configfile.integer(config, "num.nullscans")
		nullscan.seed <- configfile.integer(config, "nullscan.seed")
		
		fake.responses <- NULL
		if ("permute.scan"==scan.type){
		  if (!is.null(split.formula(d$scan.options$null.formula)$predictors)){
		    stop("Permutation with covariates is currently unavailable\n")
		  }
		    
		  fake.responses <- make.permuted.responses(h, 
    			null.formula=d$scan.options$null.formula,
    			num.perms=num.nullscans,
    			data=d$pdata,
    			seed=nullscan.seed)
		}
		else if ("nullsim.scan"==scan.type){
			fake.responses <- make.parboot.responses(h,
  				null.formula=d$nullsim.options$null.formula,
  				num.responses=num.nullscans,
  				data=d$pdata,
  				seed=nullscan.seed,
  				model.type=d$nullsim.options$fitting.family,
  				model.args=d$nullsim.options$fitting.args)
		}
		else if ("nullsimpermute.scan"==scan.type){
			fake.responses <- make.parboot.permuted.responses(h, 
  				null.formula=d$nullsim.options$null.formula,
  				num.responses=num.nullscans,
  				data=d$pdata,
  				seed=nullscan.seed,
  				model.type=d$scan.options$fitting.family,
  				model.args=d$scan.options$fitting.args)
		}
    else if ("nullfile.scan"==scan.type){
      null.file <- configfile.string(config, "nullscan.phenotype.file")
      fake.responses <- read.nullphenotype.file(null.file, ref.data=d$pdata, num.required=num.nullscans)
    }
    # univariate only:
    #  nullphen.data <-  cbind(d$pdata$SUBJECT.NAME, as.data.frame(sapply(fake.responses, function(d){d[,1]})))
    #  colnames(nullphen.data)[1] <- "SUBJECT.NAME"
    #  write.csv(file="nullphenotype.csv", nullphen.data, row.names=FALSE)
    saveRDS(fake.responses, file=paste0(pheno, ".", scan.type, ".", "nullphenotypes.RDS"))

		if ("gaussian"==d$scan.options$fitting.family
			& !unify.is.multilevel.formula(d$scan.options$null.formula)
			& !unify.is.multilevel.formula(d$scan.options$test.formula)){
			fake.response.matrix <- sapply(fake.responses$responses.list, function(x) as.matrix(x))
			result <- lm.multiscan(h,
	        response.matrix    = fake.response.matrix,
          data               = d$pdata,
          markers            = markers,
          null.formula       = d$scan.options$null.formula,
          test.formula       = d$scan.options$test.formula,
          scan.function.args = d$scan.options$fitting.args,
          weights.formula    = d$scan.options$weights.formula,
	        verbose = TRUE )
		}
		else{
			result <- general.multiscan(h,
	        responses	         = fake.responses$responses.list,
          data               = d$pdata,
          markers            = markers,
          null.formula       = d$scan.options$null.formula,
          test.formula       = d$scan.options$test.formula,
          scan.function.args = d$scan.options$fitting.args,
          reduce.dmat        = d$scan.options$reduce.dmat,
          model.type         = d$scan.options$fitting.family,
          model.args         = d$scan.options$fitting.args,
          weights.formula    = d$scan.options$weights.formula,
          cpus               = cpus,
	        verbose = TRUE )
		}
	}
  result
}

write.multiscan.max <- function(results, file){
  # record max information
  best.LOD  <- apply(results$scores.LOD, 2, max, na.rm=TRUE)
  best.modelcmp <- apply(results$scores.modelcmp, 2, max, na.rm=TRUE)

  out.data <- data.frame(
		scan.number	   	= results$response.number,
		best.LOD		= best.LOD,
		best.modelcmp		= best.modelcmp)
	write.delim(out.data, file=file)
}

write.scan <- function ( scan, filename){
  file <- file(filename, open="wt")
  scan$table$modelcmp.type <- scan$modelcmp.type

  cat(file=file, "SCAN_RESULTS ", scan$date , "\n" )
  cat(file=file, "PHENOTYPE ", scan$phenotype, "\n")
  cat(file=file, "POPULATION ", scan$population, "\n")
  cat(file=file, "BUILD ", scan$build, "\n")
  cat(file=file, "CHROMOSOME ", scan$chromosome, "\n")
  cat(file=file, "NULL.FORMULA ", scan$null.formula, "\n")
  cat(file=file, "TEST.FORMULA ", scan$test.formula, "\n")
  cat(file=file, "PHASE ", scan$phase, "\n" )
  cat(file=file, "BEGIN_SCAN_DATA\n")
  write.delim(file=file, scan$table )
  cat(file=file, "END_SCAN_DATA\n")
  close(file)
}

do.scan <- function(
		h,
    config,
    cpus=1,
		loci,
		output.dir = "./",
		output.file = NULL,
		phenotype,
	 	scan.type,
		verbose=FALSE,
		save.at.loci=NULL)
{
	phenotype <- configfile.get(config, "analysis.id")
  #--------------------
  # Set up output files
  #--------------------
  
  if (!is.null(output.file)){
    output.file <- file.path(output.dir, output.file)
    if (!file.exists(output.dir)){
        stop("Directory", output.dir, "does not exist\n")
    }
  }
  
  result <- scan.phenotype(h,
    config    = config,
    markers   = loci,
    scan.type = scan.type,
    verbose   = verbose,
    cpus      = cpus,
    save.at.loci=save.at.loci)
  
  if (is.null(result)){
      stop("No results for analysis id ", phenotype, "\n")
      next
  }
  #--------------------
  # Write results files
  #--------------------
  if (!is.null(output.file)){
    if ("scan"==scan.type){
        result$phenotype          <- phenotype
        result$date               <- date()
        result$chromosome         <- paste(sep=",", unique(happy.get.chromosome(h, loci)))
        result$build              <- configfile.string(config, "build",
                stop.on.fail=FALSE, default="UnknownBuild")
        result$population         <- configfile.string(config, "population",
                stop.on.fail=FALSE, default="UnknownPopulation")
        result$phase              <- configfile.string(config, "phase",
                stop.on.fail=FALSE, default="UnknownPhase")
        result$genetic.model      <- "happy"
  
        write.scan(result, output.file)
    }
    if (scan.type %in% c("permute.scan", "nullsim.scan", "nullsimpermute.scan", "nullfile.scan")) {
        write.multiscan.max( result, file=output.file )
    }
  }
  invisible(result)
}


general.multiscan <- function(h,
		responses.list,
    data,
    markers,
    null.formula,
    test.formula,
    scan.function.args,
    reduce.dmat,
    model.type,
    model.args,
    weights.formula,
    cpus=1,
		verbose = TRUE )
{
	num.loci        <- length(markers)
	num.responses   <- length(responses.list)
	response.names  <- split.formula(null.formula)$response.vars
	if (verbose) cat("scanning multiple phenotypes: ")

  per.scan=function(s)
  {
    cat("\n[starting scan ",sep="",s,"/",num.responses,"]\n")
    responses.list[[s]]
    sim.data <- data
    sim.data[, response.names ] <- responses.list[[s]]

    result.list <- general.scan(h,
            null.formula = null.formula,
						test.formula = test.formula,
            markers    = markers,
            data       = sim.data,
            model.type = model.type,
            model.args = model.args,
            weights.formula = weights.formula,
            verbose    = verbose,
            reduce.dmat = reduce.dmat)
    result <- result.list$table

    list(
      LOD=result$LOD,
      modelcmp=result$modelcmp,
      modelcmp.type=result.list$modelcmp.type
    )
  }

  results=NULL
  if (cpus>1)
  {
    require(multicore)
    results = mclapply(1:num.responses, per.scan)
  }
  else
  {
    results = lapply(1:num.responses, per.scan)
  }
  scores.LOD = sapply(results, function(x){x$LOD})
  scores.modelcmp = sapply(results, function(x){x$modelcmp})
	if (verbose) cat("\n")
	
	list(
			modelcmp.type = results[[1]]$modelcmp.type,  # inelegant.
			response.number = 1:num.responses,
			scores.modelcmp=scores.modelcmp,
			scores.LOD=scores.LOD)
}

lm.multiscan <- function(h,
		response.matrix,
    markers,
    null.formula,
    test.formula,
    weights.formula,
    data,
    scan.function.args=list(),
    verbose=TRUE)
{
  if (bagpipe.formula.has.abstract.loci(null.formula)) {
    stop("Currently cannot do permutation with abstract loci in the null model\n")
  }
	num.loci        <- length(markers)
	num.responses   <- ncol(response.matrix)
  scores.LOD      <- matrix(nrow=num.loci, ncol=num.responses)
  scores.modelcmp <- matrix(nrow=num.loci, ncol=num.responses)
	if (verbose) cat("scanning multiple phenotypes for marker ")
  for(m in 1:num.loci){
    if (verbose) cat("[", m, "]", sep="")
    marker <- markers[m]
    expanded <- bagpipe.expand.formula(h,
            formulae        = c(null.formula, test.formula, weights.formula),
            subjects    	  = data$SUBJECT.NAME,
            THE.LOCUS       = marker)
    gdata = cbind(data, expanded$locus.data)
    
    # interpret weights        
    weights = ifow(
        is.null(split.formula(weights.formula)$predictors),
        rep(1,nrow(gdata)),
        eval(parse(text=split.formula(expanded$formulae[3])$predictor.string),
            env=gdata))
            
    marker.results <- lm.multiresponse(
            formula         = expanded$formulae[2],
            response.matrix = response.matrix,
            data            = gdata,
            null.formula    = expanded$formulae[1],
            logP	          = TRUE,
		        LOD				      = TRUE,
		        weights         = weights,
            model.args      = scan.function.args)

    if (is.null(marker.results)) next

    scores.modelcmp[m,] <- marker.results$logP
	  scores.LOD[m,]  <- marker.results$LOD
  }
	if (verbose) cat("\n")

	list(	modelcmp.type = "logP",
			response.number=1:num.responses,
			scores.modelcmp=scores.modelcmp,
			scores.LOD=scores.LOD)
}

